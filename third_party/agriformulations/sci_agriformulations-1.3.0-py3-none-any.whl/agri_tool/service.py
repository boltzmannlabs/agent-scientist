"""One JSON request boundary around deterministic agricultural operations."""
from copy import deepcopy
import hashlib
import importlib
import json
from pathlib import Path
import signal
import tempfile
import threading

from agriformulations.rnd import control
from agriformulations.rnd.common import clean
from agriformulations.rnd.workspace import RevisionConflict
from . import catalogue, projects
from .errors import NeedsInput
from .storage import Store

MODULES = {"catalogue": "catalogue", "recipes": "recipe_actions", "simulate": "simulation_actions", "design": "design_actions",
    "data": "data_actions", "cost": "cost_actions", "research": "research_actions", "project": "projects", "legacy": "legacy"}
DEFAULTS = {"catalogue": "operations", "recipes": "create", "simulate": "run", "design": "", "data": "list", "cost": "estimate", "research": "search", "project": "get", "legacy": "catalogue"}
ROOT = Path(__file__).resolve().parent
from agriformulations._paths import resource_root
ENGINE_ROOT = resource_root()


def manifest():
    files = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(ROOT.glob("*.py"))}
    import agriformulations
    engine_code = Path(agriformulations.__file__).parent
    engine_files = {str(path.relative_to(engine_code)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(engine_code.rglob("*.py"))}
    return {"tool_version": "1.1.0", "sources_sha256": files, "engine_sources_sha256": engine_files, "scientific_engine": control.engine_manifest()}


class Context:
    def __init__(self, store, request, request_id, resumed=None):
        self.store = store
        self.root = store.root
        self.engine = ENGINE_ROOT
        self.request = request
        self.request_id = request_id
        self.resumed = resumed is not None
        self.recovered_destination = bool(resumed and resumed.get("project_id") and resumed["project_id"] != request.get("project_id"))
        self.project_id = (resumed or {}).get("project_id") or request.get("project_id")
        self.revision = 0
        self.artifacts = []
        self.strict_revision = False
        self.initial = {}
        if self.project_id:
            record = store.load(self.project_id)
            self.state = record["document"]
            self.revision = record["revision"]
            self.initial = deepcopy(self.state)
        else:
            self.state = projects.empty("New formulation project")
        self.saved_digest = self.digest(self.state) if self.project_id else None
        if resumed:
            from agriformulations.rnd.run_persistence import merge
            self.state = merge(self.state, resumed.get("initial_state", {}), resumed.get("state", {})) if self.project_id else resumed.get("state", self.state)
        with self.store.connect() as db:
            db.execute("UPDATE requests SET initial_state=COALESCE(initial_state,?) WHERE request_id=?", (json.dumps(self.initial, allow_nan=False), request_id))

    @staticmethod
    def digest(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()

    def require_project(self):
        if not self.project_id:
            raise NeedsInput("Choose or create an agricultural project first", [{"id": "project_id", "question": "Which saved agricultural project should be used? Create a project if this is a new request.", "required": True}])

    def artifact(self, path, media_type="application/octet-stream", name=None):
        result = self.store.artifact(path, media_type, name)
        if not any(a["artifact_id"] == result["artifact_id"] for a in self.artifacts):
            self.artifacts.append(result)
        return result

    def save(self):
        digest = self.digest(self.state)
        if digest == self.saved_digest:
            return
        result = (self.store.create_for_request(self.state, self.request_id) if not self.project_id else
            self.store.save(self.state, self.project_id, self.revision) if self.strict_revision else
            self.store.commit_run(self.state, self.project_id, self.revision, initial=self.initial))
        self.project_id, self.revision = result["project_id"], result["revision"]
        # A concurrent merge is authoritative; do not replace it with this worker's stale snapshot.
        if result.get("merged_concurrent_outputs"):
            self.state = self.store.load(self.project_id)["document"]
        self.initial = deepcopy(self.state)
        self.saved_digest = self.digest(self.state)
        with self.store.connect() as db:
            db.execute("UPDATE requests SET project_id=? WHERE request_id=?", (self.project_id, self.request_id))

    def checkpoint(self, state, message):
        from .design_actions import remove_old_model_labels
        remove_old_model_labels(state)
        self.state = state
        self.store.checkpoint(self.request_id, state, message)
        if self.project_id or state.get("recipes"):
            self.save()


def validate(request):
    if not isinstance(request, dict) or set(request) - {"schema_version", "operation", "action", "model", "project_id", "request_id", "payload"}:
        raise ValueError("Request must be an object with operation, action, model, project_id, request_id and payload only")
    if request.get("schema_version", "1.0") != "1.0":
        raise ValueError("Unsupported request schema_version")
    op = request.get("operation")
    if not isinstance(op, str) or op not in MODULES:
        raise ValueError("Choose operation: " + ", ".join(MODULES))
    result = deepcopy(request)
    result["action"] = result.get("action") or DEFAULTS[op]
    if not isinstance(result["action"], str) or result["action"] not in catalogue.OPERATIONS[op]["actions"] + ([""] if op == "design" else []):
        raise ValueError("Unknown action for " + op + ". Allowed actions: " + ", ".join(catalogue.OPERATIONS[op]["actions"]))
    if result.get("model") and (not isinstance(result["model"], str) or op not in ("catalogue", "simulate")):
        raise ValueError("Top-level model is supported for catalogue or simulate only")
    if not isinstance(result.get("payload", {}), dict):
        raise ValueError("payload must be an object")
    result.setdefault("payload", {})
    for field in ("project_id", "request_id"):
        if not result.get(field):
            result.pop(field, None)
        elif not isinstance(result[field], str):
            raise ValueError(field + " must be text")
    return result


def envelope(request):
    return {"schema_version": "1.0", "status": "completed", "operation": request.get("operation"), "action": request.get("action"),
        "project_id": request.get("project_id"), "request_id": request.get("request_id"), "result": {}, "questions": [], "warnings": [], "artifacts": []}


def request_digest(request):
    identity = {k: v for k, v in validate(request).items() if k != "request_id"}
    identity["engine"] = control.engine_version()
    source_manifest = manifest()
    identity["tool_sources"] = source_manifest["sources_sha256"]
    identity["engine_sources"] = source_manifest["engine_sources_sha256"]
    return hashlib.sha256(json.dumps(identity, sort_keys=True, allow_nan=False).encode()).hexdigest()


def execute(request, workspace):
    response = envelope(request if isinstance(request, dict) else {})
    context = None
    store = None
    rid = None
    stop = threading.Event()
    monitor = None
    previous_signals = {}
    try:
        request = validate(request)
        response.update(operation=request["operation"], action=request["action"])
        store = Store(workspace)
        # Engine/source changes require a new explicit request identity, never silently reuse old computations.
        digest = request_digest(request)
        rid, prior, resumed = store.reserve(request, digest)
        response["request_id"] = rid
        if prior is not None:
            result = {**response, **prior, "request_id": rid, "reused_request": True}
            return result
        context = Context(store, request, rid, resumed)
        payload = deepcopy(request["payload"])
        expected = payload.pop("expected_revision", None)
        if expected is not None and (isinstance(expected, bool) or (not resumed and expected != context.revision)):
            raise RevisionConflict("Project changed; reload before applying this edit")
        context.strict_revision = (expected is not None and not resumed) or (request["operation"], request["action"]) in {
            ("project", "rename"), ("recipes", "select"), ("recipes", "library_load"), ("data", "review")}
        token = control.RunControl(checkpoint=context.checkpoint, event=lambda event: store.event(rid, clean(event)), resume_state=(resumed or {}).get("state"))

        def watch():
            while not stop.wait(.2):
                if store.cancelled(rid):
                    token.cancel()
                    return
        monitor = threading.Thread(target=watch, daemon=True, name="agri-cancellation")
        monitor.start()
        if threading.current_thread() is threading.main_thread():
            for sig in (signal.SIGINT, signal.SIGTERM):
                previous_signals[sig] = signal.getsignal(sig)
                signal.signal(sig, lambda *_: token.cancel())
        module = importlib.import_module("agri_tool." + MODULES[request["operation"]])
        with control.scope(token):
            token.check()
            result = module.handle(request["action"], payload, context)
            token.check()
        response["result"] = clean(result)
        if isinstance(result, dict):
            if result.get("status") in ("partial", "error", "cancelled"):
                response["status"] = result["status"]
            elif result.get("status") == "unavailable":
                response["status"] = "partial"
            response["warnings"] = result.get("warnings", [])
        response["engine_version"] = control.engine_version()
    except NeedsInput as exc:
        response.update(status="needs_input", questions=exc.questions, error={"code": "missing_input", "message": str(exc)})
    except control.RunCancelled as exc:
        response.update(status="cancelled", error={"code": "cancelled", "message": str(exc)}, warnings=["Completed scientific steps remain in project revisions and request checkpoints. To continue, explicitly call project/resume with payload.request_id set to the cancelled request identity."])
    except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
        response.update(status="error", error={"code": "revision_conflict" if isinstance(exc, RevisionConflict) else "invalid_request", "message": str(exc)})
    except Exception as exc:
        response.update(status="error", error={"code": "execution_error", "message": type(exc).__name__ + ": " + str(exc)})
    finally:
        stop.set()
        if monitor:
            monitor.join(timeout=1)
        for sig, handler in previous_signals.items():
            signal.signal(sig, handler)
    if context:
        response.update(project_id=context.project_id, revision=context.revision, artifacts=context.artifacts)
    if store and rid:
        store.finish(rid, response)
    return response


def compact_response(response, store, limit=110_000):
    """Retain full JSON as a workspace artifact before reducing model-facing context."""
    body = json.dumps(response, ensure_ascii=False, allow_nan=False)
    if len(body.encode()) <= limit:
        return response
    with tempfile.TemporaryDirectory(prefix="response-", dir=store.root) as folder:
        path = Path(folder) / "full_response.json"
        path.write_text(body)
        artifact = store.artifact(path, "application/json")

    def reduce(value, depth=0):
        if depth > 9:
            return "Full detail preserved in response artifact"
        if isinstance(value, dict):
            return {k: reduce(v, depth + 1) for k, v in value.items() if k not in ("engine_manifest", "series", "observations", "pareto_front", "source_sha256")}
        if isinstance(value, list):
            return [reduce(v, depth + 1) for v in value[:6]] + ([{"additional_items": len(value) - 6}] if len(value) > 6 else [])
        if isinstance(value, str) and len(value) > 3000:
            return value[:3000] + "… (full text saved)"
        return value
    result = reduce(response)
    result["artifacts"] = response.get("artifacts", []) + [artifact]
    result["abridged"] = True
    result["detail_note"] = "Summary is not an executable request. Exact inputs/outputs are in full_response.json and saved project results."
    return result
