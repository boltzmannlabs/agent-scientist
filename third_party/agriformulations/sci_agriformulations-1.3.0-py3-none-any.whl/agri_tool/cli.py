"""One request on stdin, one JSON response on stdout; no model credentials required."""
import argparse
import json
from pathlib import Path
import sys

from .service import execute, compact_response
from .storage import Store


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=None, help="Private scientific data directory (Agent Scientist provides profile-scoped path)")
    parser.add_argument("--full", action="store_true", help="Return complete JSON without model-context abridgement")
    parser.add_argument("--request-file", type=Path, help="Read a JSON request file instead of stdin")
    args = parser.parse_args(argv)
    if args.workspace is None:
        import os
        try:
            from sci_constants import get_sci_home
            home = get_sci_home()
        except ImportError:
            home = Path(os.environ.get("SCI_HOME", Path.home() / ".sci"))
        legacy = home / "plugin-data" / "agent-plugin-agriformulations-0b0ececb" / "workspace"
        args.workspace = legacy if legacy.is_dir() else home / "agriformulations" / "workspace"
    try:
        if args.request_file:
            with args.request_file.open("rb") as incoming:
                raw = incoming.read(8_000_001)
        else:
            raw = sys.stdin.buffer.read(8_000_001)
        if not raw or len(raw) > 8_000_000:
            raise ValueError("Request must contain 1 byte to8MB JSON")
        request = json.loads(raw)
        result = execute(request, args.workspace)
        if not args.full:
            result = compact_response(result, Store(args.workspace))
    except (ValueError, UnicodeError, OSError) as exc:
        result = {"schema_version": "1.0", "status": "error", "result": {}, "questions": [], "warnings": [], "artifacts": [], "error": {"code": "invalid_json", "message": str(exc)}}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0
