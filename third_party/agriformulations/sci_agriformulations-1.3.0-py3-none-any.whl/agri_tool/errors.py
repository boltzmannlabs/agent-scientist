class NeedsInput(ValueError):
    """Missing user identity or choice; native Agent Scientist clarify owns the UI."""
    def __init__(self, message, questions):
        super().__init__(message)
        self.questions = questions


def require(payload, fields):
    missing = [name for name in fields if payload.get(name) in (None, "", [])]
    if missing:
        raise NeedsInput("Required inputs are missing: " + ", ".join(missing), [
            {"id": name, "question": "Please supply " + name.replace("_", " "), "required": True}
            for name in missing])
