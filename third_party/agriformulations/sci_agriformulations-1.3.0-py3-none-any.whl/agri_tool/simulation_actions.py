"""All engine models, batch execution and immutable scenario retrieval."""
from agriformulations.rnd import simulation_service, simulation_catalog, control
from .errors import require


def handle(action, payload, context):
    context.require_project()
    if action == "list":
        return {"scenarios": [{k: r.get(k) for k in ("scenario_id", "kind", "title", "recipe_id", "active_name", "inputs")} for r in context.state.get("analysis_runs", [])]}
    if action == "get":
        require(payload, ["scenario_id"])
        entry = next((r for r in context.state.get("analysis_runs", []) if r["scenario_id"] == payload["scenario_id"]), None)
        if entry is None:
            raise ValueError("Scenario does not belong to this project")
        return entry
    if action == "run":
        request = dict(payload.get("request", payload))
        if context.request.get("model"):
            if request.get("model") and request["model"] != context.request["model"]:
                raise ValueError("Conflicting model keys")
            request["model"] = context.request["model"]
        require(request, ["model"])
        output = simulation_service.record(context.state, request)
        context.save()
        return output
    if action == "batch":
        require(payload, ["requests"])
        requests = payload["requests"]
        if not isinstance(requests, list) or not 1 <= len(requests) <= 50:
            raise ValueError("Supply 1–50 simulation requests")
        for request in requests:
            simulation_service.prepare(context.state, request)
        cases = []
        for request in requests:
            control.check()
            try:
                output = simulation_service.record(context.state, request)
                cases.append({"status": "completed", "scenario": output})
            except (ValueError, ArithmeticError) as exc:
                cases.append({"status": "error", "request": request, "error": str(exc)})
        context.save()
        return {"status": "completed" if all(c["status"] == "completed" for c in cases) else "partial", "cases": cases}
    raise ValueError("Unknown simulation action")
