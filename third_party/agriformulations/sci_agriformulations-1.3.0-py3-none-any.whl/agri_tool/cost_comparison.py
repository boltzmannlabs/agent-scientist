"""Saved baseline comparisons for grade/supplier/ingredient cost optimization."""
import csv
import hashlib
import io
import json
import math


def numeric(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + ' must be a finite number')
    return float(value)


def index(rows, key):
    result = {}
    for row in rows:
        identity = row[key]
        if identity in result:
            raise ValueError('Duplicate saved ' + key)
        result[identity] = row
    return result


def active_basis(recipe):
    return {a['name']: numeric(a['active_fraction'], 'active fraction') for a in recipe['active_components']}


def material_inputs(spec, values):
    allowed = set(spec.get('candidate_parameters', []))
    if values.get('base_model'):
        from agriformulations.rnd import simulation_catalog
        base = simulation_catalog.spec(values['base_model'])
        allowed.update('base_inputs.' + key for key in base.get('candidate_parameters', []))
    return allowed


def without_paths(values, paths):
    # Read-only copies; never edit the saved scientific input records.
    value = json.loads(json.dumps(values, allow_nan=False))
    for path in paths:
        parts = path.split('.')
        current = value
        for part in parts[:-1]:
            current = current.get(part, {}) if isinstance(current, dict) else {}
        if isinstance(current, dict):
            current.pop(parts[-1], None)
    return value


def compare(document, request):
    from agriformulations.rnd import simulation_catalog
    recipes = index(document.get('recipes', []), 'recipe_id')
    runs = index(document.get('analysis_runs', []), 'scenario_id')
    costs = index(document.get('cost_estimates', []), 'cost_id')
    baseline = request['baseline']
    entries = [baseline, *request.get('candidates', [])]
    if not request.get('candidates'):
        raise ValueError('Supply at least one evaluated alternative')
    if any(not isinstance(e, dict) or not isinstance(e.get('id'), str) or not e['id'].strip() for e in entries):
        raise ValueError('Every iteration needs a nonempty id')
    if len({e['id'] for e in entries}) != len(entries):
        raise ValueError('Iteration IDs must be unique')
    baseline_recipe = recipes[baseline['recipe_id']]
    basis = active_basis(baseline_recipe)
    scenarios = request.get('scenarios', [])
    if not isinstance(scenarios, list) or not scenarios:
        raise ValueError('Supply objective-relevant scenarios and evaluation criteria')
    if len({s['id'] for s in scenarios}) != len(scenarios):
        raise ValueError('Scenario IDs must be unique')
    for scenario in scenarios:
        spec = simulation_catalog.spec(scenario['model'])
        criteria = scenario.get('criteria', [])
        if not criteria or len({c['metric'] for c in criteria}) != len(criteria):
            raise ValueError('Each scenario needs distinct performance criteria')
        for criterion in criteria:
            if criterion['metric'] not in spec['output_metrics']:
                raise ValueError('Metric is not an output of ' + scenario['model'])
            if criterion.get('goal') not in ('minimize', 'maximize', 'range'):
                raise ValueError('Criterion goal must be minimize, maximize or range')
            if not isinstance(criterion.get('unit'), str):
                raise ValueError('Every criterion needs its native output unit')
            if criterion['metric'] == spec['metric'] and criterion['unit'] != spec['metric_unit']:
                raise ValueError('Criterion unit differs from the model native unit')
            low, high = criterion.get('minimum'), criterion.get('maximum')
            if low is not None:
                numeric(low, 'criterion minimum')
            if high is not None:
                numeric(high, 'criterion maximum')
            if low is not None and high is not None and low > high:
                raise ValueError('Criterion minimum exceeds maximum')
            if criterion['goal'] == 'range' and low is None and high is None:
                raise ValueError('Range criteria require an acceptance bound')
            if numeric(criterion.get('tolerance', 0), 'noninferiority tolerance') < 0:
                raise ValueError('Noninferiority tolerance cannot be negative')
    rows, grade_rows = [], []
    currency = None
    for entry in entries:
        recipe = recipes[entry['recipe_id']]
        issues = []
        current_basis = active_basis(recipe)
        if (recipe['format'] != baseline_recipe['format'] or set(current_basis) != set(basis)
                or any(not math.isclose(current_basis[k], basis[k], rel_tol=1e-8, abs_tol=1e-10) for k in basis)
                or not math.isclose(recipe['batch_g'], baseline_recipe['batch_g'], rel_tol=1e-9)):
            issues.append('different active loading, format or batch basis')
        cost = costs.get(entry.get('cost_id'))
        total, limits = None, None
        if cost is None:
            issues.append('missing cost record')
        elif cost['recipe_id'] != recipe['recipe_id']:
            raise ValueError('Cost record belongs to another recipe')
        else:
            result = cost['result']
            if currency is None:
                currency = result['currency']
            elif result['currency'] != currency:
                raise ValueError('Costs use different currencies; no FX conversion is assumed')
            total = result.get('final_cost_per_saleable_kg')
            if total is None or result.get('missing_ingredients') or result.get('missing_assumptions'):
                issues.append('incomplete total production cost')
                total = None
            else:
                total = numeric(total, 'total cost per saleable kg')
                if total < 0:
                    raise ValueError('Total cost cannot be negative')
            limits = result.get('ranges', {}).get('final_cost_per_saleable_kg')
            materials = {i['name']: i for i in cost['inputs']['recipe']['ingredients']}
            for line in result['ingredients']:
                material = materials[line['name']]
                purity = numeric(material['purity_pct'], 'purity')
                price = line.get('price_per_kg')
                grade_rows.append({'iteration_id': entry['id'], 'recipe_id': recipe['recipe_id'],
                    'ingredient': line['name'], 'grade': entry.get('grades', {}).get(line['name'], ''),
                    'supplier': material.get('supplier', ''), 'lot': material.get('lot', ''),
                    'purity_pct': purity, 'grade_source': material.get('grade_source', ''),
                    'pct': material['pct'], 'input_mass_kg': line['input_mass_kg'],
                    'unit_price': None if price is None else price['base'],
                    'price_per_pure_kg': None if price is None else price['base'] / (purity / 100),
                    'material_cost_batch': None if line.get('material_cost_batch') is None else line['material_cost_batch']['base'],
                    'price_origin': line['price_origin'], 'price_estimate': line.get('price_estimate'),
                    'cost_id': cost['cost_id']})
        performance = []
        for scenario in scenarios:
            key = scenario['id']
            run = runs.get(entry.get('runs', {}).get(key))
            ref = runs.get(baseline.get('runs', {}).get(key))
            if run is None or ref is None:
                issues.append('missing baseline or candidate simulation: ' + key)
                performance.append({'scenario': key, 'status': 'unassessed', 'reason': 'missing simulation'})
                continue
            if run['recipe_id'] != recipe['recipe_id'] or ref['recipe_id'] != baseline_recipe['recipe_id']:
                raise ValueError('Simulation belongs to another recipe')
            if run['kind'] != scenario['model'] or ref['kind'] != scenario['model']:
                raise ValueError('Simulation model does not match the scenario')
            if run.get('active_name') != ref.get('active_name') or run.get('active_b_name') != ref.get('active_b_name'):
                raise ValueError('Simulation active identity differs from baseline')
            if run['engine_version'] != ref['engine_version']:
                issues.append('different engine versions: ' + key)
            varying = scenario.get('varying_inputs', [])
            spec = simulation_catalog.spec(scenario['model'])
            if not isinstance(varying, list) or any(not isinstance(k, str) for k in varying):
                raise ValueError('varying_inputs must be material field paths')
            if set(varying) - material_inputs(spec, ref['inputs']):
                raise ValueError('Only catalogue material fields can vary; hold test conditions fixed')
            if without_paths(run['inputs'], varying) != without_paths(ref['inputs'], varying):
                issues.append('different shared test conditions: ' + key)
            for criterion in scenario['criteria']:
                metric = criterion['metric']
                actual = run['result'].get('metrics', {}).get(metric)
                original = ref['result'].get('metrics', {}).get(metric)
                if actual is None or original is None:
                    issues.append('missing metric: ' + key + '.' + metric)
                    performance.append({'scenario': key, 'metric': metric, 'status': 'unassessed'})
                    continue
                actual, original = numeric(actual, metric), numeric(original, 'baseline ' + metric)
                tolerance = criterion.get('tolerance', 0)
                ok = ((criterion.get('minimum') is None or actual >= criterion['minimum'])
                      and (criterion.get('maximum') is None or actual <= criterion['maximum']))
                if criterion['goal'] == 'minimize':
                    ok = ok and actual <= original + tolerance
                elif criterion['goal'] == 'maximize':
                    ok = ok and actual >= original - tolerance
                if not ok:
                    issues.append('performance constraint failed: ' + key + '.' + metric)
                performance.append({'scenario': key, 'scenario_id': run['scenario_id'], 'metric': metric,
                    'unit': criterion['unit'], 'baseline': original, 'value': actual,
                    'delta': actual - original, 'delta_pct': None if original == 0 else (actual - original) / abs(original) * 100,
                    'minimum': criterion.get('minimum'), 'maximum': criterion.get('maximum'),
                    'minimum_margin': None if criterion.get('minimum') is None else actual - criterion['minimum'],
                    'maximum_margin': None if criterion.get('maximum') is None else criterion['maximum'] - actual,
                    'noninferiority_margin': (original + tolerance - actual if criterion['goal'] == 'minimize'
                                              else actual - original + tolerance if criterion['goal'] == 'maximize' else None),
                    'goal': criterion['goal'], 'tolerance': tolerance, 'status': 'pass' if ok else 'fail',
                    'input_provenance': run.get('input_provenance', {}),
                    'source_kind': run['result'].get('source_kind', 'assumed scenario'),
                    'composition_used_by_model': run['result'].get('recipe_linkage', {}).get('composition_used_by_model', False)})
        rows.append({'id': entry['id'], 'label': entry.get('label', recipe['name']),
            'recipe_id': recipe['recipe_id'], 'cost_id': entry.get('cost_id'),
            'cost_per_saleable_kg': total, 'cost_range': limits, 'performance': performance,
            'status': 'eligible' if not issues else 'excluded_or_unresolved', 'reasons': sorted(set(issues)),
            'changes': entry.get('changes', [])})
    baseline_cost = rows[0]['cost_per_saleable_kg']
    for row in rows:
        value = row['cost_per_saleable_kg']
        row['savings_per_kg'] = None if value is None or baseline_cost is None else baseline_cost - value
        row['savings_pct'] = None if value is None or baseline_cost in (None, 0) else (baseline_cost - value) / baseline_cost * 100
    eligible = [r for r in rows if r['status'] == 'eligible']
    # Include baseline in the minimization: an expensive alternative cannot beat
    # a still-feasible baseline just because it was generated later.
    cheapest = min(eligible, key=lambda r: (r['cost_per_saleable_kg'], r is not rows[0], r['id'])) if eligible else None
    if baseline_cost is None:
        cheapest = None
    def objectives(row):
        return [row['cost_per_saleable_kg'], *[
            p['value'] * (-1 if p['goal'] == 'maximize' else 1)
            for p in row['performance'] if p.get('goal') in ('minimize', 'maximize')]]
    pareto = [row['id'] for row in eligible if not any(
        all(a <= b for a, b in zip(objectives(other), objectives(row)))
        and any(a < b for a, b in zip(objectives(other), objectives(row)))
        for other in eligible if other is not row)]
    return {'status': 'completed', 'currency': currency, 'cost_basis': 'per kg saleable product',
        'baseline_id': baseline['id'], 'iterations': rows, 'grade_comparison': grade_rows,
        'best_evaluated_id': None if cheapest is None else cheapest['id'],
        'pareto_ids': pareto, 'product_performance_established': False,
        'selection_status': ('baseline cost unavailable; recommendation unresolved' if baseline_cost is None
                             else 'no fully assessed feasible option' if cheapest is None
                             else 'lowest cost among evaluated feasible scenarios'),
        'scope': 'Conditional on the recorded prices, properties, test conditions and evaluated search space; no global optimum or experimental validation established.',
        'material_performance_limit': 'Composition-independent equations cannot establish grade/supplier/ingredient equivalence. Material effects require matching measured properties or an applicable validated mapping; identical assumed inputs are scenario hypotheses.',
        'request_sha256': hashlib.sha256(json.dumps(request, sort_keys=True, allow_nan=False).encode()).hexdigest()}


def csv_text(rows):
    if not rows:
        return ''
    stream = io.StringIO(newline='')
    fields = list(dict.fromkeys(k for row in rows for k in row))
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: json.dumps(v, ensure_ascii=False, allow_nan=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})
    return stream.getvalue()


def write_artifacts(comparison, root):
    outputs = {'.json': json.dumps(comparison, ensure_ascii=False, indent=2, allow_nan=False),
               '-iterations.csv': csv_text(comparison['iterations']),
               '-grades.csv': csv_text(comparison['grade_comparison']),
               '-performance.csv': csv_text([dict(iteration_id=r['id'], **p)
                                            for r in comparison['iterations'] for p in r['performance']])}
    paths = []
    for suffix, text in outputs.items():
        path = root / (comparison['comparison_id'] + suffix)
        path.write_text(text, encoding='utf-8')
        paths.append(path)
    return paths

