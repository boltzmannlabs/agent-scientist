"""Concrete recipe authoring proposals checked by the existing numerical engine."""
from copy import deepcopy
import json

from agriformulations.rnd import recipes, recipe_design, recipe_inputs, recipe_library, simulation_service, formulation_types
from agriformulations.rnd.common import digest
from .errors import require, NeedsInput


def annotate(result):
    # The old studio pinned its own model; this service does not execute that model.
    from .design_actions import remove_old_model_labels
    remove_old_model_labels(result)
    for recipe in result.get("recipes", []):
        recipe.pop("design_model", None)
        recipe["authoring_context"] = "User or Agent Scientist proposal; validated by deterministic AgriFormulations code"
    return result


def add(context, result):
    result = annotate(result)
    known = {r["recipe_id"] for r in context.state.get("recipes", [])}
    context.state.setdefault("recipes", []).extend(r for r in result["recipes"] if r["recipe_id"] not in known)
    first = result["recipes"][0]
    title = context.state["brief"]["name"] if context.project_id else result["brief"]["name"]
    context.state["brief"] = {**deepcopy(result["brief"]), "name": title}
    context.state.update(recipe_result=result, selected_recipe_id=first["recipe_id"], selected_active_name=first["active_components"][0]["name"])
    context.save()
    result["next_modes"] = [{"value": "design", "label": "Design", "operation": "design", "action": "study"},
        {"value": "ai_physics", "label": "AI + Physics Design", "operation": "design", "action": "optimize"}]
    return result


def concrete_identity(brief):
    value = brief.get("active_name", "")
    if not isinstance(value, str) or not value.strip() or any(w in value.lower() for w in ("specify", "choose active", "replace with", "select identity")):
        raise NeedsInput("A real active or nutrient identity is required", [{"id": "active_name", "question": "Which active ingredient or nutrient should this formulation contain?", "required": True}])


def handle(action, payload, context):
    if action == "preview":
        require(payload, ["file"])
        return recipe_inputs.preview(payload["file"])
    if action in ("manual", "validate"):
        raw = payload.get("recipe", payload)
        require(raw, ["name", "format", "batch_g", "ingredients"])
        result = recipe_inputs.create(raw)
        if action == "validate":
            return {"valid": True, **annotate(result), "persisted": False}
        return add(context, result)
    if action == "create":
        require(payload, ["brief"])
        brief = payload["brief"]
        if not isinstance(brief, dict):
            raise ValueError("brief must be an object")
        concrete_identity(brief)
        result = recipe_design.create({"brief_json": json.dumps(brief),
            "rationale": payload.get("rationale", "User or Agent Scientist formulation hypothesis"),
            "assumptions": payload.get("assumptions", ["Ingredient identities, grades, bounds and preparation are unverified research assumptions unless separately evidenced."]),
            "source_library_ids": payload.get("source_library_ids", [])}, context.store, payload.get("query", ""))
        return add(context, result)
    if action == "portfolio":
        require(payload, ["designs"])
        result = recipe_design.portfolio({"designs_json": json.dumps(payload["designs"])}, context.store, payload.get("query", ""))
        return add(context, result)
    if action == "library_search":
        return {"entries": recipe_library.entries(context.store, payload.get("query", ""), payload.get("format", ""), payload.get("origin", ""))}
    context.require_project()
    if action == "list":
        return {"recipes": context.state.get("recipes", []), "selected_recipe_id": context.state.get("selected_recipe_id")}
    if action == "select":
        require(payload, ["recipe_id"])
        recipe, active = simulation_service.recipe(context.state, payload["recipe_id"], payload.get("active_name"))
        context.state.update(selected_recipe_id=recipe["recipe_id"], selected_active_name=active["name"])
        context.save()
        return {"recipe": recipe, "active": active}
    if action == "variant":
        require(payload, ["recipe_id", "percentages"])
        original = next((r for r in context.state.get("recipes", []) if r["recipe_id"] == payload["recipe_id"]), None)
        if original is None:
            raise ValueError("Recipe does not belong to this project")
        amounts = payload["percentages"]
        if not isinstance(amounts, dict) or set(amounts) != {i["name"] for i in original["ingredients"]}:
            raise ValueError("Supply percentages for every existing ingredient exactly once")
        raw = {"name": payload.get("name", original["name"] + " variant"), "format": original["format"], "batch_g": original["batch_g"], "mode": "fixed",
            "ingredients": [{**i, "pct": amounts[i["name"]]} for i in original["ingredients"]], "process": original.get("process", []), "currency": original.get("currency", "INR")}
        result = recipe_inputs.create(raw)
        for recipe in result["recipes"]:
            recipe["parent_recipe_id"] = original["recipe_id"]
        return add(context, result)
    if action == "library_load":
        require(payload, ["library_id"])
        result = recipe_library.apply(payload["library_id"], context.state.get("brief"), context.store)
        context.state["brief"] = result["brief"]
        context.save()
        return result
    if action == "library_save":
        require(payload, ["recipe_id"])
        recipe = next((r for r in context.state.get("recipes", []) if r["recipe_id"] == payload["recipe_id"]), None)
        if recipe is None:
            raise ValueError("Recipe does not belong to this project")
        class ValidatedEntry:
            def library_save(self, entry):
                pass  # Validate first; attach truthful coordinator metadata before the durable insert.
        entry = recipe_library.save({"recipe": recipe, "name": payload.get("name"), "notes": payload.get("notes", "")}, ValidatedEntry())
        entry["source"]["authoring_context"] = "User or Agent Scientist; actual model identity not asserted by numerical tool"
        entry["library_id"] = "saved-" + digest(entry)
        context.store.library_save(entry)
        return entry
    raise ValueError("Unknown recipe action")
