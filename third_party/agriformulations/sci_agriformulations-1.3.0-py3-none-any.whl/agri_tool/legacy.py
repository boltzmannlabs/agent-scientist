"""Explicit historical replay, separate from current formulation decisions.

Only the registered deterministic study runners can execute. Every replay gets
its own engine copy; source evidence and original archived reports stay intact.
No runner invokes the historical chat coordinator or approves a proposal.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import mimetypes
import os
from contextlib import nullcontext
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid


NOTICE = (
    "Historical research workflow. Numerical reproduction is not independent "
    "experimental validation, product readiness, efficacy, patentability or "
    "freedom to operate. Historical laboratory-operation examples are outside "
    "the current formulation-design product scope."
)

# Fixed registry rather than model-supplied shell commands or Python paths.
RUNNERS = {
    "v1_case_study": {
        "module": "scripts.run_case_study", "title": "Release case study and held-out predictions",
        "requirements": ["numpy", "scipy", "pandas", "sklearn", "matplotlib", "openpyxl", "xlrd"],
        "device_flag": False, "note": "Retrospective fitting and numerical verification; no new-chemistry validation.",
    },
    "paper_benchmark": {
        "module": "scripts.benchmark_paper", "title": "Equation-matched published-paper benchmark",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "openpyxl"],
        "device_flag": False, "note": "Replays the archived author's workbook; unresolved source discrepancies remain.",
    },
    "v2_benchmark": {
        "module": "scripts.run_v2_benchmark", "title": "Three-study chronological and transfer benchmark",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib"],
        "device_flag": True, "note": "CPU defaults to --skip-gpu; optional XGBoost/GPU legs require their dependencies.",
    },
    "v3_catalog": {
        "module": "scripts.run_v3_catalog", "title": "Catalog, ontology, protocol and claims audit",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "openpyxl", "xlrd"],
        "device_flag": False, "note": "Screening proposals stay pending; no automatic approval or live literature retrieval.",
    },
    "v4_physics": {
        "module": "scripts.run_v4_physics", "title": "Geometry, finite-bath and swelling physics verification",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "torch"],
        "device_flag": True, "note": "Independent numerical limits and identifiability; not experimental validation.",
    },
    "v5_surrogates": {
        "module": "scripts.run_v5_surrogates", "title": "Study-held-out curve-summary surrogates",
        "requirements": ["numpy", "scipy", "pandas", "sklearn", "matplotlib"],
        "device_flag": True,
        "note": "Archived v5 coverage used a legacy implementation with known calibration defects. Fresh replay uses the bundled current code; neither implies validated composition-to-performance prediction.",
    },
    "v6_design": {
        "module": "scripts.run_v6_design", "title": "Identifiable release inverse-design benchmark",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "torch"],
        "device_flag": True, "note": "Solver-checked shortlist remains a pending proposal, not an approved recommendation.",
    },
    "v7_labops": {
        "module": "scripts.run_v7_labops", "title": "Historical lab-operation numerical examples and dossier",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "sklearn"],
        "device_flag": False, "note": "Historical only: no inventory, ELN/LIMS or laboratory execution is added to the current product.",
    },
    "v8_campaign": {
        "module": "scripts.run_v8_campaign", "title": "Sulfoxaflor campaign and analogue transfer",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "torch"],
        "device_flag": False, "note": "Prior-art coverage and analogue hypotheses, not legal or efficacy conclusions. Proposals remain pending.",
    },
    "v9_stereo": {
        "module": "scripts.run_v9_stereo", "title": "Stereochemistry assumptions and identifiability",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib"],
        "device_flag": False, "note": "Total-active data cannot establish separate enantiomer release rates.",
    },
    "v10_campaign": {
        "module": "scripts.run_v10_campaign", "title": "Benzovindiflupyr chiral campaign",
        "requirements": ["numpy", "scipy", "pandas", "matplotlib", "torch"],
        "device_flag": False, "note": "Frozen evidence-set campaign; patent-window context is historical. Proposals remain pending.",
    },
    "v11_zero_order": {
        "module": "scripts.run_v11_zero_order", "title": "Membrane-release feasibility and synthetic recovery",
        "requirements": ["numpy", "scipy", "pandas"],
        "device_flag": False, "note": "Mechanistic feasibility for fixed benchmark specifications, not a recipe performance claim.",
    },
}

_RUN_ID = re.compile(r"[a-f0-9]{32}")
_REPORT_SUFFIXES = {".json", ".jsonl", ".csv", ".html", ".png", ".zip", ".npy", ".md", ".txt"}
_MAX_INLINE = 12000


def _fields(payload, allowed):
    if not isinstance(payload, dict) or set(payload) - set(allowed):
        raise ValueError("Unsupported historical workflow fields; allowed: " + ", ".join(sorted(allowed)))


def _sha(path):
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            value.update(block)
    return value.hexdigest()


def _reports(engine):
    base = engine / "reports"
    return [p for p in sorted(base.rglob("*")) if p.is_file() and not p.is_symlink()
            and p.suffix.lower() in _REPORT_SUFFIXES and base.resolve() in p.resolve().parents]


def _snapshot(root):
    # A deterministic replay may rewrite byte-identical output. Preserve that
    # output too, without treating untouched prerequisite archives as fresh work.
    return {str(p.relative_to(root)): (_sha(p), p.stat().st_mtime_ns)
            for folder in ("reports", "proposals", "data", "research")
            for p in (root / folder).rglob("*") if p.is_file() and not p.is_symlink()}


def _requirements(entry):
    return [name for name in entry["requirements"] if importlib.util.find_spec(name) is None]


def _catalogue(payload, context):
    _fields(payload, {"runner"})
    runner = payload.get("runner")
    if runner is not None and (not isinstance(runner, str) or runner not in RUNNERS):
        raise ValueError("Choose a registered historical runner")
    selected = {runner: RUNNERS[runner]} if runner else RUNNERS
    entries = []
    for key, entry in selected.items():
        missing = _requirements(entry)
        entries.append({"runner": key, **entry, "missing_dependencies": missing,
                        "available": not missing,
                        "cuda": "Optional; explicit device=cuda and a CUDA-enabled torch runtime are required"
                        if entry["device_flag"] else "No device selection; uses the runner's declared implementation"})
    reports = [{"path": str(p.relative_to(context.engine / "reports")), "bytes": p.stat().st_size}
               for p in _reports(context.engine)]
    return {"status": "completed", "runners": entries, "reports": reports,
            "notice": NOTICE, "actions": ["catalogue", "report", "run", "runs", "get"],
            "run_fields": {"runner": "Registered runner ID", "timeout_seconds": "5–600, default 180",
                           "device": "cpu (default) or cuda for runners with device selection",
                           "gpu_legs": "v2 only: include optional XGBoost/torch legs; default false"}}


def _report(payload, context):
    _fields(payload, {"path"})
    relative = payload.get("path")
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise ValueError("Supply an archived report path from the catalogue")
    path = Path(relative)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("Archived report paths must stay inside the report directory")
    base = (context.engine / "reports").resolve()
    source = base / path
    if source.is_symlink() or base not in source.resolve().parents or not source.is_file() or source.suffix.lower() not in _REPORT_SUFFIXES:
        raise ValueError("Archived report not found or unsupported")
    artifact = context.artifact(source, media_type=mimetypes.guess_type(source.name)[0] or "application/octet-stream", name=source.name)
    result = {"status": "completed", "historical": True, "path": relative,
              "notice": NOTICE, "artifacts": [artifact], "sha256": _sha(source)}
    if source.suffix in {".json", ".csv", ".md", ".txt"} and source.stat().st_size <= _MAX_INLINE:
        content = source.read_text(encoding="utf-8")
        result["content"] = json.loads(content) if source.suffix == ".json" else content
    if path.parts[0] == "v5":
        result["warning"] = RUNNERS["v5_surrogates"]["note"]
    return result


def _command(payload, entry):
    device = payload.get("device", "cpu")
    if not isinstance(device, str) or device not in {"cpu", "cuda"}:
        raise ValueError("Historical replay device must be cpu or explicit cuda")
    if device != "cpu" and not entry["device_flag"]:
        raise ValueError("This historical runner does not expose device selection")
    gpu_legs = payload.get("gpu_legs", False)
    if not isinstance(gpu_legs, bool):
        raise ValueError("gpu_legs must be true or false")
    if gpu_legs and entry["module"] != "scripts.run_v2_benchmark":
        raise ValueError("gpu_legs applies only to the v2 benchmark")
    argv = [sys.executable, "-u", "-m", entry["module"]]
    if entry["device_flag"]:
        argv.extend(["--device", device])
    if entry["module"] == "scripts.run_v2_benchmark" and not gpu_legs:
        argv.append("--skip-gpu")
    return argv


def _run(payload, context):
    from agriformulations.rnd import control

    _fields(payload, {"runner", "timeout_seconds", "device", "gpu_legs"})
    runner = payload.get("runner")
    if not isinstance(runner, str) or runner not in RUNNERS:
        raise ValueError("Choose a registered historical runner")
    entry = RUNNERS[runner]
    timeout = payload.get("timeout_seconds", 180)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 5 <= timeout <= 600:
        raise ValueError("Historical timeout_seconds must be between 5 and 600")
    command = _command(payload, entry)
    missing = _requirements(entry)
    if payload.get("gpu_legs"):
        missing += [name for name in ("torch", "xgboost") if importlib.util.find_spec(name) is None]
    if payload.get("device") == "cuda" and importlib.util.find_spec("torch") is None:
        missing.append("torch")
    if missing:
        return {"status": "error", "runner": runner, "error": "Missing historical replay dependencies: " + ", ".join(sorted(set(missing))),
                "notice": NOTICE, "artifacts": []}
    if payload.get("device") == "cuda":
        import torch
        if not torch.cuda.is_available():
            return {"status": "error", "runner": runner, "error": "CUDA was requested but is unavailable", "notice": NOTICE, "artifacts": []}
    run_id = uuid.uuid4().hex
    folder = context.root / "legacy_runs" / run_id
    isolated = folder / "engine"
    folder.mkdir(parents=True, exist_ok=False)
    token = control.current()
    if token and token.on_event:
        token.on_event({"kind": "legacy_started", "run_id": run_id, "runner": runner,
                        "message": "Historical replay started in an isolated workspace"})
    for part in ("src", "scripts", "data", "research", "docs", "reports"):
        source = context.engine / part
        if source.is_dir():
            shutil.copytree(source, isolated / part, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "workbench"))
    if not (isolated / "src" / "agriformulations").is_dir():
        import agriformulations
        shutil.copytree(Path(agriformulations.__file__).parent, isolated / "src" / "agriformulations",
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    (isolated / "proposals").mkdir(exist_ok=True)
    before = _snapshot(isolated)
    log_path = folder / "execution.log"
    # A fresh child loads only the isolated engine; inherited model/API secrets
    # and user agent settings are not needed by these deterministic runners.
    environment = {
        "PATH": os.environ.get("PATH", os.defpath), "LANG": "C.UTF-8", "TZ": "UTC",
        "PYTHONPATH": os.pathsep.join([str(isolated / "src"), str(isolated)]),
        "MPLBACKEND": "Agg", "MPLCONFIGDIR": str(folder / "matplotlib"),
        "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
    }
    # The original verification runner opportunistically compares with CUDA
    # even when --device=cpu. A CPU replay must not occupy the host's GPUs.
    if payload.get("device", "cpu") == "cpu":
        environment["CUDA_VISIBLE_DEVICES"] = ""
    started = time.monotonic()
    code, status = None, "completed"
    with log_path.open("wb") as log:
        process = subprocess.Popen(command, cwd=isolated, env=environment, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=os.name == "posix")

        def terminate():
            try:
                if os.name == "posix":
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
            except ProcessLookupError:
                pass

        try:
            with token.interrupt_with(terminate) if token else nullcontext():
                deadline = started + timeout
                while True:
                    control.check()
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise subprocess.TimeoutExpired(command, timeout)
                    try:
                        code = process.wait(timeout=min(.25, remaining))
                        control.check()
                        break
                    except subprocess.TimeoutExpired:
                        if time.monotonic() >= deadline:
                            raise
            if code:
                status = "error"
        except subprocess.TimeoutExpired:
            terminate()
            code = process.wait()
            status = "partial"
        except control.RunCancelled:
            terminate()
            code = process.wait()
            status = "cancelled"
    elapsed = time.monotonic() - started
    changed = [isolated / rel for rel, sha in _snapshot(isolated).items() if before.get(rel) != sha]
    artifacts = [context.artifact(log_path, media_type="text/plain", name="legacy-execution.log")]
    for path in changed:
        artifacts.append(context.artifact(path, media_type=mimetypes.guess_type(path.name)[0] or "application/octet-stream", name=path.name))
    result = {"status": status, "run_id": run_id, "runner": runner, "historical": True,
              "execution": {"module": entry["module"], "arguments": command[4:], "returncode": code,
                            "elapsed_seconds": round(elapsed, 3), "timeout_seconds": timeout,
                            "isolated": True, "llm_calls": 0},
              "artifacts": artifacts, "notice": NOTICE, "limitations": [entry["note"]],
              "changed_outputs": [str(path.relative_to(isolated)) for path in changed],
              "log_tail": log_path.read_bytes()[-_MAX_INLINE:].decode("utf-8", errors="replace")}
    if status == "partial":
        result["error"] = "Historical runner reached its time limit; completed files and execution log are retained"
    elif status == "error":
        result["error"] = "Historical runner failed; inspect its log and retained partial outputs"
    elif status == "cancelled":
        result["error"] = "Historical replay stopped by the user; completed files and execution log are retained"
    (folder / "run.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    if status == "cancelled":
        raise control.RunCancelled("Historical replay stopped; recover retained files with legacy/get run_id=" + run_id)
    return result


def _get(payload, context):
    _fields(payload, {"run_id"})
    run_id = payload.get("run_id")
    if not isinstance(run_id, str) or not _RUN_ID.fullmatch(run_id):
        raise ValueError("Supply this workspace's historical run ID")
    path = context.root / "legacy_runs" / run_id / "run.json"
    if path.is_symlink() or not path.is_file():
        raise ValueError("Historical run not found in this workspace")
    return json.loads(path.read_text(encoding="utf-8"))


def _runs(payload, context):
    _fields(payload, set())
    records = []
    for path in sorted((context.root / "legacy_runs").glob("*/run.json")):
        if not path.is_symlink():
            value = json.loads(path.read_text(encoding="utf-8"))
            records.append({k: value[k] for k in ("run_id", "runner", "status", "execution")})
    return {"status": "completed", "runs": records, "notice": NOTICE}


def handle(action, payload, context):
    """Dispatch an explicitly requested registered historical operation."""
    handlers = {"": _catalogue, "catalogue": _catalogue, "list": _catalogue,
                "report": _report, "run": _run, "get": _get, "runs": _runs}
    if not isinstance(action, str) or action not in handlers:
        raise ValueError("Unsupported legacy action; choose catalogue, report, run, runs or get")
    return handlers[action](payload, context)
