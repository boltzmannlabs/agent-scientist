"""Saved scientific state and portable result exports."""
import base64
from copy import deepcopy
import json
from pathlib import Path
import tempfile

from agriformulations.rnd.common import label
from .errors import require

COLLECTIONS = {"recipes": "recipe_id", "analysis_runs": "scenario_id", "design_studies": "study_id", "fit_runs": "fit_id",
    "imports": "dataset_id", "cost_estimates": "cost_id", "cost_comparisons": "comparison_id", "formulation_workflows": "workflow_id", "research_reports": "report_id", "research_searches": "search_id"}


def empty(name, active="", fmt="SC"):
    from agriformulations.rnd.formulation_types import canonical, FORMATS
    fmt = canonical(fmt)
    if fmt not in FORMATS:
        raise ValueError("Unknown formulation format")
    return {"brief": {"name": label(name, "project name"), "active_name": active, "format": fmt, "ingredients": [], "process": []},
        **{key: [] for key in COLLECTIONS}, "research_sources": [], "tool_schema_version": "1.0"}


def summary(document):
    return {"brief": document.get("brief"), "counts": {key: len(document.get(key, [])) for key in COLLECTIONS},
        "selected_recipe_id": document.get("selected_recipe_id"), "selected_active_name": document.get("selected_active_name"),
        "recipes": [{k: r.get(k) for k in ("recipe_id", "name", "format", "active_components", "active_fraction", "batch_g")} for r in document.get("recipes", [])],
        "recent_results": [{"kind": key, "id": item.get(identity), "title": item.get("name") or item.get("title")} for key, identity in COLLECTIONS.items() if key != "recipes" for item in document.get(key, [])[-5:]],
        "design_modes": ["design", "ai_physics"]}


def export(context):
    from agriformulations.rnd.api import export as original_export
    from .reporting import write_report
    with tempfile.TemporaryDirectory(prefix="agri-export-", dir=context.root) as folder:
        root = Path(folder)
        result = original_export({"document": context.state})
        archive = root / "formulation_project.zip"
        archive.write_bytes(base64.b64decode(result["archive_base64"]))
        from .cost_comparison import write_artifacts
        for comparison in context.state.get('cost_comparisons', []):
            write_artifacts(comparison, root)
        report = write_report(context.state, root)
        import zipfile
        # The engine's legacy archive contains an HTML report. Replace it in
        # the user-facing bundle so exports have one polished PDF report.
        rebuilt = root / "formulation_project-rebuilt.zip"
        with zipfile.ZipFile(archive) as source, zipfile.ZipFile(rebuilt, "w", zipfile.ZIP_DEFLATED) as target:
            for item in source.infolist():
                if item.filename != "report.html":
                    target.writestr(item, source.read(item.filename))
        rebuilt.replace(archive)
        with zipfile.ZipFile(archive, "a", zipfile.ZIP_DEFLATED) as z:
            for path in root.iterdir():
                if path not in (archive, rebuilt):
                    z.write(path, "scientific_results/" + path.name)
            z.write(report, "report.pdf")
        artifacts = [context.artifact(archive, "application/zip"), context.artifact(report, "application/pdf")]
        artifacts.extend(context.artifact(p, "image/png" if p.suffix == ".png" else "text/csv" if p.suffix == ".csv" else "application/json") for p in root.iterdir() if p != archive and p != report)
    return {"artifacts": artifacts, "evidence": "Research drafts and reproducible numerical scenarios; experimental validation is not established."}


def handle(action, payload, context):
    store = context.store
    if action == "create":
        require(payload, ["name"])
        if context.recovered_destination:
            return {**summary(context.state), "recovered_existing_project": True}
        context.state = empty(payload["name"], payload.get("active_name", ""), payload.get("format", "SC"))
        context.project_id = None
        context.revision = 0
        context.saved_digest = None
        context.initial = {}
        context.save()
        return summary(context.state)
    if action == "list":
        return {"projects": store.list()}
    if action == "jobs":
        return {"requests": store.jobs(context.project_id)}
    if action == "resume":
        require(payload, ["request_id"])
        if payload["request_id"] == context.request_id:
            raise ValueError("Resume must use a new outer request identity")
        from .service import execute, request_digest
        original = store.resume(payload["request_id"], request_digest)
        result = execute(original, context.root)
        # Outer request points to the resumed scientific project, not the resume control request.
        context.project_id = result.get("project_id")
        context.revision = result.get("revision", 0)
        context.artifacts.extend(result.get("artifacts", []))
        return result
    if action in ("job", "cancel"):
        require(payload, ["request_id"])
        return (store.job if action == "job" else store.cancel)(payload["request_id"])
    if action == "artifact":
        require(payload, ["artifact_id"])
        path = store.artifact_path(payload["artifact_id"])
        result = store.artifact(path)
        if payload.get("include_content"):
            if path.stat().st_size > 6_000_000:
                raise ValueError("Artifact exceeds inline download limit; use returned file path locally")
            result["content_base64"] = base64.b64encode(path.read_bytes()).decode()
        return result
    context.require_project()
    if action == "get":
        record = store.load(context.project_id, payload.get("revision")) if payload.get("revision") else {"document": context.state, "revision": context.revision}
        return {"revision": record["revision"], **({"document": record["document"]} if payload.get("detail") == "full" else summary(record["document"]))}
    if action == "rename":
        require(payload, ["name"])
        context.state["brief"]["name"] = label(payload["name"], "project name")
        context.save()
        return summary(context.state)
    if action == "history":
        with store.connect() as db:
            rows = db.execute("SELECT revision,name,created FROM revisions WHERE project_id=? ORDER BY revision", (context.project_id,)).fetchall()
        return {"revisions": [{"revision": r[0], "name": r[1], "created": r[2]} for r in rows]}
    if action == "fork":
        if context.recovered_destination:
            return {**summary(context.state), "recovered_existing_project": True}
        old = {"project_id": context.project_id, "revision": context.revision}
        context.state = deepcopy(context.state)
        context.state["source_project"] = old
        context.state["brief"]["name"] = label(payload.get("name", context.state["brief"]["name"] + " fork"), "project name")
        context.project_id = None
        context.revision = 0
        context.save()
        return summary(context.state)
    if action == "result":
        require(payload, ["id"])
        for collection, identity in COLLECTIONS.items():
            item = next((item for item in context.state.get(collection, []) if item.get(identity) == payload["id"]), None)
            if item is not None:
                return {"kind": collection, "record": item}
        raise ValueError("Result does not belong to this project")
    if action == "export":
        return export(context)
    raise ValueError("Unknown project action")
