"""Observation import and calibration preserve origin, review and recipe identity."""
from copy import deepcopy
from agriformulations.rnd import importing, data_tools, simulation_service, learning, data_provenance
from agriformulations.rnd.common import digest
from .errors import require


def handle(action, payload, context):
    if action == "preview":
        require(payload, ["file"])
        return importing.preview(payload["file"])
    context.require_project()
    if action == "import":
        require(payload, ["file"])
        raw = deepcopy(payload["file"])
        require(raw, ["recipe_id", "active_name", "source_kind"])
        simulation_service.recipe(context.state, raw["recipe_id"], raw["active_name"])
        if raw.get("kind") == "mixture_response":
            simulation_service.recipe(context.state, raw["recipe_id"], raw.get("active_b_name"))
            if raw.get("active_name") == raw.get("active_b_name"):
                raise ValueError("Mixture observations require two distinct project actives")
        record = data_tools.identify(importing.ingest(raw))
        record["source_selection"] = {k: raw.get(k) for k in ("condition_value", "recipe_value")}
        record["dataset_id"] = "d-" + digest({"source_identity": record["dataset_id"], "selection": record["source_selection"],
            "observations": record["observations"], "excluded": record.get("excluded", [])})
        existing = next((d for d in context.state.get("imports", []) if d["dataset_id"] == record["dataset_id"]), None)
        if existing:
            return existing
        context.state.setdefault("imports", []).append(record)
        context.save()
        return record
    if action == "list":
        return {"datasets": [{"dataset_id": data_tools.identify(d)["dataset_id"], "kind": d["kind"], "recipe_id": d["recipe_id"], "active_name": d["active_name"], "source_kind": d.get("source_kind", "unknown"), "review": d["review"], "rows": len(d["observations"])} for d in context.state.get("imports", [])],
            "fits": [{k: f.get(k) for k in ("fit_id", "dataset_id", "simulation_key", "parameters", "calibration_domain", "source_kind", "prediction_gate")} for f in context.state.get("fit_runs", [])]}
    if action in ("get", "review", "fit"):
        require(payload, ["dataset_id"])
        record = simulation_service.dataset(context.state, payload["dataset_id"])
        if action == "get":
            return record
        if action == "review":
            require(payload, ["review"])
            review = payload["review"]
            if not isinstance(review, dict) or set(review) - {"status", "notes", "excluded_source_rows"}:
                raise ValueError("Review accepts status, notes and excluded_source_rows")
            if review.get("status") not in ("unreviewed", "reviewed", "rejected"):
                raise ValueError("Choose unreviewed, reviewed or rejected review status")
            notes = review.get("notes", "")
            if not isinstance(notes, str) or len(notes) > 4000 or (review["status"] == "reviewed" and not notes.strip()):
                raise ValueError("Reviewed datasets need notes describing the actual review, up to4000 characters")
            excluded = review.get("excluded_source_rows", [])
            valid = {r["source_row"] for r in record["observations"]}
            if not isinstance(excluded, list) or any(isinstance(r, bool) or r not in valid for r in excluded):
                raise ValueError("Excluded source rows must exist in this dataset")
            record["review"] = {"status": review["status"], "notes": notes, "excluded_source_rows": sorted(set(excluded))}
            context.save()
            return record
        fitted = simulation_service.record_fit(context.state, payload["dataset_id"], payload.get("options", {}))
        context.save()
        return fitted
    if action == "learn":
        require(payload, ["measurements", "source_kind"])
        origin = data_provenance.source_kind(payload)
        result = learning.learn({**payload, "recipes": context.state.get("recipes", [])})
        result["source_kind"] = origin
        result["evidence"] = "Recipe-held-out local regression on user-declared " + origin + " observations"
        result["empirical_validation_established"] = False
        if origin != "experimental":
            result["utility_pass"] = False
            result["limitations"].append("Synthetic, literature or unspecified-origin observations cannot unlock experimental composition-performance predictions in this service.")
            for prediction in result["predictions"]:
                prediction["prediction"] = None
                prediction["status"] = "Experimental-origin gate not satisfied"
        context.state["response_measurements"] = deepcopy(payload["measurements"])
        context.state["learning_result"] = result
        context.save()
        return result
    raise ValueError("Unknown data action")
