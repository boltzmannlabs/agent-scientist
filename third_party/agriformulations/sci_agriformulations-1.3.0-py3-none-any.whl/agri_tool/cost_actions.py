from agriformulations.rnd import cost_service, control
from .errors import require
from . import cost_comparison


def handle(action, payload, context):
    context.require_project()
    if action == "list":
        return {"costs": context.state.get("cost_estimates", []), "comparisons": context.state.get("cost_comparisons", [])}
    if action == "compare":
        from copy import deepcopy
        from pathlib import Path
        import tempfile
        from agriformulations.rnd.common import digest
        result = cost_comparison.compare(context.state, payload)
        result['project_id'] = context.project_id
        result['comparison_id'] = 'cc-' + digest(result)
        existing = next((r for r in context.state.get('cost_comparisons', [])
                         if r['comparison_id'] == result['comparison_id']), None)
        if existing is None:
            result['inputs_revision'] = context.revision
            result['inputs'] = deepcopy(payload)
            context.state.setdefault('cost_comparisons', []).append(result)
            context.save()
        else:
            result = existing
        with tempfile.TemporaryDirectory(prefix='cost-comparison-', dir=context.root) as folder:
            for path in cost_comparison.write_artifacts(result, Path(folder)):
                context.artifact(path, 'text/csv' if path.suffix == '.csv' else 'application/json')
        return result
    if action == "get":
        require(payload, ["cost_id"])
        item = next((c for c in context.state.get("cost_estimates", []) if c["cost_id"] == payload["cost_id"]), None)
        if item is None:
            raise ValueError("Cost estimate does not belong to this project")
        return item
    if action == "estimate":
        result = cost_service.record(context.state, payload.get("cost", payload))
        context.save()
        return result
    if action == "batch":
        require(payload, ["costs"])
        costs = payload["costs"]
        if not isinstance(costs, list) or not 1 <= len(costs) <= 24:
            raise ValueError("Supply 1–24 cost scenarios")
        results = []
        for cost in costs:
            control.check()
            results.append(cost_service.record(context.state, cost))
        context.save()
        return {"costs": results}
    raise ValueError("Unknown costing action")
