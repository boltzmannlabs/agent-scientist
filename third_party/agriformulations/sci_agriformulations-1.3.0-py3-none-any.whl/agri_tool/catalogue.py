"""Discoverable operation contracts and exact engine-owned model schemas."""
from copy import deepcopy
from agriformulations.rnd import simulation_catalog, formulation_types, recipes, data_tools, costing

OPERATIONS = {
    "catalogue": {"actions": ["operations", "models", "formats", "recipes", "design", "data", "cost", "research", "project", "legacy"]},
    "recipes": {"actions": ["create", "manual", "validate", "preview", "portfolio", "variant", "list", "select", "library_search", "library_load", "library_save"]},
    "simulate": {"actions": ["run", "batch", "list", "get"]},
    "design": {"actions": ["study", "optimize", "workflow", "complete", "develop", "experiments", "studies", "get"]},
    "data": {"actions": ["preview", "import", "list", "get", "review", "fit", "learn"]},
    "cost": {"actions": ["estimate", "batch", "compare", "list", "get"]},
    "research": {"actions": ["search", "list", "get", "save_source", "sources", "citations"]},
    "project": {"actions": ["create", "list", "get", "rename", "fork", "history", "result", "export", "job", "jobs", "cancel", "resume", "artifact"]},
    "legacy": {"actions": ["catalogue", "list", "report", "run", "runs", "get"]},
}

EXAMPLE_RECIPE = {
    "name": "Illustrative SC hypothesis", "format": "SC", "batch_g": 500, "mode": "fixed",
    "ingredients": [
        {"name": "Tebuconazole technical", "role": "active", "pct": 21.05263157894737, "purity_pct": 95},
        {"name": "Sodium lignosulfonate", "role": "dispersant", "pct": 3, "purity_pct": 100},
        {"name": "Xanthan gum", "role": "stabilizer", "pct": .2, "purity_pct": 100},
        {"name": "Water", "role": "solvent", "pct": 75.74736842105263, "purity_pct": 100}],
    "process": "Illustrative preparation sequence; grades, compatibility and processing require verification.",
}

DETAILS = {
    "recipes": {
        "allowed_roles": sorted(recipes.ROLES),
        "project_requirement": "manual/create/portfolio SAVE validated recipes and automatically create a project if project_id is empty. validate and preview do NOT save. library_search is read-only and needs no project. Other actions require a project.",
        "manual": {"payload": {"recipe": EXAMPLE_RECIPE}, "effect": "VALIDATES AND SAVES the exact supplied recipe. No separate save call is needed. Returns saved recipe IDs and project_id in the response envelope.", "note": "Exact % w/w supplied-grade composition. Engine validates mass and purity. A name is a declared identity, not verified material availability."},
        "create": {"payload": {"brief": recipes.default_brief(), "assumptions": ["Replace example identities and ranges with concrete user facts or explicit hypotheses."], "rationale": "Agent-authored hypothesis"},
            "effect": "GENERATES AND SAVES constraint-checked candidates; no separate save action is needed.", "note": "Use a real active identity and concrete ingredient names. min_pct/max_pct are supplied-grade percentages; active_pct and mixture target_active_pct are PURE-active percentages. count<=100."},
        "portfolio": {"payload": {"designs": [{"family": "Distinct material family", "brief": "complete create brief", "assumptions": [], "rationale": "why this alternative"}]}, "effect": "VALIDATES AND SAVES all family candidates atomically before numerical execution.", "note": "2–6 families; <=24 combined recipes. All families share active identities/loading/batch/currency."},
        "validate": {"payload": {"recipe": EXAMPLE_RECIPE}, "note": "Validates without saving a recipe; may be used before a project exists."},
        "preview": {"payload": {"file": {"filename": "recipe.csv", "content_base64": "base64 bytes", "mapping": {}}}, "note": "CSV/XLSX ingredient table preview. Needs name/pct columns or explicit mapping. Does not save or invent absent amounts."},
        "variant": {"payload": {"recipe_id": "R-...", "name": "Revision", "percentages": {"EXACT ingredient name": 10}}, "note": "Supply a percentage for EVERY existing ingredient, summing to100. Active loading is recomputed."},
        "library_search": {"payload": {"query": "", "format": "", "origin": ""}},
        "library_load": {"payload": {"library_id": "starter-sc"}, "note": "Stages a brief; does not invent missing published fractions or generate candidates."},
        "library_save": {"payload": {"recipe_id": "R-...", "name": "Draft", "notes": "unmeasured"}},
        "select": {"payload": {"recipe_id": "R-...", "active_name": "exact individual active"}},
    },
    "design": {
        "action_choice": "study evaluates candidates with output criteria, margins and Pareto comparisons. workflow executes shared cases and publishes a computed comparison WITHOUT acceptance criteria. Use study when the user requests a specification comparison. optimize searches physical parameters. All actions save results automatically and require a project.",
        "study": {"payload": {"study": {"name": "Compare handling", "goal": "Compare explicit hypotheses under shared conditions",
            "candidates": [{"recipe_id": "R-...", "active_name": "exact active", "inputs": {"flow": {"consistency_pa_sn": .5}}}],
            "scenarios": [{"id": "flow", "model": "rheology", "inputs": {"yield_stress_pa": 0, "flow_index": 1}, "candidate_parameters": ["consistency_pa_sn"]}],
            "criteria": [{"scenario": "flow", "metric": "pressure_bar", "maximum": .8, "goal": "minimize", "scale": 1}],
            "assumptions": ["Candidate properties are assumptions, not predictions from ingredients."]}},
            "limits": "1–8 distinct recipe versions, same individual active; 1–4 independent scenarios; 1–12 criteria. Candidate changes only allowed material fields. Test conditions shared."},
        "optimize": {"payload": {"recipe_id": "R-...", "active_name": "exact active", "inputs": {
            "base_model": "rheology", "base_inputs": {"yield_stress_pa": 0, "flow_index": 1},
            "variables": [{"parameter": "consistency_pa_sn", "low": .01, "high": 2, "scale": "log"}],
            "objectives": [{"metric": "pressure_bar", "goal": "minimize", "scale": 1}],
            "constraints": [{"metric": "viscosity_at_100_s_pa_s", "minimum": .5}], "evaluations": 24, "seed": 42}},
            "note": "Optimizes physical inputs; no ingredient-property mapping. If study supplied too, replay full study for each shortlisted material hypothesis, with explicit property overrides."},
        "workflow": {"payload": {"workflow": {"name": "Complete comparison", "goal": "Compare all declared recipes/scenarios",
            "recipe_ids": ["R-..."], "scenarios": [{"name": "Storage screen", "model": "suspension", "inputs": {}, "assumptions": ["All unspecified inputs are catalogue assumptions."]}]}},
            "note": "Either recipe_ids or 2–6 distinct designs in portfolio format. 1–12 scenarios, <=96 cases. Optional research metadata search. Cases checkpoint automatically."},
        "experiments": {"payload": {"recipe_ids": ["R-..."], "options": {"independent_batches": 3, "technical_replicates": 2, "seed": 2026}},
            "note": "Only when explicitly requested; plans measurements, does not execute or administer a laboratory."},
        "complete": {"payload": {"request": {"name": "Two SC hypotheses", "format": "SC", "batch_g": 500,
            "actives": [{"name": "Tebuconazole technical", "target_pct": 20, "purity_pct": 95}],
            "hypotheses": [{"name": "Lignosulfonate", "ingredients": [{"name": "Sodium lignosulfonate", "role": "dispersant", "pct": 3}], "balance": {"name": "Water", "role": "solvent"}, "process": ["Illustrative sequence; verify grades and processing"], "rationale": "Explicit material hypothesis"},
                {"name": "Polyacrylate", "ingredients": [{"name": "Sodium polyacrylate", "role": "dispersant", "pct": 3}], "balance": {"name": "Water", "role": "solvent"}, "process": ["Illustrative sequence; verify grades and processing"], "rationale": "Alternative material hypothesis"}],
            "scenarios": [{"name": "Shared settling", "model": "suspension", "active_name": "Tebuconazole technical", "inputs_json": "{}"}], "literature_query": "", "assumptions": ["Material grades and physical coefficients are hypotheses; composition does not determine them."]}},
            "note": "Compact all-in-one authoring. Engine computes technical active masses and remaining balance, validates 2–6 distinct families, executes scenarios and saves comparison."},
        "develop": {"payload": {"brief": "complete recipe create brief, count2–12", "rationale": "why", "assumptions": ["explicit hypotheses"],
            "scenarios": [{"active_name": "exact active", "assumptions": ["Assumed parameters"],
                "kinetics": {"model": "first_order", "rate_per_day": .1, "plateau": 1, "lag_days": 0, "horizon_days": 30, "parameter_source": "explicit scenario"},
                "stability": {"reference_rate_per_day": .001, "reference_temperature_c": 25, "activation_energy_kj_mol": 40, "temperatures_c": [25], "horizon_days": 30, "minimum_retained_fraction": .9},
                "dosage": {"evaluation_day": 7, "target_available_g_ha": 1, "deposition_fraction": .8, "storage_temperature_c": 25}}]},
            "note": "Creates a fresh child project and runs release→chemical retention→storage-adjusted dose for every recipe/individual active. Hypothetical dose is not a field recommendation."},
    },
    "data": {
        "kinds": data_tools.KINDS,
        "import": {"payload": {"file": {"filename": "rheology.csv", "content_base64": "base64 bytes", "kind": "rheology", "recipe_id": "R-...", "active_name": "exact active", "mapping": {"x": "shear", "value": "stress", "batch": "batch"}, "x_unit": "1/s", "value_unit": "Pa", "instrument": "Declared method", "source_kind": "experimental", "context": {}}},
            "note": "Same file contract for preview. CSV/XLSX <=4MB; explicit source_kind: experimental/literature/synthetic/unknown. Release uses mapping.time and value; x/time unit mapping must be explicit."},
        "review": {"payload": {"dataset_id": "d-...", "review": {"status": "reviewed", "notes": "QC scope and exclusions", "excluded_source_rows": []}}},
        "fit": {"payload": {"dataset_id": "d-...", "options": {}}, "note": "Fits source observations; preserves recipe, active, review digest, calibration range and source kind. No empirical validation inferred."},
        "learn": {"payload": {"measurements": [{"recipe_id": "R-...", "batch_id": "B1", "value": 1}], "response_name": "Measured response", "response_unit": "declared units", "goal": "minimize", "source_kind": "experimental"},
            "note": "Requires >=8 measured recipes with same ingredient basis/format/process, held-out utility, convex-hull gate."},
    },
    "cost": {"assumption_fields": costing.ASSUMPTION_FIELDS,
        "compare": {"payload": {
            "baseline": {"id": "B0", "recipe_id": "R-baseline", "cost_id": "cost-baseline", "runs": {"flow": "s-baseline"}, "grades": {"Exact active name": "95% technical"}},
            "candidates": [{"id": "I1", "recipe_id": "R-alternative", "cost_id": "cost-alternative", "runs": {"flow": "s-alternative"}, "grades": {"Exact active name": "98% technical"}, "changes": ["grade", "supplier", "ingredients"]}],
            "scenarios": [{"id": "flow", "model": "rheology", "varying_inputs": ["yield_stress_pa", "consistency_pa_sn", "flow_index"],
                           "criteria": [{"metric": "pressure_bar", "unit": "bar", "goal": "minimize", "maximum": 1.0, "tolerance": 0}]}]},
            "note": "Uses only actual saved recipes/costs/runs. Same active loading, format, batch, currency, engine and shared test conditions required. Supports all catalogue metrics; no invented material-property mapping. Saves all iterations, grade costs, baseline deltas, feasibility/Pareto and lowest-cost feasible scenario including baseline. Returns JSON/CSV artifacts and appears in PDF/ZIP exports; no experimental validation or global optimum established."},
        "estimate": {"payload": {"recipe_id": "R-...", "prices": {"exact ingredient": {"cost_per_kg": 100}},
            "assumptions": {"currency": "INR", "yield_pct": 95, "processing_per_input_kg": 10, "packaging_per_saleable_kg": 5, "fixed_batch_cost": 0, "overhead_pct": 0, "freight_per_batch": 0, "tax_pct": 0, "pack_size_kg": 1}, "notes": ["Prices and production assumptions are explicit scenarios."]}},
        "note": "All assumptions except pack size and every positive-mass ingredient price required for final cost. Missing costs remain missing. No verified tax rate or supplier quote inferred."},
    "research": {
        "search": {"payload": {"kind": "literature", "query": "agricultural suspension formulation", "limit": 10, "focus_terms": [], "sort": "relevance"}, "note": "kind literature or patent; optional year_from/year_to. Patent country/CPC filters. Retrieval is metadata/abstracts; not full-text review."},
        "save_source": {"payload": {"search_id": "search-...", "record_id": "ref-...", "status": "reviewed", "evidence_stage": "abstract_reviewed", "notes": "What was actually reviewed and claim limits"}},
    },
    "project": {
        "create": {"payload": {"name": "My formulation project", "active_name": "Optional known active", "format": "SC"}},
        "get": {"payload": {"detail": "summary"}, "note": "detail full returns complete saved document. Optional revision retrieves history."},
        "result": {"payload": {"id": "saved scenario/study/fit/cost/workflow/dataset/report ID"}},
        "fork": {"payload": {"name": "Revised project"}},
        "export": {"payload": {}, "note": "Returns ZIP + readable PDF report, comparison/recipe/data CSV, raw uploads and per-scenario JSON/plots as downloadable artifacts."},
        "job": {"payload": {"request_id": "prior request identity"}},
        "cancel": {"payload": {"request_id": "active request identity"}},
        "resume": {"payload": {"request_id": "cancelled or interrupted request identity"}, "note": "Explicitly resume stopped work; use a NEW outer request_id for this control action. Exact retries alone never restart user-cancelled work."},
        "artifact": {"payload": {"artifact_id": "returned opaque artifact ID"}, "note": "Only workspace-owned artifacts may be retrieved; content_base64 optional include_content=true, bounded."},
    },
}


def handle(action, payload, context):
    key = context.request.get("model") or payload.get("model")
    if key:
        return {"model": deepcopy(simulation_catalog.spec(key))}
    if action == "formats":
        return {"formats": formulation_types.catalogue()}
    if action == "models":
        return {"models": [{k: m[k] for k in ("key", "title", "category", "description", "maturity", "output_metrics")} for m in simulation_catalog.catalogue()],
            "schema_lookup": {"operation": "catalogue", "model": "chosen model key", "payload": {}}}
    if action in DETAILS:
        return {"operation": action, **OPERATIONS[action], "contracts": deepcopy(DETAILS[action])}
    if action == "legacy":
        from .legacy import handle as legacy
        return legacy("catalogue", payload, context)
    if action not in ("", "operations"):
        raise ValueError("Unknown catalogue action")
    return {"tool": "agriformulations", "schema_version": "1.0", "llm_calls": False,
        "operations": OPERATIONS, "models": [m["key"] for m in simulation_catalog.catalogue()],
        "discovery": "Use catalogue action=recipes/design/data/cost/research/project for payload examples; supply model for exact engine schema.",
        "design_modes": {"design": "Compare declared candidates/scenarios against specifications", "ai_physics": "Search physical parameter settings then compare; composition-property mapping unavailable"},
        "question_handling": "Agent Scientist native clarify asks essential questions or mode choice. Missing measurements may be explicit assumptions. Cancellation is not a selected option.",
        "scientific_boundary": "Mass balance and numerical feasibility do not establish compatibility, product performance, efficacy, shelf life or legal status."}
