# Agri-formulations

An agent-led formulation design platform for **fertilizers and crop-protection products**, combining ML tools, physical simulations and constrained optimization. Start with a product goal, develop candidate recipes, compare scenarios and refine the design. Experimental data is an optional, limited feedback source for calibration and model checks.

The current product focuses on **goal → agents → recipe candidates → simulations and ML → comparison and optimization → revised design**. It supports useful design work before measurements are available. ELN, LIMS, inventory and laboratory operations are outside the current scope; older lab-operation modules and reports remain historical research work.

Open [the direct published-paper benchmark](reports/paper_benchmark.html) for equation-matched comparisons against reported R² and photodegradation half-lives. It replays 24 published parameter sets and refits the author’s exact equations. Results show partial reproduction and unresolved source discrepancies.

Open [the detailed case study](reports/case_study.html) for plots, measured-versus-modeled results, held-out predictions, physics verification, source discrepancies, and uncertainty. Analysis outputs are CSV/JSON and PNG files in [reports/](reports/).

## Agent-led formulation design studio

The GUI opens a chat-centered formulation studio. Each conversation owns a saved
project with recipe candidates, kinetics, stability, individual-active dose scenarios,
ML-assisted optimization and model comparisons. Optional experimental feedback can
refine relevant model parameters as measurements become available. Completed steps appear while agents work;
you can keep chatting, inspect results, stop runs and resume unfinished calculations.

```bash
python3 -m pip install -e ".[gui,dev]"
python3 -m scripts.run_v12_gui --no-open
```

Open `http://127.0.0.1:9173/`. The previous workbench is at `/classic`, and the campaign interface is at `/legacy`.

If your browser runs on another computer, `127.0.0.1` refers to that computer.
To access the studio over your local network or Tailscale, run
`python3 -m scripts.run_v12_gui --no-open --host 0.0.0.0` on the server, then
open `http://<server-ip>:9173/` using its local-network or Tailscale IP address.
For access through SSH instead, run
`ssh -N -L 9173:127.0.0.1:9173 <user>@<server>` on your computer and open
`http://127.0.0.1:9173/` while that tunnel remains connected.

**SC/EC validation recovery:** local calculations run independently of research;
complete recipe/physics workflows publish a saved comparison in one action.
Qualified aqueous-only EC screens, corrected editor validation, distinct scenario
selection, recoverable exports and the expanded EC/SC/SL/OD/WG/WDG/WP/SG/SP/GR/EW
guide are described in [the validation fixes](docs/v27_validation_recovery.md).

**INR formulation costing and diverse recipes:** inspect source-linked ingredient
prices, yield/processing/packaging assumptions and estimated finished cost per kg,
batch or pack. Agents can research India prices and propose distinct excipient
families; a seeded maximin selector spreads composition variants within bounds.
Missing costs remain explicit. See [costing and recipe diversity](docs/v26_cost_and_recipe_diversity.md).

**Design studies** connect product goals to whole-candidate decisions: compare up
to eight recipes across four physical scenarios, keep test conditions shared,
declare property assumptions and output specifications, inspect Pareto tradeoffs,
then create a variant and rerun. Users and agents share the engine. Exact inputs,
domain failures, optional measured-fit provenance and parent studies remain saved.
See the [design study guide](docs/v24_design_studies.md) and reproduce its independent
numerical checks with `python3 -m scripts.run_v24_design_studies`.

The [critical review and integrity fixes](docs/v25_critical_review.md) cover
finite-bath conservation at long times, derived rheology calibration conditions,
source/runtime fingerprints, complete optimization handoffs and specification
margins. Reproduce their numerical checks with `python3 -m scripts.run_v25_model_integrity`.

**AI + physics design** adds constrained Bayesian optimization to the studio:
search physical parameter bounds, set objectives and required specifications,
inspect Pareto tradeoffs, and reopen directly checked candidates in the simulator.
Both users and agents use the same local engine. Searches preserve exact inputs,
assumptions, failures and reproducible seeds; suggested experiments remain labelled
unmeasured hypotheses. See the [inverse-design guide](docs/v22_ai_physics_design.md)
and reproduce its independent numerical checks with
`python3 -m scripts.run_v22_inverse_design`.

**Parameter sensitivity** sweeps assumed physical inputs around a declared baseline,
ranks their effects on a selected output, and suggests focused validation needs.
Users and agents share the engine, exact-input history and domain checks; no
experimental dataset is required. See the [sensitivity guide](docs/v23_parameter_sensitivity.md)
for the method, interpretation limits and API example.

The **Literature & patents** tab searches Crossref, Europe PMC and Google Patents,
with publication-year filters, patent authority/CPC filters, saved search history,
source-review notes and citation downloads. Manual search works without an agent
connection; agents use the same search tools and project evidence. See the
[literature and patent search guide](docs/literature_and_patents.md).

[AI + physics inverse design and experiment prioritization](docs/v22_ai_physics_design.md) ·
[Formulation design, matched recipe comparisons and shared user/agent simulation models](docs/v21_formulation_design.md) ·
[Conversational formulation studio, Stop/resume and artifact history](docs/v19_formulation_studio.md) ·
[Simple chat, then finalize and run](docs/v18_chat_finalize.md) ·
[Live agent progress, history and recovery](docs/v17_agent_progress.md) ·
[Query-driven recipe creation, tool execution and saving](docs/v16_agent_execution.md) ·
[Current Codex agents and recipe contributions](docs/v15_codex_agents_library.md) ·
[GPT tools and recipe library](docs/v14_gpt_agents_library.md) ·
[Workbench guide, equations and limits](docs/v13_workbench.md) ·
[Measurement import templates](data/workbench_templates/).

Recipe drafts enforce ingredient bounds, total mass, individual active purity and known
costs. Release and stability calculations use explicit scenario inputs or fitted assay
data. Dose mass-balance scenarios are separate from experimentally fitted biological
dose response. Local performance rankings require measured recipes and a passing
recipe-held-out validation gate. Projects retain revision history, raw data, model runs
and reproducible report exports. The GPT-6.1 Sol coordinator selects scientific tools and consults specialist GPT agents.
The default connection uses the current local Codex sign-in; no extra API key is required.
The library includes 17 source-linked published records, five labeled design starters,
and both user-saved and agent-generated drafts.
Stage-specific GPT reviews explain assumptions and propose the next investigation;
the numerical engines validate calculations. Users can request new recipes directly in plain
language, ask agents to execute later framework steps, and reload the automatically saved
project revision with its results and tool history.


## Reproduce

From this directory with Python 3.10 or later:

```bash
python3 -m pip install -e ".[case-study,v2,dev]"
python3 -m scripts.reproduce
python3 -m pytest --disable-plugin-autoload -q
```

The archived source files permit offline reproduction after dependencies are installed. To repeat only model fitting and reporting, use `python3 -m scripts.run_case_study`. If editable installation is unavailable, the workflow adds `src/` to its import path. This execution used the existing Python environment and a workspace-local `.deps/` copy of xlrd; normal installations obtain xlrd through the case-study extra. Exact versions and input/code hashes are recorded in [run_manifest.json](reports/run_manifest.json).

## v2 three-paper benchmark

The version-2 pipeline ([protocol](docs/v2_protocol.md)) benchmarks three frozen studies — Xiang et al. 2026 DN-hydrogel fertilizer (aqueous Phe/Zn cargo release), Tang et al. 2023 tebuconazole nanocarrier, and Paul et al. 2024 herbicide beads — under one reproducible command:

```bash
python3 -m scripts.run_v2_benchmark            # auto device selection
python3 -m scripts.run_v2_benchmark --device cuda
```

Open [reports/v2/v2_benchmark.html](reports/v2/v2_benchmark.html) for the executed benchmark: computed verdicts for every registered claim (transcription checks, equation-matched photolysis refits, ANOVA recomputations, prose/rank audits), the chronological forecast track with inner-split model selection, leave-one-condition/formulation-out transfer, and the GPU physics legs. Raw-source SHA-256 hashes are verified and the execution manifest (split rules, candidates, fixed XGBoost hyperparameters, thresholds, seeds, device) is frozen **before** any fitting. Reusable logic lives in `src/agriformulations/benchmark_v2/`; the Xiang 2026 extraction adapter is `research/v2_fertilizer/extract.py`; the v2 selection registry (including the excluded 2025 rhizobacteria candidate) is in [research/search_log.md](research/search_log.md).

GPU use follows the protocol's compute rules: a fixed-hyperparameter XGBoost comparator trained on CUDA on the exact same outer splits as the CPU candidates (no hyperparameter search), batched analytic diffusion predictions, and a batched torch finite-volume PDE leg gated by mass balance (≤1e-6), mesh/time-step convergence and CPU/CUDA float64 agreement (abs ≤1e-8, rel ≤1e-6). These scenario sweeps are synthetic sensitivity calculations, not new experimental data.

## v3 formulation catalog and agent layer

The v3 phase begins the framework roadmap ([protocol](docs/v3_protocol.md), [risk register](docs/risk_register.md)):

```bash
python3 -m scripts.run_v3_catalog
```

Open [reports/v3/v3_catalog.html](reports/v3/v3_catalog.html) for the hybrid catalog: five public studies (the three v2 studies plus converted v1 azadirachtin and Zhu-fertilizer datasets) on one contract with a formulation ontology ([ontology.py](src/agriformulations/ontology.py)), an assay-protocol registry declaring sink conditions, a unit-family gate, independent-unit counts, ontology coverage, and the v2 verdict engine applied to all claims. Internal lab data enters through config-driven adapters (plate reader, dissolution export, generic ELN) that stamp provenance and refuse agent-screened ingests without an approved proposal. The agent layer is two-tier: dev-time contracts in [docs/agents/](docs/agents/) and runtime proposals with human review gates and a hash-chained activity log — agents propose, humans review, deterministic code computes. The v3 exit gate (≥8 public studies, ≥40 recipes, ≥150 curves, ≥80% core ontology coverage) is evaluated by the pipeline itself and exported honestly ([v3_gate.json](reports/v3/v3_gate.json)); it is not yet met, and the literature monitor's screening proposals are the intended growth path.

## v4–v6: physics, surrogates and inverse design

```bash
python3 -m scripts.run_v4_physics     # multi-geometry physics + identifiability (GPU)
python3 -m scripts.run_v5_surrogates  # curve-summary surrogates + LOSO + registry
python3 -m scripts.run_v6_design      # solver-verified inverse design behind review gates
```

**v4** ([report](reports/v4/v4_physics.html)): verified slab/cylinder/sphere finite-volume solvers (mass balance ≤1e-6, monotone mesh convergence, analytic agreement, CPU/CUDA float64 gates), heterogeneous diffusivity with harmonic-mean faces, finite-bath coupling (plateau K/(1+K), sink limit), quasi-static swelling (k_s=0 reduces exactly), and the published identifiability table: D and L are jointly unidentifiable from release data — only D/L² is recoverable, and all later phases respect that.

**v5** ([report](reports/v5/v5_surrogates.html)): Weibull curve-summary targets, a fixed-hyperparameter structured GP with train-median imputation plus missing indicators, hierarchical study effects with shrinkage, and Mondrian split-conformal intervals calibrated on nested held-out studies. The only acceptance path is leave-one-study-out; the run of 2026-10-19 honestly reports coverage 0.847 (just outside the 0.90±0.05 band) and no utility pass against the matched-time-mean baseline over 44 curves — weak-evidence pilot numbers, exported as they are. The frozen [model registry](reports/v5/model_registry.json) records valid input domains and prohibitions; the claims-drafter agent scales audit prose without touching computed verdicts.

**v6** ([report](reports/v6/v6_design.html)): inverse design over identifiable combinations only (effective rate and plateau fraction; D and L never proposed separately). The batched GPU grid evaluates thousands of candidates against a design brief, ranks the feasible region, and re-scores every shortlisted candidate with the independent 80-shell finite-volume solver — surrogate-only shortlists cannot ship. The shortlist becomes a `design_shortlist` proposal that a human must approve (`python3 -m scripts.review`) before any recommendation renders; the current proposal is pending by design, and the automated self-approval of agent proposals is blocked by the gate itself.

## v7: lab operations

```bash
python3 -m scripts.run_v7_labops
```

Lab-facing capabilities ([protocol](docs/v7_protocol.md), [report](reports/v7/v7_labops.html)): **batch verdicts** against product specs (early-time endpoint forecast with inner-split selection, PASS/FAIL/BORDERLINE, 3-sigma drift control vs reference batches — dry-run verified on a labelled synthetic batch); **Arrhenius temperature dependence** (synthetic-gated; first catalog result: Tang 2023 TEB release Ea = 35.5 kJ/mol, bootstrap CI [31.8, 39.1]; extrapolation refused); a **composition-bridge surrogate** with hard domain refusal (machinery verified on synthetic data; honest zero-overlap report — internal batches with recorded composition are the unlock); an **audit dossier export** (provenance chain + verdicts + manifests + agent-log verification in one zip); and an **assay-protocol matching service** (which calibrations transfer to a new assay). GUI work is deferred by decision.

## v8: sulfoxaflor campaign

```bash
python3 -m scripts.run_v8_campaign
```

A four-direction patentability-scoping campaign for India-relevant sulfoxaflor formulations ([protocol](docs/v8_protocol.md), [report](reports/v8/v8_campaign.html), [risk-register amendment A1](docs/risk_register.md)). Deterministic scoring of 29 enumerated concepts (CR/nano, seed-treatment FS, mixtures, OD/SE/ULV) against retrieval-pinned prior-art, component, compatibility and India-use registries: weighted-Jaccard prior-art flags with a scope-aware knockout rule (the marketed single-a.i. SC does not fence binaries; the anti-drift WG claim does; the CN entry blocks only the cyantraniliprole pair — the declared positive control), India relevance from metadata joins, and analogue transfer of release-kinetics regions from the five curve-bearing catalog studies (no sulfoxaflor kinetics study exists — every region is labelled hypothesis-generating and widened by its analogy weight). The 11-concept shortlist is top-3 per direction, FV-solver-verified where a kinetics claim exists, exported with deterministic data-generation plans (Sun 1950 CTC, Colby 1967, CIPAC MT 47.3 in WHO 342 ppm hard water, and a comparator at the pinned 75–100 g a.i./ha dose band), and gated behind a `campaign_shortlist` proposal pending human review. Two scoring passes must agree byte-for-byte. Nothing in the phase is a patentability, FTO, registrability, efficacy or cost conclusion.

## v9: stereochemistry layer

```bash
python3 -m scripts.run_v9_stereo
```

Makes the framework's stance on chirality explicit and machine-checked ([protocol](docs/v9_protocol.md), [report](reports/v9/v9_stereo.html), [amendment A2](docs/risk_register.md)): a controlled **stereo descriptor** on every catalog ingredient and v8 component (50 ingredient slots covered, `unspecified` counted honestly, L-phenylalanine the one source-pinned single enantiomer; sulfoxaflor is a single-stereoisomer active), a **`chiral_resolution` flag** on assay protocols, the **stereo-blind-physics assumption registered** (Fickian kernels are exact in achiral media; chitosan/alginate carriers flagged as chiral with enantioselective release explicitly unmodeled), a synthetic-gated **multi-species capability** with its identifiability statement — resolved curves recover both enantiomer rates (12/12 trials), while the total-a.i. curve is jointly unidentifiable at the campaign tolerance (47 passing (w′, k_R′, k_S′) triples) and exactly assignment-degenerate under label swap, so v1–v8 calibrations recover only the loading-weighted effective rate — and an **additive stereo overlay** on the v8 campaign: 17 of 29 concepts flag stereo-regime mismatches (single-stereoisomer sulfoxaflor transferring from achiral/racemic/natural-product analogues), overlay widening 1.00/1.15/1.30, frozen v8 exports untouched, no new proposal — the overlay feeds the pending v8 review.

## v10: benzovindiflupyr chiral campaign

```bash
python3 -m scripts.run_v10_campaign
```

The first campaign built around a **chiral active chosen for its patent window**: benzovindiflupyr — a Syngenta SDHI fungicide marketed as a racemate with basic patent expiry 2028, enantioselective bioactivity published (Chen et al. 2023) and ~69% of chiral actives sold as racemates (Jeschke 2025) as the industry gap ([protocol](docs/v10_protocol.md), [report](reports/v10/v10_campaign.html)). The v8 machinery runs on a benzovindiflupyr evidence set (`data/v10/`) with two structural additions: an **enrichment axis** — 28 concepts enumerate racemic and enantioenriched variants, prior art carries enrichment tags under a scope-aware coverage guard (the racemic Elatus binary blocks only the racemic azoxystrobin twin; the enantiomer-characterization publication carries no format tags and can never knock out a formulation concept; enantioenriched solo concepts score clear at S 0.40 where their racemic twins sit adjacent at 0.50) — and **stereo-first-class transfer**: the v9 regime distance widens transferred regions at design time (the Tang tebuconazole study — racemic chiral fungicide nanoparticles — becomes the stereo-clean `match` analogue; enantioenriched transfers drop to `related` ×1.15). The 12-concept shortlist (7 enantioenriched) is FV-solver-verified where applicable and gated behind a pending `campaign_shortlist` proposal; every enantioenriched shortlisted concept carries mandatory chiral-release-assay and enantioselective-bioassay data plans, because the v9 identifiability result forbids per-enantiomer claims from total-a.i. data. v8 exports remain byte-identical after the shared-package extension.

## v11: zero-order membrane kernel

```bash
python3 -m scripts.run_v11_zero_order
```

Closes, inside the repo, the loop the sulfoxaflor R4 session opened ([protocol](docs/v11_protocol.md), [report](reports/v11/v11_zero_order.html)): the claim pair (≤20% at day 5, ≥80% at day 35) is **analytically infeasible for the entire Fickian family** — the family's best late/early ratio is √(t₂/t₁) = 2.646, putting the day-35 ceiling at **0.478** (matching the R4 session's 47.5% numerical anchor) with zero feasible candidates — and **designable under the membrane-controlled kernel** `F(t) = plateau·clip(k₀(t−lag), 0, 1)`: 12,667 feasible (k₀, lag, plateau) grid points with the analytic corner (lag 0, plateau 1, k₀ ∈ [0.0229, 0.0400]/d) verified inside the region. A closed-form three-parameter fit recovers all parameters from noisy curves (11/12 trials), with an exported identifiability requirement: the assay window must span reservoir depletion or the plateau is under-observed. Analysis machinery only — no proposal, no recommendation; mechanistic feasibility under the stated kernel assumptions, nothing about efficacy or patentability. Scope decisions recorded in the protocol: runner consolidation rejected (byte-frozen per-campaign exports), catalog growth / stereo-resolved curves / composition bridge remain external-data unlocks, GUI deferred.

## v12: local GUI

```bash
python3 -m scripts.run_v12_gui            # serves at 127.0.0.1:9173
python3 -m scripts.run_v12_gui --selftest # headless checks (chained by reproduce)
```

The GUI un-defers the v7 decision by user instruction ([protocol](docs/v12_protocol.md)): requirements in, simulation graphs out. Four panels over the deterministic engines — a **release simulator** (Fickian sphere or zero-order membrane; optional claim pair with PASS/FAIL chips), **claim feasibility** (user claim pair → Fickian family ceiling scan with the analytic ratio bound, zero-order feasible region and corner), a **campaign explorer** (v8/v10 concept scatter by prior-art flag, transferred-region intervals by stereo regime, frozen shortlist tables), and the **v9 identifiability demonstration** (observed total curve vs degenerate alternatives) — plus an **ask console**: free-text questions routed deterministically to the engines (claim feasibility with numbers parsed from the question, blocked/adjacent/clear listings, top-N rankings with bar charts, concept lookups and comparisons, carrier/enrichment filters, stereo descriptors, pending-proposal status, identifiability), each answer naming its route and engine, with a capability-list fallback that never fabricates. Stdlib-only server, fully offline (no CDN or external URLs — tested), strict server-side validation (400s), deterministic JSON; a view, never a source — no number exists that the engines didn't compute, and no efficacy or patentability claim renders. Palette validated with the dataviz six-checks validator (categorical `#0c7f5d/#eb6834/#2a78d6` light on white, selected dark steps, status colors always icon+label); charts are inline SVG with crosshair/per-mark tooltips and table views; the page script is executed headlessly in the test suite via a DOM stub.

## Published evidence

| Domain | Source | Data used |
|---|---|---|
| Fertilizer | [Zhu et al., Nature Communications, 2026](https://doi.org/10.1038/s41467-026-68295-6) | 19 release means for fulvic-like acid and potassium, original XLS and SDs |
| Biopesticide | [Zhang et al., Nature Communications, 2025](https://doi.org/10.1038/s41467-025-57028-w) | 54 release means, 162 replicate entries; two azadirachtin carriers at three pH levels |
| Herbicide archive | [Paul et al., Scientific Reports, 2024](https://doi.org/10.1038/s41598-024-53820-8) | 272 accepted mg/g observations across 18 curves; 15 omissions and one suspected typo preserved separately |

These are recent data-accessible studies chosen after literature screening, not a claim of exhaustive coverage of the latest literature. [Search log](research/search_log.md), [methodological review](docs/methods_review.md), [evidence audit](docs/evidence_audit.md), and [formulation catalog](data/formulation_catalog.json) provide selection and provenance details.

Source workbook/prose discrepancies are retained. Observations were neither generated by AI nor reconstructed from fitted curves. The 2024 mg/g values are not normalized without known initial loading and are not pooled with fractional release.

## Library

```python
from agriformulations import fit_release, release_fraction, sphere_finite_volume

# Times in hours; release is a fraction, not percent.
fit = fit_release([0, 2, 5, 10, 20], [0, .1, .3, .55, .8], "weibull")
predicted = fit.predict([25, 30])

# An assumed ideal sphere under perfect-sink conditions.
simulated = sphere_finite_volume([0, 24, 48, 96], rate=0.002, shells=80)
```

The evidence schema distinguishes published measurements, published fitted values, derived quantities, and synthetic values. Published records require sources and locators; derived records require method and parents. Formulations carry domain, ingredient, unit, condition, and property records.

Six models are available: first-order, burst first-order, Weibull, Higuchi, Korsmeyer–Peppas, and homogeneous spherical diffusion. The finite-volume solver independently solves radial diffusion and is checked against the analytic solution and mesh refinement.

The case study evaluates early-time-to-late-time forecasting, and Extra Trees/Gaussian-process prediction with an entire pH withheld for both known carriers. Three pH folds from one study provide a small pilot benchmark; they do not establish predictions for new formulation chemistry. D/R² is calibrated; an assumed radius converts it to effective D. That value is not a measured molecular diffusivity.

## Agent work performed

Three actual sub-agents handled library/physics implementation, literature/source extraction, and independent methods/data auditing. The coordinator integrated the evidence, ran the benchmarks, generated the report, and resolved integration issues. The reviewed task contracts and handoffs are recorded in [docs/agent_workflow.md](docs/agent_workflow.md). AI assisted source finding and code construction; numerical results come from reproducible code acting on publisher data.

## Scope and extension

This run approximately reproduces published release behavior. It does not reproduce synthesis chemistry, crop yield, toxicity, pest mortality, or field efficacy. It includes a real continuum diffusion simulation; molecular dynamics and DFT were not run.

For a defensible composition-to-performance model, extend the catalog with independent recipes and measured ingredient fractions, particle sizes, loading, protocols, and replicates across several publications. Validation must then hold out complete studies and recipe families. Current fitted curves should not be marketed as a general formulation optimizer.

Software and original data have separate rights. Author/publisher attribution and source licences are retained in manifests. No licence for commercial redistribution of source workbooks is asserted.

## GPU execution

CUDA is selected automatically for batched diffusion prediction when PyTorch and a GPU are available; otherwise this workload uses NumPy on CPU. An explicit CUDA request fails clearly if CUDA is unavailable:

```bash
python3 -m scripts.gpu_simulation --device cuda
python3 -m scripts.benchmark_paper
```

The executed CUDA run produced 15,859,712 predictions over 131,072 hypothetical radius/diffusivity scenarios, checked against the independent CPU analytical solution. [Device and verification record](reports/gpu_execution.json). These scenarios are synthetic sensitivity calculations, not new experimental data or published-paper validation targets.

The small SciPy curve fits and sklearn pilot training use CPU because their datasets contain tens of observations. GPU support is an optional dependency (`.[gpu]`); install a PyTorch build appropriate to the machine. The complete reproduction workflow automatically runs both the device-selected simulation and the direct paper benchmark.
