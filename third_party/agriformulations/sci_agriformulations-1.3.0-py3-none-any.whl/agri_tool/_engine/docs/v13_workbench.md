# Recipe-to-experiment R&D workbench (v13)

**Agent and library update:** [v14 GPT-6.1 Sol agents and selectable recipe library](v14_gpt_agents_library.md) supersedes the deterministic-only agent behavior described below.

Implemented for the 2026-10-20 request to prioritize recipe suggestion, in silico modeling,
stability, kinetics, dosage and experimentation, plus an agent system in the GUI.

## Launch

```bash
python3 -m pip install -e ".[gui,dev]"
python3 -m scripts.run_v12_gui --no-open
# Optional separate workspace database / port:
python3 -m scripts.run_v12_gui --no-open --port 9174 --workspace data/workbench/workspace.sqlite3
```

The new workbench is at `/`. The original campaign/simulation interface is at
`/legacy`; its frozen campaign exports and human-review proposals are preserved.
The default server binds localhost. There are no CDN or external browser dependencies.

## Workflow

1. **Product brief:** record active/nutrient identity, crop/system, target, application,
   formulation format, objective and project name.
2. **Suggest recipes:** select actual ingredient identities and grades; enter minimum
   and maximum mass percentages, technical purity, suppliers/lots and optional prices.
   The format-scaffold button supplies editable role examples for SC, EC, WG,
   controlled release and fertilizer. These are not validated material recipes.
   Set total pure-active content and batch mass. For multiple actives, supply each
   individual pure-active target; targets must sum to the total.
3. **Select recipe and modeled active:** weigh-outs preserve total batch mass and
   purity-corrected active loading. Select the active whose release, assay and dose
   are being investigated. Combined active content is not used as a biological
   potency equivalent.
4. **Kinetics:** choose membrane zero-order, Fickian sphere, first-order or Weibull.
   Enter measured-fit parameters or explicit scenario parameters. Record the basis.
   Inspect release specifications, t10/t50/t90, mass compartments and rate sensitivity.
5. **Stability:** use chemical-assay fits or supply a chemical loss rate at a reference
   temperature and a chemical-degradation activation energy. Compare temperatures
   or a time/temperature profile. The separate Stokes screen estimates idealized
   sedimentation/creaming, not physical shelf life.
6. **Dose scenarios:** choose a target *available-active mass* at an evaluation day,
   storage retention, deposition and optional density/spray volume/product ceiling.
   The selected recipe supplies the individual active fraction. Transfer chemical
   endpoint retention only after choosing the relevant temperature. Model biological
   response separately using imported dose-response observations.
7. **Experiments:** select the number of recipes, independently prepared batches,
   technical readings, sampling times, process-factor levels and reference. Export
   a randomized mixture/process run sheet and a format-specific test queue.
8. **Results:** upload CSV/XLSX, preview mappings, filter recipes and assay conditions,
   confirm time/value units, method and batch identifiers, and inspect exclusions.
   Fit release, chemical stability or dose response. Fit parameters can populate
   subsequent scenarios for the matching recipe and active.
9. **Learning:** supply a response name/unit and one measured response per batch
   (technical replicates are averaged). At least eight distinct measured recipes
   are required. Performance ranking is enabled only if leave-one-recipe-out MAE
   improves over its matched training-mean baseline by at least 10%.
10. **Save/export:** SQLite saves append revisions and refuse stale overwrites.
    ZIP export contains a standalone HTML report with plots, project JSON, recipe
    and run-sheet CSVs, original raw files, observations, exclusions and source hashes.
    Project JSON can be restored in the GUI.

## Recipe suggestion algorithm

The generator samples conditional feasible intervals within user-specified ingredient
bounds while enforcing sum(fractions)=1. Each active's technical fraction equals its
pure-active target divided by technical purity. Candidate identifiers include material,
composition, batch and process information. Sampling is deterministic for a fixed seed.

Ranking initially uses known ingredient cost, followed by stable identifiers. Unknown
prices remain unknown. A cost ceiling requires prices for every component. Ingredient
compatibility, manufacturability, efficacy and stability are **not** assigned numerical
scores from an invented relationship.

Local learned rankings use a fixed-regularization linear mixture regression. Each
whole recipe is held out; batch means prevent extra technical replicates from becoming
independent training recipes. Prediction also requires matching ingredient identities,
format and preparation process, plus membership in the convex hull of measured
compositions. More complex chemistry/process models require appropriate data and new
validation. This model is for prioritizing experiments.

Mixture and process-factor treatment follows the statistical distinction described by
[NIST mixture experiments](https://www.itl.nist.gov/div898/handbook/pri/section5/pri54.htm)
and [NIST mixture/process designs](https://www.itl.nist.gov/div898/handbook/pri/section5/pri565.htm).
The implemented maximin screening is not claimed to be D-optimal or sufficient to identify
every mixture interaction.

## Scientific equations and limits

- **Release:** existing verified sphere kernel or explicit first-order/Weibull/membrane
  laws. All workbench times are in days; rates are per day. Sphere release identifies
  an effective rate, not independent diffusivity and radius.
- **Degradation:** reservoir and available-active compartments undergo separate
  first-order loss. Symmetric degradation/release splitting conserves reservoir +
  available + degraded = initial active. Conditional release follows the chosen
  cumulative release law. Grid convergence matters when loss is rapid.
- **Milestones:** absolute fractions of initial loading; a 90% milestone is unavailable
  when the model cannot attain it in the requested horizon. Membrane depletion uses
  the first crossing of the plateau, not the end of a flat plotting segment.
- **Chemical stability:** k(T) = k_ref exp[Ea/R (1/T_ref - 1/T)],
  retained fraction = exp(-integral k(T) dt). Arrhenius fits use batch-normalized
  chemical assays with a day-zero baseline, at least three times per batch/temperature
  and at least two temperatures. Two-temperature fits are flagged as weakly identified.
  Temperatures outside measured calibration are refused unless explicitly requested
  as extrapolation scenarios. Release Ea must not substitute for chemical-degradation Ea.
- **Physical screen:** Stokes velocity = delta_rho g diameter^2 / (18 viscosity).
  Dilute isolated spheres/Newtonian-liquid assumptions exclude aggregation, yield stress,
  crystal growth and coalescence. It cannot establish a storage-stability pass.
- **Exposure dose:** product kg/ha = target available g/ha /
  (1000 × active mass fraction × storage retention × deposition × modeled availability).
  The researcher supplies the exposure target. The tool does not infer crop uptake,
  pest control, phytotoxicity or a permitted application rate.
- **Dose response:** baseline-adjusted Hill curve with a fixed 100% upper asymptote.
  Requires an untreated control and four positive dose levels. Reported target doses
  must lie within tested dose and observed response ranges. mg/L and g active/ha
  remain distinct assay units; laboratory concentrations are not converted into field
  efficacy. No calibrated confidence interval or field registration claim is produced.
- **Uncertainty:** release-rate and deposition envelopes are labeled sensitivity
  scenarios. Tail-holdout MAE, residuals and recipe-held-out MAE are validation summaries,
  not prediction intervals.

Physical/chemical test queues should be finalized against the product and method.
Pesticide quality references include the
[2025 FAO/WHO chemical pesticide specification manual](https://www.who.int/publications/b/81994).
Field dose establishment requires context-matched biological evidence and confirmation
trials; see [FAO minimum effective dose tests](https://www.fao.org/pesticide-registration-toolkit/registration-tools/data-requirements-and-testing-guidelines/study-detail/en/c/1186953/).

## Agent system

Six named specialist tool agents are orchestrated locally: Recipe designer, Kinetics
modeler, Stability analyst, Dose scenario analyst, Experiment planner and Evidence
reviewer. The assistant accepts supported natural-language commands and questions,
uses the visible active-project inputs, and returns a tool trace with interpreted inputs,
assumptions and an input digest. Example commands are clickable in the GUI.

- "Suggest 12 recipes with 20% active and a 1000 g batch"
- "Simulate release kinetics for 60 days"
- "Simulate stability at 25, 40 and 54 C for 180 days"
- "Calculate a dose scenario for 50 g/ha available active at day 35"
- "Plan experiments for 6 recipes with 3 independent batches"
- "Run the complete workflow"
- "Why is this recipe ranked first?"
- "What evidence is missing before experimentation?"

This is deterministic language routing, not a general language model. Unsupported
questions receive capabilities and limits. No API key or network call is needed.
Historical campaign questions can route to the original deterministic question engines.
Recipe suggestions remain drafts; the agents do not approve existing campaign proposals.

## API and storage

`GET /api/rnd/bootstrap`, `GET /api/rnd/projects`; JSON POST actions under
`/api/rnd/`: recipes, kinetics, fit-release, stability, fit-stability, dosage,
fit-dose-response, experiments, preview-import, import, learn, ask, save, load, export.

Default database: `data/workbench/workspace.sqlite3`, excluded from version control.
Recipe/active model runs are retained in analysis history. Raw imports are preserved,
not silently overwritten. A saved project can contain confidential laboratory records;
keep its database and exports in the lab's intended storage location.

## Corrections to existing behavior

- Excel dissolution files use explicit format dispatch, avoiding DataFrame truth tests.
- Process notes and optional numeric values survive serialization.
- Explicit percentages at and below 1% are divided by 100.
- Incomplete explicit claim questions are rejected rather than silently completed.
- Claim endpoints are evaluated by the exact kernel, independent of the plotting grid.
- An analytic lagged membrane witness covers feasible targets outside the frozen scan.
- Fickian scan failure is distinguished from a proven family bound where appropriate.
- Legacy GUI corner intervals render only when that zero-lag corner is nonempty.
- Legacy chart units/colors are corrected without changing frozen campaign CSVs.

## Validation

```bash
python3 -m pytest --disable-plugin-autoload -q
python3 -m scripts.run_v12_gui --selftest
```

New tests cover mixture bounds/mass/purity/cost, degradation conservation, first-crossing
milestones, chemical Arrhenius recovery/extrapolation, Stokes unit conversion, dose algebra,
dose-response inversion and unit separation, chronological release fitting, independent
batch planning, import/QC/source preservation, recipe-held-out utility/domain refusal,
project revisions/conflicts, raw-file exports, agent chains and HTTP contracts.

The Node DOM harness executes the new GUI against the live API through recipe generation,
models, dose, planning, assistant and saving. It is a functional harness, not an installed
browser or a visual/accessibility certification.
