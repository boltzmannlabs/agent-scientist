# Structured formulation workspace and simulation catalogue

The studio at http://127.0.0.1:9173/ is a formulation design and simulation workspace for users and agents. Chat is the centre. Start with a product goal and recipe candidates; compare results from matching scenarios. Experimental data is optional and can calibrate or check a model when available. **+ Recipe**, **+ Data** and **New simulation** are available above the result canvas. Manual recipe design and simulations do not require an agent connection.

## Recipe inputs

**+ Recipe** opens an editable ingredient table. Users can enter percentage w/w or grams for the declared batch, technical purity, ingredient role, optional prices, supplier/lot and preparation steps. The editor shows total percentage and pure-active loading. Switching the amount basis converts entered quantities. Saving a changed recipe creates an immutable composition/process version; existing results retain their original recipe identity.

Exact recipes must total 100%. Bounded mode accepts explicit minimum/maximum percentages and generates 1–12 feasible candidates. Active targets are computed from technical loading and purity; the numerical recipe engine enforces individual-active constraints, ingredient bounds and mass balance. These checks do not infer compatibility or product performance.

CSV/XLSX recipe import uses name/ingredient, role, pct/percentage, purity_pct/purity and optional min_pct, max_pct, cost_per_kg, supplier and lot columns. Explicit mappings are supported by the API. The original import source and its SHA256 remain in recipe provenance. The form provides an ingredient CSV template.

## Experimental data

The **Data** tab separates original observations, QC review and fitted parameters:

1. Import CSV/XLSX, select the exact recipe version and individual active, assign units/method and map columns.
2. Select a source recipe label or assay condition when the file contains multiple systems.
3. Review observations, preserve source/QC exclusions and record any additional excluded source rows.
4. Fit actual observations, inspect diagnostic curves and reuse a compatible fit in the simulation builder.

Supported data kinds: release, chemical assay, dose response, rheology, solubility, rainfastness, milling, suspension separation, packaging water content, combined-active observations and other numeric properties. Each type has a downloadable CSV header template. Physical-property imports require explicit x/value units; automatic unit conversion is not assumed.

Direct fits cover existing release/chemical/dose-response engines, Herschel–Bulkley rheology, temperature-dependent solubility, a single-exponential rainfall wash-off relation and an asymptotic energy–particle-size milling relation. Other numeric properties can receive a descriptive linear fit without automatically becoming a mechanistic calibration. Combined-active fitting uses measured single-active dose axes to build a Bliss reference and reports observed-minus-reference differences; it does not automatically classify synergy.

Dataset IDs bind source hash, measurement kind, recipe, active identities, mapping and assay context. Reviews preserve the original file and source-row numbers. Fits bind the exact dataset/review digest, engine version, calibration range and identified batch count. Changing a dataset review or engine version requires refitting before a fit can be applied. Edited fitted coefficients become an assumed scenario. Extrapolation beyond supported measured ranges requires an explicit scenario choice.

## Simulation builder

Select a model, recipe version and individual active; inspect units, equations and assumptions; enter parameters or apply a matching measured fit; then **Run simulation**. Users can apply explicit inputs across project recipes/actives, prepare several scenarios with **Add to batch**, or run a batch of up to 50 requests. Combined-active studies require a distinct second active in the same recipe.

Every completed numerical result appears in **Results**, with scalar metrics, charts, tables, exact inputs, model version, provenance and downloads. A saved-scenario selector includes all historical scenarios. Original kinetics, stability and dose tabs remain available. Results can be attached to chat for interpretation or reopened in the builder as a new scenario.

### Available local models
The catalogue marks equation models that benefit from product-specific calibration, first-pass or empirical screens, and exploratory environmental calculations. Start with active solubility and dilution compatibility, rheology, suspension separation, release and chemical storage stability when those questions fit the product. Spray, rainfastness, packaging, manufacturing and soil fate remain exploratory unless supplied with formulation- and use-specific inputs. Use matched-scenario recipe comparisons to inspect tradeoffs; the platform does not assign a universal best recipe score.


| Model key | Calculation | Interpretation |
|---|---|---|
| kinetics | First-order, zero-order, Fickian or Weibull release with reservoir/available-active degradation | Explicit release scenario or measured-parameter fit; no uptake/efficacy inference |
| stability | First-order loss with Arrhenius temperature dependence and temperature profiles | Chemical retention; physical shelf life is separate |
| dosage | Individual-active exposure mass balance with first-order release/deposition/storage assumptions | Hypothetical product quantity, not a field-use recommendation |
| suspension | Particle-bin Stokes settling/creaming, hindered-settling correction and a yield-stress force screen | No flocculation, compression/cake or redispersion prediction |
| rheology | Herschel–Bulkley flow curves and approximate nominal-shear pipe-pressure screening | Steady constitutive relation; no turbulence or equipment design guarantee |
| solubility | van't Hoff temperature relation, monoprotic pH correction, log-linear cosolvency and empirical precipitation kinetics | Ideal single-solute scenario; excludes activity/polymorph/nucleation complexity |
| dilution | Dilution-path active supersaturation with optional monoprotic pH correction and CaCO3 ionic-product screen | A first-pass precipitation screen, not a universal compatibility, emulsion or flocculation prediction |
| spray | Spherical droplet drag/terminal settling, steady crosswind and d² evaporation to a dry residue | No nozzle breakup, turbulence or validated drift footprint; not AGDISP/AgDRIFT |
| spreading | Spherical-cap footprint, random overlapping coverage and constant-angle drying | Ideal surface; excludes roughness, absorption and hysteresis |
| rainfastness | Drying-dependent bound/labile deposit fractions with rainfall wash-off rates | Requires measured calibration for quantitative formulation comparisons |
| manufacturing | Empirical energy-size response, mixing-CV decay and lumped heat balance | No CFD or scale-up guarantee; single-phase thermal model |
| packaging | WVTR/linear-sorption water balance and empirical first-order solvent loss | Package/condition-specific coefficients; no leaks/seal failures |
| mixture_response | Hill single-active curves with Bliss or implicit Loewe reference surfaces | A reference does not demonstrate interaction; fixed-ratio products sample a line in the dose matrix |
| soil_fate | Sorption-retarded, well-mixed root-zone balance with competing leaching/runoff/degradation | Conservative screening calculation, not PRZM/PWC or a site/regulatory assessment |
| robustness | Seeded bounded parameter sampling, optional Gaussian-copula correlation and conditional specification probabilities | Probabilities depend on declared distributions; not automatic statistical confidence |
| sensitivity | One-at-a-time linear/log parameter sweeps with baseline replay and output-effect ranking | Ranges and baseline determine ranks; interactions and correlations are excluded |
| geometry_release | Sphere, cylinder and slab diffusion eigenmode series into a perfect sink | Uniform loading and constant diffusivity; radius or slab half-thickness |
| finite_bath | Coupled conservative particle/bath finite-volume diffusion solved by an eigensystem | Well-stirred bath, equal partition coefficients; equilibrium K/(1+K) |
| swelling_release | Quasi-static expanding-length correction to geometry-specific diffusion | Boundary-motion advection, erosion and porosity changes excluded |

The interface and agents receive the same catalogue fields, units, bounds, example inputs, equations and model limitations. Example defaults are labelled unvalidated assumptions. Higher-fidelity external simulators are not silently substituted by these local screens.

Method references include the [COMSOL Herschel–Bulkley documentation](https://doc.comsol.com/6.4/doc/com.comsol.help.pipe/pipe_ug_fluidflow.05.42.html), [primary work on additive dose-response references](https://pmc.ncbi.nlm.nih.gov/articles/PMC5808155/) and [EPA environmental modelling documentation](https://www.epa.gov/endangered-species/models-and-tools-national-level-listed-species-biological-evaluations-triazine). These references do not imply those software packages were executed or validate this implementation.

## Agent tools and API

Agents can use:

- list_simulations: inventory, one detailed schema, or key=all for every schema in one call.
- run_simulation / run_simulation_batch: the same validated models used by the manual builder.
- list_datasets / fit_dataset: actual imported observations and compatible measured fits.
- save_manual_recipe: exact user composition or explicitly bounded candidates.

Discussion mode permits catalogue/dataset discovery but does not execute or save scientific work. Product-development mode also exposes the extended catalogue tools for additional requested studies. Agents are instructed to batch related requests and avoid unrelated simulations or fabricated calibration.

New GET endpoints: /api/studio/catalogue, /api/studio/datasets and /api/studio/dataset.
New POST endpoints: /api/studio/recipe-preview, /api/studio/recipe, /api/studio/simulate, /api/studio/data-review and /api/studio/fit.
Project-owned recipes, datasets and fits are resolved on the server. Cross-project references, invalid units, nonfinite values and unsupported input keys are rejected.

A simulation request has model, recipe_id, active_name and inputs, with optional active_b_name, fit_id, comparison_dataset_id, allow_extrapolation and assumptions. The combined-active model supports comparison against an actual matching measured combination dataset. It preserves descriptive differences without asserting statistical interaction.

## Runs and persistence

Existing project/session identities and scientific revisions remain in the existing SQLite workspace. New results use the existing immutable artifact history and append-only project revisions. Numerical results are cached by validated inputs, individual-active loading and engine version. Scenario records also retain notes, fit references and recipe identity.

Batches run in background workers, publish/checkpoint each completed model and keep navigation/composition usable. Stop checks occur between models and inside sampling/flight loops. Resume reuses completed matching scenarios and restarts an unfinished numerical stage; Monte Carlo progress is not misrepresented as a completed distribution. Newer edits/imports cannot be overwritten by late revisions.

Exports retain scientific documents, original measurement sources, full artifact history and session messages. Result cards provide numerical CSV and complete input/result JSON.

## Validation

Tests cover all 18 model outputs, Newtonian/Stokes/zero-flux limits, dose-reference behaviour, mass conservation, finite-bath equilibrium for three geometries, zero-swelling equivalence, seeded sampling, known-parameter fit recovery, source immutability, CSV/XLSX entry, ownership/revision conflicts, HTTP endpoints, no-model-call user execution, agent batch execution, stale-fit rejection, stop and resume.

Run the relevant suite with:

```bash
python3 -m pytest --disable-plugin-autoload -q tests/test_simulation_platform.py tests/test_studio.py tests/test_rnd_workbench.py tests/test_agent_runs.py tests/test_codex_connection.py tests/test_product_development.py tests/test_gpt_agents_library.py tests/test_chat_finalize.py tests/test_agent_recipe_execution.py tests/test_research_outcomes.py tests/test_extended_models.py tests/test_v12_gui.py
python3 -m scripts.run_v12_gui --selftest
```
