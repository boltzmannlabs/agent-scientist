# Literature and patent search

For a crop-specific question, enter the crop and disease/pest in the query and
use **Focus crop, active or target** for aliases of one focus, for example
`coconut; Cocos nucifera`. Relevance order prioritizes literal matches in titles,
then abstracts, then remaining query-term coverage in titles and retrieval ranks
across providers. A larger bounded
pool is retrieved when focus aliases are supplied. Unmatched records remain
visible with an explicit label. **Newest** preserves date order. The match count
describes available metadata; it does not establish study quality or efficacy.

Agents receive short previews of recent saved searches and are instructed to
compare source-linked directions, preserve crop corrections, and make a
provisional selection when the user asks them to suggest targets or actives.
They must distinguish other-crop evidence, laboratory results and field outcomes
instead of treating all search hits as support for a combined product. New
`focus_terms` arrays are accepted in search parameters and agent `filters_json`.

If agent synthesis times out after research retrieval, the response retains
source links, labelled abstract excerpts, evidence limits and a next design step.
The timeout warning remains visible; this recovery is not presented as a completed
scientific comparison. Full retrieval snapshots remain unchanged in saved projects.

Open **Literature & patents** in the formulation studio’s results canvas.
No recipe or agent connection is required. An internet connection is needed for
new searches; saved searches and sources remain available offline.

## Search and review

1. Choose Scientific literature or Patents and enter keywords, a DOI or a patent number.
2. Optionally filter publication years, order by relevance or newest publications,
   and request 5–30 records. Patent search also supports publication authority
   (for example IN, US, EP or WO) and CPC classification (for example A01N).
3. Search runs in the existing background queue. Keep chatting or navigate while it runs.
   Stop interrupts between bounded provider requests; an in-flight HTTP request can
   take up to 15 seconds to return.
4. Inspect metadata and available abstracts/snippets, then open the original source.
5. Save useful sources with notes and a Saved, Reviewed or Excluded status.
   Reviewed records the user's assessment; it does not certify scientific or legal validity.

Search history preserves exact parameters, provider status and URLs, retrieval time,
normalized result snapshots and a SHA-256 digest. DOI matches are deduplicated
across literature providers. Full-text articles and patent claims are not downloaded
or interpreted automatically. Search order is the provider's ranking; a high-ranked
record is not necessarily relevant to the formulation.

Downloads include search JSON and citation CSV. Project ZIP exports retain
searches, curated sources, source-review revisions and immutable artifact history.
Forked projects inherit their saved research. Source notes use revision checks,
and only a result actually owned by the project can be saved.

## Sources and availability

Literature uses [Crossref's public metadata API](https://www.crossref.org/documentation/retrieve-metadata/rest-api/)
and [Europe PMC's REST service](https://europepmc.org/RestfulWebService).
Patent discovery uses the public Google Patents website search endpoint; see
[Google's search guide](https://support.google.com/faqs/answer/7049475).
The website endpoint is not a versioned API and may change or throttle access.
No API keys or paid search accounts are required.

A provider failure is displayed separately from a successful empty search.
Literature can return partial results when one provider is unavailable. Retry
failed retrievals; failure is not evidence that no literature or prior art exists.
Publication-year filters apply to publication dates, not patent priority dates.
The publication authority describes the returned publication, not all territories
in a patent family.

Searches are not exhaustive. Metadata, abstracts and snippets need source review.
Patent results do not establish novelty, patentability, freedom to operate or
current legal status. Consult original claims, family records and the relevant
patent register for those questions.

## Shared agent tools

- search_literature(query, filters_json): publication-year, limit and sort filters.
- search_patents(query, filters_json): additionally country and CPC filters.
- list_research(search_id): saved search inventory and curated sources, or one search.
- save_research_source(search_id, record_id, notes, status): save a retrieved result.

Use an empty JSON object for default filters. Search and inventory tools are
available in discussion mode; source curation requires execution mode. Agent
searches use the same service, persistence and source records as manual searches.
Retrieved source text is evidence, not an instruction to the agent.

## HTTP API

- GET /api/studio/research?session_id=... returns saved searches and curated sources.
- POST /api/studio/research-search accepts session_id and parameters, and returns a queued request.
- POST /api/studio/research-source accepts session_id, search_id, record_id,
  notes, status and optional expected_revision. Metadata is resolved server-side.

Example parameters:

    {"kind":"patent","query":"tebuconazole controlled release","country":"IN",
     "cpc":"A01N","year_from":2020,"limit":10,"sort":"relevance"}

## Validation

Run:

    python3 -m pytest --disable-plugin-autoload -q tests/test_research_search.py

The optional real-browser test uses Chromium DevTools and the websocket-client
package already present in many development environments. Set
AGRIFORMULATIONS_BROWSER to a local Chromium executable to enable it.
Tests cover provider parsing, deduplication, filters, outages, provenance,
agent tools, no-agent background execution, project ownership, revision
conflicts, persistence, exports, HTTP endpoints and the browser search/save flow.

