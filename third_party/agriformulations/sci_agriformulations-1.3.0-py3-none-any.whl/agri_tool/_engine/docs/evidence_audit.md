# Independent evidence audit

Audited 19 October 2026 against curated CSVs, manifests, original source tables, and primary articles. This reviews evidence and validation design; model performance remains to be assessed after execution.

## Inventory and source checks

| Dataset | Observations | Independent design coverage |
| --- | ---: | --- |
| Fertilizer 2026 | 19 means | One formulation, two released analytes |
| Azadirachtin 2025 | 54 means; 162 replicate entries archived separately | Two formulations, three pH values, nine times |
| 2,4-D 2024 archive | 288 source cells; 272 accepted values | Two carriers, nine conditions |

Rows are not independent formulation examples. Fertilizer release trajectories are represented by means and reported SDs; individual replicate trajectories are absent. The AZA triplicates may share an evolving release experiment across times.

The fertilizer workbook places 98.15869% FLA and 97.7% potassium release at day 25, followed by 100% at day 30. Prose associates the near-98% values with day 30. Preserve workbook observations and compare prose claims separately. A full-data endpoint fit does not resolve this discrepancy. [2026 primary article](https://www.nature.com/articles/s41467-026-68295-6)

AZA published means differ from recomputed triplicate means by at most 0.00879 percentage points; reported SE divided by recomputed sample SE spans approximately 0.87–2.37. Source error bars therefore should not silently become inverse-variance fitting weights. Time-zero means are positive. Acidic 96-hour workbook endpoints are AT 81.74703% and AP 98.09281%, while prose gives 65.57% and 89.31%. [2025 primary article and source data](https://www.nature.com/articles/s41467-025-57028-w)

Published fit coefficients and R-squared values are audit targets, never measured observations. Different fitting ranges, intercepts, weighting, or transformations can alter refit statistics; unexplained mismatch must be disclosed.

The 2024 archive retains one suspected decimal typo and post-disintegration omissions. It stays in mg/g because an independent active-loading denominator has not been established. [2024 article and supplements](https://www.nature.com/articles/s41598-024-53820-8)

## Leakage review

- Full-curve errors are calibration metrics. Chronological holdout must fit on the earliest 70% of times and score the final 30%, recording exact counts and rounding.
- Scaling, fitted burst/asymptote terms, model selection, label-dependent initialization, and uncertainty estimation must use training rows only. A withheld endpoint cannot normalize training data.
- Leave-one-pH-out must withhold both AZA formulations and every time/replicate at that pH. Train on source means without also adding their replicate rows.
- Fit StandardScaler and GPR kernel optimization inside each training fold. Data-selected hyperparameters require inner training splits; prespecified fixed settings do not.
- Only three pH folds exist. Predicting neutral pH 7 from acidic and alkaline curves asks the model to recover an unseen release minimum. Poor performance is informative. A hand-designed neutral-minimum feature is a disclosed mechanism-informed prior.
- Other-pH training curves contain the same times. These folds evaluate new-pH prediction at observed times, not future-time prediction, new formulations, or external studies.
- Present all prespecified models and folds. Selecting the winner on these holdouts makes its score optimistic. Three-fold spread is descriptive and cannot establish a stable confidence interval.

## Physics and limits

Homogeneous-sphere transport is an effective approximation: fertilizer includes a mineral carrier/coating, and AZA dialysis can involve membrane resistance and particle disassembly. Fitted diffusivity may absorb unresolved processes. Release identifies D/R-squared unless radius is independently fixed; DLS hydrated diameter and dry TEM diameter are distinct measurements.

Mass balance, mesh convergence, and agreement with an analytic limiting solution verify the solver under its assumptions. They do not establish the material mechanism. Parameter perturbations are scenario sensitivity unless supported by a justified probability model.

The supported result is approximate computational reproduction of selected aqueous release profiles plus transparent holdout checks. Yield, pest mortality, field persistence, manufacturing reproducibility, economics, and novel formulation superiority remain outside this benchmark.
