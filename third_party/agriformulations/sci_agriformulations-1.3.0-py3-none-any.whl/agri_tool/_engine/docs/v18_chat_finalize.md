# Simple chat, then finalize and run (v18)

The research agent window opens as a plain conversation: a message thread,
a text box and **Send**. Discuss goals, compare ideas and answer clarifying
questions there.

When the agent has enough information, an editable **Plan to run** appears
below the composer. Review the task and assumptions. Resolve essential open
questions in the chat, then select **Finalize & run** in that same window.

## Discussion behavior

Sending a message uses the discussion intent. The agent can read the current
project, search the recipe library, consult a specialist and draft a plan.
The backend restricts the available tools and rejects scientific execution or
library-write calls in this mode.

Discussion updates the draft plan and conversation. It does not generate
candidate records, calculate new model outputs or create a project revision.
The private investigation record preserves the conversation and its working
state for browser recovery.

The model updates the plan after clarifications. A plan with essential open
questions keeps the run button disabled. A follow-up reply that does not update
an existing draft marks it for review rather than silently reusing the old scope.

## Finalization and execution

The user can edit the displayed task before finalizing. The execution request
contains that exact task, its plan ID and the source discussion reference.
The backend verifies that the plan is current and its project-context fingerprint
still matches. Changes to scientific inputs require review in chat before running.

The execution agent then calls the relevant framework tools and saves results
through the existing project revision mechanism. The finalized record includes
the accepted task, its source plan, whether the user edited it and the execution
status. The completed plan is hidden from the run controls to prevent accidental
repeat execution.

The independent recipe-creation and scientific-tool buttons remain explicit
execution actions elsewhere in the workbench. The ordinary research chat and
stage discussion buttons use discussion mode.

## Simpler presentation

- Messages appear in chronological chat bubbles.
- Role rosters, large example cards and full step logs are removed from the
  default chat view.
- Message details and sources remain expandable.
- Saved investigations are under **Previous runs**.
- Live execution progress appears when a finalized task runs.
- Conversation references are kept in browser session storage; full working
  snapshots and results stay in the private workspace database.

Enter sends a message; Shift+Enter inserts a new line.

## API and validation

The existing agent endpoints accept `intent: "discussion"`.
A finalized execution uses `intent: "execute"` and `finalized_plan` containing
the exact task and plan ID. Existing explicitly executable API requests remain
supported.

Tests cover restricted discussion tools, attempted execution during chat,
incomplete and stale plans, changed project inputs, user-edited finalized scope,
chat recovery, the disabled/enabled run control, actual tool execution and
saved output revisions.

A live GPT-6.1 Sol check first drafted a release-scenario plan without changing
scientific outputs or saving a project. After explicit finalization, it ran
`simulate_kinetics`, saved revision 1 and retained the exact accepted task.

## Run outcomes

After **Finalize & run**, the GUI opens **Results & learning → Run outcomes**.
Every execution saves a report alongside its scientific outputs. The report
contains the accepted task, final answer, source links, warnings and a list of
successful tool deliverables. Buttons lead to generated recipes, kinetics,
stability, dosage or experiment results. The project page includes a **View
outcome** shortcut, and reports can be downloaded separately.

An evidence assessment is labeled **Assessment only** when it creates no recipe
candidates, numerical models or experiment matrix. It is not presented as a
completed formulation. Plan drafting preserves the user's requested deliverables;
an essential preliminary assessment must be identified during discussion.
Web source verification is enabled by default and can be disabled under agent
settings. Reports state whether web research actually occurred.

Older project revisions expose their saved assessment from conversation history
without rewriting the revision or rerunning an agent. Export bundles include the
assessment in report.html, research_outcomes.json and individual Markdown files.
A direct link using ?project=PROJECT_ID&tab=results opens a saved outcome.


## New product development from an assessment

The product page now has **Create product, recipes & simulations**. It uses the
current brief and latest assessment to create an independent product project.
The source project and its assessment revisions remain available.

The agent supplies a complete composition brief and explicit scenario inputs to
the `develop_product` tool. The tool generates 2 to 12 distinct, mass-balanced
recipe drafts and runs kinetics, stability and storage-adjusted dose scenarios
for every recipe and every individual active. Missing or invalid scenarios are
rejected together; the source project is not overwritten by a failed attempt.

The recipe list contains the new candidates. Kinetics, Stability and Dose
scenarios each display all recipe/active results in a comparison table. Selecting
a recipe or active restores its own saved inputs and curves. The selected
storage-temperature retention and individual active loading feed that dose
scenario. CSV downloads and the project export retain inputs and results.

Unmeasured release, degradation and physical inputs are explicit scenario
assumptions. Shared inputs produce shared predictions. These calculations do not
infer recipe performance from composition or establish field-effective rates.

The background API accepts `intent: "develop_product"`. Research chat can also
draft a complete product-development task for finalization; the same tool is
available during explicit execution.
