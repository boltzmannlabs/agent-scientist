# Goal-driven design studies

**Design study** connects a product decision to candidate recipes, physical
scenarios, output specifications, tradeoffs and a revised design. Manual users
and agents share the same engine. Neither an AI connection nor an experimental
dataset is required for a manual study.

## Use the workspace

1. Create recipe candidates, then click **Design study** above the canvas.
2. State the product goal and select up to eight immutable recipe versions
   containing the same individual active.
3. Add up to four physical scenarios. Declare their shared test conditions and
   choose which material/property coefficients may differ between candidates.
4. Supply the candidate-specific coefficients as explicit assumptions. Define
   minimum/maximum output requirements and optional minimize, maximize or target
   objectives. All limits use the chosen metric's units.
5. **Evaluate design study**. Inspect specification failures, incomplete scenarios,
   Pareto tradeoffs and the next design steps.
6. Inspect an exact scenario, explore a constrained revision or create a recipe
   variant. **Revise study** preserves a parent reference; select the new recipe
   and rerun the whole study after a change.

Each physical model is evaluated independently. For example, viscosity in a
suspension calculation is not silently taken from a rheology curve. A user must
supply an appropriate value for its conditions. Model coefficients are not inferred
from ingredient names or concentrations. Studies with identical outputs from
composition-independent models explicitly report that those models do not
distinguish the recipes under the supplied assumptions.

Shared conditions stay fixed within a scenario: a candidate cannot gain a better
storage result merely by lowering its test temperature or shortening the horizon.
The catalogue exposes `candidate_parameters`, an allowlist of material/property
fields that can vary explicitly. Different independent scenarios can represent
different declared test conditions.

## Interpret the comparison

**Meets model specifications** means every available bound passed in every required
scenario. This remains conditional on the model and its assumptions. It is not
experimental validation, chemical compatibility or demonstrated field efficacy.

**Outside specifications** identifies at least one failed bound. **Incomplete**
means a required model or metric is unavailable; the exact failure reason remains
visible. These candidates cannot enter the Pareto front. With objectives but no
acceptance limits, results are **evaluated without acceptance limits** and
specification satisfaction remains unassessed.

Criteria also show a signed specification margin in the output's units: positive
is inside the allowed interval, zero is on a bound and negative is outside.
Target objectives show absolute target distance. Next steps report the failing
value and the amount outside its bound. Margins stay separate across metrics.

Pareto membership uses every declared objective among complete candidates that
satisfy any declared bounds. Target objectives use absolute distance to the target;
positive scales normalize objective coordinates. There is no weighted universal
recipe score and ties remain visible. Objective tradeoffs can leave several
non-dominated candidates rather than a single winner.

**Explore constrained revision** opens the existing AI + physics builder with
the selected model's exact inputs, up to three objectives and eight bounds.
If a scenario exceeds the optimizer's objective or specification limit, the
handoff asks for an explicit scope choice instead of dropping criteria.
Initial ±20% property bounds are editable assumptions. This search covers one
model scenario; the full study must be rerun to assess all specifications after
a revision. A shortlist checks numerical feasibility, not laboratory success.

## Optional measured feedback

Agents and API requests can supply a matching `fit_ids` entry for each candidate
and scenario. The existing exact-recipe, active, dataset-review digest, engine
version and calibration-domain gates remain enforced. Fitted material coefficients
may vary only when explicitly declared as candidate parameters. Shared reference
conditions must still match. A measured fit informs a simulation; its predicted
output is not itself a measurement.

Reopening a measured-fit study in the manual editor copies the evaluated values
into explicit editable scenarios and adds an assumption note. That revision does
not claim a new calibration. The original study retains its fit provenance.

## Reproducibility and execution

Study results retain the goal, criteria, exact requests, resolved inputs, recipe
versions, model equations and limits, individual-active fractions, parameter
provenance, measured-fit references, engine version, domain failures and underlying
scenario IDs. Existing simulations are reused by their exact scenario identity.
Stop is checked between evaluations; completed scenarios remain checkpointed and
are reused on resume. A completed identical study is reused as a whole.

The Design studies tab contains every saved study. The project overview links to
recent studies. Chat can receive a study as an attachment. Study JSON and comparison
CSV are available directly; project ZIP exports also contain each study and its
comparison table. Historical studies are preserved when a design is revised.

## Agent and API contract

Agents read saved studies with `list_design_studies(study_id)`; an empty ID returns
the inventory, while an exact ID retrieves the saved request and comparison for
revision without executing calculations. They use `run_design_study(study_json)` after discovering physical model schemas
with `list_simulations`. Manual requests use `POST /api/studio/design-study` with
`session_id` and `study`:

```json
{
  "name": "Handling and storage comparison",
  "goal": "Compare physical hypotheses under shared conditions",
  "candidates": [{
    "recipe_id": "your-recipe-version",
    "active_name": "your-individual-active",
    "inputs": {"flow": {"consistency_pa_sn": 0.5}}
  }],
  "scenarios": [{
    "id": "flow",
    "model": "rheology",
    "inputs": {"yield_stress_pa": 0, "flow_index": 1},
    "candidate_parameters": ["consistency_pa_sn"]
  }],
  "criteria": [{
    "scenario": "flow",
    "metric": "pressure_bar",
    "maximum": 0.8,
    "goal": "minimize",
    "scale": 1
  }],
  "assumptions": ["Illustrative numerical specification and material coefficient; not a product recommendation."]
}
```

Candidates may also supply `fit_ids: {"flow": "matching-fit-id"}`. An optional
`parent_study_id` must belong to the project. Each scenario needs at least one
criterion; repeated scenario/metric criteria must combine their bounds and
objective in one entry. Nested optimization/uncertainty analyses and combined-active
response surfaces are excluded from these independent single-active comparisons.

## Numerical verification

```bash
python3 -m scripts.run_v24_design_studies
python3 -m pytest --disable-plugin-autoload -q tests/test_design_studies.py
```

The synthetic benchmark compares each Newtonian pressure to independent
Poiseuille arithmetic and chemical retention to `exp(-k t)`, checks exact replay,
mass balance, the expected feasible candidate and a preserved parent study after
a hypothetical parameter revision. Results and an engine/version manifest are
exported to `reports/v24/design_studies.json` and `comparison.csv`.

Tests also cover non-dominance and target distances, absence of acceptance limits,
identical composition-independent outputs, domain failures, unavailable metrics,
project ownership, measured-fit review/domain gates, cancellation/reuse, HTTP
execution, agent execution, ZIP exports, and the editor-to-engine round trip.

## Further development

This release establishes the decision and reproducibility layer. Further work
should earn stronger predictive claims with independent model benchmarks,
explicitly coupled models where justified, robust optimization across several
model specifications, and focused measured feedback that reduces design
uncertainty. Composition-to-performance learning continues to require its actual
validation and domain gates; a polished comparison interface does not replace them.
