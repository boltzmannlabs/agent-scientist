# Methodological audit: no-wetlab agricultural formulation reproduction

The defensible result is a computational reanalysis of published observations, followed by explicitly conditional transport simulations. A curve fit recovers a published pattern; it does not independently reproduce synthesis, establish material mechanism, or validate crop efficacy.

## Evidence selection and provenance

Search performed 19 October 2026. Recency is balanced against usable open numerical observations; do not describe this bounded search as exhaustive or the selected paper as the latest worldwide.

| Primary source | Numerical accessibility | Role |
| --- | --- | --- |
| [Paul et al., Scientific Reports (2024), DOI 10.1038/s41598-024-53820-8](https://www.nature.com/articles/s41598-024-53820-8) | DOCX Tables S3/S4 give direct desorption values; XLSX preserves underlying spectroscopy | Independent crop-protection archive |
| [Yoon and Jin, Archives of Metallurgy and Materials (2025), DOI 10.24425/amm.2025.154451](https://doi.org/10.24425/amm.2025.154451) | Exact composition table; curve values primarily require figure extraction | Fertilizer candidate if stronger raw data unavailable |
| [Nandal et al., Industrial Crops and Products (2025), DOI 10.1016/j.indcrop.2025.120587](https://doi.org/10.1016/j.indcrop.2025.120587) | Publisher states study data are confidential | Exclude from raw-data benchmark |

The 2024 crop-protection archive contains two organoclay/alginate carriers and nine conditions each, with two reported experimental replicates. Native response units are mg active ingredient per g formulation. The DOCX contains a suspected decimal typo, MMT2 at 45 C and 38 days, reported as 4967 ± 0.16. Preserve it in the full extracted table and exclude it from model input; do not silently replace it with 49.67. NaCl omissions follow bead dissolution and are informative missingness. Source plus/minus values are retained without assuming SD or SE. [Article and supplements](https://www.nature.com/articles/s41598-024-53820-8)

The downloaded 2024 workbook includes duplicate baseline conditions and spectroscopy, not 18 wholly independent formulations. Condition IDs must preserve experimental context. Unspecified pH or temperature remains null. Table S5 also duplicates a carrier heading, so soil-pore-water labels require reconciliation before modeling.

The 2025 extrusion study reports eight compositions and conductivity-based aqueous release measurements. Its optimized formulation has fertilizer:HPMC:EC:PSD mass ratio 1:1:10:3, with 62% released at day 2 and 80% at day 30. These provide endpoint checks, while recovering an entire curve from them would be an invented target. [Primary article PDF](https://journals.pan.pl/Content/136787/AMM-2025-3-06-Sung%20Giu%20Jin.pdf?handler=pdf)

## Prediction and validation

1. Archive source files, SHA256 digests, original sheet/table/cell locations, units, raw strings, and extraction script. Keep source observations distinct from simulated trajectories and digitized points.
2. Choose a primary endpoint and holdout strategy before examining test results. For forecasting within a condition, fit only early observations and score later times. For prediction across conditions, hold out entire curves. If comparing flexible models, choose their hyperparameters using training-only inner splits.
3. Report per-curve MAE/RMSE in native units and train/test observation counts. Compare with a simple training-only baseline. Aggregate across curves with equal curve weights, since densely sampled curves otherwise dominate.
4. Keep the same formulation-condition replicates together. Random row splitting allows nearby time points and potentially the same experimental units into both train and test, inflating accuracy. Repeated cumulative observations share measurement history and cannot be treated as independent replicates.
5. State that the experimental sample size is the number of independent formulations or experiments, not the number of spreadsheet rows. Two carriers or a handful of formulations cannot support broad molecular/formulation-design claims.
6. An empirical regressor can be an exploratory AI/ML baseline. Strong neural-network or general-purpose formulation optimization claims need a much larger, independent collection of studies. Report poor or negative holdout performance when observed.
7. A fitted published endpoint is a calibration check. An unseen endpoint is a prediction check. Neither validates field performance. Avoid claiming a held-out endpoint was independently replicated when it shaped model choice.

If the workflow fits a model to all available observations, label the resulting parameters and error metrics calibration-only. The existence of a separate ML holdout does not convert a full-data physics fit into validation.

## Physical simulation and identifiability

A minimal spherical diffusion model is an interpretable effective model:

```text
dC/dt = D_eff (1/r^2) d/dr [r^2 dC/dr]
dC/dr (0,t) = 0
C(R,t) = 0                       # perfect external sink assumption
F(t) = 1 - (6/pi^2) sum[n=1..infinity] exp(-n^2*pi^2*D_eff*t/R^2)/n^2
```

This model assumes a sphere, uniform initial loading, constant diffusivity, no swelling or degradation, and negligible external mass-transfer resistance. Those assumptions are scenario choices unless independently measured. If radius is unknown, release identifies only D_eff/R^2. A fitted D_eff obtained after assuming R is an effective scenario parameter, not a measured diffusivity. Adsorption, network relaxation, membrane transport, finite bath effects, and erosion can all alter the apparent release rate.

For a numerical solver, verify mass conservation, nonnegative concentrations, bounded monotone cumulative release, mesh/time convergence, and agreement with the analytic solution in a matching limiting case. Include shell or membrane physics only if geometry and boundary conditions are documented. Molecular docking or molecular dynamics does not directly predict a multi-day release curve without a justified multiscale link.

Empirical first-order and Weibull curves are useful comparisons. Korsmeyer-Peppas fits need a stated geometry and restricted early-release range; a fitted exponent or a high R-squared alone does not establish a unique transport mechanism. Avoid fitting an unconstrained early-time power law through complete release.

## Uncertainty and sensitivity

Separate these three quantities in outputs:

- Experimental uncertainty: obtained from real independent replicates or properly defined published error bars.
- Conditional parameter uncertainty: affected by the fitted model, residual assumptions, and sample size.
- Scenario sensitivity: consequences of assumed radius, diffusivity, sink conditions, temperature, or degradation; it is not a confidence interval.

Do not interpret tiny rounded plus/minus values or 0.00 entries as exact measurements or infinite fitting weights. If error-bar meaning is unknown, unweighted fits plus a limitation are preferable to false precision.

With only a few curves, bootstrap intervals are illustrative at best. Resample independent curves or replicate experiments, not individual cumulative time points. A measurement-noise perturbation study must be labeled a sensitivity analysis unless its noise model is justified.

For fixed-geometry diffusion, characteristic release time scales as R^2/D_eff. Test 0.5x, 1x, and 2x radius and diffusivity separately, and show their impact on a prespecified release-time or endpoint metric. Predictions outside observed pH, temperature, material composition, or media are conditional extrapolations.

## Scope of a successful case study

A successful no-wetlab case study delivers authentic numeric data, a rerunnable extraction and modeling workflow, calibrated effective physics, honestly separated holdout metrics, sensitivity figures, and a concise statement of which published release trends or endpoints were recovered approximately. It cannot establish novel formulation performance, manufacturing reproducibility, efficacy, environmental fate, or superiority without independent experimental evidence.
