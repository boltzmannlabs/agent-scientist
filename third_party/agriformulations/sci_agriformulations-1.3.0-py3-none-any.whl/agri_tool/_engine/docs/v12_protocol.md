# Local GUI protocol, version 12

Written on 2026-10-20 before building the GUI. Internal tool; not an external preregistration. This phase un-defers the v7 GUI decision by explicit user instruction (2026-10-20): the user asked for a GUI where they give requirements and see outcomes as simulation graphs and other visualizations.

## Principle: a view, never a source

The GUI renders and parameterizes the deterministic engines; it never invents numbers. Every curve comes from the verified kernels (`release_fraction` sphere kernel, `design/zero_order`), every scan from the v11 claim scans, every campaign row from the frozen phase exports under `reports/`. No agent, no proposal, no new claim: the human-review gates are untouched, and every panel carries the standing not-comparable register (plus A1/A2) - nothing shown is an efficacy, patentability or field claim.

## Panels (requirements -> outcome)

1. Release simulator: kernel (Fickian sphere / zero-order membrane), rate or (k0, lag), plateau, horizon; optional claim pair (t1 cap, t2 floor) -> simulated release curve with constraint guides and PASS/FAIL chips (status colors with icon + label, never color alone).
2. Claim feasibility: user claim pair -> Fickian family scan (achieved t2 vs rate, ceiling annotation, analytic ratio bound) and the zero-order feasible region with the analytic corner and example specs; verdict chips per kernel family.
3. Campaign explorer: v8/v10 concept scatter (novelty vs priority, marks by prior-art flag as status colors + shape), transfer-region interval chart (ordinal single-hue ramp by stereo regime; log day-rate axis), shortlist table (tabular numerals).
4. Identifiability: the v9 degenerability demonstration - observed total curve, three degenerate alternative triples, effective-rate tile, assignment-degeneracy statement.
5. Ask console: free-text questions routed DETERMINISTICALLY to the engines - a parser (regex + token matching, no model, no external call) maps questions onto the compute layer and every answer returns its route name, the engine that produced it, and where applicable a chart, verdict chips and a table. Supported intents: claim-pair feasibility and ceilings (numbers parsed from the question), blocked/adjacent/clear listings and counts, top-N rankings by priority/novelty/india/compatibility, concept lookups and A-vs-B comparisons, carrier/partner/enrichment filters, stereo-descriptor lookups, pending-proposal status, and the identifiability statement. Unrouted questions get a capability list with clickable examples - the console never fabricates an answer.

## Visualization governance

Palette validated with the dataviz skill's six-check validator, run - not eyeballed: categorical slots light `#0c7f5d / #eb6834 / #2a78d6` on surface `#ffffff` (all-pairs: PASS after snapping the brand green from #126a52 to #0c7f5d to clear the chroma floor) and dark `#2f9d7f / #d95926 / #3987e5` on surface `#14201b` (all-pairs PASS); status colors fixed (`good #0ca30c`, `warning #fab219` - icon + label mandatory, `critical #d03b3b`); regime severity uses the blue ordinal ramp (light steps 250/400/550, dark 400/500/600 - ordinal floors respected). One axis per chart; legends for >= 2 series with direct labels; crosshair tooltips on line charts, per-mark tooltips on scatters; a table view exists for every chart; theme toggle with selected (not flipped) dark steps; text in ink tokens, never series colors.

## Engineering

Stdlib only (http.server + vanilla JS + inline SVG): fully offline, no CDN, no external URLs anywhere in the page (tested). Binds 127.0.0.1 by default; strict server-side parameter validation with 400 responses; deterministic responses (fixed rounding). `python3 -m scripts.run_v12_gui` serves; `--selftest` runs the endpoint checks headlessly and is what `scripts/reproduce` chains (a long-running server does not belong in a reproduction chain). Compute lives in `agriformulations/gui/compute.py` (pure, unit-tested); serving in `agriformulations/gui/server.py`; the page is one self-contained template.

## Gates

Selftest passes (page served, all APIs - including the ask endpoint - return contract-shaped JSON, bad parameters rejected with 400, page contains no external URLs); compute layer deterministic (two calls byte-identical, questions included); campaign loader reads the frozen exports read-only; full test suite green.
