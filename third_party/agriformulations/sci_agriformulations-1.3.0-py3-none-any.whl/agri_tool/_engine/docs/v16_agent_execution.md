# Query-driven recipe creation and framework execution (v16)

For live progress, saved investigation history and browser recovery, see [v17](v17_agent_progress.md).

Users can ask the agents to create recipes and carry the investigation through later
framework tools. The current Codex sign-in and GPT-6.1 Sol remain the default connection.

## Use it in the GUI

In **Suggest recipes**, enter a request under **Create recipes from your request**
and press **Create recipes with agents**. An existing recipe, completed ingredient
table or matching library record is not required.

For example, an illustrative research request is:

> Create three aqueous SC candidates with 20% w/w tebuconazole from 95% technical
> material for a 500 g laboratory batch. Propose excipients and explain the assumptions.
> Run assumed release and chemical-stability scenarios, calculate an exposure scenario
> using the target I supply, plan screening experiments, and save the work.

The agent can propose formulation type, loading, batch size, excipient grades, ingredient
bounds and preparation steps as explicit editable design assumptions. Essential missing
active/nutrient identities or conflicting requirements prompt a focused question.
Proposed quantities pass the same purity and mass-balance validation as manual recipes.
A failed proposal returns a tool error that the agent can repair.

Recipes appear in the candidate table and ingredient editor, with weigh-outs, rationale,
assumptions and verification tests. Creation through the general research chat also
produces a link to the recipe page.

In **Ask the research agents**, **Execute task & save** requests actual execution and
persistence rather than an advisory answer. Ordinary questions can also cause tool
execution where appropriate. The agent chooses the required steps; the workflow does
not require every tool or specialist.

## Available actions

- Create new recipes from the query with `create_recipe_candidates`.
- Revise an existing bounded design with `suggest_recipes`.
- Inspect and search the recipe library, or select a recipe and individual active.
- Execute release/degradation kinetics, chemical-retention/physical-screening scenarios
  and exposure dose calculations.
- Fit real imported release, stability or biological dose-response observations.
- Validate a local measured mixture-response model.
- Generate randomized experiment plans, controls and batch/technical replication.
- Consult specialist agents.
- Save requested recipe drafts to the library, and save the complete project.

New recipe generation clears obsolete current simulations, fits and reviews. Analysis
history retains its original recipe/active identifiers. Selecting a different recipe
also removes obsolete current fits and labels transferred parameters as scenarios.

## Durable project saves

Scientific state changes made by agents are automatically committed as a project
revision at the end of the investigation. The agent can also explicitly call
`save_project`. That tool stages the commit until the final response so the saved
document contains the final conversation, tool trace and numerical outputs.

The response returns `project_saved` with the project ID and revision. The GUI updates
its project identity, saved status and project list. Later agent requests append revisions
to the same project. Reloading restores recipe drafts, model results, experiment plans,
conversation and stage reviews.

Existing revision checks prevent a stale browser session from overwriting newer work.
A failed save returns `persistence_error`, keeps completed outputs in the current
session and displays the failure. If a model call fails after successful tool execution,
the completed outputs are returned and saving is still attempted; the answer clearly
states that synthesis did not finish.

Recipe-library saving is a separate explicit action. Saved drafts retain design query,
assumptions, sources, model and rationale alongside their existing provenance.

## API

`POST /api/rnd/ask` accepts the existing question and state plus:

- `intent`: `research`, `create_recipes` or `execute`.
- `project_identity`: `{"project_id":"…","revision":1}` for an existing project.
- `focus` and the existing explicit `web_research` option.

Recipe-creation results include `recipe_creation` with status, recipe IDs and assumptions.
No textual answer is reported as a created recipe unless the recipe tool succeeded.
The bounded investigation allows 420 seconds, 16 model calls, three specialist calls
and 24 application tool calls.

## Verification and scientific limits

A live signed-in GPT-6.1 Sol test created three new SC candidates, repaired rejected
inputs, selected a recipe, ran kinetics, stability, exposure-dose and experiment-plan
tools, and saved the complete project. Eight model calls completed in approximately
102 seconds using low reasoning effort in a temporary test workspace.

Automated tests cover query-only creation, infeasible designs, source validation,
downstream execution, project reload and revision continuation, concurrency refusal,
database failure, recovery after later model failure, and GUI creation/save behavior.

The computations retain their existing scientific limits. Proposed ingredients and
preparation methods are research hypotheses. Assumed chemical retention is not validated
physical shelf life; exposure mass balance is not proof of efficacy. Fits require actual
observations. Experiment plans do not execute physical laboratory work.
