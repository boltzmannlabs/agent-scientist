# Three-paper benchmark protocol, version 2

Written on 2026-10-19 before running the new three-paper models. This internal analysis plan is not an external preregistration. Source inspection and prior benchmark results preceded it. Tolerances below are exploratory analyst decisions, not experimentally validated equivalence margins.

## Scope and freezing

Select independent nutrient-cargo hydrogel, fungicide and herbicide papers by accessible numerical data, provenance, formulation definition and assay clarity. The multifunctional hydrogel paper primarily studies bacterial-wilt management; its nutrient-cargo release is not fertilizer-efficacy validation. Data access outranks recency. Retain a selection registry with exclusions and reasons; never replace a study after seeing unfavorable model results. The selected herbicide is Paul et al. 2024 (10.1038/s41598-024-53820-8); the fertilizer/delivery benchmark is the 2026 double-network hydrogel study (10.1038/s41467-026-73922-3), using aqueous Zn/PA cargo release only. The fungicide benchmark is the 2023 TEB nanocarrier study (10.1038/s41467-023-41878-3). No pathogen or plant experiments are included in the release-model target. Source identifiers were independently verified against the publisher.

Each study provides study.json, observations.csv and claims.csv. Freeze their SHA256 hashes, source hashes, split rules, model candidates, thresholds and seeds in an execution manifest before fitting. Record subsequent amendments with reasons and changed hashes.

We benchmark selected measurements and conditional forecasts. Three papers with few recipes cannot establish a general formulation-design or field-efficacy system. Count papers, recipes, conditions, curves, times and replicates separately. Repeated measurements do not increase the number of independent formulations.

## Source and target contract

Record DOI, supplementary URLs, retrieval date, hashes and exact table/cell locator. Preserve raw strings, units and missingness. Keep measured observations, reported means, article claims and simulated outputs distinct.

Declare analyte, medium, target, denominator, time unit and measurement unit. Release percentage, mg active per g formulation, adsorption per g clay, porewater concentration and weed-control efficacy are different targets. No forced cross-study normalization, including dividing by the final observed endpoint. Do not infer final composition from feed ratios. Missing metadata remain null. A figure/table unit conflict blocks an exact denominator claim; preserve the table unit and flag uncertainty.

Retain impossible and missing values in the archive with a reason. Apply predeclared physical/QC rules for primary fitting and show sensitivity including the original problematic values. Never guess corrected decimals. Missing samples after bead disintegration are informative omissions, not zeros.

## Claims audit

Enumerate all registered claims, including conflicts and unusable claims. Statuses: reproduced at reporting precision; approximately consistent under explicit exploratory tolerance; disagreement under stated analysis; source inconsistency; not comparable; insufficient information. A disagreement does not establish that a paper is wrong.

Compare the same target, assay, time range and equation. Match logarithm base, intercept, transformation, weights and constraints where specified; record unspecified conventions. Transformed-space R-squared is not native-outcome R-squared. Distinguish fixed published parameter evaluation from refitting. Full-curve calibration is descriptive, never a forecast score.

Paul 2024 reports PSO/PFO metrics for clay adsorption before bead production. These cannot be compared with bead release-fit metrics. Its prose gives opposing release rankings and inconsistent statements about pH significance; register those conflicts. Table S4 lists 4967 mg/g at day 38 for MMT2 at 45 C, contradicting a mass bound and neighboring entries. Primary fitting excludes the impossible entry without correction; sensitivity retains it.

## Forecast and transfer tracks

Forecast each curve with at least eight unique times. Outer train is the earliest 70% of observed times, outer test the last 30%. Keep all replicates of a time together. Select models only using an inner chronological validation split inside outer training, with enough fitting points for each model. Minimize inner MAE in native units; ties favor fewer parameters then fixed model order. Refit the selected candidate on all outer training and score the untouched outer test once. Compare the constant last-observed baseline on identical test rows. Report every fold, prediction, failure and selection frequency.

Transfer holds out complete conditions, followed by complete formulations only when counts and metadata allow. All times/replicates in held-out groups remain outside training. Any scaling, imputation and hyperparameter search use training groups only, with grouped inner validation. Unknown conditions and incompatible targets block the corresponding transfer experiment. With only two recipes, leave-one-formulation-out has two exploratory folds and provides weak evidence; one recipe makes it unavailable. Three papers on different materials are a diversity benchmark, not automatically an external validation dataset. An external study test requires compatible target and assay contracts.

Prespecify a compact candidate list: persistence (constant last observation), linear trend from the last three observations, a two-parameter first-order plateau model, and a three-parameter Weibull plateau model only where at least seven outer-training observations allow meaningful inner validation. First-order fitting requires at least four fitting observations; Weibull requires at least five. All eligible candidates on a curve must be compared on the same inner validation times: cut >=4 without Weibull; cut >=5 with Weibull. Do not average different validation horizons for different candidates. Eligibility depends only on training-set size. The exact executable manifest resolves final cut details before running. A physically bounded plateau at 1000 mg/g is a mass bound, not an independently measured loading. A diffusion reference has explicit geometry and loading assumptions and remains a mechanism sensitivity. GPU XGBoost with fixed predeclared hyperparameters can serve as an exploratory within-study time-forecast comparator using the exact same outer split; no test-tuned hyperparameters. It does not constitute unseen-recipe validation. A flexible AI model must be judged on held-out groups and compared with the same baseline. No model selection from outer-test R-squared. Return explicit fit failure and baseline when candidates cannot fit.

## Replicates, uncertainty and aggregation

Preserve replicate IDs and assay structure. A declared mean-curve target may average actual replicates at each time. Unknown plus/minus semantics do not permit inverse-variance weighting, Gaussian pseudo-replicates or SD-derived confidence intervals. Longitudinal replicates can only be resampled as entire trajectories. Two replicates support descriptive spread, not apparently precise uncertainty. Condition/curve resampling remains exploratory with tiny group counts.

First average errors within each curve, then equally across curves within each study. Report native-unit MAE, RMSE and bias per study. Never average mg/g errors with percentage-point errors. Any secondary normalized metric uses a scale learned from training only and displays that definition. Provide paired baseline differences and how many curves improve.

## Numerical checks versus scientific acceptance

CPU/GPU float64 agreement: absolute error <=1e-8 plus relative error <=1e-6 against a fixed CPU reference. A discretized PDE also needs mass-balance error <=1e-6 and mesh/time-step convergence before scientific outputs are used. Document dtype-specific adjustments before execution.

A tabulated exact numerical claim agrees within half its final printed decimal unit, with explicit numerical precision. Approximate percentage claims use an exploratory absolute tolerance of 5 percentage points. Approximate mass claims use max(half final printed decimal unit, 5% of published magnitude). These are audit tolerances chosen after prior analysis, not experimentally justified equivalence margins.

Forecast utility requires at least 10% lower study-level MAE than the last-observed baseline. Report paired differences and individual failures; a point estimate passing does not imply robust generalization with few groups. Transfer uses the same threshold separately. Experimental uncertainty, absence of metadata and poor prediction remain visible even if engineering tolerances pass. Release fit cannot validate biological efficacy or deployment readiness.

## Compute and final review

Use GPUs for meaningful batched training, uncertainty or mechanistic workloads; small extraction and nonlinear fits may use CPU. Report device, dtype, seeds, work counts, wall time and CPU agreement. Hypothetical sweep count is not evidence. Diffusion identifies D/R^2 unless one quantity is measured independently; solver agreement verifies implementation, not mechanism.

One reproducible command must validate sources, freeze manifest, execute audit/forecast/transfer, and render reports with claim coverage, failures, sensitivity and limitations. Independent review checks source fidelity, units and split leakage before results are called benchmarked.
