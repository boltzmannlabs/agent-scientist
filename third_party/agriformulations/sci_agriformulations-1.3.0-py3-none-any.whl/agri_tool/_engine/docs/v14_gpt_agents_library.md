# GPT-6.1 Sol agents and recipe library (v14)

Current connection and contribution controls: [v15 Codex guide](v15_codex_agents_library.md).
Codex sign-in is now the default; the API setup below describes the optional API connection.

This update replaces the v13 question router as the default research interface.
The scientific calculators remain deterministic; the research coordinator and specialist
agents make model-backed decisions, choose tools, critique assumptions and interpret results.

## Start and connect

```bash
python3 -m scripts.run_v12_gui --no-open --port 9174
```

Open Product brief & projects → **GPT agent connection**. The model is pinned to
`gpt-6.1-sol` for the coordinator and every specialist. Enter an OpenAI API key and
press **Connect & test GPT-6.1 Sol**, or start the server with `OPENAI_API_KEY`
configured in its environment. Do not put credentials in a recipe or project JSON.

The default base URL is `https://api.openai.com/v1`. An explicitly configured HTTPS
Responses-compatible gateway can be supplied; it must serve the same requested model.
The app does not substitute another GPT version or another provider's model if the
requested model is unavailable. Connection status distinguishes configured from tested.

Credentials entered in the GUI stay in server process memory, are cleared from the
password field after submission, and are excluded from project saves and exports.
Restarting clears a GUI-entered key. A server environment key can be used for persistent
deployment configuration. TLS verification remains enabled; `SSL_CERT_FILE` supports a
managed trust bundle. On Linux, the system CA bundle is used when available. Redirects
are refused on authenticated requests.

No OpenAI API key was present in the implementation environment. Consequently, live
OpenAI generation could not be verified there. All model-loop tests use an explicitly
simulated Responses provider; the UI exposes the real connection test.

## Where GPT is used

- **Ask the research agents:** general formulation R&D questions grounded in the
  active project, recipe library and existing numerical outputs.
- **Recipe candidates:** explain ingredients, search for starting formulations,
  suggest bounded ingredient alternatives and compute draft candidates.
- **Kinetics:** reason about mechanisms, compare computed scenarios, examine
  identifiability and propose useful measurements.
- **Stability:** critique chemical and physical assumptions and design storage tests.
- **Dose scenarios:** interpret active-specific exposure calculations and biological
  dose-response evidence without equating the two.
- **Experiment plans:** revise mixture/process screening, controls, sampling and
  independent batch replication.
- **Imported results:** invoke actual data fitting and assess the evidence supporting
  the next recipe or experiment.

Each stage has an editable question and an **Ask GPT about this stage** button.
Automatic review after recipe generation, simulation, dose calculation and experiment
planning is enabled by the visible checkbox; it can be disabled. A failed GPT review
does not discard the completed scientific calculation.

The coordinator can consult formulation, kinetics, stability, dosage, experiment or
evidence specialists. These are actual additional GPT-6.1 Sol calls with specialized
instructions and shared project context. There is no fixed order and no requirement
to call every specialist. Model/tool traces identify successful calls, rejected inputs,
source references and usage. Raw chain-of-thought is not shown.

Optional **Allow GPT web research** enables the Responses built-in web-search tool.
Returned source annotations appear as links. With it disabled, agents can search the
local recipe library but cannot claim a new literature search.

## Tool execution

The model selects from explicit tools:

- get_project_context
- search_recipe_library
- load_library_recipe
- suggest_recipes
- simulate_kinetics
- simulate_stability
- calculate_dosage
- plan_experiments
- fit_measurements
- learn_response_model
- consult_specialist

The tools validate input ranges, purity, mass balance, assay identity and model domain.
Invalid calls return errors to GPT for repair. Each accepted tool runs on a staged
project copy. GPT cannot execute arbitrary Python/shell code, create measured data,
invent an assay calibration, approve existing campaign proposals or write credentials
into the workspace through these tools.

Responses are sent with `store: false`. Encrypted reasoning items returned by the API
are carried forward during the bounded tool loop as required for stateless reasoning
models. Conversation context is limited to recent turns; raw workbook bytes, credential
fields and oversized numerical arrays are excluded from model context. The investigation
has a 240-second budget, at most nine model calls, three specialist calls and 24 scientific
tool calls. A limit or failure is explicit; no deterministic answer masquerades as GPT.

The old deterministic question commands remain available only through the explicitly
labeled offline troubleshooting control and `/api/rnd/ask-offline`.

## Selectable recipe library

The initial library has **22 records**:

- **17 published formulation records**, loaded from the existing curated formulation
  ontology and ingredient provenance.
- **5 editable design starters**, one each for SC, EC, WG, controlled release and fertilizer.

Search by active ingredient, carrier, study or recipe name; filter by format and source.
Inspect an entry to see ingredients, known quantities, missing values, validation status
and source information. **Use in editor** transfers the selected record into the recipe
editor while preserving project context and source references.

Published ingredient fractions are preserved where recorded. Missing fractions and
technical-active or nutrient assays remain blank; the generator refuses an incomplete
numeric recipe. An ingredient loading is not silently treated as pure active or elemental
nutrient content.

Starting drafts contain explicit example bounds and suggested component roles/materials.
They are internal design hypotheses, not published or validated production recipes.
Compatibility, preparation process, grades and assay values still require definition.

**Save selected recipe to library** stores a generated candidate as a private user-saved
draft in the local workspace SQLite database. Saved compositions are revalidated for
mass balance and active purity. Saving cannot assert laboratory or field validation.
Saved entries can be selected in another project and include parent recipe/library
references. Existing records are not overwritten silently.

## Endpoints

- GET /api/rnd/agent-status
- POST /api/rnd/agent-configure
- POST /api/rnd/agent-test
- POST /api/rnd/ask — GPT coordinator and specialist orchestration
- POST /api/rnd/ask-offline — explicit deterministic troubleshooting commands
- POST /api/rnd/library-search
- POST /api/rnd/library-apply
- POST /api/rnd/library-save

## Validation and implementation references

Tests cover exact-model pinning, refusal to substitute models, credential exclusion,
Responses function-call loops, reasoning-item continuity, real numeric tool dispatch,
separate specialist calls, input-error repair, optional web-tool selection, library
provenance, missing-quantity preservation, starter feasibility, private recipe persistence
and browser-script integration against a running local API.

The headless DOM harness also exercises automatic GPT stage reviews with a simulated
provider, library selection and library saving. It is not an installed-browser visual
certification. External GPT access is verified only by the real connection test after
credentials are supplied.

Implementation follows the official
[OpenAI function-calling guide](https://developers.openai.com/api/docs/guides/function-calling)
and uses the requested
[GPT-6.1 Sol model identifier](https://developers.openai.com/api/docs/models/gpt-6.1-sol).
