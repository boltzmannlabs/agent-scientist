# Physics expansion and identifiability protocol, version 4

Written on 2026-10-19 before building the v4 physics layer. Internal analysis plan; not an external preregistration. Gates reuse the v2 numerical thresholds.

## Scope

Generalize the verified v2 sphere solver to the geometries the catalog actually contains, add the physics the assays demand, and publish which parameter combinations release data can identify. No new experimental claims; all new capability is verified against analytic series or exact conservation laws before any output is used downstream.

## Solvers and verification gates (all mandatory before use)

- **Geometries**: slab, cylinder, sphere via one conservative FV construction (face areas r^d, volumes ∫r^d dr). Gates per geometry: mass balance <= 1e-6; mesh convergence monotone over 20/40/80 shells; time-step convergence below the mesh error; analytic eigenmode-series agreement <= 5e-3 at 80 shells; torch CPU/CUDA float64 agreement abs <= 1e-8, rel <= 1e-6.
- **Heterogeneous diffusivity**: piecewise-constant relative D per cell with harmonic-mean face conductances. Gates: a 10x-less-permeable outer coating slows release; mass balance holds.
- **Finite bath**: well-stirred compartment coupled through the outer face (bath ratio = V_bath/V_domain, partition 1). Gates: equilibrium plateau within 1e-3 of K/(1+K); ratio 1000 within 5e-3 of the perfect-sink solution; total mass balance <= 1e-6. This makes registered non-sink assays (e.g. Tang 2023's 27/3 mL dialysis) modelable instead of decorative metadata.
- **Swelling**: quasi-static reduction tau(t) = (D/R0^2)∫dt/(1+k_s t^m)^2; the moving-boundary advection term is neglected and this approximation is registered, not hidden. Gates: k_s = 0 reduces EXACTLY (<= 1e-12) to the fixed solver; swelling slows release; monotonicity; mass balance.

## Identifiability

Synthetic data from known models, chi-square grids over parameter pairs computed with the GPU-batched verified forward kernel. A parameter is unidentifiable alone when the profiled chi-square never rises 3.84 (95%, 1 dof) above its minimum on both sides. Expected and required findings: D and R are jointly unidentifiable from released fraction (the model depends on D/R^2 only) while the effective rate and loading are identifiable. The published table restricts the v6 inversion space by construction: inversion proposes identifiable combinations (D/L^2, loading, bath ratio), never D and L separately unless one is independently measured.

## Physics features

Per catalog curve: calibrated D/L^2 on the fraction scale (percent /100; mg/g /1000 as a declared mass bound, never a measured loading), geometry tag from the ontology, assay sink condition, finite-bath plateau factor, fit R^2. Exported for every curve; >= 90% coverage of in-target curves is the v5 entry condition. Calibration is descriptive curve fitting, not a measured diffusivity.

## Compute and reporting

One command (scripts/run_v4_physics.py): hash gate -> frozen manifest (discretizations, dt safety, grids, gate thresholds) -> per-geometry and per-physics verification records -> physics features for the whole catalog -> identifiability grids on GPU -> reports/v4/v4_physics.html with every gate verdict and the honest outcome note. GPU (batch width: 10^4-10^5 forward solves per grid, float64); total budget under one hour. Scenario grids remain synthetic sensitivity calculations, never experimental evidence. The standing not-comparable register applies unchanged.
