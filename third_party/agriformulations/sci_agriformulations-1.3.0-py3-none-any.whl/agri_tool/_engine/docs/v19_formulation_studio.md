# Conversational formulation studio

The default GUI at http://127.0.0.1:9173/ is a chat-centered formulation workspace. Launch it with:

```bash
python3 -m scripts.run_v12_gui --no-open
```

Each **New project** creates a saved draft and a durable chat session immediately. A conversation owns its project identity: agent recipe generation and simulations update that project. Use **Fork** to create a separate project with source provenance. Existing projects are indexed as sessions without rewriting their scientific revisions. The prior workbench remains at /classic and the campaign interface at /legacy.

The conversation stays in the center. Its result canvas contains recipes, kinetics, stability, individual-active dose scenarios, experiment plans, imported measurements, fitted models and research reports. Select a recipe or active to compare its results. Every numerical artifact retains its exact inputs, engine version and recipe/active association. History exposes previous versions, and **Ask about this** attaches an explicit artifact reference to a message.

## Execution and collaboration

**Act on request** lets the coordinator answer questions or execute requested tools. **Discuss & plan** permits discussion and draft plans without executing scientific calculations. **Develop product** requests a complete batch of distinct recipe candidates and per-active kinetics, stability and dose calculations. Missing measurements must remain explicit hypotheses; composition alone does not determine release or chemical stability.

Tool activity and completed outputs arrive through server-sent events, with polling after a dropped connection. The server runs investigations in background workers. The composer, project navigation, result inspection and measurement import remain available. Further messages queue within their project; at most two investigations run across the workspace. No client-supplied project document can change another session's identity.

**Stop** interrupts one running task or stops all work in the selected project. **Stop all runs** also clears queued studio requests and cancels active classic-workbench investigations. The local Codex process group is terminated when stopped. HTTP model waits detach promptly and discard any later response; an already accepted remote provider request may continue until its connection returns or times out. Local scientific stages check cancellation before the next calculation and before any revision commit. A calculation already in progress reaches its next checkpoint. Stopping does not restart the server.

Recipes are checkpointed before simulations; each finished recipe/active calculation is durably checkpointed and published separately. Cancellation preserves completed outputs. **Resume unfinished** reuses matching checkpoint inputs and engine versions, then completes the remaining batch. Added measurements survive a resumed batch. Restarting the server marks abandoned jobs interrupted and makes recovery available; it never resumes stopped jobs automatically. Previously submitted, explicitly queued messages remain queued for execution.

## Efficient changes and provenance

**Edit & rerun** applies validated numeric edits directly through scientific engines, with no model request:

- Kinetic changes recalculate that recipe/active's kinetics and dependent dose.
- Chemical retention changes recalculate its stability and dependent dose.
- Physical-only stability changes preserve unchanged chemical-dose calculations.
- A recipe variant must satisfy mass balance and individual-active purity; inherited model parameters are identified as unvalidated assumptions.

Identical numerical inputs and engine versions use a bounded in-memory calculation cache. Interrupted batches additionally reuse durable completed checkpoints. Scientific revisions use optimistic concurrency: newer imports or drafts cannot be overwritten by a late investigation. Outputs from a conflicting save stay in artifact history and can be recovered.

CSV/XLSX import supports column mapping, time/value units, individual active, independent batch identifiers, QC exclusions, source recipe labels and assay-condition selection. **Export** includes the scientific project, report, recipe tables, original measurement sources, full session messages and immutable artifact history. JSON and scenario comparison CSV downloads are also available from result cards.

## Persistence and API

The existing SQLite workspace is retained at data/workbench/workspace.sqlite3. Additive tables hold studio_sessions, studio_messages, studio_requests, studio_artifacts and studio_events. Agent runs gain working_state, checkpoint_no, session_id and cancel_requested. Credentials remain in the selected server connection, outside project documents and exported artifacts.

GET endpoints under /api/studio: sessions, session, messages, artifact, run, events.
POST endpoints: new, message, stop, stop-all, resume, rename, fork, rerun, import, export.
Artifact and run lookups validate session ownership. Message request IDs are idempotent. Project titles can change without scientific recalculation or a scientific revision.

## Validation

The studio tests exercise project isolation, legacy migration, partial result visibility, queued follow-ups, native process cancellation, prompt HTTP-wait cancellation, late-write prevention, resume with newly imported measurements, selective dependency reruns, recipe variant validation, complete exports, tied-timestamp pagination and live HTTP/SSE behavior. Existing scientific and classic workbench tests remain relevant.

```bash
python3 -m pytest --disable-plugin-autoload -q tests/test_studio.py tests/test_agent_runs.py tests/test_product_development.py tests/test_agent_recipe_execution.py tests/test_rnd_workbench.py tests/test_v12_gui.py
python3 -m scripts.run_v12_gui --selftest
```

The local deployment uses the existing Python server and local scientific engines. It does not move this workspace, its database or the local Codex connection to external hosting.
