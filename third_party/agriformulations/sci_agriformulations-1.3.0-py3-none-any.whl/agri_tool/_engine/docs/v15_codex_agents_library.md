# Current Codex agents and shared recipe library (v15)

For query-driven recipe creation, later tool execution and automatic project revisions,
see [the v16 guide](v16_agent_execution.md).

The workbench defaults to the installed Codex CLI and its existing sign-in. The
coordinator and all specialist calls request `gpt-6.1-sol`. An additional OpenAI
API key is not required for this connection.

Start with `python3 -m scripts.run_v12_gui --no-open --port 9174` and open
http://127.0.0.1:9174/. Product brief & projects → Research agent settings contains
the connection selector, reasoning effort and connection test. The optional
OpenAI Responses API connection remains available. Disabling agents in the GUI
does not sign out the machine's Codex account. If Codex is signed out, run
`codex login` on the server machine.

## How Codex runs

Each model call starts a fresh noninteractive Codex invocation using saved CLI
authentication, the pinned model, a read-only sandbox and an ephemeral session.
The app passes context on stdin, runs in a temporary directory, and uses a JSON
output schema. User CLI configuration, project instructions, shell tools,
plugins, apps, hooks and native multi-agent spawning are disabled for these calls.
Specialists are separately scoped model invocations managed by the application.

Codex chooses application tools through structured decisions. The application
validates their arguments and executes recipes, simulations, fitting and experiments.
No application scientific tool is replaced by a model's invented numerical answer.
Web research is enabled only by the visible checkbox. Source annotations require
a web-search event from the CLI invocation. Existing model limits and scientific
assumptions remain applicable.

Authentication files are managed by Codex. The application does not read or copy
them into projects, the database, prompts or exports. There is no silent fallback
to another model or provider. This uses new Codex invocations with the current
machine's sign-in; it does not attach the GUI to this coding conversation.

## User and agent library contributions

The recipe library includes the existing curated published records and labeled
design starters, plus persistent contributions from users and research agents.

- **Add my recipe** opens the recipe editor. Supply actual ingredient identities,
  grades, purity, preparation details and quantities. For an exact composition,
  set each ingredient's minimum and maximum to its mass percentage. Generate a
  checked candidate, select it, enter a library name and notes, and save it.
- **Ask agents to create & save recipes** asks the coordinator to search existing
  records, consult a specialist where useful, develop feasible drafts and save up
  to three candidates through `save_recipe_to_library`. Essential missing
  identities are requested rather than invented.
- Filter by **User recipes** or **Agent recipes**. Agent entries carry their model,
  sources available to the investigation, parent recipe/library references and
  an explicit unvalidated status.

All numeric saved compositions must pass the same mass-balance, purity and active
content checks as generated recipes. Agent proposals remain hypotheses until
experimental evidence supports them. Automatic stage reviews do not have an
instruction to populate the library; saving is an explicit requested action.

## Clearer page context

Connection status appears once in the sidebar and detailed settings live in the
project page. The recipe selector appears on kinetics, stability, dose and
experiment pages. Without candidates, these pages show a create-recipe action.
The active-ingredient selector is shown only for mixtures of multiple actives.
Evidence notes sit beside the relevant results rather than in a global badge.

## Verification

The local signed-in GPT-6.1 Sol connection returned READY in a live test, including
the running GUI endpoint with high reasoning effort. A five-call live investigation
ran simulate_kinetics, consulted a separate kinetics specialist and saved an
agent-generated recipe draft in a temporary test library.
Automated tests exercise CLI invocation restrictions, exact-model pinning,
authentication-status caching, malformed outputs, unavailable tools, error
redaction, source reporting, agent tool execution, dual-origin persistence and
GUI flows. The DOM harness is a functional script test, not a browser visual review.

The integration follows the official
[Codex noninteractive interface](https://developers.openai.com/codex/noninteractive)
and the installed CLI's `codex exec --help`.
