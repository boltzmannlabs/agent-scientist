# Lab operations protocol, version 7

Written on 2026-10-20 before building the labops layer. Internal analysis plan; not an external preregistration. GUI work is explicitly deferred.

## Scope

Five lab-facing capabilities built on the existing verified machinery, each runnable offline and each exporting honest, traceable verdicts: (1) batch verdicts against product specs with drift control limits; (2) Arrhenius temperature-dependence fitting with release-at-temperature predictions; (3) a composition-bridge surrogate mapping ingredient fractions to physics parameters with hard domain refusal; (4) an audit dossier export; (5) an assay-protocol matching service.

## Batch verdict

A product spec (specs/product_*.json) declares: product id, release target window in native units at declared times, tolerance, the endpoint time, and the reference batches (internal study keys) used for drift control. The verdict workflow ingests a batch (existing adapters), forecasts the endpoint from the batch's own early times (v2 forecast-track candidates, inner-split selection), compares forecast and observed-so-far against the spec window, and computes drift: calibrated effective rate (v4 physics features logic) and endpoint z-scores against the reference-batch mean with 3-sigma control limits. Verdicts: PASS / FAIL / BORDERLINE (inside tolerance of a limit) / INSUFFICIENT_EVIDENCE (too few accepted times for the forecast track). Without real internal batches, the demonstration runs on a declared synthetic batch through the same code path - labelled synthetic, never mixed with measured data.

## Arrhenius temperature dependence

For formulations with release curves at two or more temperatures (catalog: Tang 2023 TEB at 30/40/50 C), fit ln(rate) = ln(A) - Ea/(R T) per formulation by weighted least squares on per-curve calibrated rates; export Ea with a bootstrap-over-replicates interval and release-at-temperature predictions through the verified solver. Identifiability rule: Ea and rate@Tref are jointly weakly identified from two temperatures; two-temperature fits are exported with a "weakly identified" flag, three or more without. Synthetic recovery test (known Ea) must pass before any catalog output is used. Arrhenius extrapolation beyond the fitted temperature range is refused, not extrapolated silently.

## Composition-bridge surrogate

A GP mapping ingredient-role fractions (and optionally process parameters) to physics parameters (log10 effective rate, endpoint fraction), with hard domain refusal outside the observed composition ranges (registry pattern) and a declared prohibition on training over published fit parameters (v2 rule: never train on fit metadata as if measured). Current catalog reality: no formulation yet has BOTH measured fractions and release curves (Perera has fractions without curves; curve-bearing studies have fractions as None). The bridge therefore ships as verified machinery demonstrated on synthetic composition data, and the report states the zero-overlap fact; internal batches with recorded composition are the unlock.

## Dossier export

One command zips, for a chosen study or phase: the provenance chain (source files + hashes + locators), the claims audit with verdicts, the execution manifests, gate records, the agent-log hash-chain verification result, and the standing not-comparable register. The zip is the audit-ready bundle; nothing inside is regenerated or summarized beyond what the reports already state.

## Protocol matching

Given an assay protocol record, compute protocol_distance to every catalog protocol and list which studies' calibrations, intervals and verdicts may transfer (distance < 0.3), which are marginal (0.3-0.6) and which do not transfer (> 0.6 or incompatible target families). Thresholds are declared analyst judgments. The service exists to stop a pH-7-calibrated interval from silently covering a pH-4 assay.

## Governance

Hash gate and frozen manifest before any fit; synthetic demonstrations labelled synthetic; agents unchanged (proposals only); standing not-comparable register in force. One command: python3 -m scripts.run_v7_labops. Compute: CPU only.
