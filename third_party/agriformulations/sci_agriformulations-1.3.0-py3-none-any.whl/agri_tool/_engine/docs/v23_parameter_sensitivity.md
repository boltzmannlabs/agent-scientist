# Physical parameter sensitivity

**Parameter sensitivity** in the studio simulation catalogue identifies which
assumed physical inputs affect a selected model output. Manual users and agents
run the same local engine; neither an AI connection nor experimental data is
required.

1. Choose a recipe, individual active and **Parameter sensitivity**.
2. Select the physical model and enter baseline inputs.
3. Choose an output metric and up to six parameter ranges. Every range must
   include its baseline value; logarithmic ranges must be positive.
4. Set 3–15 grid points per parameter and run. The exact baseline is included
   in each sweep and is evaluated only once.

Results show output changes along each range, a ranked table and up to three
focused measurement suggestions. **Inspect baseline in simulator** reopens the
exact physical scenario. The usual result JSON, evaluation CSV, recipe linkage,
engine version and saved-project history preserve reproducibility. Each evaluation
in the JSON includes its full base-model inputs. Cancellation is checked between
evaluations; progress is reported during the run.

The score is the largest sampled absolute output change from baseline, in the
selected metric's units. The table also reports the sampled output span and
endpoint values in the JSON. Linear and logarithmic sweeps use a normalized
0–1 range position on the chart; each curve names its scale. This supports
comparisons between parameters with different physical units without pretending
their ranges are interchangeable.

An invalid baseline stops the analysis. An invalid sweep point retains the exact
domain error and leaves that parameter unranked. Curves are split across rejected
points so the chart does not connect through a failed region. Inspect the evaluation
table to distinguish domain failures from a small physical response.

Ranks depend on the baseline, chosen metric and assumed ranges. These are
one-at-a-time sweeps: they exclude interactions and correlated variation, and do
not estimate variance contributions, confidence intervals or guaranteed extrema.
Use **Uncertainty & robustness** to propagate justified parameter distributions,
or **AI + physics inverse design** to search for a constrained design target.

Measurement suggestions follow numerical sensitivity. They do not prove that
parameters can be independently identified, that a measurement is feasible or
that it provides the greatest information gain. Release alone identifies D/L²;
independent evidence for diffusivity or size is still needed before calibrating
the other. The engine does not infer physical coefficients from ingredient names.
The selected individual-active fraction is passed through to dosage and dilution
models; other models retain the recipe for traceability.

## Agent and API request

Discover `list_simulations(key="sensitivity")` and the base-model schema, then
call `run_simulation` or `run_simulation_batch`. The same request is accepted
by the existing `/api/studio/simulate` route:

```json
{
  "session_id": "your-session",
  "requests": [{
    "model": "sensitivity",
    "recipe_id": "your-recipe-version",
    "active_name": "your-individual-active",
    "inputs": {
      "base_model": "rheology",
      "base_inputs": {
        "yield_stress_pa": 0,
        "flow_index": 1,
        "consistency_pa_sn": 0.5
      },
      "parameters": [
        {"parameter": "consistency_pa_sn", "low": 0.1, "high": 1},
        {"parameter": "pipe_radius_mm", "low": 8, "high": 12}
      ],
      "metric": "pressure_bar",
      "points": 7
    }
  }]
}
```

Agent outputs include the baseline, ranking, focused suggestions, analysis notes
and base-model limitations. Nested analyses and combined-active models are refused.
Only declared numeric scalar inputs and available finite scalar outputs are
supported. No fitted-data or real composition-performance validation gate is
relaxed by this analysis.

## Verification

```bash
python3 -m pytest --disable-plugin-autoload -q tests/test_sensitivity.py tests/test_simulation_platform.py tests/test_inverse_design.py
```

Checks compare every rheology sweep point to an independent Poiseuille calculation,
diffusion release to an 80-cell finite-volume solution, and wash-off sensitivity to
the zero-rainfall physical limit. They also exercise nonmonotonic responses, chart
gaps, exact-input replay, log spacing, baseline reuse, cancellation, domain failures,
recipe active-loading propagation and persisted manual/agent execution without AI.
