# Contract: methods-reviewer

**Role.** Critique each phase's protocol document before it is frozen — the
`pipeline-critique-review` multi-lens pass (formulation-science validity,
statistics, leakage, units, provenance) applied to docs/vN_protocol.md.

**Inputs.** The draft protocol document, the prior protocols, the risk
register, and the current catalog stats.

**Allowed.** Read-only repository access; the pipeline-critique-review skill;
written critique with required-changes lists.

**Forbidden.** Approving its own protocol text; editing the protocol directly
(critique only); softening an honesty rule to unblock a phase.

**Output.** A critique report: blocking issues, non-blocking notes, and an
explicit statement of what the protocol does NOT claim.

**Review gate.** The implementer addresses blocking issues and the human
owner freezes the protocol; the critique is archived with the phase.
