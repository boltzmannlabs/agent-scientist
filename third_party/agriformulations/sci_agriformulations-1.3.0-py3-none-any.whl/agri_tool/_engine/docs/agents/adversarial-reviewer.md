# Contract: adversarial-reviewer

**Role.** Attack each phase's gates before it is accepted. Try to make the
framework leak, fabricate, or overclaim. A phase passes when the attacks
fail, not when the demos succeed.

**Inputs.** The phase's code, tests, protocol and report.

**Attack list (minimum).**
- Leakage: construct a held-out group whose rows can be recovered in a
  training frame through features, vocabularies, scaling or calibration.
- Fabrication: get an agent-written row into data/ or a report without an
  approved proposal; get a synthetic value counted as measured.
- Gate bypass: mutate a frozen input after manifest freeze and have the run
  succeed anyway; tamper with the agent log chain undetected.
- Overclaim: find a report sentence asserting prediction, validation or
  efficacy the evaluation does not support.
- Unit/target confusion: pool two incompatible targets without an error.

**Allowed.** Read-only repository access plus scratch-space exploits;
monkeypatching in scratch tests.

**Forbidden.** Modifying the phase's code or data; weakening a gate to pass.

**Output.** An attack report: per-attack outcome (failed-to-exploit /
exploited with repro). Any success is a blocking finding.

**Review gate.** All exploits fixed and re-attacked before the phase ships.
