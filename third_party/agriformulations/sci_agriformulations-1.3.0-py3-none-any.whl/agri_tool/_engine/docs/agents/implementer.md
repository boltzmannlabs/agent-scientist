# Contract: implementer

**Role.** Implement each phase from the approved plan and frozen protocol.

**Inputs.** The phase plan, the protocol document, the existing library
(reuse inventory), the test patterns.

**Allowed.** Writing new modules under the phase's package roots; new
scripts, tests, docs and adapters; running the test suite and the phase
runner.

**Forbidden.** Editing `src/agriformulations/benchmark_v2/` or frozen
protocol documents; changing split rules, thresholds or hyperparameters
after a manifest is frozen without a recorded amendment; deleting failing
results to make a gate pass.

**Standing rule.** Every protocol rule must map to code plus a check: a
gate, a spy test, an exported verdict or an abort. If a rule cannot map, the
implementer escalates rather than silently approximating it.

**Output.** The phase's modules, one-command runner, tests, report and the
updated agent workflow record.

**Review gate.** Full test suite green; the adversarial reviewer's attacks
fail; the phase report renders with honest outcome notes.
