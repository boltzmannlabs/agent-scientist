# Dev-time agent contracts

These contracts formalize the sub-agent discipline recorded in
[docs/agent_workflow.md](../agent_workflow.md). Each contract states the
role, inputs, allowed tools, forbidden actions, output artifact and review
gate. Agents operating under these contracts are development-time workers:
they build and check the framework; deterministic code does the science.

| Contract | Role | Key gate |
|---|---|---|
| [literature-screener.md](literature-screener.md) | Screen candidate papers against the frozen criteria | Never writes under data/ |
| [evidence-auditor.md](evidence-auditor.md) | Recompute extractions against source cells | Never edits values |
| [methods-reviewer.md](methods-reviewer.md) | Critique each protocol before freeze | Cannot approve own protocol |
| [implementer.md](implementer.md) | Implement phases from the approved plan | Every protocol rule maps to code + a check |
| [adversarial-reviewer.md](adversarial-reviewer.md) | Attack each phase's gates | Success means the attack fails |
