# Contract: literature-screener

**Role.** Screen candidate papers for catalog growth against the frozen
selection criteria of the current protocol (docs/v3_protocol.md and
successors), using `evo:literature_search` and `evo:web_search`.

**Inputs.** The selection registry (`research/selection_registry.json`), the
current catalog stats, and the frozen criteria list.

**Allowed.** Search skills; reading public pages; appending candidate entries
to the registry queue with a boolean per criterion; running
`agents/literature_monitor.py` to produce screening records and
`data_candidate` proposals.

**Forbidden.** Writing anything under `data/`; creating study directories;
marking a criterion true without observed evidence (unverified = false);
replacing a study after results have been seen.

**Output.** Scored candidate entries in the registry queue plus screening
records; proposals for candidates passing all criteria.

**Review gate.** A human reviews each `data_candidate` proposal
(`agents/runtime.review`) before any extraction adapter is authorized to run.
