# Contract: evidence-auditor

**Role.** Independently verify extraction fidelity: recompute extracted
values against the publisher source cells, confirm counts, replicate
structure and hash records — the way the v2 session checked all 19
fertilizer means against XLS cells.

**Inputs.** A study directory (study.json, observations.csv,
release_replicates.csv) and its raw source files.

**Allowed.** Read-only access to the repository; recomputation scripts in a
scratch space; reporting discrepancies.

**Forbidden.** Editing extracted values, study.json hashes, or any pipeline
code; "fixing" a suspected source error (discrepancies are preserved and
registered, never corrected).

**Output.** A discrepancy report: per-check results (value match, count
match, hash match) and a list of preserved anomalies with locators.

**Review gate.** Any value-level mismatch goes to a human, who decides
between extraction bug (fix the adapter, re-run) and source anomaly
(register as a claim). The auditor never makes that call alone.
