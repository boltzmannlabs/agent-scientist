# INR formulation costing and diverse recipes

New briefs default to INR for India. Recipe cards offer **Calculate / edit cost**,
**Estimate India prices with agent**, and **Suggest diverse alternatives**.

## Cost scenarios

Costing retains exact recipe masses, ingredient prices, production assumptions,
source/grade caveats, low/base/high ranges and the scientific engine manifest.
Changing a costing scenario never rewrites the recipe. Missing prices remain
unknown; partial results show the known subtotal and priced mass coverage. A
supplied zero is an explicit assumption, not a default for missing data.

For input mass `B`, saleable mass `S = B × yield_pct / 100`, ingredient mass
fractions `wᵢ` and as-supplied prices `pᵢ`:

```text
materials = B × Σ(wᵢ × pᵢ)
manufacturing = materials + B × processing_per_input_kg + fixed_batch_cost
pre_tax = manufacturing × (1 + overhead_pct/100)
          + freight_per_batch + S × packaging_per_saleable_kg
final_batch = pre_tax × (1 + tax_pct/100)
final_per_kg = final_batch / S
cost_per_pack = final_per_kg × pack_size_kg
```

All production fields except pack size require explicit inputs for a final cost.
Zero tax/freight is an exclusion scenario, not verified GST treatment or free
delivery. Yield is a costing assumption, not a prediction of active recovery.
Purity is already reflected in technical ingredient masses; it is not applied a
second time. There is no implicit currency or litre-to-kilogram conversion.
Bounds propagate together and are not statistical confidence intervals.

The price agent uses `calculate_formulation_cost` after checking technical grade,
unit, source, pack/MOQ and date. Grade or small-pack proxies remain explicit. When
research is unavailable, heuristic estimates must say so, without invented sources.
Results are estimates rather than quotations or selling prices. Profit, financing,
minimum-pack procurement cash outlay and unlisted charges are excluded. Independent
scenarios persist in `cost_estimates`, display beside recipes and export through
`formulation_costs.csv` and `cost_estimates/*.json`.

## Diverse suggestions

Within one ingredient space, a seeded feasible pool includes linear-programming
boundary solutions. Greedy maximin selection spreads compositions by total
variation distance (half the L1 mass-fraction distance), before cost sorting.
Active assay, mass balance, bounds and material-cost ceilings remain enforced.
The finite pool does not prove globally maximal diversity or performance. Fixed
compositions return one recipe with an honest shortfall explanation.

The agent's `create_recipe_portfolio` tool accepts 2–6 material/format families,
up to 24 requested recipes, and requires shared individual active identities,
pure-active targets, batch mass and currency. Percentage jitter or renamed
families do not qualify as different chemistry. Each draft carries a family,
rationale, assumptions and exact family brief. Existing recipes remain saved.
The studio's alternatives action also preserves the current formulation format.
Compatibility, physical properties and efficacy remain unmeasured hypotheses.

The recipe editor's cost ceiling applies to materials per input kg, separately
from finished cost per saleable kg.

## Indicative India example

`data/prices/india_2026-10-22.json` contains seven source-linked ingredient price
estimates for the existing coconut tebuconazole/emamectin SC drafts, with listing
anchors, confidence, grade, pack/MOQ and rejected misleading leads. This is an
editable research snapshot, not a universal price catalogue.

With assumed 98% saleable yield, INR 30 processing/input kg, INR 25
packaging/saleable kg, 10% manufacturing overhead and explicitly excluded fixed
batch, freight and tax charges:

| Original draft | Materials / input kg | Finished / saleable kg | Price-bound range / saleable kg |
|---|---:|---:|---:|
| SC 01 | INR 458.09 | INR 572.85 | INR 414.20–751.88 |
| SC 02 | INR 397.21 | INR 504.52 | INR 373.53–661.25 |

These mix bulk technical-material and small-pack excipient anchors. Poloxamer 188
uses a costly 1 kg laboratory-grade proxy; an industrial bulk quote is missing.
Emamectin 90% evidence has low confidence. These are pre-tax, freight-excluded
planning estimates. Lower cost does not establish better formulation performance.

The same project now retains six additional agent-designed drafts: three
lignosulfonate/sulfosuccinate variants and three acrylic-copolymer/nonionic
variants. Active identities and pure-active targets remain unchanged. Their
provisional base costs are INR 341.21–349.56/kg and INR 350.60–378.55/kg respectively,
under the same production assumptions. Exact India quotes for the branded
excipients are missing: these rows include clearly labelled proxy/heuristic prices
from `data/prices/india_additional_2026-10-22.json`, rather than verified procurement
prices. The full inputs, outputs and price ranges are retained in
`reports/v26/agent_recipe_portfolio.json`, `coconut_original_costs.json` and
`agent_portfolio_costs.json`. All eight recipes have separate cost scenarios;
original recipe and cost records are preserved. Manufacturer references establish
general excipient roles and identity, not compatibility with the dual-active mix.

## Verification

```bash
python3 -m scripts.run_v26_cost_diversity
python3 -m pytest --disable-plugin-autoload -q
```

The independent accounting benchmark derives INR 40,002 final batch cost from
100 kg inputs and 80 kg saleable mass. The diversity benchmark checks all three
known simplex vertices, mass balance and seeded reproducibility. Tests cover
unknown prices, ranges, purity, currency, numerical limits, atomic actions,
revisions, ownership, persistence, exports, UI provenance and agent tools.

The complete suite passed on 2026-10-22: **671 passed, 1 skipped**, with two existing
surrogate imputation warnings. Follow-up tests also verified that portfolio actions
retain original recipes and that both new agent actions are wired in the editor.
Live checks confirmed eight recipe artifacts and eight matching cost scenarios.
