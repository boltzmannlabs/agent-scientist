# SC/EC validation fixes and formulation classes

The October 22 browser report identified workflow, interpretation and interface
failures. This change addresses those engineering failures while retaining the
scientific boundary: numerical scenarios do not demonstrate product stability,
compatibility, shelf life, efficacy or manufacturing readiness.

## Resulting behavior

| Finding | Implemented behavior |
|---|---|
| Research blocked local calculations | Separate bounded research and local worker capacity. A project can run one local calculation and one research task concurrently. Research follow-ups remain ordered. |
| Concurrent work could overwrite results | Completed run artifacts merge by immutable record identity. Newer settings remain authoritative; conflicting edits to the same scientific record are refused. Ordinary user saves retain revision checks. |
| Repeated schema reads and unfinished synthesis | Cached schema reads, bounded model/research budgets, saved checkpoint syntheses and elapsed/last-progress indicators. Duplicate reads do not count as scientific progress. Discussion and tool-error repair remain separate. |
| Recipes completed but downstream models awaited another model response | `run_formulation_workflow` validates recipe families and all declared scenarios together, executes/checkpoints each case, and publishes a complete computed comparison without another model turn. Domain failures remain partial results. |
| EC aqueous excess looked like actual precipitation | A prominent aqueous-only label and interpretation appear before the number. EC/OD/EW explicitly gate product precipitation, emulsion stability and compatibility as unavailable. Agent batches and design comparisons retain the same qualifications. |
| Recipe ranking from shared assumed inputs | Recipe linkage and comparisons explicitly prohibit ranking excipient systems where composition does not parameterize the model. |
| Indistinguishable scenarios and stale selection | Optional names, readable parameter summaries, timestamp and ID suffix; newly completed and cached scenarios select correctly. Selected result/tab persist in the project URL across reloads. Historical records are presented without rewriting their scientific payloads. |
| Invalid live composition summaries | Field validation precedes total/active calculations. Invalid purity, negative amounts, reversed bounds and inconsistent references disable Save and show row errors. Floating-point boundary tolerance permits exact purity-corrected targets to reopen. |
| Unexplained amounts in bounds mode | Excipient reference amounts are optional when bounds are supplied. Each active still needs a technical target amount to define its pure-active loading. References must lie inside their bounds. |
| Unverified ingredient grades | Selection and generated records explicitly mark grades/availability as unverified. Whole supplied-grade masses include their carrier. Source metadata is not represented as verified inventory. |
| Search mistaken for source verification | Separate metadata-only, abstract-reviewed and full-text-reviewed stages. Reviewed stages require recorded review notes. A reviewer label does not automatically establish claim support. |
| Export completion could not be observed | Visible preparation/error feedback, filename/size, and a recoverable download link for the current page session. Browser preparation is not asserted to prove the file was saved. |

Research model calls are bounded to 180 seconds and the coordinator's shared time
budget is 360 seconds. Completed outputs survive timeout or cancellation. A
checkpoint report is explicitly incomplete; it is not disguised as a finished
scientific review. The complete workflow action removes the additional model
round-trip between authored recipe/scenario inputs and their computed comparison.

## Formulation classes

The recipe editor, bounded generation, manual entry and agent guide support EC,
SC, SL, OD, WG (WDG alias), WP, SG, SP, GR and EW. Existing CR and fertilizer design
categories remain, explicitly distinguished from standard pesticide physical-form
codes. Each class exposes physical form, dilution/dispersing needs, potential
market advantages, design cautions and relevant assessment needs.

The requested marketing advantages are conditional. SC does not guarantee safety
or non-flammability; SL does not guarantee perfect stability; EC does not guarantee
penetration or knockdown; WP does not establish crop tolerance. GR is a direct dry
application class where the actual product label permits it. “Tank mixing” in the
guide means water preparation, not permission to combine pesticide products.

Definitions use the [APVMA formulation guide](https://www.apvma.gov.au/about/communication-and-decision-making/section-6a-guidelines/formulation-types)
and [CIPAC formulation codes](https://www.cipac.org/images/Handbook-O/DD_App_D_293_294.pdf).
These sources define classes rather than approving proposed recipes.

## Complete workflow action

`run_formulation_workflow(workflow_json=...)` accepts a name, goal, either 2–6
independent `designs` or existing `recipe_ids`, 1–12 named base-model `scenarios`,
and an optional bounded metadata research query. Scenarios apply across candidate
versions under shared declared conditions; mixture workflows identify the
individual active. Up to 96 cases are permitted. Every request validates before
state mutation, then completed cases are checkpointed. The report includes:

- Actual ingredient percentages and technical purity accounting.
- Model outputs with units, scenario references and interpretation gates.
- Explicit comparison limits and unresolved validation needs.
- Full workflow inputs, individual scenario provenance and engine manifest.

A rejected model case remains in the report and prevents a fully computed status.
No universal recipe score, learned composition/property mapping or emulsion model
is invented. Metadata retrieval remains separate from source review.

## Verification evidence

The full test suite passed: **699 passed, 1 skipped**, with two existing
surrogate all-NaN warnings. No experimental validation is implied by these tests.

```bash
python3 -m pytest --disable-plugin-autoload -q
python3 -m scripts.run_v27_validation_recovery --browser --browser-executable PATH
```

`reports/v27/validation_recovery.json` records 18 passing real-Chromium checks in
an isolated workspace, including local execution while a scripted research worker
is active, input validation, distinct/selected scenarios, reload, desktop/mobile
layout, ZIP download and recovery-link download. The ZIP's project and artifact
history were reopened and checked. This browser coordination fixture is explicitly
scripted, not evidence that a live model reviewed literature.

Independent checks reproduce 2.76356657 mm/day for the report's 5 µm SC reference,
fourfold scaling at 10 µm, 2,500 mg/L EC dilution, and the restricted carbonate
ratio. The aqueous excess remains a hypothetical fraction, not actual EC
precipitation. Screenshots and a downloaded archive are in `reports/v27/`.

`tests/test_validation_recovery.py` covers concurrent completion in both orders,
research cancellation, source/recipe consistency, retained user settings, all
requested classes, incomplete evidence and bounded synthesis. The workflow tests
verify that recipes, all physical cases and the final comparison complete with
only one scripted model response, without a second response available.

Two new live-provider workflows completed without cancellation or warnings:

| Project | Completion time | Saved result |
|---|---:|---|
| [SC](http://localhost:9173/?session=e70df61653d841da8ee4cbccf4d58f15&tab=evidence) | 127 seconds | Two recipes, four evaluated scenarios and final comparison |
| [EC](http://localhost:9173/?session=92a5239545b54231b50c74c6721445b2&tab=evidence) | 213 seconds | Two recipes, four evaluated scenarios and final comparison |

[Live numerical checks](../reports/v27/live_atomic_workflows.json) independently
verify mass balance, pure-active loading, the SC settling/process outputs and the
EC dilution outputs and interpretation gates. These runs used the configured live
agent and local numerical solvers. Source discovery remains metadata/abstract
retrieval, not verified full-text compatibility evidence.

[Live browser checks](../reports/v27/live_browser_reports.json) confirm both final
reports render their comparison tables and download project archives containing
the two recipes, four analyses and computed workflow. No JavaScript errors were
observed. Screenshots and downloaded archives are retained in `reports/v27/`.

The original SC and EC projects from the supplied report have unchanged revisions
and SHA-256 content hashes. New runs used separate projects. Earlier incomplete
multi-turn runs remain recorded in `reports/v27/live_workflows.json`; their saved
partials are not counted as successful completions. An independent local scenario
also completed while one of those actual research runs remained active.

## Scientific work still required

The software now makes limitations explicit and supports reproducible execution.
It does not supply independently validated composition-to-rheology, milling or
emulsion-stability mappings for the proposed SC/EC systems. Those capabilities
require applicable parameter evidence, validation and domain gates. Product
performance remains unverified; the platform cannot legitimately resolve that
gap by relabelling a physical scenario as a prediction.
