# Live agent progress and investigation history (v17)

The default agent window now uses [simple discussion followed by finalization and execution](v18_chat_finalize.md).

Agent work now runs independently of the browser request. The GUI shows model
requests, framework tool execution, rejected inputs and project-save completion
while the investigation is running. These events describe actions and results;
private chain-of-thought is not exposed.

## GUI behavior

Creating recipes, asking the research agents and automatic stage reviews use
background investigations. A temporary progress panel appears during the run.
The numerical tools and existing project revision rules are unchanged.

**Ask the research agents → Agent investigations** lists recent work across
projects or for the current project. Each entry shows status, question, tool
progress and the saved project revision when available.

- **Open saved results** restores the revision associated with that investigation.
- **Follow up from latest** loads the latest saved project and prepares an editable
  follow-up question. It does not automatically repeat the previous task.
- **Open working draft** recovers the request's original state and any completed
  outputs when saving failed or the investigation stopped.
- **Track this investigation** reconnects to a running job.

Refreshing the page automatically reconnects to the tab's active investigation
when browser session storage is available. Only the investigation ID is stored
there. Closing the page does not cancel the server's job; another page can find
it in the persistent history.

Completed runs retain their result and original working state in the private
workspace database. This also preserves unsaved inputs and uploaded source files
for recovery if the final project save fails. Credential fields are removed from
recovery snapshots; agent credentials remain in the connection service.

## Execution and recovery rules

A repeated start request with the same request ID and payload returns the existing
investigation. It does not run the model or tools twice. Reusing an ID for a different
payload is rejected. At most two background investigations run per server at once.

Connection settings cannot change during a background investigation. This prevents
a run from switching provider or credentials between coordinator/specialist calls.
The existing model pin remains GPT-6.1 Sol.

Research model requests may run for up to 10 minutes each, within a shared
30-minute investigation budget that includes coordinator and specialist turns.
The previous 80-second request cutoff could stop source verification before
any result was returned. Connection checks retain their shorter timeout.

A server process restart marks its unfinished work as interrupted when history is
read. The original working draft and previously saved project remain recoverable.
The application does not silently restart interrupted jobs, and it does not claim
that unfinished in-memory calculations were committed.

Save conflicts remain visible as completed-but-unsaved results. Opening an old run
restores its recorded revision; use **Follow up from latest** to build on the current
project without targeting an obsolete revision.

## Endpoints

- POST /api/rnd/agent-start — existing agent request plus optional client_request_id.
- GET /api/rnd/agent-run?run_id=… — progress and terminal result.
- GET /api/rnd/agent-runs — recent investigation summaries.
- GET /api/rnd/agent-runs?project_id=… — summaries for one project.

The synchronous POST /api/rnd/ask endpoint remains available for existing callers.
History summaries exclude full numerical results and original project snapshots;
these are returned only when an individual completed investigation is requested.

## Validation

Automated tests cover progress before completion, background HTTP behavior,
idempotent retry, capacity limits, credential removal, worker failure, interruption,
durable reopening, settings changes during execution and GUI result recovery.

A live GPT-6.1 Sol background test returned its run handle in approximately
15 milliseconds, reported model/tool/save events, saved project revision 1 and
recovered the same answer through a newly opened investigation service. That test
used a temporary workspace and did not create product recipes or field-use claims.

Functional GUI checks use the existing DOM harness and a running local HTTP API.
