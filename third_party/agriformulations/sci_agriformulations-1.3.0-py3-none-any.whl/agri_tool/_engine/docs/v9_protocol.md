# Stereochemistry protocol, version 9

Written on 2026-10-20 before building the stereo layer. Internal analysis plan; not an external preregistration.

## Scope

Make the framework's stance on chirality explicit, machine-checked and honest. Five deliverables: (1) a controlled stereo descriptor on every catalog ingredient and v8 component (descriptor + evidence, `unspecified` allowed and counted, never imputed); (2) a `chiral_resolution` flag on assay protocols (whether the analytical method resolves enantiomers); (3) the physics assumption stated and a synthetic-gated multi-species capability: per-enantiomer release through the verified kernel, with the identifiability statement that follows; (4) a stereo overlay on the v8 campaign (regime distance between concept and analogue, mismatch flags, overlay widening - never rewriting frozen v8 exports); (5) a chiral-carrier flag, because chitosan/alginate/agarose carriers are chiral and the kernels do not model enantioselective release. Out of scope, per the standing register and amendment A2: enantioselective efficacy/toxicity (not comparable), and any enantiomer-specific kinetic claim from total-a.i. data.

## Physics assumption (registered, amendment A2)

The Fickian kernels v1-v8 treat the active as one stereo-blind species. This is exact for diffusion in achiral media (enantiomers share the scalar diffusivity) and exact for what total-a.i. assays measure. It is NOT a model of enantioselective release from chiral carriers or chiral media - for that, stereo-resolved curves are required, and none exist in the catalog (the protocol inventory is expected to show `chiral_resolution` unspecified everywhere; that zero is an export, not a failure being hidden).

## Descriptors and registries (data/v9/stereo)

Controlled vocabulary on IngredientSpec: achiral, racemic, enantiopure, single_stereoisomer, diastereomeric_mixture, multi_stereocenter_natural, complex_mixture, unspecified. Three pinned registries: `ingredients.json` (every catalog ingredient of every formulation, keyed study/formulation/ingredient-name, validated to exist in the catalog), `components.json` (must cover exactly the v8 component set), `analogues.json` (must cover exactly the five v8 analogue study keys; records the active and carrier regime per study). Every entry carries descriptor, note, source_url and retrieved_utc. Descriptors are screening-level analyst judgments where the source is silent - the note says so; `L-phenylalanine` is the one source-pinned single stereoisomer (the L- prefix is in the ingredient name).

## Multi-species machinery and identifiability (synthetic-gated)

Per-enantiomer release is w·F(k_R) + (1-w)·F(k_S) through the same verified analytic kernel, w the loading share. Automated demonstrations on declared synthetic data: (a) recovery gate - from stereo-RESOLVED curves both k_R and k_S are recovered within the v6-style tolerance (rate ratio 1.25x) in >= 90% of trials; (b) degeneracy demonstration on the TOTAL curve, exporting two separate statements. VALUE degeneracy is empirical: grids count the (w', k_R', k_S') triples reproducing the total curve at a strict tolerance (0.02 fraction) and at the campaign's own feasibility tolerance (0.05 fraction - the same number v8 calls feasible); the verdict is read at the campaign tolerance, and the run of 2026-10-20 produced jointly unidentifiable there (47 passing triples over three loading splits; at the strict tolerance the manifold nearly closes). ASSIGNMENT degeneracy is exact and grid-free: (w, k_R, k_S) and (1-w, k_S, k_R) produce identical total curves, so total-a.i. data can never say which enantiomer carries which rate. Either way, only the loading-weighted effective rate (what v1-v8 calibrate from total-a.i. data) is recoverable. Verdicts are exported as computed; the demo never fabricates certainty.

## v8 overlay (additive only)

For every v8 concept: the stereo regimes of its active(s) and partner, the chosen analogue's active regime, a regime distance - match (same descriptor, or both single-isomer forms), related (achiral/racemic vs single-isomer family: solubility-regime uncertainty), cross_class (multi_stereocenter_natural or complex_mixture on either side against a non-identical other), unspecified (either side unknown) - and the worst-case regime over the concept's actives. Mismatched regimes widen the transferred region geometrically by a declared factor (match 1.00, related 1.15, cross_class 1.30, unspecified 1.15) in an OVERLAY export; frozen v8 numbers are never edited. Concepts carrying chiral carriers (chitosan, alginate, agarose-class) get a chiral_carrier flag with the registered-assumption note. MIX/ROBUST concepts (no kinetics claim) export regimes and flags without a regime distance.

## Gates

Registries valid and complete (every catalog ingredient described or explicitly unspecified; components/analogues cover their v8 sets exactly); resolved-curve recovery gate passes; the degeneracy demonstration runs and its verdict is recorded; the protocol chiral-resolution inventory covers every registered protocol; the overlay covers every v8 concept row; two overlay passes are byte-identical; the pending v8 campaign proposal is untouched.

## Governance

Protocol doc first (this file, hash-pinned); manifest frozen and re-verified before any computation; deterministic computation only; no new proposal type - v9 is an analysis layer feeding the existing pending v8 human review, not a decision point of its own. One command: python3 -m scripts.run_v9_stereo. Compute: CPU only. scripts/reproduce chains v1 through v9.
