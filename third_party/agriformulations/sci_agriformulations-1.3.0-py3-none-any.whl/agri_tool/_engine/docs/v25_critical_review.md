# Critical review and model-integrity improvements

The review prioritized errors that could change a formulation design decision or
misstate the evidence behind a numerical result. Reproductions used synthetic
inputs and local code; no new chemical, field-efficacy or measured-performance
claim was made.

## Findings and fixes

| Priority | Finding | Consequence | Fix |
|---|---|---|---|
| High | Finite-bath diffusion propagated a slightly negative numerical eigenvalue for its theoretically neutral conservation mode. | At declared long-time settings, total mass could decay and the bath could settle below the correct equilibrium. | Preserve the exact zero eigenvalue and reject violations of mass conservation, concentration bounds or the bath equilibrium bound. |
| High | Rheology calibration checked the displayed shear grid, omitting the shear used for pipe pressure and the fixed 100 s⁻¹ viscosity metric. | Outputs could be marked fit-informed while querying the constitutive relation outside its measured range. | Check every implemented constitutive query, require explicit extrapolation when needed and record both requested and calibrated ranges. |
| High | The engine fingerprint omitted lower-level release, geometry, swelling and other numerical dependencies and runtime versions. | A changed solver could reuse an old cached result or leave an old measured fit eligible. | Hash an explicit set of scientific source files, including lower-level solvers, and Python/NumPy/SciPy versions. Store the manifest with fits, simulations and studies. |
| Medium | Opening a constrained revision sliced a scenario's objectives to the optimizer limit. | A valid four-objective study could open a search that omitted an objective. | Refuse oversized transfers with a specific scope-selection message. Supported transfers preserve every declared objective and bound for that scenario. |
| Medium | An unavailable optimization metric aborted the entire search. | A single endpoint with no finite drying time discarded useful evaluations elsewhere in the domain. | Preserve the endpoint as an unavailable-metric rejection, retain its exact reason and continue. Unsupported metric names remain input errors. |

Before the finite-bath fix, a cylinder with bath ratio `0.001`, diffusivity
`1e-6 m²/s`, length `50 µm` and horizon `36500 days` returned a mass-balance error
of approximately `0.329775`. The independently known closed-bath equilibrium is
`K/(1+K)`, here `0.000999001`. The repaired model preserves mass to floating-point
precision across all three geometries and the tested small/large bath ratios.

The rheology reproduction fitted synthetic observations over `0.1–1000 s⁻¹`
and selected a displayed grid of `1, 10, 100 s⁻¹`. With a `10 mm` pipe radius and
`1000 L/min` flow, the implemented nominal shear is approximately `21220.66 s⁻¹`.
That request previously passed the calibration gate. It now requires an explicit
extrapolation choice; the resulting artifact records the actual domain use.
This checks the model's approximate nominal-shear relation, rather than upgrading
it to a validated non-Newtonian hydraulic design calculation.

## Better design decisions

Study criteria now include a **signed specification margin** in the metric's own
units: positive is inside all supplied bounds, zero is on a bound, and negative
is outside. The violation magnitude reports the distance outside the allowed
interval. Target objectives also report absolute target distance. Next steps name
the failing value and distance instead of only saying that a requirement failed.
Margins for different metrics are not added into a universal score.

Without acceptance limits, next-step guidance explicitly says that specification
satisfaction is unassessed. New artifacts retain a source/runtime manifest;
historical results remain unchanged. Earlier fits require refitting when their
recorded engine identity differs. A numerical solver replay remains distinct from
independent experimental validation.

## Verification

```bash
python3 -m scripts.run_v25_model_integrity
python3 -m scripts.run_v24_design_studies
python3 -m scripts.run_v22_inverse_design
python3 -m pytest --disable-plugin-autoload -q
```

The version-25 benchmark exports `reports/v25/model_integrity.json`, including
exact finite-bath inputs, conservation and equilibrium errors, requested versus
calibrated shear ranges, boundary-search results and the engine manifest.

On 2026-10-21, all three benchmark scripts passed and the complete suite reported
**602 passed, 1 skipped**, with two existing surrogate imputation warnings.
Across the nine extreme finite-bath cases, the maximum conservation and
equilibrium errors were both `2.3425705819590803e-14`. A live studio replay of the
synthetic handling/storage example evaluated all six cases, retained its original
study, and verified the new margins and engine manifest.

Regression tests independently assemble finite-volume face fluxes and propagate
them with a matrix-exponential action to check transient release without using
the production eigensystem solver. They also cover zero/long-time limits,
concentration bounds, corrupt-solver refusal, source-change cache invalidation,
runtime identity, fit invalidation, explicit versus implicit extrapolation,
two-sided specification margins, exact-boundary satisfaction, objective transfer,
undefined-metric retention, editor round trips and existing studio/agent behavior.

## Remaining limitations and development priorities

1. Studies evaluate independent model scenarios. They do not yet propagate shared
   property uncertainty through a coupled model network or perform whole-study
   robust optimization. The present per-model optimizer must be followed by a
   complete study replay.
2. Recipe ingredients do not determine viscosity, diffusivity, degradation or
   biological performance. Candidate property changes remain assumptions or
   matching measured fits. Stronger composition predictions need independent
   formulation validation and applicable domain gates.
3. Rheology pumping pressure is a nominal-shear screen. Most ancillary models
   remain first-pass relations whose fidelity depends on explicit scenario inputs.
   More advanced formulations need model-specific independent benchmarks and
   targeted calibration, rather than treating a completed run as validation.
4. A source/runtime manifest identifies the execution environment but does not
   archive a complete restorable build. Deployment must restart scientific workers
   after code changes; fully isolated replay environments remain future work.

These limitations are retained in the product scope. They are not reported as
capabilities delivered by this review.
