# AI and physics inverse design

The formulation studio now includes **AI + physics design** in the canvas toolbar
and the simulation catalogue. It searches bounded parameters of a physical model
for declared objectives and specifications. Users and chat agents execute the same
numerical engine. No remote model or AI connection is required for the manual search.

## Use the workspace

1. Create or select a recipe and individual active, then choose **AI + physics design**.
2. Select a physical model and set its fixed scenario inputs.
3. Choose up to six numeric search parameters, bounds and linear or logarithmic scales.
4. Define up to three objectives: minimize, maximize or approach a target. Each scale
   expresses the change that counts as one objective unit; weights express priority.
5. Add required minimum/maximum output specifications, choose 12–96 evaluations
   and a reproducible seed, then run.

The result shows search progress, feasible evaluations, the Pareto tradeoffs and a
shortlist of up to eight non-dominated candidates ordered by the declared priorities.
**Inspect candidate in simulator** opens the exact inputs in the original model.
Numerical CSV and complete result JSON remain downloadable through Results.
Historical results, assumptions, recipe identity and engine version use the existing
project artifact system. Stop is checked between physics evaluations. A resumed
unfinished search restarts deterministically; completed scenarios are reused.

The model's physical inputs remain visible in the builder. Search parameter values
override the corresponding fixed inputs. A recipe supplies traceability and its
individual-active fraction to models that use loading (dosage and dilution).
The search does not infer rheology, diffusivity or stability from ingredient names.

## Numerical method

A seeded Latin hypercube plus center and diagonal boundary points initializes
the search. Fixed radial-basis Gaussian processes on normalized search coordinates
model the physical response metrics. Ninety-six reproducible posterior draws per
pool point estimate constrained expected improvement of the weighted, scaled
objective. Target distance is applied to the response draws, keeping the underlying
response model smooth near a target. Distinct response columns assume independent
GP residuals; repeated references to the same metric share the same draw. This
approximation guides sampling; direct outputs determine final feasibility.
Periodic distance-based exploration limits premature concentration on one region.
Before any feasible point exists, sampling prioritizes estimated feasibility.

Every sampled point is evaluated by the base physical model. Domain failures are
retained with their exact reason and excluded from the shortlist. Actual output
metrics determine constraint satisfaction. Pareto membership uses the individual
scaled objectives, including target distance; weights order the final front.
Shortlist outputs are replayed with the base solver before saving. Replay checks
reproducibility, and is distinct from independent experimental validation.

The returned interpolation standard deviation belongs to the numerical surrogate.
It is not measurement error, material variability, a calibrated confidence interval
or a probability of laboratory success. The exploration suggestion is explicitly
marked surrogate-only and has not been evaluated by the physics model. The leading
feasible candidate is a hypothesis for experimental confirmation.

Method references: [Snoek, Larochelle and Adams (2012)](https://proceedings.neurips.cc/paper_files/paper/2012/hash/05311655a15b75fab86956663e1819cd-Abstract.html)
and the [SciPy LatinHypercube implementation](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.qmc.LatinHypercube.html).
The fixed-kernel implementation here is a bounded simulator search; it does not
reproduce every method or hyperparameter treatment in that paper.

## Agents and API

Agents discover the `inverse_design` schema with `list_simulations` and execute it
with the existing `run_simulation` or `run_simulation_batch` tools. Their result
includes the checked shortlist, exact best inputs, base-model assumptions, search
status and next experiments. The same request works through `/api/studio/simulate`:

```json
{
  "session_id": "your-session",
  "requests": [{
    "model": "inverse_design",
    "recipe_id": "your-recipe-version",
    "active_name": "your-individual-active",
    "inputs": {
      "base_model": "rheology",
      "base_inputs": {"yield_stress_pa": 0, "flow_index": 1},
      "variables": [{"parameter": "consistency_pa_sn", "low": 0.01, "high": 2, "scale": "log"}],
      "objectives": [{"metric": "pressure_bar", "goal": "minimize", "scale": 1}],
      "constraints": [{"metric": "viscosity_at_100_s_pa_s", "minimum": 0.5}],
      "evaluations": 24,
      "seed": 42
    }
  }]
}
```

`input:parameter_name` is also available as a metric for a searched parameter,
allowing tradeoffs such as lower energy input versus particle size. Only numeric
finite output metrics are eligible. Nested optimization/robustness and combined
two-active models are refused. Diffusion searches refuse to vary both diffusivity
and characteristic length because release alone identifies their ratio D/L².

Numerical feasibility depends on the model and input assumptions. No feasible point
within a budget does not prove that the physical specification is impossible.
The software does not claim a global optimum or validated composition-performance
predictions from this search.

## Reproduce the verification

```bash
python3 -m scripts.run_v22_inverse_design
python3 -m pytest --disable-plugin-autoload -q tests/test_inverse_design.py tests/test_simulation_platform.py
```

The runner exports [exact inputs, checks and full results](../reports/v22/inverse_design.json)
and [the evaluation history](../reports/v22/search_history.csv). All examples are
explicitly synthetic numerical scenarios. Checks compare the Newtonian search to
the independently calculated Poiseuille optimum, preserve real pressure/viscosity
tradeoffs, return an empty shortlist for an unreachable specification, and compare
a sphere release design to independent 40- and 80-cell finite-volume solutions.

The tests additionally cover GP interpolation, seed reproducibility, log bounds,
target objectives, model-domain rejections, exact evaluation accounting,
cancellation, identifiability refusal, agent tool outputs, HTTP routes and persisted
manual execution without an AI connection.
