# Benzovindiflupyr chiral campaign protocol, version 10

Written on 2026-10-20 before building the phase. Internal analysis plan; not an external preregistration and not legal advice.

## Scope

A formulation campaign around benzovindiflupyr - a chiral SDHI fungicide marketed as a racemate, with basic patent expiry 2028 (S&P Global via AgriBusiness Global) and enantioselective bioactivity documented (Chen et al. 2023). The v8 machinery (registries, prior-art flags, analogue transfer, ranking, proposal gate) is reused with one structural addition the active earns: an ENRICHMENT axis - concepts enumerate racemic and enantioenriched variants, prior art carries enrichment tags, and the v9 stereo layer is first-class (regime distance enters the transferred region directly, not as an overlay). Deliverables and exclusions as in v8 plus amendment A2: prior-art coverage flags, feasibility regions, evidence plans - never patentability, FTO, efficacy or enantioselective-performance conclusions.

## Why this active (session-verified 2026-10-20)

Expiry 2028 in the same off-patent list that pinned sulfoxaflor 2027 (agribusinessglobal.com); chiral sold as racemate, absolute configuration and enantioselective bioactivity/toxicity/dissipation published (Chen et al. 2023, J Agric Food Chem, PubMed 37260103); enantiomer-specific soil behavior published (J Hazard Mater 2026, 10.1016/j.jhazmat.2026.141088); ~69% of chiral actives are sold as racemates (Jeschke 2025, PMC11906909) - the enrichment axis is the documented industry gap. Syngenta crops: corn, soybean, turf, ornamentals (blight, mildew, rust, scab, leafspot); the campaign targets Indian soybean/groundnut/chili contexts.

## Pinned registries (data/v10)

Same shapes as v8: prior_art.json (5 entries; declares the six similarity dimensions with weights ai 0.30 / format 0.25 / carrier 0.10 / use 0.10 / coform 0.15 / enrichment 0.10 - v8 files carry no weights block and keep the frozen five-dimension formulas byte-identically), components.json (12, each now also carrying a stereo descriptor), format_compatibility.json (unchanged matrix), analogue_map.json (the same five curve-bearing catalog studies), india/use_context.json (3: soybean rust, groundnut/chili leafspot, hard-water robustness), concepts/concept_axes.json (cap 64; enrichment axis on FS/MIX/ROBUST, racemic-only CR; positive control = the commercial benzovindiflupyr+azoxystrobin binary, expected blocked), methods/methods.json (the four pinned methods plus this campaign's direction rationale codes).

## Scoring additions over v8

Similarity: the enrichment dimension is a Jaccard over enrichment tags (racemic / enantioenriched). Knockout coverage guard extends to enrichment: a racemic entry does not fence an enantioenriched concept and an enantioenriched binary is not fenced by the racemic commercial binary; the enantiomer-characterization publication carries no format tags, so it can never knock out a formulation concept - it only raises S (enriched concepts score their nearest art at 0.40, below the 0.45 adjacent line; racemic solo concepts sit adjacent to the racemic reference). India relevance, compatibility and priority formulas unchanged from v8.

## Stereo as first-class transfer input (v9 machinery, applied at design time)

Concept active regime: racemic concepts carry the technical material's racemic regime; enantioenriched concepts carry enantiopure (a single-enantiomer solid can differ in solubility/crystal form - exactly amendment A2's registered risk, so enriched transfers widen). Regime distance vs the chosen analogue's active regime (v9 descriptors): match 1.00 / related 1.15 / cross_class 1.30 / unspecified 1.15 widens the transferred region GEOMETRICALLY BEFORE the feasibility evaluation (v8 applied no stereo widening; v9 widened only as an overlay; v10 bakes it in). Chiral carriers (chitosan, alginate) keep the registered-assumption flag. Expected consequence: the Tang 2023 tebuconazole study (racemic chiral fungicide, polymer nanoparticle) is the stereo-clean analogue for racemic nano concepts (match), while the same concept enantioenriched drops to related.

## Data-generation plans

Partner concepts -> Sun 1950 CTC + Colby 1967; carrier concepts -> release assay; robust formats -> CIPAC MT 47.3 in WHO 342 ppm water; all -> comparator against the commercial racemic reference at the campaign's pinned context. NEW for the enrichment axis: every enantioenriched shortlisted concept carries a mandatory enantiomer-resolution plan - stereo-resolved release assay (chiral HPLC; the v9 identifiability result says per-enantiomer rates need resolved curves) and enantioselective bioassay at the partner lab - because the framework will not claim enantioenriched advantage from total-a.i. data. Rationale codes (IP_WINDOW_2028, RACEMATE_TO_ENRICHED_GAP, ENANTIOSELECTIVE_SOIL_2026, NO_BZF_KINETICS_STUDY) carry the patent/legal context only.

## Gates

Registries valid; the declared positive control (racemic benzovindiflupyr+azoxystrobin SC binary) flagged blocked by the commercial-binary entry; every enumerated concept scored; every carrier concept carries a stereo-annotated transferred region or an explicit reason; shortlist FV-solver-verified where applicable; enrichment coverage semantics tested (racemic art does not fence enriched concepts); campaign_shortlist proposal pending; two scoring passes byte-identical; v8 exports byte-identical after the shared-package extension (the campaign package changes must not perturb the frozen v8 outputs).

## Governance

Protocol doc first (this file, hash-pinned); manifest frozen and re-verified before scoring; deterministic computation only; agents propose via agents/runtime.py, humans review via scripts.review; amendments A1 and A2 in force. One command: python3 -m scripts.run_v10_campaign. Compute: CPU only. scripts/reproduce chains v1 through v10.
