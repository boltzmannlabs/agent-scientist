# Zero-order membrane kernel protocol, version 11

Written on 2026-10-20 before building the phase. Internal analysis plan; not an external preregistration.

## Scope

Add the membrane-controlled (zero-order) release kernel to the design machinery and close, inside the repo, the loop the sulfoxaflor R4 session opened: the claim pair (<=20% released at day 5 AND >=80% at day 35) is (a) proven ANALYTICALLY infeasible for the entire Fickian family - the family's best late/early release ratio is bounded, and the bound puts the day-35 ceiling near 0.47 (the R4 session's numerical ceiling was 47.5% under its exact constraint definition) - and (b) made designable under zero-order release, with the feasible (k0, plateau, lag) region exported. Model assumptions only: mechanistic membrane control is an assumption of the concept class (reservoir + rate-controlling membrane), exactly as the Fickian kernel assumes a homogeneous matrix.

## Kernel and identifiability

F(t) = plateau x clip(k0 (t - lag), 0, 1): constant-rate release at k0 (per day) after an induction lag (days), clamped at the plateau (released fraction). Full-curve identifiability: all three parameters recoverable (lag = onset, k0 = ramp slope / plateau, plateau = asymptote) - demonstrated by a synthetic closed-form-fit recovery gate (>= 90% of trials within k0 10%, plateau 0.05, lag 1 day) on an observation grid that is dense early (lag resolution) and spans reservoir depletion (plateau resolution). A window that ends mid-ramp leaves the plateau under-observed: that is an identifiability requirement on assay design, exported with the gate, not a fitting detail. Endpoint-pair identifiability: two endpoint constraints leave a manifold - the EXPORT is the feasible parameter region, mirroring the v6 region philosophy. No new proposal type and no recommendation: this phase is analysis machinery, like v7/v9.

## Claim-pair demonstration (frozen constants)

t1 = 5 d cap 0.20, t2 = 35 d floor 0.80. Fickian side: for tau1 with F(tau1) <= cap the best plateau is min(1, cap / F(tau1)), so the achievable t2 fraction is max over tau1 of min(1, cap/F(tau1)) x F((t2/t1) tau1); the scan exports the ceiling and n_feasible (expected 0, ceiling ~0.47, consistent with R4's 47.5%). Zero-order side: 3-D grid over k0 x lag x plateau exports the feasible region; the analytic corner (lag = 0, plateau = 1, k0 in [floor/t2, cap/t1] = [0.0229, 0.0400] /d, nonempty iff floor x t1 <= cap x t2) must lie inside it, and example specs with computed day-5/day-35 values are exported.

## Scope decisions recorded (not built, with reasons)

Runner consolidation REJECTED: v8/v10 exports are byte-frozen with campaign-specific columns and gates, so a unified runner would branch on campaign at every step; the genuine reuse already lives in the parameterized campaign package (load_registries data_subdir, weights schema, enrichment axis). Catalog growth, the first stereo-resolved release curves, and composition-bridge activation remain external-data unlocks (partner labs / literature screening), not code. GUI remains deferred by user decision. The three pending human reviews (v6 design_shortlist, v8 and v10 campaign_shortlist) are decisions, not build items.

## Gates

Analytic bound recorded and consistent (Fickian ceiling < 0.80); Fickian claim scan returns zero feasible candidates; zero-order region nonempty and contains the analytic corner; synthetic recovery gate passes (>= 90%); two scan passes byte-identical; no proposal submitted (no recommendation rendered by this phase).

## Governance

Protocol doc first (this file, hash-pinned); manifest frozen and re-verified before any scan; deterministic computation only (no RNG in the scans; the recovery gate uses a pinned seed); standing not-comparable register plus amendments A1/A2 in force - kernel feasibility says nothing about efficacy, field performance or patentability. One command: python3 -m scripts.run_v11_zero_order. Compute: CPU only. scripts/reproduce chains v1 through v11.
