# Surrogate and model-registry protocol, version 5

Written on 2026-10-19 before building the v5 surrogate layer. Internal analysis plan; not an external preregistration.

## Scope

Uncertainty-aware surrogates mapping formulation/assay covariates to release-curve summaries, validated by whole-study holdout, with a frozen model registry declaring each model's valid domain and prohibitions, plus the claims-drafter agent that scales audit prose without touching verdicts. No composition-to-performance claim beyond what leave-one-study-out supports.

## Targets and features (frozen)

Targets are CURVE SUMMARIES on the fraction scale, not individual time points: Weibull time-scale tau and shape beta (via the existing bounded fitter), endpoint fraction, and time-to-50%. Curves reconstruct through the Weibull family and rescale to native units per study (percent /100; mg/g /1000 as a declared mass bound, never a measured loading). Covariates: log10 end time, pH, temperature, finite-bath factor, log10 calibrated D/L^2 (v4 physics features), geometry/assay/sink/data-source indicators with train-only vocabularies. Missingness handling, declared: tree models consume NaN natively; the GP imputes TRAIN-median values and appends an explicit missing-indicator column per imputed feature, so missingness stays visible to the kernel and test rows never inform the imputation.

## Models (fixed hyperparameters, no test-fold search)

- StructuredGP: one sklearn GaussianProcessRegressor per summary target, Matern(nu=1.5, length_scale=1, fixed) + WhiteKernel(0.05, fixed), normalized targets, standardized features. Registered anti-goal: no deep networks on tens-to-hundreds of observations without a written justification; none is offered here.
- Hierarchical study effects with shrinkage n/(n+5) toward the global mean, estimated on training studies only; held-out studies carry zero effect (unknown), which is the honest choice.
- Mondrian split-conformal intervals at alpha=0.10 per data_source group, calibrated on training-group residuals with whole-group folds.

## Evaluation (the only acceptance path)

Leave-one-study-out over every catalog study: reconstruct held-out curves and score curve-first MAE in native units against the matched-time-mean baseline pooled only within a unit family. Utility threshold: at least 10% lower study-level MAE than baseline. Conformal coverage reported on the same folds; acceptance band 0.90 +/- 0.05. Public-only is the primary result; hybrid (internal-inclusive) runs side by side when internal data exists, with the manifest recording which tracks saw it. Failures export; nothing is tuned to pass.

## Model registry (frozen output)

reports/v5/model_registry.json records per model: identity hashes, training slice, the observed input domain (feature ranges), evaluation verdicts and prohibitions (no extrapolation outside the domain; no cross-family prediction; no study effects for unseen studies). The v6 design phase must hard-refuse candidates outside the registered domain.

## Claims drafter

The deterministic v2 engine computes every verdict. The drafter agent classifies claims onto handlers, drafts verdict-basis prose from templates keyed by verdict, stamps verdict_drafted_by, and flags disagreement/insufficient rows as needs_human. Confirmation stays empty until human review; the counts, not the prose, carry the science. A single verdict_draft proposal summarizes each drafting pass.

## Compute and reporting

One command (scripts/run_v5_surrogates.py): hash gate -> frozen manifest (kernel spec, alpha, shrinkage, utility threshold) -> curve summaries -> LOSO evaluation with coverage -> registry freeze -> drafted claims audit -> reports/v5/v5_surrogates.html. CPU minutes for GP fits; GPU only for optional XGBoost comparators. If no model clears the utility threshold, v6 proceeds in physics-only inversion mode - a documented branch, not a silent downgrade, stated in the report.
