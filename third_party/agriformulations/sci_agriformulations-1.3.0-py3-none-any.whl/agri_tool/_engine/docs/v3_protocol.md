# Formulation catalog protocol, version 3

Written on 2026-10-19 before building the v3 catalog layer. This internal plan follows docs/v2_protocol.md's discipline: it is not an external preregistration, and its growth targets are analyst judgment, not statistically derived thresholds.

## Goal

Turn the repository from a three-study benchmark into a hybrid formulation catalog: one registry of public (literature) and internal (proprietary) studies on a shared contract, with a formulation ontology, an assay-protocol registry, explicit unit gates, and agent-assisted literature screening that proposes but never ingests. The catalog is the inventory phases v4-v6 draw from; no design-model claims are made here.

## Selection criteria (frozen; all mandatory for literature acceptance)

A candidate paper enters the catalog only when all seven hold: numerical release series with at least six time points (means or replicates); machine-readable supplementary data; formulation composition at least at ratio level; assay medium/temperature/pH stated or explicitly registered as a gap; target and denominator unambiguous; licence permits internal analysis; no plot digitization required. Candidates are recorded in research/selection_registry.json with a boolean per criterion; unverified counts as failing. No study is replaced after results are seen (v2 rule).

## Growth targets to exit v3 (analyst judgment)

At least 8 public studies (5 exist at v3.0: the three v2 studies plus the two v1 conversions), at least 40 independent formulation-recipes, at least 150 release curves, at least 1,500 accepted observation rows, and at least 80% catalog coverage on core ontology fields (geometry, mass fraction or ratio, protocol block). At least one internal batch must exercise the adapter contract, excluded from public benchmark tracks by construction. If targets are unmet at run time, the runner exports the shortfall honestly; it does not lower the bar.

## Contract

Every study directory carries study.json (schema_version, source hashes, target contract, ontology block, protocols block), observations.csv and claims.csv, exactly as in v2. Ontology records (ontology.py) use ingredient roles from the frozen registry, geometry from the frozen set, and leave unmeasured fields None — never imputed; gaps surface in the coverage matrix. Assay protocols (protocol_registry.py) declare sink_condition and bath ratio when known; Tang 2023's 27/3 mL dialysis is registered finite_bath. Unit families (units.py) forbid pooling percent with mg/g and reject unknown time units. The three v2 study directories stay frozen on disk; their ontology/protocol enrichment lives in data/catalog/enrichment/ and merges at catalog load.

## Internal data

Internal studies live under data/internal/<program>/<batch>/ with raw exports gitignored and only hashes plus curated CSVs committed. Adapters (adapters/) are config-driven (ingest.json per batch) and stamp every row recorded_by. An agent-screened ingest additionally requires an APPROVED data_candidate proposal before an adapter will run. Internal studies never enter public benchmark tracks; hybrid modelling appears only in v5+ and is always reported beside public-only results, with the manifest recording which tracks saw internal data.

## Agents

Dev-time contracts live in docs/agents/ and extend docs/agent_workflow.md: literature-screener, evidence-auditor, methods-reviewer, implementer, adversarial-reviewer. Runtime agents submit proposals (agents/runtime.py): JSON files under proposals/ with status pending/approved/rejected, a human reviewer, and a hash-chained activity log. Agents cannot review proposals. The literature monitor (agents/literature_monitor.py) screens candidates against the frozen criteria and emits data_candidate proposals only; an approved proposal authorizes a human-driven extraction adapter that cites the proposal id as ingest_channel. Agents never fabricate observations; all numeric results come from deterministic code.

## Validation and reporting

One command (scripts/run_v3_catalog.py) must: run idempotent conversions, verify every registered study's source hashes, freeze the execution manifest before any analysis, validate the catalog contract (counts vs CSVs, hash presence, single unit family per study), audit every claim with the v2 verdict engine, compute the coverage matrix and independent-unit stats, summarize literature-monitor proposals, and render reports/v3/v3_catalog.html with the honest outcome note. Catalog problems abort the run; coverage gaps are exported as warnings. The standing not-comparable register (docs/risk_register.md) applies: efficacy, toxicity, crop yield, field performance and synthesis chemistry remain outside every target.

## Compute

CPU only. The GPU is not used in v3 except when the v2 regression benchmark is re-run.
