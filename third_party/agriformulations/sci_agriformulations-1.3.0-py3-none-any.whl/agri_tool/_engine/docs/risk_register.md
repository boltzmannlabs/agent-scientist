# Risk register and standing scope limits

Created with v3 (2026-10-19); updated every phase. Likelihood and impact are analyst judgments.

## Standing not-comparable register

The framework does not model, and every protocol must keep registering as not
comparable: crop yield, weed-control or pest-mortality efficacy, toxicity,
environmental fate beyond aqueous release, field performance, and synthesis
chemistry (reaction design, process safety). Release-model fits never
validate biological performance or deployment readiness. Molecular dynamics
and DFT were not run and are not claimed.

## Risk table

| Risk | Likelihood | Impact | Mitigation | Owner phase |
|---|---|---|---|---|
| Data leakage through features, vocabularies or calibration folds | Medium | High | Spy tests every phase; train-only vocabularies; group-level calibration | all |
| Distribution shift between literature and internal assays | High | High | data_source separation; Mondrian conformal (v5); side-by-side public-only reporting; protocol_distance diagnostic | v3, v5 |
| Overfitting on a small catalog | High | High | Curve-summary targets; fixed hyperparameters; mandatory baselines; deep nets an anti-goal | v5 |
| Unit or target incompatibilities on pooling | Medium | High | units.py family gate; per-study target contracts; percent never pooled with mg/g | v3 |
| Inverse design claiming unidentifiable parameters | Medium | High | v4 identifiability table restricts the v6 inversion space by construction | v4, v6 |
| Agent-fabricated or hallucinated evidence | Medium | High | Agents draft only; deterministic engines compute; proposal gate with human review; authored_by provenance; hash-chained log | v3-v6 |
| Catalog growth stalls below design-model targets | Medium | Medium | Explicit exit gate; v6 physics-only fallback branch; registry documents what the data supports | v3, v6 |
| Cross-device numerical drift | Low | Medium | float64 everywhere; CPU/CUDA agreement gates (abs 1e-8, rel 1e-6) re-run per phase | all |
| Scope creep into efficacy/toxicity claims | Medium | High | Standing not-comparable register; mandatory limitations block in every report | all |
| Post-hoc edits to frozen v2 evidence | Low | High | data/v2 stays frozen; catalog enrichment lives beside the registry and merges at load | v3 |

## Amendment A1 (v8, 2026-10-20)

Added to the standing not-comparable register: patentability and other legal conclusions, freedom-to-operate opinions, registrability assessments, and market economics or cost comparability. The v8 campaign produces prior-art coverage flags, transferred feasibility regions and evidence plans only; it never asserts that a concept is patentable, registrable, or commercially viable.

| Risk | Likelihood | Impact | Mitigation | Owner phase |
|---|---|---|---|---|
| Prior-art registry incompleteness -> false novelty confidence | Medium | High | Retrieval-date pinning per entry; mandatory coverage disclaimer on every export; human review of every shortlist | v8 |
| Analogue-transfer overstatement (no sulfoxaflor release-kinetics study exists) | High | High | Documented widening band tied to the analogy weight; hypothesis-generating label; weak-analogy (w < 0.4) caps feasibility at 0.5 | v8 |
| Scope creep into efficacy or legal claims | Medium | High | Standing register + A1; patent/legal context only as rationale_code in data plans; agents propose, humans review | all |

## Amendment A2 (v9, 2026-10-20)

The framework's release kernels are stereo-blind by construction (exact for diffusion in achiral media and for total-a.i. assays); enantioselective release from chiral carriers or chiral media is not modeled, and enantiomer-specific kinetics cannot be claimed from total-release data.

| Risk | Likelihood | Impact | Mitigation | Owner phase |
|---|---|---|---|---|
| Stereochemical regime differences (racemic vs enantiopure, natural-product mixtures) shift solubility/dissolution and flow silently into calibrated rates | Medium | Medium | v9 stereo descriptors on every ingredient/component; regime-distance flags and overlay widening on v8 transferred regions; never silently pooled | v9 |
| Enantioselective release from chiral carriers (chitosan, alginate, agarose-class) modeled nowhere | Medium | Medium | Registered assumption; chiral_carrier flags on concepts and carriers; liftable only with stereo-resolved assays | v9 |
| Enantiomer-specific rates claimed from total-a.i. curves | Medium | High | v9 identifiability demonstration: total-release data recover only the loading-weighted effective rate; per-enantiomer claims blocked without resolved assays | v9 |
