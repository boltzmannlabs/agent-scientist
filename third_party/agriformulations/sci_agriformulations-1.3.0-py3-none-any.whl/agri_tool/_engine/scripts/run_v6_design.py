"""One reproducible command for the v6 inverse-design phase (docs/v6_protocol.md).

Reads (or derives) a design brief, freezes the manifest, evaluates the batched
identifiable candidate grid on GPU, ranks and solver-verifies the shortlist,
submits a design_shortlist proposal, and renders the report.  The
recommendation section appears ONLY for an approved proposal.

    python3 -m scripts.run_v6_design [--device auto|cpu|cuda] [--approve <proposal_id>]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v6"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.agents import require_approved  # noqa: E402
from agriformulations.agents.screening import build_shortlist_proposal  # noqa: E402
from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.catalog import load_catalog  # noqa: E402
from agriformulations.design import CandidateSpace, feasible_region, rank_candidates, verify_shortlist_against_solver  # noqa: E402
from agriformulations.physics.features import physics_features  # noqa: E402


def _derive_brief(catalog) -> dict:
    """Deterministic brief from a real catalog curve: the curve the verified
    mechanism fits BEST (highest calibrated spherical-diffusion R^2), so the
    brief asks for mechanistic feasibility where the mechanism plausibly
    holds. Curves the mechanism cannot reproduce are exactly the negative
    results this phase must be able to export."""
    physics = physics_features(catalog)
    physics = physics[physics["calibrated_r2"].notna()]
    row = physics.sort_values("calibrated_r2", ascending=False).iloc[0]
    study_key = row["study_key"]
    entry = catalog.studies[study_key]
    observations = entry["observations"]
    observations = observations[observations["curve_id"] == row["curve_id"]]
    scale = 100.0 if row["unit"] == "%" else 1000.0
    return {
        "brief_id": f"derived_{row['curve_id']}",
        "target_curve_id": row["curve_id"],
        "target_source": (
            "observed author source-data curve with the best calibrated mechanism fit "
            f"(R^2={row['calibrated_r2']:.3f}); mechanistic feasibility target, not a design claim"
        ),
        "times": observations["time"].astype(float).tolist(),
        "values": observations["value"].astype(float).tolist(),
        "tolerance": 5.0,
        "scale_to_fraction": scale,
        "unit": row["unit"],
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--approve", default=None, help="approved design_shortlist proposal id")
    args = parser.parse_args(argv)
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)

    catalog = load_catalog()
    gate = json.loads((REPO / "reports/v5/v5_gate.json").read_text())
    v6_mode = gate.get("v6_mode", "physics_only")

    brief_path = OUT / "design_brief.json"
    if not brief_path.exists():
        brief = _derive_brief(catalog)
        brief_path.write_text(json.dumps(brief, indent=1, sort_keys=True))
    brief = json.loads(brief_path.read_text())
    print(f"[1/6] brief: {brief['brief_id']} ({len(brief['times'])} points, mode={v6_mode})")

    space = CandidateSpace(
        rate_bounds=(1e-4, 1.0), rate_points=96, plateau_bounds=(0.05, 1.0), plateau_points=32
    )
    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device=args.device,
        extra={
            "phase": "v6",
            "protocol": {
                "document": "docs/v6_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v6_protocol.md").read_bytes()).hexdigest(),
            },
            "v6_mode": v6_mode,
            "v5_gate": gate,
            "brief": {**brief, "sha256": hashlib.sha256(brief_path.read_bytes()).hexdigest()},
            "space": space.describe(),
        },
    )
    verify_inputs(manifest)
    print(f"[2/6] manifest frozen ({space.size} candidates over identifiable axes)")

    surrogate = None  # physics-only mode: no surrogate earned a role (v5 gate)
    result = feasible_region(brief, space, device=args.device, surrogate=surrogate)
    np.save(OUT / "v6_mismatch_grid.npy", result["mismatch_grid"])
    print(
        f"[3/6] inversion: {result['n_feasible']} feasible candidates; best mismatch "
        f"{result['best']['mismatch_native_refined']:.3f} {brief.get('unit', '')} at rate "
        f"{result['best']['rate_refined']:.3e}"
    )

    entries, shortlist = rank_candidates(result, top_k=12)
    verified = verify_shortlist_against_solver(shortlist, brief)
    pd.DataFrame(entries).to_csv(OUT / "v6_feasible_candidates.csv", index=False)
    pd.DataFrame(verified).to_csv(OUT / "v6_verified_shortlist.csv", index=False)
    all_verified = all(entry["solver_verified"] for entry in verified) if verified else False
    print(f"[4/6] shortlist: {len(verified)} candidates, solver-verified={all_verified}")

    proposal = build_shortlist_proposal(
        verified,
        brief_id=brief["brief_id"],
        manifest_sha256=manifest["protocol"]["sha256"],
        v6_mode=v6_mode,
    )
    print(f"[5/6] design_shortlist proposal submitted: {proposal.proposal_id} (pending human review)")

    approved = None
    if args.approve:
        try:
            approved = require_approved("v6", args.approve)
        except PermissionError as exc:
            print(f"    approval refused: {exc}")
    recommendation = ""
    if approved is not None and approved.proposal_id == proposal.proposal_id:
        recommendation = f"""<h2>6. Recommendation (approved)</h2>
<p>Approved by {approved.reviewer} at {approved.reviewed_utc}. Top candidates:</p>
{_table(pd.DataFrame(verified), columns=['rate', 'plateau_fraction', 'mismatch_native', 'solver_mismatch_native', 'solver_verified'])}
<p class="small">Mechanistic feasibility under stated model assumptions only; the standing
not-comparable register applies to this recommendation.</p>"""

    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v6 inverse design</title>
<style>{STYLE}</style></head><body>
<h1>Inverse design, version 6</h1>
<p>Frozen protocol <code>docs/v6_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen before any evaluation.
Mode: <strong>{v6_mode}</strong> (decided by the v5 gate; the surrogate earned no role -
coverage 0.847 against the 0.90&plusmn;0.05 band and no utility pass).</p>
<div class="note"><strong>Outcome.</strong> Target profile
<code>{brief['brief_id']}</code> (an observed catalog curve; mechanistic feasibility, not a
design claim). {result['n_feasible']} of {space.size} identifiable candidates reproduce it within
{brief['tolerance']} {brief.get('unit', '')}; the best mismatch is
{result['best']['mismatch_native_refined']:.3f}. Every shortlisted candidate was re-scored with
the independent 80-shell finite-volume solver ({'all verified' if all_verified else 'verification failures flagged'}).
D and L are never proposed separately. The recommendation section appears only after human
approval of proposal <code>{proposal.proposal_id}</code>.</div>
<h2>1. Brief</h2>
{_table(pd.DataFrame({'time': brief['times'], 'target': brief['values']}))}
<h2>2. Candidate space (identifiable axes only)</h2>
{_table(pd.DataFrame([dict(space.describe())]))}
<h2>3. Feasible region summary</h2>
<p>Best candidate: rate {result['best']['rate_refined']:.4g}, plateau fraction
{result['best']['plateau_fraction']:.3f}, mismatch {result['best']['mismatch_native_refined']:.3f}
{brief.get('unit', '')}. Feasible rates span
{float(result['axes']['rates'][result['feasible_grid'].any(axis=0)].min()) if result['n_feasible'] else float('nan'):.3e}
to
{float(result['axes']['rates'][result['feasible_grid'].any(axis=0)].max()) if result['n_feasible'] else float('nan'):.3e}.</p>
<h2>4. Verified shortlist</h2>
{_table(pd.DataFrame(verified), columns=['rate', 'plateau_fraction', 'mismatch_native', 'solver_mismatch_native', 'solver_verified'])}
<h2>5. Governance</h2>
<p>Shortlist submitted as proposal <code>{proposal.proposal_id}</code> (pending). Review with
<code>python3 -m scripts.review --show v6 {proposal.proposal_id}</code> then
<code>--decide v6 {proposal.proposal_id} approved --reviewer "human:&lt;name&gt;"</code>, and re-run
with <code>--approve {proposal.proposal_id}</code> to render the recommendation.
The disclaimer rides on every shortlist: mechanistic feasibility only - no efficacy, toxicity,
field, cost or synthesis-chemistry claim.</p>
{recommendation}
<h2>7. Interpretation and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v6_design</code>. Exports:
<a href="v6_feasible_candidates.csv">feasible candidates</a> ·
<a href="v6_verified_shortlist.csv">verified shortlist</a> ·
<a href="v6_mismatch_grid.npy">mismatch grid</a>.</p>
</body></html>"""
    report = OUT / "v6_design.html"
    report.write_text(html)
    with open(OUT / "v6_gate.json", "w") as handle:
        json.dump(
            {
                "v6_mode": v6_mode,
                "n_feasible": result["n_feasible"],
                "best_mismatch": result["best"]["mismatch_native_refined"],
                "shortlist_size": len(verified),
                "solver_verified_all": all_verified,
                "proposal_id": proposal.proposal_id,
                "recommendation_rendered": approved is not None,
            },
            handle,
            indent=1,
        )
    print(f"[6/6] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
