"""One reproducible command for the v9 stereochemistry layer (docs/v9_protocol.md).

Validates the pinned stereo registries, merges descriptors onto the
catalog, runs the synthetic recovery gate and the total-curve degeneracy
demonstration, inventories assay-protocol chiral resolution, and writes
the additive stereo overlay on the v8 campaign.  Frozen v8 exports are
never touched; no new proposal is submitted (analysis feeding the
pending v8 human review).

    python3 -m scripts.run_v9_stereo
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v9"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.benchmark_v2.io_utils import sha256_file  # noqa: E402
from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.campaign import load_registries  # noqa: E402
from agriformulations.catalog import load_catalog  # noqa: E402
from agriformulations.stereo import (  # noqa: E402
    build_overlay,
    degeneracy_demo,
    load_stereo_registries,
    recovery_gate,
)
from agriformulations.stereo.registry import stereo_coverage  # noqa: E402
from agriformulations.stereo.regimes import WIDENING  # noqa: E402
from agriformulations.stereo.release import (  # noqa: E402
    DEGENERACY_TOLERANCE,
    RECOVERY_MIN_SHARE,
    RECOVERY_RATE_RATIO,
    RECOVERY_TRIALS,
)

V9_INPUT_PATTERNS = (
    "data/v9/stereo/ingredients.json", "data/v9/stereo/components.json", "data/v9/stereo/analogues.json",
    "data/v8/components.json", "data/v8/analogue_map.json", "reports/v8/v8_concepts.csv",
)
V9_CODE_PATTERNS = (
    "src/agriformulations/stereo/*.py", "scripts/run_v9_stereo.py",
    "src/agriformulations/ontology.py", "src/agriformulations/protocol_registry.py",
)


def _collect(patterns) -> dict:
    records = {}
    for pattern in patterns:
        for path in sorted(REPO.glob(pattern)):
            records[path.relative_to(REPO).as_posix()] = {"sha256": sha256_file(path)}
    return records


def _catalog_ingredient_triples(catalog) -> set[tuple[str, str, str]]:
    triples = set()
    for study_key, entry in sorted(catalog.studies.items()):
        study_id = entry["meta"].get("study_id", study_key)
        for formulation in (f for f in catalog.formulations if f.study_id == study_id):
            for ingredient in formulation.ingredients:
                triples.add((study_key, formulation.formulation_id, ingredient.name))
    return triples


def main(argv=None) -> int:
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)

    v8_concepts_path = REPO / "reports/v8/v8_concepts.csv"
    if not v8_concepts_path.exists():
        raise SystemExit("reports/v8/v8_concepts.csv missing; run python3 -m scripts.run_v8_campaign first")
    v8_concepts = pd.read_csv(v8_concepts_path)

    catalog = load_catalog()
    v8_registries = load_registries(catalog_study_keys=set(catalog.studies))
    component_names = {record["name"] for record in v8_registries.components["components"]}
    analogue_keys = {entry["study_key"] for entry in v8_registries.analogue_map["analogues"]}
    stereo = load_stereo_registries(catalog, component_names, analogue_keys)
    coverage_rows = stereo_coverage(catalog, stereo)
    covered = {
        (study, form, name)
        for study, forms in stereo.ingredients["ingredients"].items()
        for form, names in forms.items()
        for name in names
    }
    misses = sorted(_catalog_ingredient_triples(catalog) - covered)
    if misses:
        raise SystemExit(f"stereo registry does not cover catalog ingredients: {misses}")
    pd.DataFrame(coverage_rows).to_csv(OUT / "v9_stereo_coverage.csv", index=False)
    n_unspecified = sum(row["unspecified"] for row in coverage_rows)
    n_total = sum(row["n_ingredients"] for row in coverage_rows)
    print(f"[1/7] stereo registries valid; catalog coverage complete ({n_total} ingredient slots, "
          f"{n_unspecified} honestly unspecified)")

    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device="cpu",
        extra={
            "phase": "v9",
            "protocol": {
                "document": "docs/v9_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v9_protocol.md").read_bytes()).hexdigest(),
            },
            "constants": {
                "regime_widening": WIDENING,
                "recovery_rate_ratio": RECOVERY_RATE_RATIO,
                "recovery_min_share": RECOVERY_MIN_SHARE,
                "recovery_trials": RECOVERY_TRIALS,
                "degeneracy_tolerance": DEGENERACY_TOLERANCE,
                "physics_assumption": "stereo-blind Fickian kernels (achiral media); amendment A2",
            },
            "inputs_v9": _collect(V9_INPUT_PATTERNS),
            "code_sha256_v9": _collect(V9_CODE_PATTERNS),
        },
    )
    verify_inputs(manifest)
    for rel, entry in manifest["inputs_v9"].items():
        if sha256_file(REPO / rel) != entry["sha256"]:
            raise SystemExit(f"v9 input hash drift after freeze: {rel}")
    print(f"[2/7] manifest frozen and re-verified ({len(manifest['inputs_v9'])} v9 inputs)")

    gate = recovery_gate()
    if not gate["pass"]:
        raise SystemExit(f"stereo recovery gate FAILED: {gate}")
    with open(OUT / "v9_recovery_gate.json", "w") as handle:
        json.dump(gate, handle, indent=1)
    print(f"[3/7] recovery gate PASS ({gate['recovered']}/{gate['trials']} trials within {RECOVERY_RATE_RATIO}x)")

    demo = degeneracy_demo()
    with open(OUT / "v9_degeneracy_demo.json", "w") as handle:
        json.dump(demo, handle, indent=1)
    print(f"[4/7] degeneracy verdict at campaign tolerance: {demo['verdict']} "
          f"({demo['campaign']['n_passing_triples']} triples / {demo['campaign']['distinct_loadings']} loading splits "
          f"at 0.05; {demo['strict']['n_passing_triples']} at strict 0.02; "
          f"effective rate {demo['effective_rate']:.4g} /h; assignment degeneracy exact)")

    inventory = {
        protocol.protocol_id: protocol.chiral_resolution for protocol in catalog.protocols.values()
    }
    resolved = [pid for pid, flag in inventory.items() if flag == "yes"]
    pd.DataFrame(
        [{"protocol_id": pid, "chiral_resolution": flag} for pid, flag in sorted(inventory.items())]
    ).to_csv(OUT / "v9_protocol_resolution.csv", index=False)
    print(f"[5/7] protocol inventory: {len(inventory)} protocols, {len(resolved)} stereo-resolving "
          f"(expected 0 - total-a.i. assays; the honest zero behind the degeneracy statement)")

    overlay = build_overlay(v8_concepts, stereo, primary_active="sulfoxaflor")
    first_bytes = overlay.to_csv(index=False).encode()
    overlay_again = build_overlay(v8_concepts, stereo, primary_active="sulfoxaflor")
    determinism_pass = first_bytes == overlay_again.to_csv(index=False).encode()
    if not determinism_pass:
        raise SystemExit("determinism gate FAILED: two overlay passes differ")
    overlay.to_csv(OUT / "v9_stereo_overlay.csv", index=False)
    n_mismatch = int(overlay["stereo_regime_mismatch"].sum())
    n_chiral_carrier = int(overlay["chiral_carrier"].sum())
    print(f"[6/7] overlay: {len(overlay)} v8 concepts, {n_mismatch} stereo-regime mismatches, "
          f"{n_chiral_carrier} chiral-carrier concepts (byte-identical rerun: {determinism_pass})")

    v8_gate = json.loads((REPO / "reports/v8/v8_gate.json").read_text())
    gates = {
        "registries_valid": True,
        "catalog_stereo_coverage_complete": len(misses) == 0,
        "ingredient_slots": n_total,
        "ingredient_slots_unspecified": n_unspecified,
        "recovery_pass": gate["pass"],
        "degeneracy_verdict": demo["verdict"],
        "degeneracy_demonstrated": demo["verdict"]
        in ("jointly_unidentifiable", "values_identifiable_assignment_always_degenerate"),
        "n_passing_triples_campaign_tolerance": demo["campaign"]["n_passing_triples"],
        "n_passing_triples_strict": demo["strict"]["n_passing_triples"],
        "assignment_degeneracy": "exact (swap symmetry)",
        "effective_rate_per_hour": demo["effective_rate"],
        "n_chiral_resolved_protocols": len(resolved),
        "protocol_inventory_complete": len(inventory) == len(catalog.protocols),
        "overlay_rows": int(len(overlay)),
        "overlay_complete": len(overlay) == len(v8_concepts),
        "overlay_mismatches": n_mismatch,
        "overlay_chiral_carriers": n_chiral_carrier,
        "determinism_pass": bool(determinism_pass),
        "v8_proposal_untouched": bool(v8_gate.get("proposal_pending")),
        "assumption": "stereo-blind Fickian kernels (achiral media); amendment A2",
    }
    with open(OUT / "v9_stereo_gate.json", "w") as handle:
        json.dump(gates, handle, indent=1)

    coverage_frame = pd.DataFrame(coverage_rows)
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v9 stereochemistry</title>
<style>{STYLE}</style></head><body>
<h1>Stereochemistry, version 9</h1>
<p>Frozen protocol <code>docs/v9_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen and re-verified before any
computation. Risk-register amendment A2 in force.</p>
<div class="note"><strong>Outcome.</strong> Every catalog ingredient and v8 component now carries a
stereo descriptor ({n_unspecified} of {n_total} ingredient slots honestly unspecified); sulfoxaflor is
a single-stereoisomer active, and the v8 transfer crosses stereo regimes - {n_mismatch} of {len(overlay)}
concepts flag a regime mismatch and get overlay widening, {n_chiral_carrier} concepts carry a chiral
carrier under the registered assumption. The synthetic gate recovers both enantiomer rates from
resolved curves ({gate['recovered']}/{gate['trials']} trials), while the total-curve demonstration
verdict is <strong>{demo['verdict']}</strong> at the campaign tolerance
({demo['campaign']['n_passing_triples']} passing (w', k_R', k_S') triples over
{demo['campaign']['distinct_loadings']} loading splits; {demo['strict']['n_passing_triples']} at
strict 0.02): total-a.i. data support only the loading-weighted effective rate
({demo['effective_rate']:.4g} /h here), and the catalog's {len(resolved)} stereo-resolving protocols
(meaning none) cannot lift that. Frozen v8 exports are untouched; no new proposal - this feeds the
pending v8 review.</div>
<h2>1. Stereo coverage of the catalog</h2>
{_table(coverage_frame)}
<p class="small">Descriptors are screening-level analyst judgments with pinned anchors;
<code>unspecified</code> is counted, never imputed. L-phenylalanine is the source-pinned single
stereoisomer.</p>
<h2>2. Synthetic recovery gate (resolved curves)</h2>
{_table(pd.DataFrame([{"recovered": gate["recovered"], "trials": gate["trials"],
                       "min_share": gate["min_share"], "rate_ratio_tolerance": gate["rate_ratio_tolerance"],
                       "verdict": "PASS"}]))}
<h2>3. Total-curve degeneracy demonstration</h2>
{_table(pd.DataFrame([
  {"block": "strict (0.02)", **{k: demo["strict"][k] for k in ("n_passing_triples", "distinct_loadings")}},
  {"block": "campaign (0.05)", **{k: demo["campaign"][k] for k in ("n_passing_triples", "distinct_loadings")}},
  {"block": "effective single-species fit", "n_passing_triples": None, "distinct_loadings": None},
]))}
<p>True parameters: w={demo['true']['w']}, k_R={demo['true']['k_r']}, k_S={demo['true']['k_s']} /h;
the effective rate the total data DO support is {demo['effective_rate']:.4g} /h.
{demo['swap_symmetry']}. {demo['statement']} - per-enantiomer kinetic claims are blocked without
stereo-resolved assays, exactly as amendment A2 requires.</p>
<h2>4. Assay-protocol chiral resolution</h2>
<p>{len(inventory)} registered protocols inventoried; {len(resolved)} resolve enantiomers. Every
future protocol record carries the <code>chiral_resolution</code> flag (yes/no/unspecified).</p>
<h2>5. v8 campaign stereo overlay (additive)</h2>
{_table(overlay, columns=['concept_id', 'direction', 'active_regimes', 'analogue', 'analogue_regime',
                          'regime', 'stereo_widen_factor', 'overlay_region_low_per_day',
                          'overlay_region_high_per_day', 'stereo_regime_mismatch', 'chiral_carrier'])}
<p class="small">Overlay regions widen the frozen v8 regions by match 1.00 / related 1.15 /
cross_class 1.30 (declared analyst judgments). Chiral carriers (chitosan, alginate) carry the
amendment-A2 assumption note.</p>
<h2>6. Governance and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v9_stereo</code> (CPU only, deterministic).
Exports: <a href="v9_stereo_coverage.csv">coverage</a> ·
<a href="v9_recovery_gate.json">recovery gate</a> ·
<a href="v9_degeneracy_demo.json">degeneracy demo</a> ·
<a href="v9_protocol_resolution.csv">protocol inventory</a> ·
<a href="v9_stereo_overlay.csv">v8 overlay</a> · <a href="v9_stereo_gate.json">gates</a>.
No enantioselective efficacy, toxicity or fate claim is made anywhere - the standing
not-comparable register applies.</p>
</body></html>"""
    report = OUT / "v9_stereo.html"
    report.write_text(html)
    print(f"[7/7] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
