"""Extract published fertilizer means; preserve workbook vs text discrepancy."""
from pathlib import Path
import sys, hashlib, json
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / ".deps"))
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/fertilizer_2026_source_data.xls"
DOI = "10.1038/s41467-026-68295-6"
URL = "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-026-68295-6/MediaObjects/41467_2026_68295_MOESM4_ESM.xls"

def extract():
    table = pd.read_excel(RAW, sheet_name="Fig. 7B-C", header=None)
    rows=[]
    for active, indices in [("FLA",range(2,12)),("K+",range(16,25))]:
        for i in indices:
            r=table.iloc[i]
            rows.append(dict(study="fertilizer_2026",formulation="WP_ATP_ASO_SRF",active=active,
                time_d=float(r[0]),time_h=float(r[0])*24,release_pct=float(r[3]),
                sd_pct=float(r[4]),concentration_mg_l=float(r[1]),concentration_sd_mg_l=float(r[2]),
                n_replicates=3,evidence_kind="published_measured",doi=DOI,
                source_sheet="Fig. 7B-C",source_cells=f"A{i+1}:E{i+1}"))
    out=ROOT/"data/curated/fertilizer_2026_release.csv"
    pd.DataFrame(rows).to_csv(out,index=False)
    manifest=dict(doi=DOI,url=URL,publication_date="2026-01-13",
        retrieved_utc="2026-10-19",raw_file=str(RAW.relative_to(ROOT)),
        sha256=hashlib.sha256(RAW.read_bytes()).hexdigest(),
        extraction="Fig. 7B-C, rows 3:12 and 17:25; numeric values copied without smoothing; days converted to hours",
        licence="Publisher article: CC BY-NC-ND 4.0; numerical facts extracted with attribution. Original workbook preserved.",
        discrepancy="Main-text paragraph says FLA 98.15% and K+ 97.7% at day30. Workbook has FLA98.15869 and K+97.7 at day25; both100 at day30. Analyze workbook values, retain text claims as separate audit targets.",
        conditions="30 g SRF in 1 L deionized water; approximately 5 mm spherical particles; unknown release-test temperature",
        limitations=["Only mean and SD supplied for release, not individual replicate trajectories",
        "Homogeneous sphere is a simplifying effective model; coating and ion exchange not resolved",
        "Methods160 W vs abstract180 W microwave power discrepancy; not relevant to release fit, do not silently reconcile"])
    (ROOT/"data/curated/fertilizer_2026_provenance.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(f"Extracted {len(rows)} fertilizer mean observations -> {out}")

if __name__=="__main__": extract()
