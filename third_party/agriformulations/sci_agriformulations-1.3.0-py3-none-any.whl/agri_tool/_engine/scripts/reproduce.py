"""Verify archived evidence, re-extract source values, and execute the study offline."""
from pathlib import Path
import hashlib, json, os, runpy
ROOT=Path(__file__).resolve().parents[1]
def verify(path, expected):
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=expected: raise ValueError(f"Source hash mismatch: {path}")
def main():
    os.chdir(ROOT)
    a=json.loads((ROOT/"research/azadirachtin_2025_manifest.json").read_text())
    f=json.loads((ROOT/"data/curated/fertilizer_2026_provenance.json").read_text())
    verify(ROOT/"data/raw/azadirachtin_2025_source_data.xlsx",a["sha256"])
    verify(ROOT/f["raw_file"],f["sha256"])
    c=json.loads((ROOT/"data/crop_protection/provenance.json").read_text())
    for name,info in c["files"].items(): verify(ROOT/"research/crop_protection"/name,info["sha256"])
    print("All archived source hashes verified.")
    runpy.run_path(str(ROOT/"research/tools/extract_azadirachtin_2025.py"),run_name="__main__")
    runpy.run_module("scripts.extract_fertilizer",run_name="__main__")
    runpy.run_module("research.crop_protection.extract",run_name="__main__")
    runpy.run_module("scripts.run_case_study",run_name="__main__")
    from scripts.gpu_simulation import main as run_gpu
    run_gpu([])
    runpy.run_module("scripts.benchmark_paper",run_name="__main__")
    from scripts.run_v2_benchmark import main as run_v2
    run_v2([])
    from scripts.run_v3_catalog import main as run_v3
    run_v3()
    from scripts.run_v4_physics import main as run_v4
    run_v4([])
    from scripts.run_v5_surrogates import main as run_v5
    run_v5([])
    from scripts.run_v6_design import main as run_v6
    run_v6([])
    from scripts.run_v7_labops import main as run_v7
    run_v7([])
    from scripts.run_v8_campaign import main as run_v8
    run_v8([])
    from scripts.run_v9_stereo import main as run_v9
    run_v9([])
    from scripts.run_v10_campaign import main as run_v10
    run_v10([])
    from scripts.run_v11_zero_order import main as run_v11
    run_v11([])
    from scripts.run_v12_gui import main as run_v12
    run_v12(["--selftest"])
if __name__=="__main__": main()
