"""Independent algebra and feasible-mixture coverage checks for INR design costs."""
import json
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from agriformulations.rnd import control, costing, recipes


def main():
    recipe={"currency":"INR","batch_g":100000,"ingredients":[
        {"name":"Technical material","fraction":.2,"purity_pct":50,"cost_per_kg":1000},
        {"name":"Vehicle","fraction":.8,"cost_per_kg":100}]}
    assumptions={"yield_pct":80,"processing_per_input_kg":10,"packaging_per_saleable_kg":5,
        "fixed_batch_cost":1000,"overhead_pct":10,"freight_per_batch":500,"tax_pct":18,"pack_size_kg":2}
    result=costing.estimate(recipe,assumptions)
    # Independent accounting: 100kg input, 80kg saleable product.
    expected_batch=((20*1000+80*100+100*10+1000)*1.1+500+80*5)*1.18
    brief=recipes.default_brief()
    brief.update(name="Synthetic diversity benchmark",active_pct=20,count=4,ingredients=[
        {"name":"Reference active","role":"active","min_pct":20,"max_pct":20,"purity_pct":100},
        *[{"name":name,"role":"carrier","min_pct":0,"max_pct":80,"purity_pct":100}
          for name in ("Material A","Material B","Material C")]])
    generated=recipes.suggest(brief)
    compositions=np.array([[i["fraction"] for i in r["ingredients"]] for r in generated["recipes"]])
    # All three analytically known simplex vertices must be represented.
    vertices=[np.array([.2,*[.8 if j==i else 0 for j in range(3)]]) for i in range(3)]
    checks={"independent_final_batch_error":abs(result["final_batch_cost"]-expected_batch),
        "independent_cost_per_kg_error":abs(result["final_cost_per_saleable_kg"]-expected_batch/80),
        "independent_pack_cost_error":abs(result["cost_per_pack"]-expected_batch/80*2),
        "simplex_extreme_coverage":all(np.any(np.max(np.abs(compositions-v),axis=1)<1e-9) for v in vertices),
        "mixture_mass_balance":bool(np.allclose(compositions.sum(axis=1),1,rtol=0,atol=1e-10)),
        "reproducible_seed":generated==recipes.suggest(brief)}
    passed=all(checks[k]<1e-8 for k in checks if k.endswith("error")) and all(checks[k] for k in checks if not k.endswith("error"))
    report={"passed":bool(passed),"checks":checks,"cost_inputs":{"recipe":recipe,"assumptions":assumptions},
        "cost_output":result,"diversity_inputs":brief,"diversity_output":generated,
        "evidence":"Synthetic numerical benchmarks; not chemical performance or supplier price validation",
        "engine_manifest":control.engine_manifest()}
    destination=ROOT/"reports/v26/cost_diversity.json";destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(report,indent=2,allow_nan=False))
    print(json.dumps({"passed":bool(passed),"checks":checks,"report":str(destination)},indent=2))
    return 0 if passed else 1


if __name__=="__main__":
    raise SystemExit(main())
