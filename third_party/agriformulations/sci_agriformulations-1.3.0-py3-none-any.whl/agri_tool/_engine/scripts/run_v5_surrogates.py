"""One reproducible command for the v5 surrogate phase (docs/v5_protocol.md).

Curve summaries, leave-one-study-out evaluation with Mondrian conformal
coverage, the frozen model registry, and the drafted claims audit.

    python3 -m scripts.run_v5_surrogates [--device auto|cpu|cuda]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v5"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.agents.claims_drafter import draft_verdicts, submit_draft_summary  # noqa: E402
from agriformulations.benchmark_v2.claims_audit import audit_study  # noqa: E402
from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.catalog import catalog_stats, load_catalog  # noqa: E402
from agriformulations.physics.features import physics_features  # noqa: E402
from agriformulations.surrogate.evaluate import run_leave_one_study_out  # noqa: E402
from agriformulations.surrogate.features import SUMMARY_TARGETS, curve_summaries, design_matrix  # noqa: E402
from agriformulations.surrogate.models import CONFORMAL_ALPHA, FIXED_KERNEL_SPEC  # noqa: E402
from agriformulations.surrogate.registry import build_registry, write_registry  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args(argv)
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)

    catalog = load_catalog()
    physics = physics_features(catalog)
    summaries = curve_summaries(catalog, physics)
    summaries.to_csv(OUT / "v5_curve_summaries.csv", index=False)
    print(f"[1/6] curve summaries: {len(summaries)} curves across {summaries['study_key'].nunique()} studies")

    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device=args.device,
        extra={
            "phase": "v5",
            "protocol": {
                "document": "docs/v5_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v5_protocol.md").read_bytes()).hexdigest(),
            },
            "models": {
                "gp_structured": dict(FIXED_KERNEL_SPEC),
                "hierarchical_shrinkage": 5.0,
                "conformal_alpha": CONFORMAL_ALPHA,
                "utility_threshold": 0.10,
                "hyperparameter_search": "none",
            },
        },
    )
    verify_inputs(manifest)
    print(f"[2/6] manifest frozen and verified ({len(manifest['inputs'])} inputs)")

    observations_by_curve = {}
    for _, entry in catalog.studies.items():
        observations = entry["observations"]
        if "included_primary" in observations.columns:
            observations = observations[observations["included_primary"].astype(bool)]
        if "qc_status" in observations.columns:
            observations = observations[observations["qc_status"] == "accepted"]
        if "in_target" in observations.columns:
            observations = observations[observations["in_target"].astype(bool)]
        for curve_id, curve in observations.groupby("curve_id"):
            observations_by_curve[curve_id] = curve

    public = summaries[summaries["data_source"] == "literature"].copy()
    result = run_leave_one_study_out(public, observations_by_curve)
    result["predictions"].to_csv(OUT / "v5_loso_predictions.csv", index=False)
    if result["per_curve"] is not None:
        result["per_curve"].to_csv(OUT / "v5_loso_per_curve.csv", index=False)
    coverage_rate = result["coverage_rate"]
    coverage_ok = bool(pd.notna(coverage_rate) and abs(coverage_rate - (1.0 - CONFORMAL_ALPHA)) <= 0.05)
    any_utility = any(u["meets_threshold"] for u in result["utility"].values()) if result["utility"] else False
    print(
        f"[3/6] LOSO: coverage={coverage_rate if pd.isna(coverage_rate) else round(coverage_rate, 3)} "
        f"(band {'OK' if coverage_ok else 'OUT'}), utility pass={any_utility}"
    )

    summary_rows = {}
    if result["summary"] is not None and not result["summary"].empty:
        result["summary"].to_csv(OUT / "v5_loso_summary.csv", index=False)
        for _, row in result["summary"].iterrows():
            summary_rows[row["model"]] = round(float(row["mae"]), 4)
    X_all = design_matrix(public)
    registry = build_registry(
        models={
            "gp_structured": {
                "code_sha256": hashlib.sha256(Path(REPO / "src/agriformulations/surrogate/models.py").read_bytes()).hexdigest(),
                "training_slice": "public_literature",
                "targets": list(SUMMARY_TARGETS),
            }
        },
        summaries=public,
        feature_columns=list(X_all.columns),
        evaluation={"summary_rows": summary_rows, "utility": result["utility"], "coverage_rate": coverage_rate},
        manifest_path=OUT / "execution_manifest.json",
    )
    write_registry(registry, OUT / "model_registry.json")
    print("[4/6] model registry frozen")

    audits = []
    for key in sorted(catalog.studies):
        entry = catalog.studies[key]
        study = {
            "study_key": key,
            "meta": entry["meta"],
            "observations": entry["observations"],
            "claims": pd.read_csv(entry["path"] / "claims.csv"),
        }
        for optional in ("release_replicates.csv", "photolysis.csv"):
            path = entry["path"] / optional
            if path.exists():
                study[optional[:-4]] = pd.read_csv(path)
        audits.append(audit_study(study))
    audit = pd.concat(audits, ignore_index=True)
    drafted = draft_verdicts(audit)
    drafted.to_csv(OUT / "v5_claims_audit_drafts.csv", index=False)
    proposal = submit_draft_summary(drafted, phase="v5")
    print(
        f"[5/6] claims drafted: {int(drafted['needs_human'].sum())} of {len(drafted)} need human review; "
        f"proposal {proposal.proposal_id} pending"
    )

    utility_rows = [
        {"model": model, **record} for model, record in result["utility"].items()
    ]
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v5 surrogates</title>
<style>{STYLE}</style></head><body>
<h1>Uncertainty-aware surrogates, version 5</h1>
<p>Frozen protocol <code>docs/v5_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen before any fit.
Targets are Weibull curve summaries on the fraction scale; hyperparameters are fixed;
the only acceptance path is leave-one-study-out.</p>
<div class="note"><strong>Outcome.</strong> Conformal coverage
{'' if pd.isna(coverage_rate) else f'{coverage_rate:.3f}'} (acceptance band 0.90 +/- 0.05:
{'met' if coverage_ok else 'not met'}). Utility versus the matched-time-mean baseline:
{'at least one model passes the 10% threshold' if any_utility else 'no model passes; v6 proceeds in physics-only inversion mode'}.
With {len(public)} curves over {public['study_key'].nunique()} studies these are weak-evidence
pilot results, exported as they are.</div>
<h2>1. Curve summaries</h2>
{_table(summaries.groupby('study_key').agg(curves=('curve_id', 'count'),
    median_tau=('weibull_tau_time', 'median'), median_beta=('weibull_beta', 'median'),
    median_endpoint=('endpoint_fraction', 'median')).reset_index())}
<h2>2. Leave-one-study-out evaluation (native units)</h2>
{_table(result['summary'])}
<p>Utility verdicts:</p>
{_table(pd.DataFrame(utility_rows))}
<h2>3. Conformal coverage</h2>
<p>Empirical coverage across held-out summaries: {coverage_rate}. Per target:</p>
{_table(result['coverage'].groupby('target')['covered'].mean().reset_index(name='coverage'))}
<h2>4. Model registry</h2>
<p>Frozen at <a href="model_registry.json">model_registry.json</a>: observed input domains,
evaluation verdicts and prohibitions. v6 hard-refuses candidates outside the domain.</p>
<h2>5. Drafted claims audit</h2>
<p>Deterministic verdicts with agent-drafted bases; {int(drafted['needs_human'].sum())} rows
flagged needs_human. Confirmation is a human action; the pending proposal is
<code>{proposal.proposal_id}</code>.</p>
<h2>6. Interpretation and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v5_surrogates</code>. Exports:
<a href="v5_curve_summaries.csv">summaries</a> ·
<a href="v5_loso_predictions.csv">predictions</a> ·
<a href="v5_loso_summary.csv">metrics</a> ·
<a href="v5_claims_audit_drafts.csv">drafted audit</a>. The surrogates describe
release curves only; the standing not-comparable register is unchanged.</p>
</body></html>"""
    report = OUT / "v5_surrogates.html"
    report.write_text(html)
    with open(OUT / "v5_gate.json", "w") as handle:
        json.dump(
            {
                "coverage_rate": None if pd.isna(coverage_rate) else float(coverage_rate),
                "coverage_ok": coverage_ok,
                "any_utility_pass": any_utility,
                "v6_mode": "surrogate+physics" if any_utility else "physics_only",
            },
            handle,
            indent=1,
        )
    print(f"[6/6] report rendered: {report} ({time.perf_counter() - started:.1f} s total); v6 mode: {'surrogate+physics' if any_utility else 'physics_only'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
