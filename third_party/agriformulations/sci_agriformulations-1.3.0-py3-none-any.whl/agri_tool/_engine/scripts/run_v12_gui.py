"""Launch the R&D workbench or self-test the GUI (docs/v21_formulation_design.md).

    python3 -m scripts.run_v12_gui [--port 9173] [--host 127.0.0.1] [--no-open]
    python3 -m scripts.run_v12_gui --selftest     # headless endpoint checks

The server binds localhost. Scientific calculations run locally; configured
GPT-6.1 Sol agents use the current Codex sign-in by default (optional Responses API).  The selftest is what scripts/reproduce
chains.
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
import urllib.error
import urllib.request
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.gui import make_server  # noqa: E402
from agriformulations.gui.page import PAGE  # noqa: E402

DEFAULT_PORT = 9173


def _get(url: str) -> tuple[int, dict | str]:
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            body = response.read().decode("utf-8")
            content_type = response.headers.get("Content-Type", "")
            return response.status, json.loads(body) if "json" in content_type else body
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def selftest() -> int:
    server = make_server("127.0.0.1", 0)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{port}"
    checks: list[tuple[str, bool, str]] = []

    status, page = _get(base + "/")
    checks.append(("page served", status == 200 and 'id="studioRoot"' in page and 'id="chatMessages"' in page, f"status {status}"))
    checks.append(("page assets are local", 'src="http' not in page and 'href="http' not in page, "external asset dependency found"))

    status, payload = _get(base + "/api/simulate?kernel=zero_order&k0=0.03&plateau=0.9&lag=2&t_max=60&points=120&t1=5&cap=0.2&t2=35&floor=0.8")
    ok = status == 200 and len(payload.get("times", [])) == 120 and payload.get("claim", {}).get("pass") is True
    checks.append(("simulate + claim PASS path", ok, f"status {status}"))
    _, again = _get(base + "/api/simulate?kernel=zero_order&k0=0.03&plateau=0.9&lag=2&t_max=60&points=120")
    checks.append(("deterministic simulate", again["values"] == payload["values"], "values drift"))

    status, payload = _get(base + "/api/claim?t1=5&cap=0.2&t2=35&floor=0.8")
    ok = status == 200 and payload["fickian"]["verdict"] == "infeasible_for_the_family" and payload["zero_order"]["verdict"] == "feasible"
    checks.append(("claim scan verdicts (Fickian infeasible / zero-order feasible)", ok, f"status {status}"))

    status, payload = _get(base + "/api/campaign?phase=v10")
    checks.append(("campaign v10 export", status == 200 and payload.get("n_concepts") == 28, f"status {status}"))
    status, _ = _get(base + "/api/campaign?phase=v7")
    checks.append(("campaign rejects unknown phase", status == 400, f"status {status}"))

    status, payload = _get(base + "/api/degeneracy")
    ok = status == 200 and payload.get("verdict") == "jointly_unidentifiable" and len(payload.get("alternatives", [])) == 3
    checks.append(("degeneracy demo", ok, f"status {status}"))

    status, payload = _get(base + "/api/ask?q=which+concepts+are+blocked+in+v10%3F")
    ok = status == 200 and payload.get("route") == "flag_listing" and payload.get("table", {}).get("rows")
    checks.append(("ask console routes questions", ok, f"status {status}"))
    status, payload = _get(base + "/api/ask?q=")
    checks.append(("ask rejects empty question", status == 400, f"status {status}"))

    status, payload = _get(base + "/api/simulate?kernel=bogus")
    checks.append(("bad kernel rejected", status == 400 and "kernel" in payload.get("error", ""), f"status {status}"))
    status, _ = _get(base + "/api/simulate?kernel=fickian&rate=-1")
    checks.append(("bad rate rejected", status == 400, f"status {status}"))

    server.shutdown()
    failed = [name for name, ok, _ in checks if not ok]
    for name, ok, detail in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + ("" if ok else f" ({detail})"))
    if failed:
        print(f"selftest FAILED ({len(failed)} checks)")
        return 1
    print("selftest PASSED")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--no-open", action="store_true")
    parser.add_argument("--workspace", type=Path, help="Path to the local project SQLite database")
    args = parser.parse_args(argv)
    if args.selftest:
        return selftest()

    server = make_server(args.host, args.port, workspace_path=args.workspace)
    url = f"http://{args.host}:{server.server_address[1]}"
    print(f"GUI serving at {url} (Ctrl-C to stop; local scientific tools, optional GPT-6.1 Sol agents)")
    if not args.no_open:
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
