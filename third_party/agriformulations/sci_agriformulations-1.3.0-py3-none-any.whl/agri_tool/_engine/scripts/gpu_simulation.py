"""GPU batched physics prediction extension, explicitly synthetic scenarios."""
from pathlib import Path
import os,sys,json,time,argparse,hashlib
os.environ.setdefault("MPLCONFIGDIR","/tmp/agriformulations-matplotlib")
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from agriformulations import fit_release,release_fraction
from agriformulations.accelerated import batch_sphere_predictions
OUT=ROOT/"reports"

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument("--device",choices=["auto","cpu","cuda"],default="auto")
    parser.add_argument("--grid-size",type=int,default=256)
    args=parser.parse_args(argv)
    if not 2<=args.grid_size<=512:raise ValueError("Grid size must be 2..512")
    source=ROOT/"data/curated/fertilizer_2026_release.csv"
    df=pd.read_csv(source)
    radius=np.geomspace(.5,2,args.grid_size);diffusivity=np.geomspace(.25,4,args.grid_size)
    rr,dd=np.meshgrid(radius,diffusivity)
    times=np.linspace(0,720,121)
    allrows=[];checks=[];metas=[]
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),constrained_layout=True)
    wall_start=time.perf_counter()
    for ax,(active,g) in zip(axes,df.groupby("active",sort=True)):
        fit=fit_release(g.time_h.to_numpy(),g.release_pct.to_numpy()/100,"spherical_diffusion")
        rate=fit.parameters["rate"]
        rates=(rate*dd/rr**2).ravel()
        begin=time.perf_counter()
        pred,meta=batch_sphere_predictions(rates,times,device=args.device)
        seconds=time.perf_counter()-begin
        # Independent NumPy library reference uses the original 100-mode series.
        selected=np.linspace(0,len(rates)-1,64,dtype=int)
        error=max(float(np.max(abs(pred[i]-release_fraction(times,"spherical_diffusion",{"rate":float(rates[i])})))) for i in selected)
        if error>1e-8:raise RuntimeError(f"GPU/CPU analytic mismatch: {error}")
        if not np.all((pred>=0)&(pred<=1)) or np.any(np.diff(pred,axis=1)<-1e-10):
            raise RuntimeError("Invalid mass-fraction predictions")
        checks.append(dict(active=active,max_abs_gpu_reference_error_fraction=error,
            reference_scenarios=len(selected),bounded=True,monotonic=True))
        frame=pd.DataFrame(dict(active=active,radius_multiplier=rr.ravel(),
            effective_diffusivity_multiplier=dd.ravel(),effective_rate_h_inverse=rates,
            release_day30_pct=pred[:,-1]*100))
        frame["evidence_kind"]="synthetic"
        frame["method"]="ideal_sphere_parameter_grid_not_published_observations"
        frame["parent_source"]="data/curated/fertilizer_2026_release.csv"
        allrows.append(frame)
        meta.update(active=active,scenario_count=len(rates),time_points=len(times),
            predictions=int(pred.size),prediction_seconds=seconds,reference_rate_h_inverse=rate)
        metas.append(meta)
        mesh=ax.pcolormesh(radius,diffusivity,pred[:,-1].reshape(rr.shape)*100,shading="auto",vmin=0,vmax=100,cmap="viridis")
        ax.set(xscale="log",yscale="log",xlabel="Assumed radius / reference radius",
            ylabel="Assumed effective D / reference D",title=active+" — release at day 30")
        ax.plot([1],[1],marker="o",markerfacecolor="none",markeredgecolor="white",markersize=8)
    fig.colorbar(mesh,ax=axes,label="Simulated release (%)")
    fig.savefig(OUT/"gpu_physics_sweep.png",dpi=170);plt.close(fig)
    pd.concat(allrows,ignore_index=True).to_csv(OUT/"gpu_physics_scenarios.csv",index=False)
    manifest=dict(workload="batched ideal-sphere physics predictions",requested_device=args.device,
        executions=metas,total_predictions=sum(m["predictions"] for m in metas),
        wall_seconds=time.perf_counter()-wall_start,verification=checks,
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        accelerated_module_sha256=hashlib.sha256((ROOT/"src/agriformulations/accelerated.py").read_bytes()).hexdigest(),
        interpretation="Synthetic deterministic sensitivity grid; not a probability distribution, experimental benchmark, or uncertainty interval",
        cpu_tasks="Tiny SciPy calibration and sklearn training remain CPU; GPU used for batched simulation prediction")
    (OUT/"gpu_execution.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps(manifest,indent=2))

if __name__=="__main__":main()
