"""One reproducible command for the v11 zero-order kernel phase (docs/v11_protocol.md).

Freezes the manifest, proves the claim pair infeasible for the whole
Fickian family (analytic ratio bound + ceiling scan, anchored to the R4
session's 47.5%), exports the feasible zero-order (k0, lag, plateau)
region with the analytic corner check, runs the synthetic recovery gate,
and renders the report.  Analysis machinery only: no proposal, no
recommendation.

    python3 -m scripts.run_v11_zero_order
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v11"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.benchmark_v2.io_utils import sha256_file  # noqa: E402
from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.design.zero_order import (  # noqa: E402
    CLAIM_CAP_T1,
    CLAIM_FLOOR_T2,
    CLAIM_T1_DAYS,
    CLAIM_T2_DAYS,
    FICKIAN_TAU_GRID,
    RECOVERY_K0_REL,
    RECOVERY_LAG_ABS,
    RECOVERY_PLATEAU_ABS,
    RECOVERY_TRIALS,
    ZERO_ORDER_K0_GRID,
    ZERO_ORDER_LAG_GRID,
    ZERO_ORDER_PLATEAU_GRID,
    fickian_claim_scan,
    synthetic_recovery,
    zero_order_claim_scan,
)

V11_CODE_PATTERNS = ("src/agriformulations/design/zero_order.py", "scripts/run_v11_zero_order.py")


def _collect(patterns) -> dict:
    records = {}
    for pattern in patterns:
        for path in sorted(REPO.glob(pattern)):
            records[path.relative_to(REPO).as_posix()] = {"sha256": sha256_file(path)}
    return records


def main(argv=None) -> int:
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)

    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device="cpu",
        extra={
            "phase": "v11",
            "protocol": {
                "document": "docs/v11_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v11_protocol.md").read_bytes()).hexdigest(),
            },
            "constants": {
                "claim": {"t1_days": CLAIM_T1_DAYS, "cap_t1": CLAIM_CAP_T1,
                          "t2_days": CLAIM_T2_DAYS, "floor_t2": CLAIM_FLOOR_T2},
                "fickian_tau_grid": FICKIAN_TAU_GRID,
                "zero_order_grid": [ZERO_ORDER_K0_GRID, ZERO_ORDER_LAG_GRID, ZERO_ORDER_PLATEAU_GRID],
                "recovery": {"trials": RECOVERY_TRIALS, "k0_rel": RECOVERY_K0_REL,
                             "plateau_abs": RECOVERY_PLATEAU_ABS, "lag_abs": RECOVERY_LAG_ABS},
                "kernel": "F(t) = plateau * clip(k0 (t - lag), 0, 1); membrane-controlled reservoir",
            },
            "code_sha256_v11": _collect(V11_CODE_PATTERNS),
        },
    )
    verify_inputs(manifest)
    print(f"[1/5] manifest frozen ({len(manifest['code_sha256_v11'])} code inputs)")

    fickian = fickian_claim_scan()
    scan = fickian["scan"]
    pd.DataFrame(
        {
            "tau1": scan["tau1"],
            "F_t1": scan["f1"],
            "F_t2": scan["f2"],
            "plateau_best": scan["plateau_best"],
            "achieved_t2": scan["achieved"],
        }
    ).to_csv(OUT / "v11_fickian_scan.csv", index=False)
    print(f"[2/5] Fickian family: n_feasible={fickian['n_feasible']} "
          f"(claim INFEASIBLE); day-{CLAIM_T2_DAYS:.0f} ceiling {fickian['ceiling_t2']:.3f} "
          f"at rate {fickian['best_rate_per_day']:.3g}/d; analytic ratio bound "
          f"sqrt(t2/t1)={fickian['ratio_bound_sqrt']:.3f} (R4 session anchor: 0.475)")

    zero = zero_order_claim_scan()
    with open(OUT / "v11_zero_order_region.json", "w") as handle:
        json.dump(zero, handle, indent=1)
    print(f"[3/5] zero-order region: {zero['n_feasible']} feasible grid points, "
          f"k0 in [{zero['k0_feasible_min']:.4g}, {zero['k0_feasible_max']:.4g}]/d; "
          f"analytic corner {zero['corner']['k0_interval_per_day']} "
          f"nonempty={zero['corner']['nonempty']} satisfies={zero['corner']['satisfies_claim']}")

    recovery = synthetic_recovery()
    if not recovery["pass"]:
        raise SystemExit(f"recovery gate FAILED: {recovery}")
    with open(OUT / "v11_recovery_gate.json", "w") as handle:
        json.dump(recovery, handle, indent=1)
    print(f"[4/5] recovery gate PASS ({recovery['recovered']}/{recovery['trials']} trials; "
          f"plateau requires a window spanning depletion)")

    fickian_again, zero_again = fickian_claim_scan(), zero_order_claim_scan()
    determinism_pass = (
        fickian["ceiling_t2"] == fickian_again["ceiling_t2"]
        and fickian["n_feasible"] == fickian_again["n_feasible"]
        and zero["n_feasible"] == zero_again["n_feasible"]
        and zero["examples"] == zero_again["examples"]
    )
    if not determinism_pass:
        raise SystemExit("determinism gate FAILED: two scan passes differ")

    gates = {
        "analytic_bound_consistent": bool(fickian["ceiling_t2"] < CLAIM_FLOOR_T2),
        "fickian_claim_infeasible": fickian["n_feasible"] == 0,
        "fickian_ceiling_t2": fickian["ceiling_t2"],
        "r4_anchor": 0.475,
        "ceiling_matches_r4_anchor": bool(abs(fickian["ceiling_t2"] - 0.475) <= 0.01),
        "zero_order_claim_feasible": zero["n_feasible"] > 0,
        "zero_order_corner_valid": bool(zero["corner"]["nonempty"] and zero["corner"]["satisfies_claim"]),
        "recovery_pass": recovery["pass"],
        "determinism_pass": bool(determinism_pass),
        "proposal_submitted": False,
        "assumption": "membrane-controlled reservoir; mechanistic feasibility only - no efficacy, field or patentability claim",
    }
    with open(OUT / "v11_gate.json", "w") as handle:
        json.dump(gates, handle, indent=1)

    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v11 zero-order kernel</title>
<style>{STYLE}</style></head><body>
<h1>Zero-order membrane kernel, version 11</h1>
<p>Frozen protocol <code>docs/v11_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen before any scan.</p>
<div class="note"><strong>Outcome.</strong> The claim pair the sulfoxaflor R4 session proved
numerically infeasible (<= {CLAIM_CAP_T1:.0%} at day {CLAIM_T1_DAYS:.0f}, >= {CLAIM_FLOOR_T2:.0%} at
day {CLAIM_T2_DAYS:.0f}) is now proven in-repo and analytically: the Fickian family's best
late/early ratio is sqrt(t2/t1) = {fickian['ratio_bound_sqrt']:.3f}, putting the day-35 ceiling at
{fickian['ceiling_t2']:.3f} (R4 anchor 0.475) with {fickian['n_feasible']} feasible candidates.
Under the membrane kernel the same pair is designable: {zero['n_feasible']} feasible
(k0, lag, plateau) grid points, k0 in [{zero['k0_feasible_min']:.4g},
{zero['k0_feasible_max']:.4g}]/d, and the analytic corner (lag 0, plateau 1,
k0 in [{zero['corner']['k0_interval_per_day'][0]:.4f}, {zero['corner']['k0_interval_per_day'][1]:.4f}]/d)
verified inside the region. Recovery gate {recovery['recovered']}/{recovery['trials']}: full curves
identify all three parameters, provided the assay window spans reservoir depletion.
Mechanistic feasibility only - the standing not-comparable register applies.</div>
<h2>1. Fickian family ceiling</h2>
{_table(pd.DataFrame([{"n_feasible": fickian["n_feasible"], "ceiling_t2": round(fickian["ceiling_t2"], 4),
                       "best_rate_per_day": fickian["best_rate_per_day"], "best_plateau": round(fickian["best_plateau"], 3),
                       "ratio_bound_sqrt": fickian["ratio_bound_sqrt"]}]))}
<p class="small">Scan export: <a href="v11_fickian_scan.csv">v11_fickian_scan.csv</a></p>
<h2>2. Zero-order feasible region</h2>
{_table(pd.DataFrame(zero["examples"]))}
<p class="small">Full region summary: <a href="v11_zero_order_region.json">v11_zero_order_region.json</a></p>
<h2>3. Recovery gate</h2>
{_table(pd.DataFrame([{"recovered": recovery["recovered"], "trials": recovery["trials"],
                       "k0_rel_tol": recovery["tolerances"]["k0_rel"],
                       "plateau_abs_tol": recovery["tolerances"]["plateau_abs"],
                       "lag_abs_tol": recovery["tolerances"]["lag_abs"]}]))}
<h2>4. Scope decisions and reproduction</h2>
<p>Runner consolidation rejected (byte-frozen per-campaign exports; reuse lives in the
parameterized campaign package). Catalog growth, stereo-resolved curves and the composition bridge
remain external-data unlocks. GUI deferred. Reproduce with
<code>python3 -m scripts.run_v11_zero_order</code> (CPU, deterministic - two scan passes
byte-identical). Gates: <a href="v11_gate.json">v11_gate.json</a>.</p>
</body></html>"""
    report = OUT / "v11_zero_order.html"
    report.write_text(html)
    print(f"[5/5] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
