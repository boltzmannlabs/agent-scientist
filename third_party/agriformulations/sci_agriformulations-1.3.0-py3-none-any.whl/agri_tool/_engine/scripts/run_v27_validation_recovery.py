"""SC/EC acceptance checks in an isolated workspace, with optional real Chromium.

python3 -m scripts.run_v27_validation_recovery --browser --browser-executable PATH
Browser queue tests use an explicitly scripted waiting research worker, not an LLM.
"""
import argparse
from copy import deepcopy
import json
import math
from pathlib import Path
import sys
import tempfile
import threading
import time
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from agriformulations.rnd import control, simulation_models
from agriformulations.gui.server import make_server

class TestConnection:
    def status(self):return {"configured":True,"verified":True,"model":"Scripted acceptance coordinator","provider":"test"}

def recipe(name,fmt,active_pct,extras):
    rows=[{"name":"Reference technical active","role":"active","pct":active_pct/.95,"purity_pct":95}]
    rows.extend({"name":n,"role":role,"pct":v,"purity_pct":100} for n,role,v in extras)
    rows.append({"name":"Water" if fmt=="SC" else "Reference solvent","role":"solvent","pct":100-sum(i["pct"] for i in rows),"purity_pct":100})
    return {"name":name,"format":fmt,"batch_g":1000,"mode":"fixed","ingredients":rows}

def browser_checks(destination,executable=None):
    from playwright.sync_api import sync_playwright
    release=threading.Event();entered=threading.Event();errors=[];checks={}
    with tempfile.TemporaryDirectory(prefix="agri-v27-browser-") as tmp:
        server=make_server(port=0,workspace_path=Path(tmp)/"browser.sqlite3",agent_connection=TestConnection())
        threading.Thread(target=server.serve_forever,daemon=True).start()
        base="http://127.0.0.1:"+str(server.server_address[1])
        def waiting_research(raw,*args,**kwargs):
            state=deepcopy(raw["state"])
            control.checkpoint(state,"Scripted research checkpoint; independent local work is available")
            entered.set()
            while not release.wait(.01):control.check()
            state.setdefault("research_reports",[]).append({"report_id":"scripted-final","task":"Coordination acceptance fixture","answer":"Scripted research worker finished; this is not a live scientific source review."})
            control.checkpoint(state,"Scripted coordination fixture complete")
            identity=raw["project_identity"]
            saved=server.sessions.workspace.commit_run(state,identity["project_id"],identity["revision"],initial=raw["state"])
            return {"answer":"Scripted coordination fixture completed","project_saved":saved,"warnings":[]}
        server.agent_runs.runner=waiting_research
        sc=server.sessions.create("Isolated SC acceptance");scid=sc["session"]["session_id"]
        e=server.sessions.create("Isolated EC acceptance");ecid=e["session"]["session_id"]
        sc_recipe=server.sessions.add_recipe(scid,recipe("SC reference","SC",20,[("Dispersant","dispersant",2),("Glycol","solvent",5)]))["recipes"][0]
        ec_recipe=server.sessions.add_recipe(ecid,recipe("EC reference","EC",25,[("Emulsifier","surfactant",10)]))["recipes"][0]
        try:
            with sync_playwright() as p:
                options={"headless":True,"args":["--no-sandbox"]}
                if executable:options["executable_path"]=executable
                browser=p.chromium.launch(**options)
                context=browser.new_context(viewport={"width":1500,"height":1050},timezone_id="Asia/Kolkata",accept_downloads=True)
                page=context.new_page();page.set_default_timeout(15000)
                page.on("pageerror",lambda error:errors.append(str(error)))
                page.goto(base+"/?session="+scid+"&tab=recipe")
                page.wait_for_function("window.formulationStudio?.app.view?.project")
                page.locator("[data-edit]").first.click()
                codes=page.locator("#recipeFormat option").evaluate_all("elements=>elements.map(e=>e.value)")
                checks["requested_format_controls"]=all(c in codes for c in ["EC","SC","SL","OD","WG","WP","SG","SP","GR","EW"])
                active=page.locator("#recipeIngredientRows tr").first
                purity=active.locator("[data-recipe-field=purity_pct]")
                purity.fill("105")
                checks["invalid_purity_blocks_live_totals"]=page.locator("#saveRecipe").is_disabled() and "Pure active:" not in page.locator("#recipeBalance").inner_text()
                purity.fill("95");active.locator("[data-recipe-field=pct]").fill("-5")
                checks["negative_amount_blocks_live_totals"]=page.locator("#saveRecipe").is_disabled() and "Pure active:" not in page.locator("#recipeBalance").inner_text()
                page.screenshot(path=str(destination/"invalid-inputs.png"),full_page=True)
                page.locator("[data-close=recipeDialog]").first.click()
                page.locator("[data-edit]").first.click();page.locator("#recipeMode").select_option("ranges")
                vehicle=page.locator("#recipeIngredientRows tr").last
                vehicle.locator("[data-recipe-field=pct]").fill("")
                vehicle.locator("[data-recipe-field=min_pct]").fill("65")
                vehicle.locator("[data-recipe-field=max_pct]").fill("80")
                checks["optional_excipient_reference"]=not page.locator("#saveRecipe").is_disabled() and not vehicle.locator("[data-recipe-field=pct]").evaluate("e=>e.required")
                active=page.locator("#recipeIngredientRows tr").first
                active.locator("[data-recipe-field=min_pct]").fill("30");active.locator("[data-recipe-field=max_pct]").fill("20")
                checks["reversed_bounds_block_immediately"]=page.locator("#saveRecipe").is_disabled()
                page.locator("[data-close=recipeDialog]").first.click()
                # Start a held research worker through the actual composer.
                page.locator("#messageInput").fill("Run the scripted coordination acceptance fixture")
                page.locator("#sendMessage").click()
                assert entered.wait(5)
                def simulate(key,inputs,name):
                    page.locator("#labNewSimulation").click();page.locator("#simulationModel").select_option(key)
                    first=next(iter(inputs));page.locator("[data-sim-key='"+first+"']").wait_for()
                    page.locator("#simulationName").fill(name)
                    for key,value in inputs.items():
                        field=page.locator("[data-sim-key='"+key+"']")
                        field.fill(", ".join(map(str,value)) if isinstance(value,list) else str(value))
                    page.locator("#simulationForm button[type=submit]").click()
                    page.locator("#simulationDialog").wait_for(state="hidden")
                    page.wait_for_function("name=>document.querySelector('#labResultChoice')?.selectedOptions[0]?.textContent.includes(name)",arg=name,timeout=20000)
                inputs={"particle_sizes_um":[5],"particle_weights":[1],"density_difference_kg_m3":500,"viscosity_mpa_s":100,"solids_volume_fraction":.15,"hindered_exponent":4.65,"yield_stress_pa":0,"container_height_cm":10,"horizon_days":1}
                simulate("suspension",inputs,"SC 5 micrometres")
                checks["local_result_while_research_active"]=bool(server.agent_runs.active)
                checks["elapsed_progress_visible"]="elapsed" in page.locator("#chatMessages").inner_text()
                simulate("suspension",{**inputs,"particle_sizes_um":[10]},"SC 10 micrometres")
                checks["new_scenario_selected"]=page.locator("#labResultChoice option:checked").inner_text().startswith("SC 10 micrometres")
                page.screenshot(path=str(destination/"independent-local-results.png"),full_page=True)
                # Cached reuse must select the requested old scenario as well.
                simulate("suspension",inputs,"SC 5 micrometres")
                checks["cached_scenario_selected"]=page.locator("#labResultChoice option:checked").inner_text().startswith("SC 5 micrometres")
                release.set()
                deadline=time.monotonic()+8
                while server.agent_runs.active and time.monotonic()<deadline:time.sleep(.02)
                state=server.sessions.workspace.load(sc["project"]["project_id"])["document"]
                checks["both_finished_outputs_persist"]=len(state["analysis_runs"])==2 and any(r["report_id"]=="scripted-final" for r in state.get("research_reports",[]))
                page.goto(base+"/?session="+ecid+"&tab=recipe");page.wait_for_function("window.formulationStudio?.app.view?.project")
                dilution={"dilution_factors":[100],"product_density_kg_l":1,"solubility_mg_l":100,"hardness_mg_l_caco3":0}
                simulate("dilution",dilution,"EC soft water")
                simulate("dilution",{**dilution,"hardness_mg_l_caco3":500},"EC hard water 500")
                text=page.locator("#canvasContent").inner_text()
                checks["ec_aqueous_gate_visible"]="Aqueous-only excess fraction (hypothetical)" in text and "not predicted product precipitation" in text
                checks["water_scenarios_distinct"]="EC soft water" in text and "EC hard water 500" in text
                page.screenshot(path=str(destination/"ec-aqueous-gate.png"),full_page=True)
                with page.expect_download() as downloaded:page.locator("#exportSession").click()
                path=destination/"browser-export.zip";downloaded.value.save_as(path)
                with zipfile.ZipFile(path) as archive:
                    exported=json.loads(archive.read("project.json"));history=json.loads(archive.read("artifact_history.json"))
                    checks["download_archive_round_trip"]=len(exported["analysis_runs"])==2 and any(a["kind"]=="dilution" for a in history)
                checks["recoverable_download_visible"]=page.get_by_role("link",name="Download again").is_visible()
                with page.expect_download() as repeated:page.get_by_role("link",name="Download again").click()
                checks["recoverable_link_downloads"]=repeated.value.suggested_filename==downloaded.value.suggested_filename
                page.reload();page.locator("#labResultChoice").wait_for()
                checks["scenario_persistence_after_reload"]=page.locator("#labResultChoice option").count()==2
                page.set_viewport_size({"width":420,"height":900});page.locator("#toggleCanvas").click()
                page.screenshot(path=str(destination/"mobile-results.png"),full_page=True)
                checks["mobile_no_page_overflow"]=page.evaluate("document.documentElement.scrollWidth<=innerWidth")
                checks["no_javascript_errors"]=not errors
                browser.close()
        finally:
            release.set();server.sessions.stop_all();server.sessions.close();server.shutdown();server.server_close()
    return {"checks":checks,"javascript_errors":errors,"research_basis":"Scripted waiting worker, not a live model or source-verification assessment"}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--browser",action="store_true");parser.add_argument("--browser-executable")
    args=parser.parse_args();destination=ROOT/"reports/v27";destination.mkdir(parents=True,exist_ok=True)
    inputs={"particle_sizes_um":[5],"particle_weights":[1],"density_difference_kg_m3":500,"viscosity_mpa_s":100,"solids_volume_fraction":.15,"hindered_exponent":4.65,"yield_stress_pa":0,"container_height_cm":10,"horizon_days":1}
    base=simulation_models.run("suspension",inputs);larger=simulation_models.run("suspension",{**inputs,"particle_sizes_um":[10]})
    expected=500*9.80665*(5e-6)**2/(18*.1)*.85**4.65*86400*1000
    dilution=simulation_models.run("dilution",{"dilution_factors":[100],"solubility_mg_l":100,"product_density_kg_l":1,"hardness_mg_l_caco3":500,"calcium_fraction":.7,"carbonate_mmol_l":.01,"caco3_ksp":3.3e-9},.25)
    checks={"independent_settling_error_mm_day":abs(base["rows"][0]["velocity_mm_day"]-expected),
        "diameter_squared_scaling":math.isclose(larger["rows"][0]["velocity_mm_day"],expected*4,rel_tol=1e-12),
        "independent_active_concentration":dilution["rows"][0]["active_mg_l"]==2500,
        "aqueous_excess_only":dilution["product_predictions"]["precipitated_fraction"] is None,
        "independent_carbonate_error":abs(dilution["metrics"]["caco3_saturation_ratio"]-(500/100090*.7)*(.01*.001)/3.3e-9)}
    result={"numerical_checks":checks,"evidence":"Implementation and coordination checks; no wet-lab or composition-to-performance validation"}
    if args.browser:result["browser"]=browser_checks(destination,args.browser_executable)
    result["passed"]=checks["independent_settling_error_mm_day"]<1e-10 and checks["independent_carbonate_error"]<1e-10 and all(v for k,v in checks.items() if "error" not in k) and (all(result["browser"]["checks"].values()) if args.browser else True)
    (destination/"validation_recovery.json").write_text(json.dumps(result,indent=2,allow_nan=False));print(json.dumps(result,indent=2))
    return 0 if result["passed"] else 1

if __name__=="__main__":raise SystemExit(main())
