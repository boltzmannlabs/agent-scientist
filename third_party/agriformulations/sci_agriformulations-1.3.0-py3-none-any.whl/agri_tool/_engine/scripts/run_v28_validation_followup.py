"""Real-browser checks for import origin/units, study selection and project naming.

Uses an isolated workspace and local calculations only; no external model/search.
"""
import argparse
import json
from pathlib import Path
import tempfile
import threading
import time
import zipfile

from .run_v27_validation_recovery import ROOT, TestConnection, recipe
from agriformulations.gui.server import make_server


def browser_checks(destination, executable=None):
    from playwright.sync_api import sync_playwright
    checks={};errors=[]
    with tempfile.TemporaryDirectory(prefix='agri-v28-browser-') as tmp:
        server=make_server(port=0,workspace_path=Path(tmp)/'browser.sqlite3',agent_connection=TestConnection())
        threading.Thread(target=server.serve_forever,daemon=True).start()
        base='http://127.0.0.1:'+str(server.server_address[1])
        view=server.sessions.create('Isolated v28 acceptance');sid=view['session']['session_id']
        server.sessions.add_recipe(sid,recipe('Hypothesis A','SC',20,[('Dispersant A','dispersant',2)]))
        server.sessions.add_recipe(sid,recipe('Hypothesis B','SC',20,[('Dispersant B','dispersant',3)]))
        try:
            with sync_playwright() as p:
                options={'headless':True,'args':['--no-sandbox']}
                if executable:options['executable_path']=executable
                browser=p.chromium.launch(**options)
                context=browser.new_context(viewport={'width':1500,'height':1050},accept_downloads=True)
                page=context.new_page();page.set_default_timeout(15000)
                page.on('pageerror',lambda error:errors.append(str(error)))
                page.goto(base+'/?session='+sid+'&tab=data')
                page.wait_for_function('window.formulationStudio?.app.view?.project')
                page.locator('#labAddData').click()
                page.locator('#measurementSourceKind').select_option('synthetic')
                page.locator('#measurementKind').select_option('suspension')
                page.locator('#measurementMethod').fill('Synthetic software QA, not measured')
                csv='time_days,original_time_minutes,separated_fraction\n0,0,0\n0.25,360,0.1\n0.5,720,0.2\n0.75,1080,0.3\n1,1440,0.4\n'
                page.locator('#measurementFile').set_input_files({'name':'synthetic-dual-time.csv','mimeType':'text/csv','buffer':csv.encode()})
                page.locator('#mappingFields [data-mapping=x]').wait_for()
                checks['prefers_normalized_time_days']=page.locator('#mappingFields [data-mapping=x]').input_value()=='time_days'
                checks['time_unit_matches_column']=page.locator('#measurementXUnit').input_value()=='days'
                checks['conflicting_time_columns_require_confirmation']=page.locator('#timeMappingConfirmLabel').is_visible()
                page.locator('#uploadForm button.primary').click()
                page.locator('#importError').wait_for(state='visible')
                checks['confirmation_error_inside_dialog']=page.locator('#uploadDialog').is_visible() and 'Confirm' in page.locator('#importError').inner_text()
                page.locator('#mappingFields [data-mapping=x]').select_option('original_time_minutes')
                checks['selected_minutes_inferred']=page.locator('#measurementXUnit').input_value()=='minutes'
                checks['explicit_days_conversion_preview']='→ days' in page.locator('#timeConversionPreview').inner_text() and '1440' in page.locator('#timeConversionPreview').inner_text().replace(',','')
                page.locator('#timeMappingConfirmed').check()
                page.locator('#measurementValue').fill('percent')
                page.locator('#uploadForm button.primary').click()
                page.wait_for_function("document.querySelector('#importError').textContent.includes('Use days')")
                checks['backend_validation_visible_in_modal']=page.locator('#uploadDialog').is_visible() and page.locator('#importError').is_visible()
                page.screenshot(path=str(destination/'import-conversion-error.png'),full_page=True)
                page.locator('#measurementValue').fill('fraction')
                page.locator('#uploadForm button.primary').click()
                page.locator('#uploadDialog').wait_for(state='hidden')
                page.get_by_role('button',name='Fit dataset',exact=True).click()
                page.get_by_role('button',name='Inspect fit',exact=True).wait_for(timeout=25000)
                page.get_by_role('button',name='Inspect fit',exact=True).click()
                page.wait_for_function("document.querySelector('#canvasContent').textContent.includes('synthetic descriptive fit')")
                text=page.locator('#canvasContent').inner_text()
                checks['synthetic_data_and_fit_visible']='synthetic' in text and 'no empirical validation' in text
                doc=server.sessions.workspace.load(view['project']['project_id'])['document']
                data=doc['imports'][0];fit=doc['fit_runs'][0]
                checks['converted_observations_correct']=[r['x'] for r in data['observations']]==[0,.25,.5,.75,1]
                checks['origin_retained_in_fit_gate']=fit['source_kind']=='synthetic' and fit['prediction_gate']['empirical_validation_established'] is False
                page.screenshot(path=str(destination/'synthetic-fit.png'),full_page=True)
                page.locator('#labDesignStudy').click()
                page.locator('#studyName').fill('First comparison')
                page.locator('#studyRun').click()
                page.locator('#studyDialog').wait_for(state='hidden')
                page.wait_for_function("document.querySelector('#studyChoice')?.selectedOptions[0]?.textContent.includes('First comparison')",timeout=30000)
                old=page.locator('#studyChoice').input_value()
                page.locator('[data-study-revise]').click()
                page.locator('#studyName').fill('Revised comparison')
                page.locator('#studyRun').click()
                page.locator('#studyDialog').wait_for(state='hidden')
                page.wait_for_function("document.querySelector('#studyChoice')?.selectedOptions[0]?.textContent.includes('Revised comparison')",timeout=30000)
                checks['new_study_selected']=page.locator('#studyChoice').input_value()!=old
                page.reload();page.locator('#studyChoice').wait_for()
                checks['revised_study_selection_survives_reload']='Revised comparison' in page.locator('#studyChoice option:checked').inner_text()
                page.locator('#renameSession').click()
                page.locator('#projectName').fill('Renamed in page — v28')
                page.locator('#nameSubmit').click();page.locator('#nameDialog').wait_for(state='hidden')
                page.reload();page.wait_for_function("document.querySelector('#sessionTitle').textContent==='Renamed in page — v28'")
                checks['rename_persists_without_prompt']=page.locator('#sessionTitle').inner_text()=='Renamed in page — v28'
                with page.expect_download() as downloaded:page.locator('#exportSession').click()
                path=destination/'synthetic-feedback-project.zip';downloaded.value.save_as(path)
                with zipfile.ZipFile(path) as archive:
                    project=json.loads(archive.read('project.json'))
                    history=json.loads(archive.read('artifact_history.json'))
                checks['source_kind_export_round_trip']=project['imports'][0]['source_kind']=='synthetic' and project['fit_runs'][0]['source_kind']=='synthetic' and any(a['kind']=='fit' and a['payload']['prediction_gate']['source_kind']=='synthetic' for a in history)
                checks['time_conversion_export_round_trip']=project['imports'][0]['time_conversion']['source_unit']=='minutes'
                page.locator('#forkSession').click();page.locator('#projectName').fill('Separate QA fork');page.locator('#nameSubmit').click();page.locator('#nameDialog').wait_for(state='hidden')
                checks['fork_uses_in_page_dialog']='Separate QA fork' in page.locator('#sessionTitle').inner_text()
                checks['no_javascript_errors']=not errors
                browser.close()
        finally:
            server.sessions.stop_all();server.sessions.close();server.shutdown();server.server_close()
    return {'passed':all(checks.values()),'checks':checks,'javascript_errors':errors,'basis':'Real Chromium with isolated local scientific tools; no live agent or empirical product validation'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--browser-executable');args=parser.parse_args()
    destination=ROOT/'reports/v28';destination.mkdir(parents=True,exist_ok=True)
    result=browser_checks(destination,args.browser_executable)
    (destination/'browser_validation.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2));return 0 if result['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
