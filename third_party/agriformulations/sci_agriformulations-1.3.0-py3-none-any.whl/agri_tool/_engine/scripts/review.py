"""Human review CLI for agent proposals.

    python3 -m scripts.review --list
    python3 -m scripts.review --show v6 <proposal_id>
    python3 -m scripts.review --decide v6 <proposal_id> approved --reviewer "human:<name>"
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.agents import review, verify_log_chain  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--show", nargs=2, metavar=("PHASE", "PROPOSAL_ID"))
    parser.add_argument("--decide", nargs=3, metavar=("PHASE", "PROPOSAL_ID", "DECISION"))
    parser.add_argument("--reviewer", default="human:reviewer")
    parser.add_argument("--verify-chain", action="store_true")
    args = parser.parse_args(argv)

    if args.verify_chain:
        print("log chain:", "INTACT" if verify_log_chain() else "TAMPERED")
        return 0 if verify_log_chain() else 1
    if args.list:
        for phase_dir in sorted((REPO / "proposals").glob("*")):
            if not phase_dir.is_dir():
                continue
            for path in sorted(phase_dir.glob("*.json")):
                record = json.loads(path.read_text())
                print(
                    f"{phase_dir.name:4s} {record['proposal_id']:36s} {record['status']:9s} "
                    f"{record['authored_by']}"
                )
        return 0
    if args.show:
        phase, proposal_id = args.show
        path = REPO / "proposals" / phase / f"{proposal_id}.json"
        print(json.dumps(json.loads(path.read_text()), indent=1, sort_keys=True))
        return 0
    if args.decide:
        phase, proposal_id, decision = args.decide
        proposal = review(phase, proposal_id, decision, args.reviewer)
        print(f"{proposal.proposal_id}: {proposal.status} by {proposal.reviewer} at {proposal.reviewed_utc}")
        return 0
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
