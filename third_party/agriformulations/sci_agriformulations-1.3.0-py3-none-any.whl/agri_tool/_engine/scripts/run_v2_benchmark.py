"""One reproducible command for the v2 three-paper benchmark (docs/v2_protocol.md).

Validates source hashes, freezes the execution manifest BEFORE any fitting,
runs the claims audit, the forecast track, the transfer track and the GPU
physics legs, then renders the report.  Every stage prints one status line;
any gate failure aborts with a non-zero exit.

    python3 -m scripts.run_v2_benchmark [--device auto|cpu|cuda] [--studies ...] [--skip-gpu]
"""

from __future__ import annotations

import argparse
import json
import runpy
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v2"

try:  # editable install or not, mirror scripts/reproduce.py behaviour
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.benchmark_v2.claims_audit import audit_study  # noqa: E402
from agriformulations.benchmark_v2.forecast import run_forecast_track  # noqa: E402
from agriformulations.benchmark_v2.gpu_fv import calibration_sweep, verify_fv  # noqa: E402
from agriformulations.benchmark_v2.gpu_models import FIXED_HYPERPARAMETERS, XGBContext  # noqa: E402
from agriformulations.benchmark_v2.io_utils import load_study, verify_study_sources  # noqa: E402
from agriformulations.benchmark_v2.manifest import (  # noqa: E402
    freeze_execution_manifest,
    verify_inputs,
)
from agriformulations.benchmark_v2.report import render_report  # noqa: E402
from agriformulations.benchmark_v2.transfer import recipe_endpoint_pilot, run_transfer_track  # noqa: E402

STUDY_ORDER = ("herbicide", "crop", "fertilizer")
PLATEAU_BOUNDS = {"herbicide": 1000.0, "crop": None, "fertilizer": None}


def _device_record(requested: str) -> dict:
    record = {"requested": requested, "resolved": "cpu", "gpu_name": None, "dtype": "float64"}
    try:
        import torch

        record["torch_version"] = torch.__version__
        if requested == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("explicit --device cuda requested but CUDA is unavailable")
        if requested in ("auto", "cuda") and torch.cuda.is_available():
            record["resolved"] = "cuda"
            record["gpu_name"] = torch.cuda.get_device_name(0)
    except ImportError:
        record["torch_version"] = None
    try:
        import xgboost

        record["xgboost_version"] = xgboost.__version__
    except ImportError:
        record["xgboost_version"] = None
    return record


def _plots(forecast_predictions, transfer_predictions, physics, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    studies = sorted(forecast_predictions["study_id"].unique())
    fig, axes = plt.subplots(1, len(studies), figsize=(5.2 * len(studies), 4.0), constrained_layout=True)
    for ax, study_id in zip(np.atleast_1d(axes), studies):
        block = forecast_predictions[forecast_predictions["study_id"] == study_id]
        curves = sorted(block["curve_id"].unique())
        pivot = (
            block[block["model"] == "selected_candidate"].groupby("curve_id")[["observed", "predicted"]]
            .apply(lambda g: float(np.mean(np.abs(g["predicted"] - g["observed"]))))
        )
        curve = pivot.idxmax() if len(pivot) else curves[0]
        rows = block[block["curve_id"] == curve]
        observed = rows.groupby("time")["observed"].first()
        selected_model = "selected_candidate"
        ax.plot(observed.index, observed.values, "o", color="#18352b", label="observed", ms=5)
        for model, color, style in (
            (selected_model, "#679448", "-"),
            ("last_observed_baseline", "#b8860b", "--"),
            ("xgboost_fixed", "#4169b1", ":"),
        ):
            sub = rows[rows["model"] == model]
            if sub.empty:
                continue
            ax.plot(sub["time"], sub["predicted"], style, color=color, label=model, lw=1.8)
        cutoff = rows["time"].min()
        ax.axvline(cutoff, color="#999999", lw=0.8, ls="-.")
        ax.set_title(f"{study_id}\n{curve}", fontsize=9)
        ax.set_xlabel(f"time [{rows['time_unit'].iloc[0]}]")
        ax.set_ylabel(f"release [{rows['unit'].iloc[0]}]")
        ax.legend(fontsize=7)
    fig.suptitle("Held-out forecasts (test block right of the dotted line)", fontsize=11)
    fig.savefig(out_dir / "v2_forecast_example.png", dpi=160)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2), constrained_layout=True)
    for ax, model in zip(axes, ("last_observed_baseline", "xgboost_fixed")):
        for study_id, marker in zip(studies, "os^"):
            rows = transfer_predictions[
                (transfer_predictions["study_id"] == study_id)
                & (transfer_predictions["model"].str.contains("baseline" if model == "last_observed_baseline" else "xgboost"))
            ] if not transfer_predictions.empty else pd.DataFrame()
            if rows.empty:
                continue
            ax.scatter(rows["observed"], rows["predicted"], s=12, alpha=0.55, marker=marker, label=study_id)
        lim = [0, 0]
        if not transfer_predictions.empty:
            stack = np.concatenate([transfer_predictions["observed"], transfer_predictions["predicted"]])
            lim = [float(stack.min()), float(stack.max())]
        ax.plot(lim, lim, color="#999999", lw=0.8)
        ax.set_title("matched-time-mean baseline" if "baseline" in model else "xgboost_fixed", fontsize=10)
        ax.set_xlabel("observed")
        ax.set_ylabel("predicted")
        ax.legend(fontsize=7)
    fig.suptitle("Transfer track: held-out conditions/formulations", fontsize=11)
    fig.savefig(out_dir / "v2_transfer_predictions.png", dpi=160)
    plt.close(fig)

    keys = [k for k, v in physics["sweeps"].items() if len(v["rate_grid_h_inverse"])]
    fig, axes = plt.subplots(1, max(len(keys), 1), figsize=(5.0 * max(len(keys), 1), 3.8), constrained_layout=True)
    for ax, key in zip(np.atleast_1d(axes), keys):
        sweep = physics["sweeps"][key]
        rates = sweep["rate_grid_h_inverse"]
        calibration = [
            row["rate_h_inverse"]
            for row in physics["calibration"]
            if row["study_id"] == sweep["study_id"]
        ]
        ax.semilogx(rates, 100.0 * sweep["released_fraction_end"], color="#679448", lw=1.8)
        if calibration:
            ax.axvspan(min(calibration), max(calibration), color="#dbe4da", alpha=0.8, zorder=0)
        ax.set_title(f"{sweep['study_id']} (t={sweep['end_time_native']:g})", fontsize=9)
        ax.set_xlabel("effective D/R$^2$ [1/time]")
        ax.set_ylabel("released fraction at end time [%]")
    if not keys:
        np.atleast_1d(axes)[0].text(0.5, 0.5, "GPU physics legs skipped (--skip-gpu)", ha="center", va="center")
        np.atleast_1d(axes)[0].set_axis_off()
    fig.suptitle("Synthetic rate-sensitivity sweep (calibrated ranges shaded)", fontsize=11)
    fig.savefig(out_dir / "v2_physics_sweep.png", dpi=160)
    plt.close(fig)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--studies", default=",".join(STUDY_ORDER))
    parser.add_argument("--skip-gpu", action="store_true", help="skip XGBoost comparator and GPU physics legs")
    args = parser.parse_args(argv)
    started = time.perf_counter()

    study_keys = [s for s in args.studies.split(",") if s]
    OUT.mkdir(parents=True, exist_ok=True)

    # 1. Ensure the fertilizer extraction exists (idempotent, hash-checked).
    if "fertilizer" in study_keys and not (REPO / "data/v2/fertilizer/study.json").exists():
        print("[1/8] fertilizer extraction missing; running research/v2_fertilizer/extract.py")
        runpy.run_path(str(REPO / "research/v2_fertilizer/extract.py"), run_name="__main__")

    # 2. Load studies and verify raw source hashes before anything else.
    studies = {}
    for key in study_keys:
        study = load_study(key)
        records = verify_study_sources(study)
        studies[key] = study
        print(f"[2/8] {key}: sources verified ({len(records)} hashes) — {study['meta']['study_id']}")

    # 3. Freeze the execution manifest BEFORE any fitting.
    device = _device_record(args.device)
    manifest_extra = {
        "device": device,
        "xgboost": {
            "hyperparameters": dict(FIXED_HYPERPARAMETERS),
            "role": "exploratory_within_study_comparator",
            "hyperparameter_search": "none",
            "missing_values": "native_nan_no_imputation",
        },
        "per_study": {
            key: {"plateau_bound": PLATEAU_BOUNDS.get(key)} for key in study_keys
        },
    }
    manifest = freeze_execution_manifest(OUT / "execution_manifest.json", device=args.device, extra=manifest_extra)
    verify_inputs(manifest)
    print(f"[3/8] execution manifest frozen and verified ({len(manifest['inputs'])} inputs, device={device['resolved']})")

    # 4. Forecast track.
    forecast_results = {}
    xgb_records = {}
    for key in study_keys:
        xgb = None if args.skip_gpu else XGBContext(device=args.device)
        forecast_results[key] = run_forecast_track(
            studies[key], plateau_bound=PLATEAU_BOUNDS.get(key), xgb=xgb
        )
        if xgb is not None and not forecast_results[key]["predictions"].empty:
            xgb_records[key] = dict(xgb.metadata)
            xgb_records[key]["prediction_agreement"] = None
        n = 0 if forecast_results[key]["folds"].empty else int((forecast_results[key]["folds"]["status"] == "selected").sum())
        print(f"[4/8] forecast {key}: {n} curves selected a parametric/naive candidate")

    # 5. Claims audit with forecast predictions attached.
    audits = []
    for key in study_keys:
        predictions = forecast_results[key]["predictions"]
        audits.append(audit_study(studies[key], forecast_predictions=predictions))
    audit = pd.concat(audits, ignore_index=True) if audits else pd.DataFrame()
    audit.to_csv(OUT / "v2_claims_audit.csv", index=False)
    verdict_counts = audit["verdict"].value_counts().to_dict() if not audit.empty else {}
    print(f"[5/8] claims audit: {verdict_counts}")

    # 6. Transfer track (+ crop recipe-endpoint pilot).
    transfer_results = {}
    for key in study_keys:
        factory = (lambda: XGBContext(device=args.device)) if not args.skip_gpu else None
        transfer_results[key] = run_transfer_track(studies[key], xgb_factory=factory)
        executed = 0 if transfer_results[key]["folds"].empty else int((transfer_results[key]["folds"]["status"] == "executed").sum())
        print(f"[6/8] transfer {key}: {executed} folds executed")
    recipe_pilot = recipe_endpoint_pilot(studies["crop"]) if "crop" in studies else None

    # 7. GPU physics legs.
    gpu_record = {"device": device}
    if not args.skip_gpu:
        gpu_record["verify"] = verify_fv(device=args.device)
        physics, verification = calibration_sweep(studies, device=args.device)
        gpu_record["verification"] = verification
        print(
            f"[7/8] GPU physics: mass_balance={verification['fv_subset_shells80']['mass_balance_error']:.2e}, "
            f"fv_vs_analytic={verification['fv_subset_vs_analytic_max_abs']:.2e}, "
            f"mesh={gpu_record['verify']['mesh_errors_vs_analytic']}"
        )
    else:
        physics = {"calibration": [], "sweeps": {}}
        print("[7/8] GPU physics skipped (--skip-gpu)")

    # 8. Exports, plots and report.
    forecast_folds = pd.concat([r["folds"] for r in forecast_results.values() if not r["folds"].empty], ignore_index=True)
    forecast_predictions = pd.concat([r["predictions"] for r in forecast_results.values() if not r["predictions"].empty], ignore_index=True)
    forecast_summary = pd.concat([r["summary"] for r in forecast_results.values() if r["summary"] is not None and not r["summary"].empty], ignore_index=True)
    forecast_selections = pd.concat([r["selection_frequency"] for r in forecast_results.values() if not r["selection_frequency"].empty], ignore_index=True)
    forecast_utility = {studies[k]["meta"]["study_id"]: v["utility"] for k, v in forecast_results.items()}

    transfer_folds = pd.concat([r["folds"] for r in transfer_results.values() if not r["folds"].empty], ignore_index=True)
    transfer_predictions = pd.concat([r["predictions"] for r in transfer_results.values() if not r["predictions"].empty], ignore_index=True)
    transfer_summary = pd.concat([r["summary"] for r in transfer_results.values() if r["summary"] is not None and not r["summary"].empty], ignore_index=True)
    transfer_utility = {studies[k]["meta"]["study_id"]: v["utility"] for k, v in transfer_results.items()}

    physics_calibration = pd.DataFrame(physics["calibration"])
    forecast_folds.to_csv(OUT / "v2_forecast_folds.csv", index=False)
    forecast_predictions.to_csv(OUT / "v2_forecast_predictions.csv", index=False)
    forecast_summary.to_csv(OUT / "v2_forecast_summary.csv", index=False)
    if not forecast_selections.empty:
        forecast_selections.to_csv(OUT / "v2_forecast_selections.csv", index=False)
    transfer_folds.to_csv(OUT / "v2_transfer_folds.csv", index=False)
    if not transfer_predictions.empty:
        transfer_predictions.to_csv(OUT / "v2_transfer_predictions.csv", index=False)
    if transfer_summary is not None and not transfer_summary.empty:
        transfer_summary.to_csv(OUT / "v2_transfer_summary.csv", index=False)
    if recipe_pilot is not None and not recipe_pilot.empty:
        recipe_pilot.to_csv(OUT / "v2_recipe_endpoint_pilot.csv", index=False)
    if not physics_calibration.empty:
        physics_calibration.to_csv(OUT / "v2_physics_calibration.csv", index=False)
    sweep_rows = []
    for key, sweep in physics["sweeps"].items():
        for rate, fraction in zip(sweep["rate_grid_h_inverse"], sweep["released_fraction_end"]):
            sweep_rows.append(
                {"study_id": sweep["study_id"], "rate_h_inverse": rate, "end_time": sweep["end_time_native"], "released_fraction": fraction}
            )
    if sweep_rows:
        pd.DataFrame(sweep_rows).to_csv(OUT / "v2_physics_sweep.csv", index=False)
    gpu_record["xgboost_records"] = xgb_records
    gpu_record["wall_s_total"] = round(time.perf_counter() - started, 2)
    with open(OUT / "v2_gpu_execution.json", "w") as handle:
        json.dump(gpu_record, handle, indent=1, default=float)

    _plots(forecast_predictions, transfer_predictions, physics, OUT)
    report = render_report(
        OUT,
        manifest=manifest,
        studies=studies,
        audit=audit,
        forecast_folds=forecast_folds,
        forecast_summary=forecast_summary,
        forecast_selections=forecast_selections,
        forecast_utility=forecast_utility,
        transfer_folds=transfer_folds,
        transfer_summary=transfer_summary,
        transfer_utility=transfer_utility,
        recipe_pilot=recipe_pilot,
        physics_calibration=physics_calibration,
        gpu_record=gpu_record,
        device=device,
    )
    print(f"[8/8] report rendered: {report} ({gpu_record['wall_s_total']} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
