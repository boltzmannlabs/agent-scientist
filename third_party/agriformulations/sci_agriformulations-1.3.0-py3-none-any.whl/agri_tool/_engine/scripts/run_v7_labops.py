"""One reproducible command for the lab-operations phase (docs/v7_protocol.md).

Batch-verdict dry run on a declared synthetic batch, Arrhenius fitting
(synthetic gate + catalog fit), the composition-bridge machinery with its
honest overlap report, protocol matching, and the dossier export.

    python3 -m scripts.run_v7_labops
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v7"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.catalog import load_catalog  # noqa: E402
from agriformulations.labops.arrhenius import fit_arrhenius, rate_at_temperature, synthetic_recovery  # noqa: E402
from agriformulations.labops.composition import composition_features, synthetic_demo  # noqa: E402
from agriformulations.labops.dossier import export_dossier  # noqa: E402
from agriformulations.labops.protocol_match import match_protocols  # noqa: E402
from agriformulations.labops.specs import (  # noqa: E402
    ProductSpec,
    drift_control,
    forecast_endpoint,
    spec_verdict,
)
from agriformulations.protocol_registry import AssayProtocol, protocol_from_dict  # noqa: E402
from agriformulations.release import release_fraction  # noqa: E402


def _synthetic_batch(seed: int = 11, rate: float = 0.02, plateau: float = 0.78) -> pd.DataFrame:
    """Declared synthetic batch (never mixed with measured data)."""
    rng = np.random.default_rng(seed)
    times = np.array([0.0, 4.0, 8.0, 16.0, 24.0, 48.0, 72.0, 96.0])
    values = plateau * np.array([release_fraction(float(t), "spherical_diffusion", {"rate": rate}) for t in times])
    values = values + 0.004 * rng.normal(size=times.size)
    return pd.DataFrame(
        {
            "study_id": "internal_demo_synthetic",
            "formulation_id": "DEMO_X1",
            "condition_id": "release_assay",
            "curve_id": "internal_demo_synthetic__DEMO_X1__release_assay",
            "time": times,
            "time_unit": "h",
            "value": np.clip(values, 0, 1) * 100.0,
            "unit": "%",
            "ph": 7.0,
            "temperature_c": 25.0,
            "included_primary": True,
            "qc_status": "accepted",
        }
    )


def main(argv=None) -> int:
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    catalog = load_catalog()

    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device="cpu",
        extra={
            "phase": "v7",
            "protocol": {
                "document": "docs/v7_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v7_protocol.md").read_bytes()).hexdigest(),
            },
            "thresholds": {
                "spec_borderline_tolerance_factor": 1.0,
                "drift_control_sigma": 3.0,
                "protocol_transfer_distance": 0.3,
                "protocol_marginal_distance": 0.6,
                "arrhenius_min_temperatures": 2,
            },
        },
    )
    verify_inputs(manifest)
    print(f"[1/6] manifest frozen and verified ({len(manifest['inputs'])} inputs)")

    # 2. Arrhenius: synthetic gate first, then the catalog fit.
    gate = synthetic_recovery()
    if not gate["pass"]:
        raise SystemExit(f"Arrhenius synthetic gate FAILED: {gate}")
    arrhenius_rows = []
    from agriformulations.benchmark_v2.io_utils import load_study

    crop = load_study("crop")
    fig3a = crop["observations"][crop["observations"]["condition_id"].str.startswith("Figure_3a")].copy()
    fit = fit_arrhenius(fig3a, replicates=crop.get("release_replicates"))
    arrhenius_rows.append(
        {
            "formulation": "TEB_NPs (Tang 2023, Fig 3a, pH 6)",
            **{k: fit.get(k) for k in ("n_temperatures", "temperatures_c", "ea_kj_mol", "weakly_identified", "residual_rms_log")},
            "ea_ci_kj_mol": str(fit.get("ea_ci_kj_mol")),
            "rate_at_35C": rate_at_temperature(fit, 35.0),
            "rate_at_45C": rate_at_temperature(fit, 45.0),
        }
    )
    arrhenius_frame = pd.DataFrame(arrhenius_rows)
    arrhenius_frame.to_csv(OUT / "v7_arrhenius.csv", index=False)
    print(
        f"[2/6] Arrhenius: synthetic gate PASS (recovered {gate['recovered']:.1f} vs {gate['ea_true']}); "
        f"catalog fit Ea={fit['ea_kj_mol']:.1f} kJ/mol (CI {fit['ea_ci_kj_mol']})"
    )

    # 3. Composition bridge: overlap report + synthetic machinery demo.
    _, overlap = composition_features(catalog)
    demo = synthetic_demo()
    if not (demo["recovery_pass"] and demo["domain_refusal_pass"]):
        raise SystemExit("composition-bridge synthetic demo FAILED")
    with open(OUT / "v7_composition_overlap.json", "w") as handle:
        json.dump({**overlap, "demo": {k: demo[k] for k in ("recovery_pass", "domain_refusal_pass", "n_synthetic_rows", "note")}}, handle, indent=1)
    print(f"[3/6] composition bridge: overlap={overlap}; machinery demo PASS (synthetic only)")

    # 4. Batch-verdict dry run on the declared synthetic batch.
    spec = ProductSpec(
        product_id="DEMO_X",
        endpoint_time=96.0,
        time_unit="h",
        unit="%",
        window=(60.0, 85.0),
        tolerance=2.5,
        reference_batches=("synthetic_ref_1", "synthetic_ref_2", "synthetic_ref_3"),
        min_forecast_times=5,
    )
    batch = _synthetic_batch()
    reference_frames = {
        f"synthetic_ref_{i}": _synthetic_batch(seed=20 + i, rate=0.02 * (1 + 0.04 * (i - 1)))
        for i in (1, 2, 3)
    }
    forecast = forecast_endpoint(batch[batch["time"] <= 48.0], spec)
    observed_endpoint = float(batch.loc[batch["time"] == spec.endpoint_time, "value"].iloc[0])
    verdict = spec_verdict(forecast.get("forecast"), observed_endpoint, spec)
    drift = drift_control(batch, reference_frames, spec.unit)
    verdict_record = {
        "product": spec.product_id,
        "batch": "internal_demo_synthetic (SYNTHETIC dry run)",
        "forecast_candidate": forecast.get("candidate"),
        "forecast_endpoint": forecast.get("forecast"),
        "observed_endpoint": observed_endpoint,
        "window": list(spec.window),
        "verdict": verdict["verdict"],
        "in_control": drift["in_control"],
        "rate_zscore": drift["rate_zscore"],
        "endpoint_zscore": drift["endpoint_zscore"],
    }
    with open(OUT / "v7_batch_verdict.json", "w") as handle:
        json.dump(verdict_record, handle, indent=1)
    print(f"[4/6] batch verdict dry run: {verdict['verdict']} (forecast {forecast.get('forecast'):.1f}% vs observed {observed_endpoint:.1f}%), in-control={drift['in_control']}")

    # 5. Protocol matching for the demo batch's assay.
    query = AssayProtocol(
        protocol_id="demo_batch_assay",
        assay_type="immersion_release",
        target="cumulative_release",
        unit="%",
        time_unit="h",
        medium="water",
        temperature_c=25.0,
        ph=7.0,
        sink_condition="unknown",
    )
    catalog_protocols = {}
    for key, entry in catalog.studies.items():
        for record in entry["meta"].get("protocols", []):
            catalog_protocols[key] = protocol_from_dict(record)
    matches = match_protocols(query, catalog_protocols)
    matches.to_csv(OUT / "v7_protocol_matches.csv", index=False)
    print(f"[5/6] protocol matching: {int((matches['transfer'] == 'yes').sum())} transfer, "
          f"{int((matches['transfer'] == 'marginal').sum())} marginal, {int((matches['transfer'] == 'no').sum())} no")

    # 6. Dossier export + report.
    dossier = export_dossier(OUT / "v7_audit_dossier.zip")
    print(f"[6/6] dossier: {dossier.name} ({dossier.stat().st_size // 1024} KB)")

    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v7 lab operations</title>
<style>{STYLE}</style></head><body>
<h1>Lab operations, version 7</h1>
<p>Frozen protocol <code>docs/v7_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen before any fit.</p>
<div class="note"><strong>Outcome.</strong> Arrhenius machinery passes its synthetic gate
(recovered {gate['recovered']:.1f} kJ/mol vs {gate['ea_true']:.0f} true) and delivers the first
catalog result: Tang 2023 TEB release carries Ea = {fit['ea_kj_mol']:.1f} kJ/mol
(bootstrap CI {fit['ea_ci_kj_mol']}). The batch-verdict workflow runs end-to-end on a
declared SYNTHETIC batch ({verdict['verdict']}); the composition bridge's honest overlap
report shows zero formulations with both measured fractions and curves - internal batches
with recorded composition are the unlock. The standing not-comparable register is unchanged.</div>
<h2>1. Arrhenius temperature dependence</h2>
{_table(arrhenius_frame)}
<p>Synthetic gate passed before any catalog output was used; extrapolation outside the
fitted range is refused by construction.</p>
<h2>2. Composition-bridge status</h2>
<p>Overlap report: {overlap}. Machinery verified on synthetic data (recovery and domain
refusal both pass); training on published fit parameters remains forbidden.</p>
<h2>3. Batch verdict (synthetic dry run)</h2>
{_table(pd.DataFrame([verdict_record]))}
<p>The dry run exercises the exact code path a real batch will take: adapter ingest ->
early-time forecast with inner-split selection -> spec comparison -> drift control limits.</p>
<h2>4. Protocol matching</h2>
{_table(matches)}
<h2>5. Dossier</h2>
<p><a href="v7_audit_dossier.zip">v7_audit_dossier.zip</a>: provenance chain, claims audits,
manifests, gates, agent-log chain verification, not-comparable register.</p>
<h2>6. Interpretation and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v7_labops</code>. All synthetic artefacts are
labelled synthetic and never enter the catalog. GUI work is deferred by decision.</p>
</body></html>"""
    report = OUT / "v7_labops.html"
    report.write_text(html)
    print(f"[6/6] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
