"""Reproduce release data and evaluate constrained, ML, and diffusion models.
Run from checkout: python3 -m scripts.run_case_study
"""
from pathlib import Path
import os, sys, json, hashlib, platform, importlib.metadata, html
os.environ.setdefault("MPLCONFIGDIR", "/tmp/agriformulations-matplotlib")
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
sys.path.insert(0,str(ROOT/".deps"))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.exceptions import ConvergenceWarning
import warnings
from agriformulations import fit_release, release_fraction, sphere_finite_volume
warnings.filterwarnings("ignore", category=ConvergenceWarning)
OUT=ROOT/"reports"
SEED=271828

def metric(y,p):
    y,p=np.asarray(y),np.asarray(p)
    error=p-y
    return {"mae_pp":float(np.mean(abs(error))*100),
            "rmse_pp":float(np.sqrt(np.mean(error**2))*100),
            "r2":float(1-np.sum(error**2)/np.sum((y-y.mean())**2)) if np.ptp(y)>1e-12 else None}

def load():
    f=pd.read_csv(ROOT/"data/curated/fertilizer_2026_release.csv")
    f["curve_id"]="fertilizer_2026_"+f.active
    f["ph"]=np.nan
    a=pd.read_csv(ROOT/"data/curated/azadirachtin_2025_release.csv")
    a["study"]="azadirachtin_2025"
    a["evidence_kind"]="published_measured"
    a["active"]="azadirachtin"
    a["curve_id"]="aza_"+a.formulation.str.replace(" ","_")+"_pH"+a.ph.astype(str)
    return pd.concat([f,a],ignore_index=True).assign(release_fraction=lambda d:d.release_pct/100)

def kinetic_benchmark(df):
    summaries,predictions,fit_objects=[],[],{}
    models=["first_order","burst_first_order","weibull","higuchi","korsmeyer_peppas","spherical_diffusion"]
    for curve,g in df.groupby("curve_id",sort=True):
        g=g.sort_values("time_h")
        t=g.time_h.to_numpy(); y=g.release_fraction.to_numpy()
        ntrain=len(g)-3
        baseline=np.repeat(y[ntrain-1],len(y))
        mask=np.arange(len(y))>=ntrain
        summaries.append(dict(curve_id=curve,model="last_observed_baseline",split="future_holdout",
            n_train=ntrain,n_eval=int(mask.sum()),train_cutoff_h=float(t[ntrain-1]),
            parameters="{}",status="ok",**metric(y[mask],baseline[mask])))
        for i in np.flatnonzero(mask):
            predictions.append(dict(curve_id=curve,model="last_observed_baseline",split="future_holdout",
                time_h=float(t[i]),observed_fraction=float(y[i]),predicted_fraction=float(baseline[i]),
                evaluation_point=True,time_extrapolation=True))
        for model in models:
            for split,n in [("full_fit",len(g)),("future_holdout",ntrain)]:
                try:
                    fit=fit_release(t[:n],y[:n],model)
                    if not fit.success: raise RuntimeError(fit.message)
                    pred=fit.predict(t)
                    # Full-fit metric is on exactly the model fitting subset.
                    eligible=(y<=0.6) if model=="korsmeyer_peppas" else np.ones(len(y),dtype=bool)
                    mask=eligible if split=="full_fit" else np.arange(len(y))>=n
                    scores=metric(y[mask],pred[mask])
                    summaries.append(dict(curve_id=curve,model=model,split=split,
                        n_train=fit.n_points,n_eval=int(mask.sum()),
                        train_cutoff_h=float(t[n-1]),parameters=json.dumps(fit.parameters),
                        status="ok",**scores))
                    fit_objects[(curve,model,split)]=fit
                    for i,row in enumerate(g.itertuples()):
                        predictions.append(dict(curve_id=curve,model=model,split=split,
                            time_h=float(t[i]),observed_fraction=float(y[i]),predicted_fraction=float(pred[i]),
                            evaluation_point=bool(mask[i]),time_extrapolation=bool(i>=n)))
                except (ValueError,RuntimeError) as e:
                    summaries.append(dict(curve_id=curve,model=model,split=split,status="unfit",reason=str(e)))
    return pd.DataFrame(summaries),pd.DataFrame(predictions),fit_objects

def ml_benchmark(df):
    a=df[df.study=="azadirachtin_2025"].copy()
    a["carrier_AT"]=(a.formulation=="AT NPs").astype(float)
    X=a[["time_h","ph","carrier_AT"]].copy()
    X["time_h"]=np.log1p(X.time_h)
    y=a.release_fraction.to_numpy()
    scores,rows=[],[]
    for ph in sorted(a.ph.unique()):
        train=(a.ph!=ph).to_numpy(); test=~train
        models={
            "extra_trees":ExtraTreesRegressor(n_estimators=300,min_samples_leaf=2,random_state=SEED,n_jobs=1),
            "gaussian_process":make_pipeline(StandardScaler(),GaussianProcessRegressor(
                kernel=ConstantKernel(0.2,(1e-3,10))*RBF([1,1,1],(0.05,20))+WhiteKernel(0.005,(1e-5,0.1)),
                normalize_y=True,n_restarts_optimizer=2,random_state=SEED)),
            # A meaningful null: average available pH curves at same carrier/time.
            "matched_time_carrier_mean":None}
        for name,model in models.items():
            if model is None:
                lookup=a.loc[train].groupby(["formulation","time_h"]).release_fraction.mean()
                pred=np.array([lookup.loc[(r.formulation,r.time_h)] for r in a.loc[test].itertuples()])
            else:
                model.fit(X.loc[train],y[train])
                pred=model.predict(X.loc[test])
            raw=pred.copy(); pred=np.clip(pred,0,1)
            scores.append(dict(model=name,heldout_ph=float(ph),n_train=int(train.sum()),n_test=int(test.sum()),
                validation="leave_one_pH_out_both_carriers",**metric(y[test],pred),
                raw_out_of_bounds=int(np.sum((raw<0)|(raw>1)))))
            for row,p,r in zip(a.loc[test].itertuples(),pred,raw):
                rows.append(dict(model=name,heldout_ph=float(ph),curve_id=row.curve_id,time_h=row.time_h,
                    observed_fraction=row.release_fraction,predicted_fraction=float(p),raw_prediction=float(r)))
    return pd.DataFrame(scores),pd.DataFrame(rows)

def physics(df,fits):
    rows,sensitivity=[],[]
    targets=[c for c in sorted(df.curve_id.unique()) if c.startswith("fertilizer")]
    fig,axes=plt.subplots(1,2,figsize=(12,4.2),constrained_layout=True)
    for ax,curve in zip(axes,targets):
        g=df[df.curve_id==curve].sort_values("time_h")
        fit=fits[(curve,"spherical_diffusion","full_fit")]
        rate=fit.parameters["rate"]
        t=np.linspace(0,g.time_h.max(),200)
        analytic=release_fraction(t,"spherical_diffusion",{"rate":rate})
        for shells in (20,40,80):
            fv=sphere_finite_volume(t,rate,shells=shells)
            rows.append(dict(curve_id=curve,shells=shells,rate_h_inverse=rate,
                max_abs_difference_pp=float(np.max(abs(fv-analytic))*100),
                monotonic=bool(np.all(np.diff(fv)>=-1e-8)),bounded=bool(np.all((fv>=0)&(fv<=1)))))
        ax.scatter(g.time_h/24,g.release_pct,label="Published means",color="#202020",s=25,zorder=4)
        ax.plot(t/24,analytic*100,label="Calibrated ideal sphere",color="#2274a5")
        for factor in (0.5,0.75,1,1.25,1.5,2):
            scaled=rate/factor**2
            p=release_fraction(t,"spherical_diffusion",{"rate":scaled})
            # Rref=2.5 mm is approximate published radius, D effective not measured.
            sensitivity.append(dict(curve_id=curve,radius_factor=factor,
                radius_mm=2.5*factor,rate_h_inverse=scaled,release_day30_pct=float(p[-1]*100),
                effective_D_m2_s=rate*(0.0025**2)/3600,
                evidence_kind="synthetic"))
            if factor in (0.5,2):
                ax.plot(t/24,p*100,"--",label=f"Assumed radius ×{factor}")
        ax.set(title=curve.replace("fertilizer_2026_",""),xlabel="Time (days)",ylabel="Cumulative release (%)",ylim=(0,105))
        ax.legend(fontsize=8)
    fig.savefig(OUT/"physics_sensitivity.png",dpi=170); plt.close(fig)
    return pd.DataFrame(rows),pd.DataFrame(sensitivity)

def published_fit_audit(df,kin):
    claims=pd.read_csv(ROOT/"data/curated/azadirachtin_2025_reported_fits.csv")
    rows=[]
    for row in claims[claims.model.isin(["first_order","higuchi"])].itertuples():
        curve="aza_"+row.formulation.replace(" ","_")+"_pH"+str(int(row.ph))
        full=kin[(kin.curve_id==curve)&(kin.model==row.model)&(kin.split=="full_fit")&(kin.status=="ok")]
        g=df[df.curve_id==curve]
        x=np.sqrt(g.time_h.to_numpy()) if row.model=="higuchi" else g.time_h.to_numpy()
        y=g.release_fraction.to_numpy()
        alternate=np.polyval(np.polyfit(x,y,1),x) if row.model=="higuchi" else None
        rows.append(dict(curve_id=curve,model=row.model,published_r2=row.reported_r2,
            refit_bounded_fraction_r2=float(full.iloc[0].r2),
            alternate_unbounded_intercept_higuchi_r2=metric(y,alternate)["r2"] if alternate is not None else None,
            source_sheet=row.source_sheet,source_cell=row.source_cell,
            caveat="Different explicit fitting procedure; no claim of exact statistical replication",
            evidence_kind="derived",parent_data="data/curated/azadirachtin_2025_reported_fits.csv;data/curated/azadirachtin_2025_release.csv"))
    return pd.DataFrame(rows)

def bootstrap(df):
    # Conditional endpoint uncertainty only; repeated cumulative observations are not resampled as independent.
    a=df[df.study=="azadirachtin_2025"]
    rng=np.random.default_rng(SEED); rows=[]
    for curve,g in a.groupby("curve_id"):
        r=g.sort_values("time_h").iloc[-1]
        values=np.array([r[f"replicate_{i}_pct"] for i in (1,2,3)],float)
        means=rng.choice(values,size=(5000,3),replace=True).mean(axis=1)
        rows.append(dict(curve_id=curve,time_h=float(r.time_h),source_mean_pct=float(r.release_pct),
            recomputed_mean_pct=float(values.mean()),bootstrap_low_pct=float(np.quantile(means,0.025)),
            bootstrap_high_pct=float(np.quantile(means,0.975)),
            caveat="Illustrative percentile bootstrap of three endpoint replicates; weak coverage, no cross-study uncertainty"))
    return pd.DataFrame(rows)

def plots(df,fits,mlpred):
    curves=sorted(df.curve_id.unique())
    fig,axes=plt.subplots(2,4,figsize=(16,7),constrained_layout=True)
    colors={"first_order":"#d17d27","weibull":"#2c7a55","spherical_diffusion":"#2274a5"}
    for ax,curve in zip(axes.flat,curves):
        g=df[df.curve_id==curve].sort_values("time_h"); scale=24 if curve.startswith("fertilizer") else 1
        t=np.linspace(0,g.time_h.max(),250)
        ax.scatter(g.time_h/scale,g.release_pct,s=20,color="#222222",label="Published means",zorder=4)
        err=g.sd_pct if curve.startswith("fertilizer") else g.se_pct
        ax.errorbar(g.time_h/scale,g.release_pct,yerr=err,fmt="none",color="#777777",alpha=.5)
        for model,color in colors.items():
            fit=fits.get((curve,model,"full_fit"))
            if fit: ax.plot(t/scale,100*fit.predict(t),color=color,label=model)
        cutoff=g.time_h.iloc[len(g)-4]/scale
        ax.axvline(cutoff,color="#777777",ls=":",label="Forecast training cutoff")
        ax.set(title=curve,ylim=(0,105),xlabel="Time (days)" if scale==24 else "Time (hours)",ylabel="Release (%)")
    handles,labels=axes.flat[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="outside lower center",ncol=5,fontsize=9)
    fig.savefig(OUT/"release_models.png",dpi=160); plt.close(fig)
    fig,ax=plt.subplots(figsize=(6,5),constrained_layout=True)
    for name,g in mlpred.groupby("model"):
        ax.scatter(g.observed_fraction*100,g.predicted_fraction*100,label=name,alpha=.7,s=25)
    ax.plot([0,100],[0,100],"--",color="#777777")
    ax.set(xlabel="Published withheld release (%)",ylabel="Predicted release (%)",title="Leave one pH out: both carriers withheld",xlim=(0,105),ylim=(0,105))
    ax.legend(fontsize=8);fig.savefig(OUT/"ml_validation.png",dpi=170);plt.close(fig)

def report(df,kin,ml,phys,sensitivity,endpoint,audit):
    forecast=kin[(kin.split=="future_holdout")&(kin.status=="ok")]
    summary=forecast.groupby("model").agg(mae_pp=("mae_pp","mean"),rmse_pp=("rmse_pp","mean"),successful_curves=("curve_id","count")).sort_values("mae_pp").reset_index()
    mlsum=ml.groupby("model")[["mae_pp","rmse_pp"]].mean().sort_values("mae_pp").reset_index()
    source_a="https://www.nature.com/articles/s41467-025-57028-w"
    source_f="https://www.nature.com/articles/s41467-026-68295-6"
    def table(x): return x.to_html(index=False,float_format=lambda x:f"{x:.4g}",border=0)
    fertfit=kin[(kin.curve_id.str.startswith("fertilizer"))&(kin.model=="weibull")&(kin.split=="full_fit")][["curve_id","mae_pp","rmse_pp","r2"]]
    fends=df[(df.study=="fertilizer_2026")&(df.time_h==720)][["active","release_pct"]]
    af=endpoint[["curve_id","source_mean_pct","bootstrap_low_pct","bootstrap_high_pct"]]
    doc=f"""<!doctype html><html lang="en"><meta charset="utf-8"><title>Agri-formulations computational replication</title>
<style>body{{font:16px/1.6 system-ui,sans-serif;max-width:1160px;margin:40px auto;padding:0 24px;color:#173329;background:#f8faf7}}h1,h2{{line-height:1.2}}h2{{margin-top:42px}}table{{border-collapse:collapse;max-width:100%;font-size:14px;background:white}}td,th{{border-bottom:1px solid #dbe4da;padding:7px 11px;text-align:left}}img{{width:100%;background:white}}a{{color:#126a52}}.note{{padding:16px;background:#e7efdf;border-left:4px solid #679448}}code{{background:#e8eee7;padding:2px 5px}}</style>
<h1>Agri-formulation library: computational replication study</h1>
<p><a href="paper_benchmark.html">Direct benchmark against published paper equations, fit statistics, and half-lives</a></p>
<p>Run date: 2026-10-19. Seed: {SEED}. Scope: fertilizer and crop-protection controlled release. 
This is a retrospective reproduction and prediction benchmark using published numerical data. No wet-lab experiments were performed.</p>
<div class="note">A fitted curve reproduces a dataset under its conditions. It does not establish crop performance, pest mortality, environmental safety, manufacture reproducibility, or field effectiveness.</div>
<h2>1. Evidence and case selection</h2>
<p>The workspace contains {len(df)} published mean observations in eight release curves: 19 fertilizer means and 54 biopesticide means (162 underlying biopesticide replicate entries). The 2024 herbicide archive adds 272 usable observations in 18 native mg/g curves; it is not pooled with fractional-release measurements.</p>
<p><a href="{source_f}">Zhu et al., Nature Communications, 13 January 2026</a>: waste-potato-derived fertilizer product mixed with attapulgite and treated with aminosilicone oil. Approximately 5 mm particles; 30 g tested in 1 L deionized water. We extract FLA and potassium release means/SD from the supplied workbook. The full chemical conversion process is outside this model.</p>
<p><a href="{source_a}">Zhang et al., Nature Communications, 18 February 2025</a>: azadirachtin assembled with tannic acid (AT) or phenylalanine (AP), tested at pH 5, 7, and 9, 25°C. We retain the reported means, triplicate values, and workbook error columns separately.</p>
<p>These are recent accessible primary studies selected for numerical source data, not a claim to have found the newest paper in the entire field. Search candidates and selection rationale are in <a href="../research/search_log.md">the search log</a>. Original files, hashes, source cells, units, and extraction scripts are retained.</p>
<h2>2. What was replicated</h2>
<p>Direct extraction reproduces the supplied workbooks without graph digitization, smoothing, or invented data. 
The fertilizer workbook has 100% release for both analytes at day 30; its values close to 98.15% FLA and 97.7% K+ occur at day 25. Article prose places those values at day 30. We preserve that discrepancy rather than move data points.</p>
{table(fends)}
<p>For azadirachtin, the acidic endpoint prose differs from the workbook; our analysis uses the workbook. Its reported error column also does not generally equal standard error recomputed from the three supplied replicates. We retain both. Reported model R² values are comparison targets; they are not our validation scores.</p>
<p>All numerical outputs from our models are marked derived; hypothetical radius changes are synthetic scenarios. The original observations remain published measurements.</p>
<p>Independent Weibull calibration to the two fertilizer curves gives the following approximate reconstruction errors. These are fits to the observed curves, not held-out performance.</p>
{table(fertfit)}
<p>AZA published fit statistics are audited under explicitly stated alternative procedures below. The unbounded-intercept Higuchi column is a diagnostic ordinary linear regression of release against square-root time; it is distinct from the bounded zero-intercept library model. Differences can reflect fitting convention and also reveal unresolved source inconsistencies. We did not reproduce all published fit claims.</p>
{table(audit[["curve_id","model","published_r2","refit_bounded_fraction_r2","alternate_unbounded_intercept_higuchi_r2"]])}
<h2>3. Kinetic models and forecasting protocol</h2>
<p>We fit first-order, a first-order model with an initial burst, Weibull, Higuchi, early-stage Korsmeyer–Peppas, and ideal spherical diffusion using bounded nonlinear least squares on fractional release. Time is in hours. Peppas uses only observed fractions at or below 0.6. Higuchi and Peppas are clipped at exhaustion for numerical boundedness; late-time use is a stress test beyond their usual early-stage domain.</p>
<p>For each curve we reserve the last approximately 30% of times (three points) and fit the first seven of ten or first six of nine. Holdout points and predictions are exported. These are future-time predictions for an already observed formulation and condition. Full-fit scores use each model’s fitting domain and must not be compared as if they share the same observations. No holdout was used for hyperparameter selection. Some weakly identified Weibull time constants reach their numerical bound; exported parameter values must not be read as independently measured material properties.</p>
<p>Macro-average error across successfully fitted curves (see count; Peppas cannot fit two curves with too few early points), in percentage points. Each model was prespecified; sorting this table is descriptive, not a nested model-selection result.</p>
{table(summary)}
<img src="release_models.png" alt="Published release curves and fitted models">
<p>Every fit parameter, per-curve score, fitting cutoff, and forecast is available in <a href="kinetic_metrics.csv">kinetic_metrics.csv</a> and <a href="kinetic_predictions.csv">kinetic_predictions.csv</a>. The last-observed-release baseline uses no withheld labels. Very negative R² can occur on a nearly flat three-point holdout; absolute percentage-point errors are easier to interpret. A weak forecast is retained; we do not reinterpret a good in-sample fit as evidence of reliable extrapolation.</p>
<h2>4. AI prediction models</h2>
<p>Extra Trees and a Gaussian process use log(1 + time), pH, and a carrier indicator. In each of three folds, all observations for one pH are withheld for both carriers. The remaining two pH values supply training data. A matched-time, matched-carrier mean of available pH curves is the null predictor. Predictions are bounded to [0,1]; raw values and boundary violations are exported.</p>
{table(mlsum)}
<img src="ml_validation.png" alt="Predicted versus published release on withheld pH conditions">
<p>The executed AI models fail to improve on the simple null: mean absolute errors are about 48.9 points for Extra Trees, 39.6 for the Gaussian process, and 32.6 for the null. This is evidence that the present dataset and inputs do not support reliable pH transfer. This is condition transfer within one paper and two known carrier chemistries. pH 7 is interpolation; pH 5 and 9 are extrapolation from the other two values. With only three pH levels, these folds cannot demonstrate generalization to a new formulation, publication, laboratory, or field. Replicates at a time point are kept together. The reported table averages three fold errors rather than treating 162 replicate entries as independent training rows.</p>
<h2>5. Physics simulation and numerical verification</h2>
<p>We solve radial Fickian diffusion in a homogeneous sphere by a conservative finite-volume discretization, with uniform initial loading, fixed radius, constant effective diffusivity, and a perfect sink at the outer surface. An independent analytical series provides a numerical verification target. This does not resolve real coatings, swelling, adsorption, dissolution, or assembly disintegration.</p>
<p>The fitted parameter is D/R² in h⁻¹. Release alone cannot identify D and R separately. Assuming the published approximate 2.5 mm reference radius gives an effective D, not a measured molecular diffusion coefficient. Radius scenarios hold that effective D fixed, so doubling radius quarters D/R². These assumptions are explicitly hypothetical and are not a prediction that a manufactured particle will scale this way.</p>
{table(phys)}
<img src="physics_sensitivity.png" alt="Ideal sphere release and hypothetical radius changes">
<p>Numerical agreement with the analytical solution verifies the solver; agreement with experimental means assesses the simplified model. Those are separate tests. <a href="physics_sensitivity.csv">Scenario values</a> and <a href="physics_verification.csv">solver errors</a> are exported.</p>
<h2>6. Uncertainty and evidence limits</h2>
<p>The following endpoint intervals resample the three supplied azadirachtin endpoint values 5,000 times. They illustrate replicate uncertainty conditional on this dataset; n=3 provides weak interval coverage and excludes laboratory, extraction, model, and formulation variability. Fertilizer replicate trajectories were not supplied, so no replicate bootstrap was invented for that case.</p>
{table(af)}
<p>Neither model is a formulation-composition optimizer. The current evidence varies too few independent chemistries and recipes to learn a defensible composition-to-performance model. The schema records recipe and physicochemical properties for expansion; missing quantities remain missing. Molecular dynamics or DFT would require defined structures, force fields, and validation targets and were not substituted with fabricated simulations.</p>
<h2>7. Reproduction and artifacts</h2>
<p>From the project directory, run <code>python3 -m scripts.run_case_study</code>. 
Use <code>python3 -m scripts.reproduce</code> to validate raw hashes and repeat all extractions before analysis.
Dependencies and versions are in <a href="run_manifest.json">run_manifest.json</a>. 
The workflow runs offline after source downloads. Source-data licences and author credit remain with their respective publications; the software and data are documented separately.</p>
<p>Next evidence needed for composition prediction: independent formulations with measured ingredient fractions, particle size, loading, protocol, and release replicates from multiple papers. Future validation should hold out complete studies and recipe families. No external biological validation is claimed by this computational case study.</p>
</html>"""
    (OUT/"case_study.html").write_text(doc)

def main():
    OUT.mkdir(exist_ok=True)
    df=load()
    if len(df)!=73 or df.curve_id.nunique()!=8: raise ValueError("Unexpected curated data size")
    if not df.release_fraction.between(0,1).all(): raise ValueError("Invalid fractions")
    df.to_csv(OUT/"analysis_observations.csv",index=False)
    kin,pred,fits=kinetic_benchmark(df)
    ml,mlpred=ml_benchmark(df)
    audit=published_fit_audit(df,kin)
    audit.to_csv(OUT/"published_fit_audit.csv",index=False)
    phys,sens=physics(df,fits)
    ends=bootstrap(df)
    for name,frame in [("kinetic_metrics",kin),("kinetic_predictions",pred),("ml_metrics",ml),
        ("ml_predictions",mlpred),("physics_verification",phys),("physics_sensitivity",sens),("endpoint_uncertainty",ends)]:
        frame["evidence_kind"]="synthetic" if name=="physics_sensitivity" else "derived"
        frame["parent_data"]="data/curated/azadirachtin_2025_release.csv" if name.startswith("ml") or name=="endpoint_uncertainty" else ("data/curated/fertilizer_2026_release.csv" if name.startswith("physics") else "data/curated/fertilizer_2026_release.csv;data/curated/azadirachtin_2025_release.csv")
        frame.to_csv(OUT/f"{name}.csv",index=False)
    if not (phys.loc[phys.shells==80,"max_abs_difference_pp"]<0.25).all(): raise RuntimeError("Fine-grid verification tolerance exceeded")
    for _, group in phys.groupby("curve_id"):
        if not np.all(np.diff(group.sort_values("shells").max_abs_difference_pp)<0): raise RuntimeError("Mesh convergence failed")
    plots(df,fits,mlpred)
    report(df,kin,ml,phys,sens,ends,audit)
    paths=list((ROOT/"data/curated").glob("*"))+list((ROOT/"scripts").glob("*.py"))+list((ROOT/"src/agriformulations").glob("*.py"))
    manifest=dict(seed=SEED,python=platform.python_version(),run_date_utc="2026-10-19",
        versions={n:importlib.metadata.version(n) for n in ["numpy","scipy","pandas","scikit-learn","matplotlib","openpyxl","xlrd"]},
        input_and_code_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()},
        mean_observations=len(df),curves=df.curve_id.nunique(),wetlab_performed=False,
        warnings=["Single-study condition transfer, no external validation","Publisher prose/source-data discrepancies preserved"])
    (OUT/"run_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(kin[(kin.split=="future_holdout")&(kin.status=="ok")].groupby("model")[["mae_pp","rmse_pp"]].mean().to_string())
    print(ml.groupby("model")[["mae_pp","rmse_pp"]].mean().to_string())
    print("Report:",OUT/"case_study.html")

if __name__=="__main__": main()
