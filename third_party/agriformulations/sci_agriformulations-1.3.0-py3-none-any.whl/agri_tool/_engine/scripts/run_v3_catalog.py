"""One reproducible command for the v3 formulation catalog (docs/v3_protocol.md).

Runs the idempotent v1->v3 conversions, verifies every registered study's
source hashes, freezes the execution manifest before any analysis, validates
the catalog contract, audits every claim with the v2 verdict engine, computes
the coverage matrix and independent-unit stats, screens the literature queue,
and renders reports/v3/v3_catalog.html.  Catalog problems abort; coverage
gaps and unmet growth targets are exported honestly.

    python3 -m scripts.run_v3_catalog
"""

from __future__ import annotations

import json
import runpy
import sys
import time
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v3"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.benchmark_v2.claims_audit import audit_study  # noqa: E402
from agriformulations.benchmark_v2.io_utils import verify_study_sources  # noqa: E402
from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.catalog import (  # noqa: E402
    catalog_stats,
    coverage_matrix,
    load_catalog,
    validate_catalog,
)

GROWTH_TARGETS = {
    "public_studies": 8,
    "recipes": 40,
    "curves": 150,
    "accepted_rows": 1500,
    "core_coverage": 0.80,
}
CORE_COVERAGE_FIELDS = ("geometry", "mass_fraction", "protocol_block")


def _audit_input(catalog: dict, key: str) -> dict:
    entry = catalog.studies[key]
    study = {
        "study_key": key,
        "meta": entry["meta"],
        "observations": entry["observations"],
        "claims": pd.read_csv(entry["path"] / "claims.csv"),
    }
    replicates = entry["path"] / "release_replicates.csv"
    if replicates.exists():
        study["release_replicates"] = pd.read_csv(replicates)
    photolysis = entry["path"] / "photolysis.csv"
    if photolysis.exists():
        study["photolysis"] = pd.read_csv(photolysis)
    return study


def main() -> int:
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)

    # 1. Idempotent conversions and enrichment.
    runpy.run_path(str(REPO / "research/v3_v1_conversion/convert.py"), run_name="__main__")
    if not (REPO / "data/v3/perera_2026/study.json").exists():
        runpy.run_path(str(REPO / "research/v3_perera_2026/extract.py"), run_name="__main__")
    print("[1/7] v1->v3 conversions, perera extraction and v2 enrichment written")

    # 2. Load the catalog and verify every study's declared source hashes.
    catalog = load_catalog()
    for key in sorted(catalog.studies):
        entry = catalog.studies[key]
        study = _audit_input(catalog, key)
        records = verify_study_sources(study)
        print(f"[2/7] {key}: {len(records)} source hashes verified ({entry['data_source']})")

    # 3. Freeze the execution manifest before any analysis.
    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device="cpu",
        extra={
            "phase": "v3",
            "protocol": {
                "document": "docs/v3_protocol.md",
                "sha256": __import__("hashlib").sha256((REPO / "docs/v3_protocol.md").read_bytes()).hexdigest(),
            },
            "growth_targets": GROWTH_TARGETS,
            "agent_gates": {"proposal_types": ["data_candidate", "verdict_draft", "design_shortlist"]},
        },
    )
    verify_inputs(manifest)
    print(f"[3/7] execution manifest frozen and verified ({len(manifest['inputs'])} inputs)")

    # 4. Catalog contract validation: problems abort, gaps export as warnings.
    problems, warnings = validate_catalog(catalog)
    if problems:
        for problem in problems:
            print(f"    PROBLEM: {problem}")
        raise SystemExit("catalog validation failed; refusing to continue")
    pd.DataFrame({"warning": warnings}).to_csv(OUT / "v3_catalog_warnings.csv", index=False)
    print(f"[4/7] catalog valid; {len(warnings)} declared-gap warnings exported")

    # 5. Claims audit with the v2 verdict engine.
    audits = [audit_study(_audit_input(catalog, key)) for key in sorted(catalog.studies)]
    audit = pd.concat(audits, ignore_index=True)
    audit.to_csv(OUT / "v3_claims_audit.csv", index=False)
    verdict_counts = audit["verdict"].value_counts().to_dict()
    per_study = audit.groupby(["study_id", "verdict"]).size().unstack(fill_value=0)
    print(f"[5/7] claims audit: {verdict_counts}")

    # 6. Coverage matrix, stats and growth-target check.
    coverage = coverage_matrix(catalog)
    coverage.to_csv(OUT / "v3_coverage_matrix.csv", index=False)
    stats = catalog_stats(catalog)
    stats.to_csv(OUT / "v3_catalog_stats.csv", index=False)
    public = stats[stats["data_source"] == "literature"]
    core_coverage = coverage.loc[coverage["study"] == "overall", CORE_COVERAGE_FIELDS]
    core_mean = float(core_coverage.mean(axis=1).iloc[0]) if not core_coverage.empty else 0.0
    achieved = {
        "public_studies": int(len(public)),
        "recipes": int(public["recipes"].sum()),
        "curves": int(public["curves"].sum()),
        "accepted_rows": int(public["observation_rows"].sum()),
        "core_coverage": round(core_mean, 3),
    }
    shortfalls = {
        target: f"{achieved[target]} of {required}"
        for target, required in GROWTH_TARGETS.items()
        if achieved[target] < required
    }
    print(f"[6/7] catalog: {achieved}; shortfalls: {shortfalls or 'none'}")

    # 7. Literature monitor screening + report.
    from agriformulations.agents.literature_monitor import run_monitor

    screened = run_monitor(REPO / "research/selection_registry.json", phase="v3")
    screening_frame = pd.DataFrame(
        [
            {**{k: r[k] for k in ("doi", "title", "year", "screening_score", "decision", "notes")},
             **r["criteria"]}
            for r in screened
        ]
    )
    screening_frame.to_csv(OUT / "v3_literature_screening.csv", index=False)
    n_proposed = sum(1 for r in screened if r["decision"] == "propose_for_extraction")
    print(f"[7/7] literature monitor: {len(screened)} candidates screened, {n_proposed} proposals")

    gate_status = "MET" if not shortfalls else f"NOT MET ({len(shortfalls)} shortfalls, exported honestly)"
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v3 formulation catalog</title>
<style>{STYLE}</style></head><body>
<h1>Formulation catalog, version 3</h1>
<p>Frozen protocol <code>docs/v3_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen before any
analysis. Hybrid inventory: public literature studies plus (when present) internal
batches that never enter public benchmark tracks.</p>
<div class="note"><strong>Outcome.</strong> {len(catalog.studies)} studies registered
({int(len(public))} public, {len(catalog.studies) - int(len(public))} internal);
{int(public['curves'].sum())} public curves across {int(public['recipes'].sum())} recipes.
v3 exit gate: <strong>{gate_status}</strong>. Growth-target shortfalls are exported,
never lowered. Every claim carries a computed verdict; the standing
not-comparable register (efficacy, toxicity, yield, field, synthesis chemistry)
remains in force.</div>
<h2>1. Catalog inventory (independent units)</h2>
{_table(stats)}
<h2>2. Ontology coverage</h2>
<p>Fraction of formulations per study with each ontology field recorded; the
overall row is the catalog mean over core fields used by the exit gate.</p>
{_table(coverage)}
<h2>3. Claims audit (v2 verdict engine)</h2>
{_table(per_study.reset_index())}
<p>Disagreements under our stated analysis:</p>
{_table(audit[audit['verdict'] == 'disagreement_under_stated_analysis'],
        columns=['study_id', 'claim_id', 'comparison_scope', 'reported_value', 'our_value', 'verdict_basis'])}
<h2>4. Literature screening</h2>
<p>Screened against the seven frozen criteria; unverified counts as failing.
Only candidates passing all criteria become data_candidate proposals, which
require human approval before any extraction runs.</p>
{_table(screening_frame if not screening_frame.empty else None)}
<h2>5. Agent activity and governance</h2>
<p>Dev-time contracts live in <code>docs/agents/</code>; runtime proposals are
hash-chained in <code>proposals/agent_log.jsonl</code>. Agents propose; humans
review; deterministic code computes. This run created {n_proposed} screening
proposals.</p>
<h2>6. Interpretation and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v3_catalog</code>. The catalog is
an inventory and evidence audit, not a design model; no composition-to-performance
claim is made at v3. Full exports:
<a href="v3_catalog_stats.csv">stats</a> · <a href="v3_coverage_matrix.csv">coverage</a> ·
<a href="v3_claims_audit.csv">claims audit</a> ·
<a href="v3_literature_screening.csv">screening</a> ·
<a href="v3_catalog_warnings.csv">declared gaps</a></p>
</body></html>"""
    report = OUT / "v3_catalog.html"
    report.write_text(html)
    print(f"[7/7] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    with open(OUT / "v3_gate.json", "w") as handle:
        json.dump({"targets": GROWTH_TARGETS, "achieved": achieved, "shortfalls": shortfalls}, handle, indent=1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
