"""One reproducible command for the v4 physics phase (docs/v4_protocol.md).

Verifies every solver gate, computes physics features for the whole catalog,
runs the GPU identifiability grids, and renders reports/v4/v4_physics.html.
Any failed gate aborts with a non-zero exit.

    python3 -m scripts.run_v4_physics [--device auto|cpu|cuda]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v4"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.catalog import load_catalog  # noqa: E402
from agriformulations.physics.features import physics_features  # noqa: E402
from agriformulations.physics.identifiability import profile_grid, unidentifiable_pairs  # noqa: E402
from agriformulations.physics.verification import (  # noqa: E402
    verify_finite_bath,
    verify_geometry,
    verify_heterogeneous,
    verify_swelling,
)

GEOMETRY_RUNS = ("slab", "cylinder", "sphere")


def _device_record(requested: str) -> dict:
    record = {"requested": requested, "resolved": "cpu", "gpu_name": None}
    try:
        import torch

        record["torch_version"] = torch.__version__
        if requested == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("explicit --device cuda requested but CUDA is unavailable")
        if requested in ("auto", "cuda") and torch.cuda.is_available():
            record["resolved"] = "cuda"
            record["gpu_name"] = torch.cuda.get_device_name(0)
    except ImportError:
        record["torch_version"] = None
    return record


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args(argv)
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    device = _device_record(args.device)

    # 1. Hash gate + frozen manifest before any physics output is used.
    catalog = load_catalog()
    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device=args.device,
        extra={
            "phase": "v4",
            "protocol": {
                "document": "docs/v4_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v4_protocol.md").read_bytes()).hexdigest(),
            },
            "device": device,
            "discretization": {"shells": [20, 40, 80], "dt_safety": [0.5, 0.25], "dtype": "float64"},
            "gate_thresholds": {
                "mass_balance": 1e-6, "analytic_agreement_80": 5e-3,
                "cpu_gpu_abs": 1e-8, "cpu_gpu_rel": 1e-6,
            },
        },
    )
    verify_inputs(manifest)
    print(f"[1/5] manifest frozen ({len(manifest['inputs'])} inputs, device={device['resolved']})")

    # 2. Solver verification gates per geometry and per physics.
    records = {}
    failed = []
    for geometry in GEOMETRY_RUNS:
        records[geometry] = verify_geometry(geometry, device=args.device)
        for gate, ok in records[geometry]["gates"].items():
            if not ok:
                failed.append(f"{geometry}.{gate}")
    records["finite_bath"] = verify_finite_bath(device=args.device)
    failed += [f"finite_bath.{g}" for g, ok in records["finite_bath"]["gates"].items() if not ok]
    records["heterogeneous"] = verify_heterogeneous(device=args.device)
    failed += [f"heterogeneous.{g}" for g, ok in records["heterogeneous"]["gates"].items() if not ok]
    records["swelling"] = verify_swelling(device=args.device)
    failed += [f"swelling.{g}" for g, ok in records["swelling"]["gates"].items() if not ok]
    print(f"[2/5] verification gates: {'ALL PASS' if not failed else 'FAILED: ' + ', '.join(failed)}")

    # 3. Physics features for the whole catalog.
    features = physics_features(catalog)
    features.to_csv(OUT / "v4_physics_features.csv", index=False)
    in_target_curves = features["calibrated_rate_per_time"].notna().sum()
    coverage_fraction = float(in_target_curves / max(len(features), 1))
    print(f"[3/5] physics features: {in_target_curves}/{len(features)} curves calibrated ({coverage_fraction:.0%})")

    # 4. Identifiability grids (GPU batched forward solves).
    times = np.array([1.0, 2.0, 4.0, 8.0, 16.0, 24.0, 36.0, 48.0])
    profiles = [
        profile_grid(times=times, true_rate=0.05, noise=0.02, pair=("D", "R"), device=args.device),
        profile_grid(times=times, true_rate=0.05, noise=0.02, pair=("rate", "loading"), device=args.device),
    ]
    table = pd.DataFrame(unidentifiable_pairs(profiles))
    table.to_csv(OUT / "v4_identifiability.csv", index=False)
    d_unident = bool(table[(table.parameter == "D")]["unidentifiable_alone"].iloc[0])
    rate_ident = not bool(table[(table.parameter == "rate")]["unidentifiable_alone"].iloc[0])
    print(f"[4/5] identifiability: D-alone unidentifiable={d_unident}, rate identifiable={rate_ident}")

    # 5. Report.
    gate_summary = pd.DataFrame(
        [
            {"solver": geometry, **{k: bool(v) for k, v in records[geometry]["gates"].items()}}
            for geometry in GEOMETRY_RUNS
        ]
        + [
            {"solver": "finite_bath", **{k: bool(v) for k, v in records["finite_bath"]["gates"].items()}},
            {"solver": "heterogeneous", **{k: bool(v) for k, v in records["heterogeneous"]["gates"].items()}},
            {"solver": "swelling", **{k: bool(v) for k, v in records["swelling"]["gates"].items()}},
        ]
    )
    mesh = pd.DataFrame(
        [{"geometry": g, **{f"shells_{k}": v for k, v in records[g]["mesh_errors_vs_analytic"].items()}} for g in GEOMETRY_RUNS]
    )
    if failed:
        raise SystemExit(f"v4 verification failed: {failed}")
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v4 physics</title>
<style>{STYLE}</style></head><body>
<h1>Physics expansion and identifiability, version 4</h1>
<p>Frozen protocol <code>docs/v4_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen before any physics
output was used. Device: {device['resolved']}{'' if not device['gpu_name'] else ' (' + device['gpu_name'] + ')'}.</p>
<div class="note"><strong>Outcome.</strong> All solver gates pass for slab, cylinder and
sphere geometries, heterogeneous diffusivity, finite bath and quasi-static swelling.
The identifiability table confirms D and L are jointly unidentifiable from released
fraction (the model sees D/L<sup>2</sup> only) while the effective rate and loading are
identifiable; v6 inversion is restricted accordingly. Calibrated rates are curve fits,
not measured molecular diffusivities.</div>
<h2>1. Solver verification gates</h2>
{_table(gate_summary)}
<h2>2. Mesh convergence (max |FV - analytic|)</h2>
{_table(mesh)}
<p>Finite bath: plateau errors {records['finite_bath']['per_ratio']}; sink-limit difference
{records['finite_bath']['sink_limit_max_abs_diff_ratio_1000']:.2e} at ratio 1000.
Swelling k_s=0 reduction matches the fixed solver to
{records['swelling']['ks0_matches_fixed_solver_max_abs']:.1e}.</p>
<h2>3. Physics features (catalog calibration)</h2>
{_table(features.groupby('study_key').agg(curves=('curve_id', 'count'),
    median_rate=('calibrated_rate_per_time', 'median'),
    median_r2=('calibrated_r2', 'median')).reset_index())}
<p class="small">Full export: <a href="v4_physics_features.csv">v4_physics_features.csv</a> ·
<a href="v4_identifiability.csv">v4_identifiability.csv</a></p>
<h2>4. Identifiability</h2>
{_table(table)}
<p>A parameter flagged unidentifiable alone cannot be a v6 inversion target unless
independently measured.</p>
<h2>5. Interpretation and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v4_physics</code>. Scenario grids and
identifiability studies are synthetic calculations on verified solvers, not experimental
evidence. The standing not-comparable register (efficacy, toxicity, yield, field,
synthesis chemistry) is unchanged.</p>
</body></html>"""
    report = OUT / "v4_physics.html"
    report.write_text(html)
    print(f"[5/5] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
