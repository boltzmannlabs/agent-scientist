"""Independent conservation limits and calibration-boundary regression benchmark.

Synthetic numerical fixtures only. Run: python3 -m scripts.run_v25_model_integrity
"""
import base64
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from agriformulations.rnd import control,data_tools,simulation_models,simulation_service
from agriformulations.rnd.recipe_inputs import create


def main():
    equilibria = []
    for geometry in ("sphere","cylinder","slab"):
        for bath in (.001,5,1e6):
            inputs = {"geometry":geometry,"bath_ratio":bath,"diffusivity_m2_s":1e-6,"length_um":50,"horizon_days":36500}
            result = simulation_models.run("finite_bath",inputs)
            equilibria.append({"inputs":inputs,"metrics":result["metrics"],"independent_equilibrium":bath/(1+bath),
                "absolute_error":abs(result["metrics"]["release_at_horizon"]-bath/(1+bath))})
    recipe = create({"name":"Synthetic calibration guard fixture","format":"SC","mode":"fixed","batch_g":1000,
        "process":"Numerical fixture only; no real preparation performed.",
        "ingredients":[{"name":"Reference active","role":"active","pct":10,"purity_pct":100},
                       {"name":"Reference vehicle","role":"solvent","pct":90,"purity_pct":100}]})["recipes"][0]
    lines = ["shear,stress,batch"]+[f"{x},{2+.5*x**.6},B{i%2}" for i,x in enumerate(np.geomspace(.1,1000,20))]
    dataset = data_tools.identify(data_tools.ingest({"kind":"rheology","filename":"synthetic_guard_fixture.csv",
        "content_base64":base64.b64encode("\n".join(lines).encode()).decode(),"recipe_id":recipe["recipe_id"],
        "active_name":recipe["active_components"][0]["name"],"instrument":"Synthetic numerical fixture, not measured data",
        "x_unit":"1/s","value_unit":"Pa","mapping":{"x":"shear","value":"stress","batch":"batch"}}))
    state = {"recipes":[recipe],"imports":[dataset]}
    fitted = simulation_service.record_fit(state,dataset["dataset_id"])
    request = {"model":"rheology","recipe_id":recipe["recipe_id"],"active_name":recipe["active_components"][0]["name"],
        "fit_id":fitted["fit_id"],"inputs":{"shear_rates_s":[1,10,100],"pipe_radius_mm":10,"flow_l_min":1000}}
    rejected = False
    try:
        simulation_service.prepare(state,request)
    except ValueError as exc:
        rejected = "Derived shear queries" in str(exc)
    request["allow_extrapolation"] = True
    explicit = simulation_service.record(state,request)
    search = simulation_models.run("inverse_design",{
        "base_model":"spreading","base_inputs":{"droplet_diameter_um":100,"evaporation_um2_s":50},
        "variables":[{"parameter":"relative_humidity","low":.5,"high":1}],
        "objectives":[{"metric":"drying_time_s","goal":"minimize"}],"constraints":[],"evaluations":12})
    checks = {"maximum_mass_balance_error":max(r["metrics"]["mass_balance_error"] for r in equilibria),
              "maximum_equilibrium_error":max(r["absolute_error"] for r in equilibria),
              "implicit_derived_extrapolation_rejected":rejected,
              "explicit_extrapolation_recorded":explicit["result"]["calibration"]["scenario_domain"]["outside_calibration"],
              "undefined_boundary_retained":search["metrics"]["unavailable_metric_candidates"]==1,
              "drying_optimum_matches_independent_d_squared_limit":abs(search["best_metrics"]["drying_time_s"]-400)<1e-9}
    passed = checks["maximum_mass_balance_error"]<1e-10 and checks["maximum_equilibrium_error"]<1e-10 and all(
        checks[key] for key in ("implicit_derived_extrapolation_rejected","explicit_extrapolation_recorded","undefined_boundary_retained","drying_optimum_matches_independent_d_squared_limit"))
    output = ROOT/"reports/v25"
    output.mkdir(exist_ok=True)
    report = {"evidence":"Synthetic numerical verification; no experimental or composition-performance validation implied.",
              "engine_manifest":control.engine_manifest(),"runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "passed":bool(passed),"checks":checks,"finite_bath_cases":equilibria,
              "rheology_domain":explicit["result"]["calibration"]["scenario_domain"],"boundary_search":search}
    target = output/"model_integrity.json"
    target.write_text(json.dumps(report,indent=2,allow_nan=False))
    print(json.dumps({"passed":bool(passed),"checks":checks,"report":str(target)},indent=2))
    if not passed:
        raise SystemExit("Model integrity benchmark failed")


if __name__ == "__main__":
    main()
