"""Direct benchmark against Zhang et al. Nat Commun (2025), DOI57028.
Uses the author's exact workbook equations, not the generic library variants.
"""
from pathlib import Path
import os,sys,json,hashlib
os.environ.setdefault("MPLCONFIGDIR","/tmp/agriformulations-matplotlib")
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar, least_squares
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
OUT=ROOT/"reports"
RAW=ROOT/"data/raw/azadirachtin_2025_source_data.xlsx"
DOI="10.1038/s41467-025-57028-w"
PAPER="https://www.nature.com/articles/s41467-025-57028-w"
SPECS={
 "first_order":dict(parameters=("a","b"),rows=(27,28),r2=29,equation="a*(1-exp(-b*t))",bounds=(-8,3)),
 "ritger_peppas":dict(parameters=("a","b"),rows=(36,37),r2=38,equation="a*t**b",bounds=(0.001,3)),
 "higuchi":dict(parameters=("a","b"),rows=(45,46),r2=47,equation="a*sqrt(t)+b"),
 "peppas_sahlin":dict(parameters=("a","b","c"),rows=(54,55,56),r2=57,equation="a*t**c+b*t**(2*c)",bounds=(0.001,2)),
}

def score(y,p):
    y,p=np.asarray(y),np.asarray(p)
    return dict(mae_pp=float(np.mean(abs(y-p))),rmse_pp=float(np.sqrt(np.mean((y-p)**2))),
        r2=float(1-np.sum((y-p)**2)/np.sum((y-y.mean())**2)))

def evaluate(t,model,p):
    t=np.asarray(t,float)
    if model=="first_order": return p["a"]*(-np.expm1(-p["b"]*t))
    if model=="higuchi": return p["a"]*np.sqrt(t)+p["b"]
    if model=="ritger_peppas": return p["a"]*t**p["b"]
    if model=="peppas_sahlin": return p["a"]*t**p["c"]+p["b"]*t**(2*p["c"])
    raise ValueError(model)

def refit(t,y,model):
    """Unweighted all-time least squares in percent; explicit bounds recorded."""
    t,y=np.asarray(t,float),np.asarray(y,float)
    if model=="higuchi":
        a,b=np.linalg.lstsq(np.column_stack([np.sqrt(t),np.ones(len(t))]),y,rcond=None)[0]
        return {"a":float(a),"b":float(b)}
    # Variable projection solves linear coefficients exactly for a fixed exponent/rate.
    def solve(z):
        if model=="first_order":
            design=(-np.expm1(-(10**z)*t))[:,None]
        elif model=="ritger_peppas":
            design=(t**z)[:,None]
        else: design=np.column_stack([t**z,t**(2*z)])
        coef=np.linalg.lstsq(design,y,rcond=None)[0]
        return float(np.sum((design@coef-y)**2)),coef
    low,high=SPECS[model]["bounds"]
    grid=np.linspace(low,high,401)
    losses=[solve(z)[0] for z in grid]
    candidates=[(losses[0],grid[0]),(losses[-1],grid[-1])]
    for i in range(1,len(grid)-1):
        if losses[i]<=losses[i-1] and losses[i]<=losses[i+1]:
            fit=minimize_scalar(lambda z:solve(z)[0],bounds=(grid[i-1],grid[i+1]),
                method="bounded",options={"xatol":1e-12})
            candidates.append((float(fit.fun),float(fit.x)))
    _,z=min(candidates)
    _,coef=solve(z)
    if model=="first_order": return {"a":float(coef[0]),"b":float(10**z)}
    if model=="ritger_peppas": return {"a":float(coef[0]),"b":float(z)}
    return {"a":float(coef[0]),"b":float(coef[1]),"c":float(z)}

def cell_number(v): return float(str(v).split("±")[0].strip())

def extract_release(x):
    observations=[]; parameters=[]
    for form,start,basecol in [("AT NPs",2,2),("AP NPs",13,8)]:
        for j,ph in enumerate((5,7,9)):
            col=2+2*j
            for r in range(start,start+9):
                observations.append(dict(formulation=form,ph=ph,time_h=float(x.iloc[r,1]),
                    release_pct=float(x.iloc[r,col]),se_pct=float(x.iloc[r,col+1]),
                    source_sheet="Figure 6",source_cells=f"B{r+1}:{chr(65+col+1)}{r+1}",
                    evidence_kind="published_measured",doi=DOI))
            for model,spec in SPECS.items():
                p={name:cell_number(x.iloc[r,basecol+j]) for name,r in zip(spec["parameters"],spec["rows"])}
                parameters.append(dict(formulation=form,ph=ph,model=model,equation=spec["equation"],
                    parameters=json.dumps(p),reported_r2=float(x.iloc[spec["r2"],basecol+j]),
                    source_sheet="Figure 6",source_column=chr(65+basecol+j),
                    parameter_rows=json.dumps([r+1 for r in spec["rows"]]),
                    r2_cell=f"{chr(65+basecol+j)}{spec['r2']+1}",
                    evidence_kind="published_fitted",doi=DOI))
    return pd.DataFrame(observations),pd.DataFrame(parameters)

def release_benchmark(obs,params):
    rows,predictions=[],[]
    for claim in params.itertuples():
        g=obs[(obs.formulation==claim.formulation)&(obs.ph==claim.ph)].sort_values("time_h")
        t=g.time_h.to_numpy();y=g.release_pct.to_numpy()
        published=json.loads(claim.parameters)
        fit=refit(t,y,claim.model)
        pp=evaluate(t,claim.model,published);rp=evaluate(t,claim.model,fit)
        pm,rm=score(y,pp),score(y,rp)
        rows.append(dict(formulation=claim.formulation,ph=claim.ph,model=claim.model,
            equation=claim.equation,n_points=len(t),published_reported_r2=claim.reported_r2,
            published_parameters_recomputed_r2=pm["r2"],our_equation_matched_r2=rm["r2"],
            our_r2_minus_reported=rm["r2"]-claim.reported_r2,
            published_parameter_mae_pp=pm["mae_pp"],our_mae_pp=rm["mae_pp"],our_rmse_pp=rm["rmse_pp"],
            published_parameters=claim.parameters,our_parameters=json.dumps(fit),source_r2_cell=claim.r2_cell,
            fit_scope="calibration_all_nine_Figure6_means_unweighted_not_holdout",
            evidence_kind="derived",doi=DOI))
        for time,actual,p,r in zip(t,y,pp,rp):
            predictions.append(dict(formulation=claim.formulation,ph=claim.ph,model=claim.model,time_h=time,
                source_release_pct=actual,published_parameter_prediction_pct=p,our_refit_prediction_pct=r))
    return pd.DataFrame(rows),pd.DataFrame(predictions)

def photo_benchmark(x):
    observations=[];rows=[]
    for form,start,col,reported in [("AZA EC",51,2,18.50),("AT NPs",64,3,30.62),("AP NPs",77,4,56.19)]:
        t=x.iloc[start:start+10,0].to_numpy(float);y=x.iloc[start:start+10,4].to_numpy(float)
        for r,time,val in zip(range(start,start+10),t,y):
            observations.append(dict(formulation=form,time_min=time,retention_pct=val,
                replicate_1_pct=float(x.iloc[r,1]),replicate_2_pct=float(x.iloc[r,2]),replicate_3_pct=float(x.iloc[r,3]),
                source_sheet="Figure 5",source_cells=f"A{r+1}:F{r+1}",
                evidence_kind="published_measured",doi=DOI))
        # Author's two-parameter exponential; no weighting because error columns are inconsistent.
        fit=least_squares(lambda p:p[0]*np.exp(-p[1]*t)-y,[100,.02],
            bounds=([0,1e-10],[1000,10]),ftol=1e-13,xtol=1e-13,gtol=1e-13,max_nfev=3000)
        a,k=map(float,fit.x);half=float(np.log(2)/k)
        pub_a=cell_number(x.iloc[92,col]);pub_k=-cell_number(x.iloc[93,col])
        pm=score(y,pub_a*np.exp(-pub_k*t));rm=score(y,a*np.exp(-k*t))
        rows.append(dict(formulation=form,reported_text_dt50_min=reported,
            our_dt50_relative_fitted_initial_min=half,
            absolute_difference_min=half-reported,relative_difference_pct=(half/reported-1)*100,
            our_time_to_50percent_of_normalized_initial_min=float(np.log(a/50)/k),
            source_parameter_implied_dt50_min=float(np.log(2)/pub_k),
            source_reported_r2=float(x.iloc[94,col]),source_parameter_recomputed_r2=pm["r2"],our_r2=rm["r2"],
            our_amplitude_pct=a,our_rate_min_inverse=k,our_mae_pp=rm["mae_pp"],
            published_amplitude_pct=pub_a,published_rate_min_inverse=pub_k,
            equation="retention=a*exp(-k*time_min)",source_parameter_cells=f"{chr(65+col)}93:{chr(65+col)}95",
            n_points=10,evidence_kind="derived",doi=DOI))
    return pd.DataFrame(rows),pd.DataFrame(observations)

def narrative_benchmark(obs,release):
    rows=[]
    for form,ph,time,reported in [("AT NPs",5,96,65.57),("AP NPs",5,96,89.31),
                                 ("AT NPs",9,48,76.06),("AP NPs",9,48,93.51)]:
        g=obs[(obs.formulation==form)&(obs.ph==ph)&(obs.time_h==time)]
        raw=float(g.iloc[0].release_pct)
        fit=release[(release.formulation==form)&(release.ph==ph)&(release.model=="higuchi")].iloc[0]
        pred=float(evaluate([time],"higuchi",json.loads(fit.our_parameters))[0])
        rows.append(dict(formulation=form,ph=ph,time_h=time,paper_prose_release_pct=reported,
            workbook_release_pct=raw,workbook_minus_prose_pp=raw-reported,
            equation_matched_higuchi_fit_pct=pred,evidence_kind="derived",doi=DOI))
    return pd.DataFrame(rows)

def plots(obs,release,photo,pobs):
    fig,axes=plt.subplots(2,3,figsize=(13,7),constrained_layout=True)
    for ax,((form,ph),g) in zip(axes.flat,obs.groupby(["formulation","ph"])):
        row=release[(release.formulation==form)&(release.ph==ph)&(release.model=="higuchi")].iloc[0]
        t=np.linspace(0,96,200)
        ax.scatter(g.time_h,g.release_pct,color="#22352a",label="Published Figure 6 means",s=23,zorder=5)
        ax.plot(t,evaluate(t,"higuchi",json.loads(row.published_parameters)),ls="--",color="#bd6e31",label="Published parameters")
        ax.plot(t,evaluate(t,"higuchi",json.loads(row.our_parameters)),color="#257ab1",label="Same-equation refit")
        ax.set(title=f"{form}, pH {ph}",xlabel="Hours",ylabel="Release (%)")
    handles,labels=axes.flat[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="outside lower center",ncol=3)
    fig.savefig(OUT/"paper_release_comparison.png",dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(13,3.7),constrained_layout=True)
    for ax,row in zip(axes,photo.itertuples()):
        g=pobs[pobs.formulation==row.formulation];t=np.linspace(0,60,200)
        ax.scatter(g.time_min,g.retention_pct,s=23,color="#22352a",label="Published means")
        ax.plot(t,row.our_amplitude_pct*np.exp(-row.our_rate_min_inverse*t),label="Equation-matched refit",color="#257ab1")
        ax.plot(t,row.published_amplitude_pct*np.exp(-row.published_rate_min_inverse*t),"--",label="Published parameters",color="#bd6e31")
        ax.axhline(50,color="#aaaaaa",ls=":")
        ax.set(title=row.formulation,xlabel="Minutes of UV exposure",ylabel="Retention (%)")
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="outside lower center",ncol=3)
    fig.savefig(OUT/"paper_photostability_comparison.png",dpi=160);plt.close(fig)

def write_report(release,photo,narrative):
    def tab(d):return d.to_html(index=False,float_format=lambda x:f"{x:.4f}",border=0)
    main=release[release.model=="higuchi"][["formulation","ph","published_reported_r2","published_parameters_recomputed_r2","our_equation_matched_r2","our_mae_pp"]]
    brief=photo[["formulation","reported_text_dt50_min","our_dt50_relative_fitted_initial_min","absolute_difference_min","our_r2"]]
    summary=release.groupby("model").agg(mean_refit_mae_pp=("our_mae_pp","mean"),
        mean_absolute_r2_gap=("our_r2_minus_reported",lambda s:abs(s).mean())).reset_index()
    gpu_path=OUT/"gpu_execution.json"
    gpu_note=""
    if gpu_path.exists():
        gpu=json.loads(gpu_path.read_text())
        devices=sorted({m["device"] for m in gpu["executions"]})
        gpu_note=f'<h2>GPU computation extension</h2><p>{gpu["total_predictions"]:,} batched ideal-sphere predictions were executed using {", ".join(devices)}. These are hypothetical radius/diffusivity scenarios for the separate fertilizer case, not experimental observations or extra paper-replication evidence. Small equation fitting and sklearn training use CPU.</p><img src="gpu_physics_sweep.png" alt="GPU simulated parameter sensitivity"><p><a href="gpu_execution.json">Device and CPU-reference verification record</a> · <a href="gpu_physics_scenarios.csv">Scenario outputs</a>.</p>'
    doc=f"""<!doctype html><html lang="en"><meta charset="utf-8"><title>Direct published-paper benchmark</title>
<style>body{{font:16px/1.6 system-ui,sans-serif;max-width:1160px;margin:35px auto;padding:0 24px;color:#18352b;background:#f8faf7}}h1,h2{{line-height:1.2}}h2{{margin-top:36px}}table{{border-collapse:collapse;background:white;font-size:14px}}td,th{{padding:8px;border-bottom:1px solid #dbe4da;text-align:left}}img{{width:100%}}a{{color:#126a52}}.note{{padding:15px;background:#e7efdf;border-left:4px solid #679448}}</style>
<h1>Benchmark against a published paper</h1>
<p>Reference: <a href="{PAPER}">Zhang et al., Sustainable pest management using plant secondary metabolites regulated azadirachtin nano-assemblies, Nature Communications 16, 1721 (2025)</a>. DOI {DOI}. Run 2026-10-19.</p>
<div class="note">Outcome: partial numerical reproduction. The refits recover selected release trends and fit some supplied curves well, but the reported statistics and half-lives are not consistently reproduced. We do not claim to match all paper results or outperform the paper.</div>
<h2>Benchmark contract</h2>
<p>Data: original publisher workbook, Figure 6 (54 release means, six curves) and Figure 5f (30 photoretention means, three curves). Source bytes are hash-checked. This benchmark uses the exact equations and printed parameter values in the workbook. Data extraction, parameter replay, and refitting are three separate operations.</p>
<p>The earlier library benchmark used a unit-asymptote first-order model and zero-intercept Higuchi model. Those are different from this paper. Here first-order is a(1−exp(−bt)), Higuchi is a√t+b, Ritger–Peppas is atᵇ, and Peppas–Sahlin is atᶜ+bt²ᶜ. Release is in percent and time in hours. Figure 6 means are rounded differently from the more detailed supplementary sheet; this direct benchmark uses the Figure 6 values associated with its fit tables.</p>
<p>We replay all 24 printed parameter sets, then refit the same equations by unweighted least squares on all nine means per curve. No clipping or forced 100% plateau is imposed on these diagnostic paper equations. Power exponents are bounded explicitly (0.001–3 for Ritger–Peppas; 0.001–2 for Peppas–Sahlin). First-order rate search spans 10⁻⁸–10³ h⁻¹. Unknown original weighting/subset choices prevent a claim of identical fitting procedure. Published SE columns are not used as weights. Signed Peppas–Sahlin coefficients may cancel and its exponent can reach a numerical bound; those weakly identified coefficients have no established material interpretation.</p>
<h2>1. Release kinetics: paper versus reproduced statistics</h2>
<p>The key Higuchi comparison below distinguishes the reported R² from the R² obtained by evaluating the paper's own printed parameters on its supplied observations. The third value is our refit of exactly the same equation. Larger R² here indicates calibration fit, not independent predictive skill.</p>
{tab(main)}
<img src="paper_release_comparison.png" alt="Printed Higuchi equations and refitted curves compared with published observations">
<p>All four equation families:</p>
{tab(summary)}
<p><a href="paper_release_benchmark.csv">Full 24-row comparison, parameters, errors, and source cells</a> · <a href="paper_release_predictions.csv">Every replay and refit prediction</a>. Disagreement between printed parameters, reported R², and supplied observations remains unresolved; this could involve source inconsistencies, fit subsets, weighting, or undocumented conventions. We do not select a convenient subset to force agreement.</p>
<h2>2. Photodegradation: reported half-life benchmark</h2>
<p>The workbook supplies the exponential equation y=a exp(bt), with negative b. We write k=−b and refit y=a exp(−kt). The half-life relative to the fitted initial level is ln(2)/k. We also export the time to 50% of the normalized initial amount, ln(a/50)/k, so the amplitude convention is explicit.</p>
{tab(brief)}
<img src="paper_photostability_comparison.png" alt="Photoretention means compared with printed and refitted exponentials">
<p>The source observations labelled AT decay more slowly than those labelled AP. This ordering differs from the prose half-lives. The AT refit produces about 56.27 minutes, close to the prose AP value of 56.19 minutes, but we do not swap sample labels. This is a benchmark failure to reproduce the published assignment, not proof of a specific editorial error.</p>
<p><a href="paper_photostability_benchmark.csv">Half-life comparison, both conventions, printed parameter implied half-lives, and fit errors</a>.</p>
<h2>3. Direct checks of narrative release claims</h2>
{tab(narrative[["formulation","ph","time_h","paper_prose_release_pct","workbook_release_pct","workbook_minus_prose_pp"]])}
<p>The alkaline 48-hour statements agree to rounding with the workbook. The acidic 96-hour statements do not. Reading a source value back from the same workbook checks extraction and consistency; it is not an independent experimental replication. The model fit column remains available in <a href="paper_narrative_benchmark.csv">the CSV</a>.</p>
{gpu_note}
<h2>Interpretation and reproduction</h2>
<p>We have benchmarked against a specific published paper using comparable equations, units, and numerical targets. We can reproduce some source-data trends and approximate fits. We cannot honestly report full agreement with its fit statistics or half-life assignments. No crop efficacy, pest mortality, or wet-lab result is independently reproduced.</p>
<p>These are retrospective calibration and consistency checks. The separate <a href="case_study.html">case-study report</a> contains held-out forecasting and AI prediction failures; its validation scores must not be compared with the paper's in-sample R² as if they measure the same task.</p>
<p>Run <code>python3 -m scripts.benchmark_paper</code>, or <code>python3 -m scripts.reproduce</code> for the complete workflow. <a href="paper_benchmark_manifest.json">Manifest and code/data hashes</a>. Original workbook and author/publisher attribution are preserved; no commercial redistribution rights are asserted.</p></html>"""
    (OUT/"paper_benchmark.html").write_text(doc)

def main():
    OUT.mkdir(exist_ok=True)
    expected=json.loads((ROOT/"research/azadirachtin_2025_manifest.json").read_text())["sha256"]
    actual=hashlib.sha256(RAW.read_bytes()).hexdigest()
    if actual!=expected:raise ValueError("Publisher workbook SHA256 mismatch")
    x=pd.ExcelFile(RAW)
    obs,params=extract_release(pd.read_excel(x,sheet_name="Figure 6",header=None))
    release,pred=release_benchmark(obs,params)
    photo,pobs=photo_benchmark(pd.read_excel(x,sheet_name="Figure 5",header=None))
    narrative=narrative_benchmark(obs,release)
    files={"paper_release_observations":obs,"paper_reported_parameters":params,"paper_release_benchmark":release,
           "paper_release_predictions":pred,"paper_photostability_benchmark":photo,
           "paper_photostability_observations":pobs,"paper_narrative_benchmark":narrative}
    for name,df in files.items():
        if "evidence_kind" not in df:df["evidence_kind"]="derived"
        df["parent_source"]="data/raw/azadirachtin_2025_source_data.xlsx"
        df.to_csv(OUT/f"{name}.csv",index=False)
    plots(obs,release,photo,pobs)
    write_report(release,photo,narrative)
    manifest=dict(doi=DOI,source_url=json.loads((ROOT/"research/azadirachtin_2025_manifest.json").read_text())["source_url"],
        source_sha256=actual,benchmark_code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        run_date_utc="2026-10-19",models=24,release_mean_observations=len(obs),photostability_mean_observations=len(pobs),
        evaluation="retrospective calibration and claim consistency; no biological validation")
    (OUT/"paper_benchmark_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(photo[["formulation","reported_text_dt50_min","our_dt50_relative_fitted_initial_min","our_r2"]].to_string(index=False))
    print(release.groupby("model")[["our_mae_pp","our_r2_minus_reported"]].mean().to_string())
    print("Report:",OUT/"paper_benchmark.html")

if __name__=="__main__":main()
