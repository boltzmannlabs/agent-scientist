"""One reproducible command for the v8 sulfoxaflor campaign (docs/v8_protocol.md).

Validates the pinned registries, freezes the manifest, enumerates and
scores every concept (prior-art flags, India relevance, compatibility,
analogue-transferred feasibility regions), ranks the per-direction
shortlist, re-verifies shortlisted carrier candidates with the 80-shell
FV solver, emits the deterministic data plans, submits a
campaign_shortlist proposal, and renders the report.  The
recommendation section appears ONLY for a human-approved proposal.

    python3 -m scripts.run_v8_campaign [--approve <proposal_id>]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "reports" / "v8"

try:
    import agriformulations  # noqa: F401
except ImportError:
    sys.path.insert(0, str(REPO / "src"))

from agriformulations.agents import require_approved  # noqa: E402
from agriformulations.benchmark_v2.io_utils import sha256_file  # noqa: E402
from agriformulations.benchmark_v2.manifest import freeze_execution_manifest, verify_inputs  # noqa: E402
from agriformulations.benchmark_v2.report import STYLE, _table  # noqa: E402
from agriformulations.campaign import (  # noqa: E402
    analogue_frame,
    assess_prior_art,
    build_campaign_shortlist_proposal,
    build_dataplan,
    build_shortlist,
    enumerate_concepts,
    india_relevance,
    load_registries,
    priority,
    transfer_concept,
)
from agriformulations.campaign.concepts import enumeration_summary  # noqa: E402
from agriformulations.campaign.india import WEIGHTS as INDIA_WEIGHTS  # noqa: E402
from agriformulations.campaign.prior_art import ADJACENT_THRESHOLD, WEIGHTS as PRIOR_ART_WEIGHTS  # noqa: E402
from agriformulations.campaign.rank import PER_DIRECTION, WEIGHTS as PRIORITY_WEIGHTS  # noqa: E402
from agriformulations.campaign.transfer import (  # noqa: E402
    GRID_PLATEAU_POINTS,
    GRID_RATE_POINTS,
    MIN_CALIBRATION_R2,
    MIN_CURVES,
    TOLERANCE_FRACTION,
    WEAK_ANALOGY_W,
    WIDEN_BASE,
    WEIGHTS as TRANSFER_WEIGHTS,
)
from agriformulations.catalog import load_catalog  # noqa: E402
from agriformulations.design import verify_shortlist_against_solver  # noqa: E402

V8_INPUT_PATTERNS = ("data/v8/prior_art.json", "data/v8/components.json", "data/v8/format_compatibility.json",
                     "data/v8/analogue_map.json", "data/v8/india/use_context.json",
                     "data/v8/concepts/concept_axes.json", "data/v8/methods/methods.json")
V8_CODE_PATTERNS = ("src/agriformulations/campaign/*.py", "scripts/run_v8_campaign.py")

CONCEPT_COLUMNS = [
    "concept_id", "direction", "role", "format", "carrier", "partner", "geometry",
    "flag", "blocked_by", "nearest_art", "S_nearest", "novelty", "positive_control",
    "pest_score", "crop_score", "robust_score", "india", "compatibility",
    "w", "analogue", "region_low_per_day", "region_high_per_day", "region_widen_factor",
    "feasibility", "feasibility_reason", "n_feasible", "priority", "renormalized",
]
TRANSFER_COLUMNS = [
    "concept_id", "role", "analogue", "w", "geometry_match", "carrier_match", "solubility_match",
    "region_low_per_day", "region_high_per_day", "region_widen_factor", "brief_id",
    "feasibility", "feasibility_reason", "n_feasible", "label",
]


def _collect(patterns) -> dict:
    records = {}
    for pattern in patterns:
        for path in sorted(REPO.glob(pattern)):
            records[path.relative_to(REPO).as_posix()] = {"sha256": sha256_file(path)}
    return records


def _score_concepts(registries, analogues, active_class) -> tuple[dict, pd.DataFrame, list[dict]]:
    """One deterministic scoring pass: concepts -> scored frame + transfer records."""
    concepts = enumerate_concepts(registries)
    summary = enumeration_summary(concepts)
    rows, transfers = [], []
    for concept in concepts:
        art = assess_prior_art(concept, registries.prior_art_entries)
        india = india_relevance(concept, registries.use_context["contexts"])
        compatibility = registries.compatibility(concept.format, active_class)
        transfer = transfer_concept(concept, analogues, active_solubility_class=active_class)
        rows.append(
            {
                "concept_id": concept.concept_id,
                "direction": concept.direction,
                "role": concept.role,
                "format": concept.format,
                "carrier": concept.carrier,
                "partner": concept.partner,
                "geometry": concept.geometry,
                "positive_control": concept.positive_control,
                "compatibility": compatibility,
                **{k: v for k, v in art.items() if k != "coverage_disclaimer"},
                **{k: v for k, v in india.items() if k != "concept_id"},
                **{k: transfer.get(k) for k in (
                    "w", "analogue", "region_low_per_day", "region_high_per_day",
                    "region_widen_factor", "feasibility", "feasibility_reason", "n_feasible",
                )},
            }
        )
        transfers.append(transfer)
    frame = pd.DataFrame(rows)
    scored = [priority(row) for _, row in frame.iterrows()]
    frame["priority"] = [s for s, _ in scored]
    frame["renormalized"] = [r for _, r in scored]
    frame = frame[CONCEPT_COLUMNS].sort_values("concept_id", kind="mergesort").reset_index(drop=True)
    transfer_frame = pd.DataFrame([{k: t.get(k) for k in TRANSFER_COLUMNS} for t in transfers])
    transfer_frame = transfer_frame.sort_values("concept_id", kind="mergesort").reset_index(drop=True)
    return summary, frame, transfers


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approve", default=None, help="approved campaign_shortlist proposal id")
    args = parser.parse_args(argv)
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)

    catalog = load_catalog()
    registries = load_registries(catalog_study_keys=set(catalog.studies))
    active_class = registries.component("sulfoxaflor")["solubility_class"]
    print(f"[1/7] registries valid ({len(registries.prior_art_entries)} prior-art entries, "
          f"{len(registries.components['components'])} components, active class {active_class})")

    manifest = freeze_execution_manifest(
        OUT / "execution_manifest.json",
        device="cpu",
        extra={
            "phase": "v8",
            "protocol": {
                "document": "docs/v8_protocol.md",
                "sha256": hashlib.sha256((REPO / "docs/v8_protocol.md").read_bytes()).hexdigest(),
            },
            "constants": {
                "prior_art_weights": PRIOR_ART_WEIGHTS,
                "adjacent_threshold": ADJACENT_THRESHOLD,
                "india_weights": INDIA_WEIGHTS,
                "transfer_weights": TRANSFER_WEIGHTS,
                "transfer_widen_base": WIDEN_BASE,
                "transfer_weak_w": WEAK_ANALOGY_W,
                "transfer_min_calibration_r2": MIN_CALIBRATION_R2,
                "transfer_min_curves": MIN_CURVES,
                "transfer_tolerance_fraction": TOLERANCE_FRACTION,
                "transfer_grid": [GRID_RATE_POINTS, GRID_PLATEAU_POINTS],
                "priority_weights": PRIORITY_WEIGHTS,
                "shortlist_per_direction": PER_DIRECTION,
                "solver": "conservative radial FV, 80 shells, float64 (v6 machinery)",
            },
            "inputs_v8": _collect(V8_INPUT_PATTERNS),
            "code_sha256_v8": _collect(V8_CODE_PATTERNS),
        },
    )
    verify_inputs(manifest)
    for rel, entry in manifest["inputs_v8"].items():
        if sha256_file(REPO / rel) != entry["sha256"]:
            raise SystemExit(f"v8 input hash drift after freeze: {rel}")
    print(f"[2/7] manifest frozen and re-verified ({len(manifest['inputs_v8'])} v8 inputs)")

    analogues = analogue_frame(catalog, registries)
    usable = {k: a["n_curves"] for k, a in sorted(analogues.items())}
    print(f"[3/7] analogue frame: usable curves per study {usable}")

    summary, frame, transfers = _score_concepts(registries, analogues, active_class)
    first_bytes = frame.to_csv(index=False).encode()
    _, frame_again, _ = _score_concepts(registries, analogues, active_class)
    determinism_pass = first_bytes == frame_again.to_csv(index=False).encode()
    if not determinism_pass:
        raise SystemExit("determinism gate FAILED: two scoring passes differ")
    frame.to_csv(OUT / "v8_concepts.csv", index=False)
    pd.DataFrame([{k: t.get(k) for k in TRANSFER_COLUMNS} for t in transfers]).sort_values(
        "concept_id", kind="mergesort"
    ).to_csv(OUT / "v8_transfer.csv", index=False)
    transfer_by_id = {t["concept_id"]: t for t in transfers}
    blocked = frame[frame["flag"] == "blocked"]
    print(f"[4/7] scored {len(frame)} concepts: {len(blocked)} blocked, "
          f"{int((frame['flag'] == 'clear').sum())} clear, "
          f"{int((frame['flag'] == 'adjacent').sum())} adjacent (byte-identical rerun: {determinism_pass})")

    shortlist = build_shortlist(frame)
    shortlist_rows = []
    for _, row in shortlist.iterrows():
        record = {**row.to_dict()}
        transfer = transfer_by_id[row["concept_id"]]
        if row["role"] == "carrier" and transfer.get("verify_candidate") and transfer.get("feasibility_reason") not in (
            "region_only_analogue_kernel_not_sphere", "not_applicable_no_release_kinetics_claim",
        ):
            verified = verify_shortlist_against_solver(
                [transfer["verify_candidate"]], transfer["brief"], tolerance=transfer["brief"]["tolerance"] * 1.05
            )[0]
            record["solver_mismatch_native"] = verified["solver_mismatch_native"]
            record["solver_verified"] = verified["solver_verified"]
            record["solver_note"] = "80-shell FV re-verification of the transferred-region candidate"
        else:
            record["solver_mismatch_native"] = None
            record["solver_verified"] = None
            record["solver_note"] = (
                "not_applicable_no_kinetics_claim" if row["role"] != "carrier"
                else transfer.get("feasibility_reason", "region_only")
            )
        record["transfer_note"] = (
            f"analogue {transfer.get('analogue')}, w={transfer.get('w')}, "
            f"region [{transfer.get('region_low_per_day'):.3g}, {transfer.get('region_high_per_day'):.3g}] /d"
            if transfer.get("analogue") else "no kinetics claim"
        )
        shortlist_rows.append(record)
    shortlist_frame = pd.DataFrame(shortlist_rows)
    shortlist_frame.to_csv(OUT / "v8_shortlist.csv", index=False)
    fv_entries = [r for r in shortlist_rows if r["solver_verified"] is not None]
    solver_ok = all(r["solver_verified"] for r in fv_entries)
    print(f"[5/7] shortlist {len(shortlist_rows)} concepts; FV-verified {len(fv_entries)} "
          f"carrier candidates, all pass={solver_ok}")

    dataplan = build_dataplan(frame, list(shortlist["concept_id"]), registries)
    dataplan.to_csv(OUT / "v8_dataplan.csv", index=False)
    print(f"[6/7] data plan: {len(dataplan)} rows across {dataplan['concept_id'].nunique()} shortlisted concepts")

    proposal = build_campaign_shortlist_proposal(
        shortlist_rows,
        manifest_sha256=manifest["protocol"]["sha256"],
        n_concepts=int(len(frame)),
    )
    print(f"[6/7] campaign_shortlist proposal submitted: {proposal.proposal_id} (pending human review)")

    approved = None
    if args.approve:
        try:
            approved = require_approved("v8", args.approve)
        except PermissionError as exc:
            print(f"    approval refused: {exc}")
    recommendation = ""
    if approved is not None and approved.proposal_id == proposal.proposal_id:
        recommendation = f"""<h2>8. Recommendation (approved)</h2>
<p>Approved by {approved.reviewer} at {approved.reviewed_utc}. Ranked shortlist:</p>
{_table(shortlist_frame, columns=['concept_id', 'direction', 'format', 'flag', 'S_nearest', 'india', 'feasibility', 'compatibility', 'priority', 'solver_verified'])}
<p class="small">Prior-art coverage flags against the pinned registry only; analogue regions are
hypothesis-generating; the standing not-comparable register and amendment A1 apply to this
recommendation.</p>"""

    carrier_rows = frame[frame["role"] == "carrier"]
    gates = {
        "registries_valid": True,
        "n_concepts": int(len(frame)),
        "concepts_by_direction": summary["by_direction"],
        "positive_control_blocked": bool(
            frame.loc[frame["positive_control"], "flag"].eq("blocked").all()
        ) and str(frame.loc[frame["positive_control"], "blocked_by"].iloc[0]) == "cn110063334a_cyan_sul_binary",
        "all_concepts_scored": bool(
            len(frame) == summary["n_concepts"]
            and frame["flag"].isin(["clear", "adjacent", "blocked"]).all()
            and frame.loc[frame["flag"] != "blocked", "priority"].notna().all()
        ),
        "carrier_regions_or_reason": bool(
            carrier_rows["feasibility_reason"].ne("").all()
            and (carrier_rows["region_low_per_day"].notna() | carrier_rows["feasibility_reason"].ne("")).all()
        ),
        "shortlist_size": int(len(shortlist_frame)),
        "shortlist_fv_verified": int(len(fv_entries)),
        "shortlist_region_only_or_na": int(len(shortlist_rows) - len(fv_entries)),
        "shortlist_solver_verified": bool(solver_ok),
        "determinism_pass": bool(determinism_pass),
        "proposal_id": proposal.proposal_id,
        "proposal_pending": proposal.status == "pending",
        "recommendation_rendered": approved is not None,
        "coverage_disclaimer": "prior-art registry is retrieval-date pinned, not exhaustive; no legal conclusion",
    }
    with open(OUT / "v8_gate.json", "w") as handle:
        json.dump(gates, handle, indent=1)

    flag_counts = frame.groupby("flag").size().to_dict()
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>v8 sulfoxaflor campaign</title>
<style>{STYLE}</style></head><body>
<h1>Sulfoxaflor campaign, version 8</h1>
<p>Frozen protocol <code>docs/v8_protocol.md</code>; manifest
<a href="execution_manifest.json">execution_manifest.json</a> frozen and re-verified before any
scoring. Risk-register amendment A1 in force.</p>
<div class="note"><strong>Outcome.</strong> {summary['n_concepts']} concepts enumerated across four
directions {summary['by_direction']}; {flag_counts.get('blocked', 0)} blocked by the knockout rule
(including the declared positive control and every WG concept fenced by WO2013061165A2),
{flag_counts.get('clear', 0)} clear and {flag_counts.get('adjacent', 0)} adjacent against the
pinned registry. The shortlist is the top {PER_DIRECTION} per direction, FV-solver-verified where a
kinetics claim exists, and sits behind proposal <code>{proposal.proposal_id}</code> pending human
review. Two scoring passes were byte-identical. These are coverage flags and evidence plans -
not patentability, efficacy or cost conclusions.</div>
<h2>1. Pinned registries</h2>
<p>{len(registries.prior_art_entries)} prior-art entries (retrieval-date pinned),
{len(registries.components['components'])} components (banned keys rejected by the loader),
{len(analogues)} catalog analogues with usable curves {usable}.</p>
{_table(pd.DataFrame([{"study": k, "geometry": a["geometry_tag"], "carrier_class": a["carrier_class"],
                       "active_solubility": a["active_solubility_class"], "usable_curves": a["n_curves"]}
                      for k, a in sorted(analogues.items())]))}
<h2>2. Prior-art flags</h2>
<p>Knockout = ai overlap AND (format OR coform overlap). Adjacent at S &ge; {ADJACENT_THRESHOLD}.
Nearest art for every concept is exported.</p>
{_table(blocked, columns=['concept_id', 'direction', 'format', 'partner', 'blocked_by']) if not blocked.empty else '<p class="small"><em>no blocked concepts</em></p>'}
<h2>3. Scored concepts</h2>
{_table(frame, columns=['concept_id', 'direction', 'format', 'carrier', 'partner', 'flag', 'nearest_art', 'S_nearest', 'novelty', 'india', 'compatibility', 'feasibility', 'priority'])}
<p class="small">Full export with transfer fields: <a href="v8_concepts.csv">v8_concepts.csv</a></p>
<h2>4. Analogue-transferred regions</h2>
<p>No sulfoxaflor release-kinetics study exists; every region is hypothesis-generating. Region =
[q25, q75] of calibrated D/L&sup2; per day widened by 1 + 0.5(1-w).</p>
{_table(pd.DataFrame([{k: t.get(k) for k in TRANSFER_COLUMNS} for t in transfers]),
        columns=['concept_id', 'analogue', 'w', 'region_low_per_day', 'region_high_per_day', 'feasibility', 'feasibility_reason'])}
<h2>5. Data-generation plans</h2>
{_table(dataplan, columns=['concept_id', 'test_id', 'acceptance', 'rationale_codes'])}
<p class="small">Patent/legal context appears only as rationale codes; bioassays are named as
partner experiments - the framework registers efficacy as not comparable.</p>
<h2>6. Shortlist and governance</h2>
{_table(shortlist_frame, columns=['concept_id', 'direction', 'format', 'carrier', 'partner', 'flag', 'S_nearest', 'india', 'feasibility', 'compatibility', 'priority', 'solver_verified'])}
<p>Proposal <code>{proposal.proposal_id}</code> is pending. Review with
<code>python3 -m scripts.review --show v8 {proposal.proposal_id}</code>, decide with
<code>--decide v8 {proposal.proposal_id} approved --reviewer "human:&lt;name&gt;"</code>, then re-run
with <code>--approve {proposal.proposal_id}</code> to render the recommendation. Agents never
self-approve.</p>
{recommendation}
<h2>9. Interpretation and reproduction</h2>
<p>Reproduce with <code>python3 -m scripts.run_v8_campaign</code> (CPU only, deterministic -
two scoring passes must agree byte-for-byte). Exports:
<a href="v8_concepts.csv">concepts</a> ·
<a href="v8_transfer.csv">transfer</a> ·
<a href="v8_dataplan.csv">data plan</a> ·
<a href="v8_shortlist.csv">shortlist</a> ·
<a href="v8_gate.json">gates</a>. The prior-art registry is not exhaustive; nothing here is a
freedom-to-operate, patentability, efficacy, toxicity or cost statement.</p>
</body></html>"""
    report = OUT / "v8_campaign.html"
    report.write_text(html)
    print(f"[7/7] report rendered: {report} ({time.perf_counter() - started:.1f} s total)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
