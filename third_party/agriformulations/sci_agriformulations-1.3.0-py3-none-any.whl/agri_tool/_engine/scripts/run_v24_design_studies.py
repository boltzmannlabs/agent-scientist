"""Reproduce synthetic whole-design comparisons against independent physical limits.

Run: python3 -m scripts.run_v24_design_studies
No chemical compatibility, measured formulation performance or field efficacy is implied.
"""
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys

import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from agriformulations.rnd import control, design_studies, simulation_models
from agriformulations.rnd.recipe_inputs import create


def main():
    recipes = [create({"name":f"Synthetic candidate {i+1}", "format":"SC", "mode":"fixed", "batch_g":1000,
        "process":"Numerical reference composition only; not a validated preparation method.",
        "ingredients":[{"name":"Reference active technical","role":"active","pct":pct,"purity_pct":95},
                       {"name":"Reference vehicle","role":"solvent","pct":100-pct,"purity_pct":100}]})["recipes"][0]
        for i,pct in enumerate([10,15,20])]
    request = {"name":"Synthetic handling and storage benchmark", "goal":"Check shared-condition specification decisions against independent physical calculations",
        "assumptions":["All coefficients are synthetic numerical assumptions, not measured properties or composition predictions."],
        "candidates":[{"recipe_id":r["recipe_id"], "active_name":r["active_components"][0]["name"],
            "inputs":{"flow":{"consistency_pa_sn":mu},"storage":{"reference_rate_per_day":rate}}}
            for r,mu,rate in zip(recipes,[.1,.5,1],[.01,.005,.001])],
        "scenarios":[{"id":"flow","model":"rheology","inputs":{"yield_stress_pa":0,"flow_index":1,
             "pipe_radius_mm":10,"pipe_length_m":5,"flow_l_min":5},"candidate_parameters":["consistency_pa_sn"]},
            {"id":"storage","model":"stability","inputs":{"temperatures_c":[25],"reference_temperature_c":25,"horizon_days":100},
             "candidate_parameters":["reference_rate_per_day"]}],
        "criteria":[{"scenario":"flow","metric":"pressure_bar","goal":"minimize","maximum":.8},
                    {"scenario":"storage","metric":"retention_at_first_temperature","goal":"maximize","minimum":.5}]}
    state = {"brief":{"name":"Synthetic design study reference"}, "recipes":recipes}
    original = design_studies.record(state, request)
    pressure_errors, retention_errors, replay_errors = [], [], []
    for candidate,mu,rate in zip(original["candidates"],[.1,.5,1],[.01,.005,.001]):
        exact_pressure = 8*mu*5*(5*.001/60)/(np.pi*.01**4)/1e5
        pressure_errors.append(abs(candidate["checks"][0]["value"]-exact_pressure))
        retention_errors.append(abs(candidate["checks"][1]["value"]-np.exp(-rate*100)))
        for case in candidate["cases"].values():
            replay = simulation_models.run(case["model"],case["inputs"],candidate["active_fraction"])
            replay_errors.extend(abs(v-replay["metrics"][k]) for k,v in case["metrics"].items() if isinstance(v,(float,int)))
    revision = deepcopy(request)
    revision["parent_study_id"] = original["study_id"]
    revision["candidates"][0]["inputs"]["storage"]["reference_rate_per_day"] = .001
    revision["assumptions"].append("The revised loss rate is a hypothetical parameter change, not evidence that the recipe improved.")
    updated = design_studies.record(state, revision)
    checks = {"poiseuille_max_abs_error":max(pressure_errors), "first_order_retention_max_abs_error":max(retention_errors),
              "direct_replay_max_abs_error":max(replay_errors),
              "correct_original_feasible_recipe":original["pareto_recipe_ids"] == [recipes[1]["recipe_id"]],
              "original_pass_count":original["summary"]["meeting_specifications"],
              "revised_pass_count":updated["summary"]["meeting_specifications"],
              "original_preserved":state["design_studies"][0] == original,
              "recipe_mass_balance":all(abs(sum(i["pct"] for i in r["ingredients"])-100)<1e-10 for r in recipes)}
    passed = (checks["poiseuille_max_abs_error"]<1e-12 and checks["first_order_retention_max_abs_error"]<1e-10 and
              checks["direct_replay_max_abs_error"]==0 and checks["correct_original_feasible_recipe"] and
              checks["original_pass_count"]==1 and checks["revised_pass_count"]==2 and checks["original_preserved"] and checks["recipe_mass_balance"])
    output = ROOT/"reports/v24"
    output.mkdir(exist_ok=True)
    manifest = {"engine_version":control.engine_version(),"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,
                "runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "evidence":"synthetic numerical verification; not measured formulation validation"}
    (output/"design_studies.json").write_text(json.dumps({"manifest":manifest,"passed":passed,"checks":checks,"studies":state["design_studies"]},indent=2,allow_nan=False))
    with (output/"comparison.csv").open("w",newline="") as stream:
        writer = csv.DictWriter(stream,fieldnames=["recipe","status","pareto","pressure_bar","retention"])
        writer.writeheader()
        for c in original["candidates"]:
            writer.writerow(dict(recipe=c["recipe_name"],status=c["status"],pareto=c["pareto"],pressure_bar=c["checks"][0]["value"],retention=c["checks"][1]["value"]))
    print(json.dumps({"passed":bool(passed),"checks":checks,"report":str(output/"design_studies.json")},indent=2))
    if not passed:
        raise SystemExit("Independent design-study verification failed")


if __name__ == "__main__":
    main()
