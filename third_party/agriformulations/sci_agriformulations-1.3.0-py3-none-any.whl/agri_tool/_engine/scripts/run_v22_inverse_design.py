"""Reproduce the AI/physics design examples and an independent diffusion check.

All inputs are synthetic numerical scenarios, not measured formulations.
Run: python3 -m scripts.run_v22_inverse_design
"""
import csv
import hashlib
import json
import platform
from pathlib import Path
import sys

import numpy as np
import scipy
from scipy.linalg import eigh

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from agriformulations.rnd import control, simulation_models
from agriformulations.physics.geometry import fv_operator


def independent_release(inputs, cells):
    """Volume-weighted finite-volume eigensystem, independent of eigenmode series."""
    operator, volumes = fv_operator(cells, inputs["geometry"])
    root = np.sqrt(volumes)
    symmetric = root[:, None] * operator / root[None, :]
    eigenvalues, eigenvectors = eigh(symmetric)
    tau = inputs["diffusivity_m2_s"] * inputs["horizon_days"] * 86400 / (inputs["length_um"] * 1e-6)**2
    retained = np.sum((eigenvectors.T @ root)**2 * np.exp(eigenvalues * tau)) / volumes.sum()
    return float(1 - retained)


def main():
    scenarios = {
        "newtonian_constraint":{},
        "viscosity_pressure_tradeoff":{
            "objectives":[{"metric":"pressure_bar","goal":"minimize","scale":1},
                          {"metric":"viscosity_at_100_s_pa_s","goal":"maximize","scale":1}]},
        "unreachable_specification":{
            "constraints":[{"metric":"viscosity_at_100_s_pa_s","minimum":3}]},
        "sphere_release_target":{
            "base_model":"geometry_release", "base_inputs":{"geometry":"sphere","diffusivity_m2_s":1e-16,"horizon_days":30},
            "variables":[{"parameter":"length_um","low":5,"high":500,"scale":"log"}],
            "objectives":[{"metric":"release_at_horizon","goal":"target","target":.65}],
            "constraints":[], "evaluations":32},
    }
    results = {name:simulation_models.run("inverse_design", request) for name, request in scenarios.items()}
    fluid = results["newtonian_constraint"]
    inputs = fluid["best_inputs"]
    q = inputs["flow_l_min"] * .001 / 60
    exact_pressure = 8 * .5 * inputs["pipe_length_m"] * q / (np.pi * (inputs["pipe_radius_mm"] * .001)**4) / 1e5
    sphere = results["sphere_release_target"]
    coarse = independent_release(sphere["best_inputs"], 40)
    fine = independent_release(sphere["best_inputs"], 80)
    analytic = sphere["best_metrics"]["release_at_horizon"]
    checks = {
        "newtonian_optimal_pressure_bar":float(exact_pressure),
        "newtonian_relative_optimality_gap":fluid["best_metrics"]["pressure_bar"] / exact_pressure - 1,
        "viscosity_specification_pass":fluid["best_metrics"]["viscosity_at_100_s_pa_s"] >= .5,
        "infeasible_search_has_empty_shortlist":results["unreachable_specification"]["shortlist"] == [],
        "sphere_target_error":abs(analytic - .65),
        "sphere_finite_volume_40_cells":coarse,
        "sphere_finite_volume_80_cells":fine,
        "sphere_finite_volume_refinement_delta":abs(fine - coarse),
        "sphere_independent_solver_absolute_error":abs(fine - analytic),
    }
    passed = (checks["viscosity_specification_pass"] and 0 <= checks["newtonian_relative_optimality_gap"] < .02
              and checks["infeasible_search_has_empty_shortlist"] and checks["sphere_target_error"] < .02
              and checks["sphere_independent_solver_absolute_error"] < .002
              and checks["sphere_finite_volume_refinement_delta"] < .002)
    report = {"evidence":"synthetic numerical verification; no experimental measurements", "engine_version":control.engine_version(),
              "checks":checks, "verification_pass":bool(passed), "requests":scenarios, "results":results}
    report["runtime"] = {"python":platform.python_version(), "numpy":np.__version__, "scipy":scipy.__version__}
    sources = [Path(__file__).relative_to(ROOT), Path("src/agriformulations/rnd/inverse_design.py"),
               Path("src/agriformulations/physics/geometry.py"), Path("src/agriformulations/rnd/simulation_models.py")]
    report["source_sha256"] = {str(path):hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in sources}
    output = ROOT / "reports" / "v22"
    output.mkdir(parents=True, exist_ok=True)
    (output / "inverse_design.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    rows = [{"scenario":name,**row} for name, result in results.items() for row in result["rows"]]
    columns = list(dict.fromkeys(k for row in rows for k in row))
    with (output / "search_history.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps({"verification_pass":bool(passed), **checks}, indent=2))
    if not passed:
        raise SystemExit("Inverse-design numerical checks failed")


if __name__ == "__main__":
    main()
