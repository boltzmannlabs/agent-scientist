"""Extraction adapter for the v2 fertilizer benchmark (Xiang et al. 2026).

Reads the publisher source workbook ``41467_2026_73922_MOESM7_ESM.xlsx``
(sheet ``Figure 3``: panels 3i-3n; sheet ``Supplementary Figure 14``: agarose
DN control panels a-c) cell by cell with per-row locators, and writes
``data/v2/fertilizer/{observations,release_replicates,claims}.csv`` plus
``study.json``.  Values are cumulative aqueous release percentages with three
replicate columns; no digitization, no smoothing, no generated observations.

Target restriction (docs/v2_protocol.md): aqueous Phe and Zn2+ cargo release
from the CMA/CTA DN gels only.  The pesticide (zhongshengmycin) series are
archived with ``in_target=False``; plant, pathogen, earthworm and germination
assays are not part of the release-model target and are registered as not
comparable.  PA in the protocol is L-phenylalanine (Phe).
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import openpyxl

REPO = Path(__file__).resolve().parents[2]
WORKBOOK = REPO / "research/v2_fertilizer/41467_2026_73922_MOESM7_ESM.xlsx"
OUT = REPO / "data" / "v2" / "fertilizer"

STUDY_ID = "xiang2026_dn_gel"
DOI = "10.1038/s41467-026-73922-3"

# Panel letters in sheet order with (analyte, formulation, in_target).
FIG3_PANELS = {
    "3i": ("Phe", "CMA_DN", True),
    "3j": ("pesticide", "CMA_DN", False),
    "3k": ("Zn2+", "CMA_DN", True),
    "3l": ("Phe", "CTA_DN", True),
    "3m": ("pesticide", "CTA_DN", False),
    "3n": ("Zn2+", "CTA_DN", True),
}
SUPP14_PANELS = {  # panel-analyte order ASSUMED to mirror Fig. 3 (registered)
    "14a": ("Phe", "agarose_DN", False),
    "14b": ("pesticide", "agarose_DN", False),
    "14c": ("Zn2+", "agarose_DN", False),
}
FIG3_START_ROWS = {"3i": 1, "3j": 12, "3k": 23, "3l": 34, "3m": 45, "3n": 56}
SUPP14_START_ROWS = {"14a": 1, "14b": 12, "14c": 23}
PH_GROUPS = [  # (condition_id, ph, time column, replicate columns)
    ("ph3", 3.0, 1, [2, 3, 4]),
    ("ph5", 5.0, 6, [7, 8, 9]),
    ("ph7", 7.0, 11, [12, 13, 14]),
]
N_DATA_ROWS = 8


def _sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _cell(sheet, row: int, column: int):
    return sheet.cell(row=row, column=column).value


def extract() -> None:
    workbook = openpyxl.load_workbook(WORKBOOK, data_only=True)
    fig3 = workbook["Figure 3"]
    supp14 = workbook["Supplementary Figure 14"]

    observation_rows, replicate_rows = [], []
    anova = {}

    def pull(sheet, panel, start_row, analyte, formulation, in_target, sheet_name):
        for condition_id, ph, time_col, rep_cols in PH_GROUPS:
            time_letter = sheet.cell(row=start_row + 1, column=time_col).coordinate[:1]
            first = sheet.cell(row=start_row + 2, column=rep_cols[0]).coordinate
            last = sheet.cell(row=start_row + 1 + N_DATA_ROWS, column=rep_cols[-1]).coordinate
            curve_id = f"{STUDY_ID}__{formulation}__{analyte}__{condition_id}"
            for offset in range(N_DATA_ROWS):
                row_index = start_row + 2 + offset
                time_h = float(_cell(sheet, row_index, time_col))
                values = [float(_cell(sheet, row_index, col)) for col in rep_cols]
                locator = (
                    f"{WORKBOOK.name}::'{sheet_name}'!{first}:{last}; "
                    f"panel {panel}; {condition_id}; t={time_h:g} h"
                )
                mean = sum(values) / len(values)
                sd = math.sqrt(sum((v - mean) ** 2 for v in values) / (len(values) - 1))
                common = {
                    "study_id": STUDY_ID,
                    "formulation_id": formulation,
                    "condition_id": condition_id,
                    "curve_id": curve_id,
                    "time": time_h,
                    "time_unit": "h",
                    "unit": "%",
                    "ph": ph,
                    "temperature_c": None,
                    "condition_name": f"aqueous release at pH {ph:g}",
                    "source_locator": locator,
                    "evidence_kind": "author_source_data_mean",
                    "sd": round(sd, 6),
                    "n_replicates": 3,
                    "endpoint": "cumulative_release",
                    "panel": panel,
                    "analyte": analyte,
                    "in_target": in_target,
                }
                observation_rows.append({**common, "value": round(mean, 6)})
                for replicate_index, value in enumerate(values, start=1):
                    replicate_rows.append(
                        {
                            **common,
                            "replicate_id": replicate_index,
                            "value": value,
                            "source_locator": locator
                            + f"; replicate {replicate_index}",
                        }
                    )
        # ANOVA block: endpoint statistics at 168 h across the three pH groups.
        anova[panel] = {
            "formulation": formulation,
            "analyte": analyte,
            "ss_between": float(_cell(sheet, start_row + 2, 17)),
            "ss_within": float(_cell(sheet, start_row + 3, 17)),
            "df_between": int(_cell(sheet, start_row + 2, 18)),
            "df_within": int(_cell(sheet, start_row + 3, 18)),
            "F": float(_cell(sheet, start_row + 2, 20)),
            "locator": f"{WORKBOOK.name}::'{sheet_name}'!Q{start_row + 2}:T{start_row + 3}",
        }

    for panel, (analyte, formulation, in_target) in FIG3_PANELS.items():
        pull(fig3, panel, FIG3_START_ROWS[panel], analyte, formulation, in_target, "Figure 3")
    for panel, (analyte, formulation, in_target) in SUPP14_PANELS.items():
        pull(supp14, panel, SUPP14_START_ROWS[panel], analyte, formulation, in_target, "Supplementary Figure 14")

    # --- claims ledger -------------------------------------------------
    claims = []

    def claim(**kwargs):
        row = {
            "study_id": STUDY_ID,
            "metric": "",
            "time": 168,
            "time_unit": "h",
            "unit": "%",
            "tolerance": "",
            "evidence_kind": "published_text",
            "claim_type": "",
            "claim_text": "",
            "status": "eligible",
            "comparison_scope": "",
        }
        row.update(kwargs)
        claims.append(row)

    # Endpoint anchors: no printed endpoint table exists in the paper; the
    # anchor is the author source-data mean, used for the forecast audit.
    for row in observation_rows:
        if row["time"] != 168.0:
            continue
        claim(
            claim_id=f"endpoint168_{row['formulation_id']}_{row['analyte']}_{row['condition_id']}",
            formulation_id=row["formulation_id"],
            condition_id=row["condition_id"],
            analyte=row["analyte"],
            metric="cumulative_release",
            reported_value=row["value"],
            tolerance=0.005,
            source_locator=row["source_locator"],
            evidence_kind="workbook_derived_mean",
            claim_type="endpoint_anchor",
            claim_text="168 h endpoint from author source-data replicates; no printed endpoint table exists.",
            status="eligible_for_forecast_audit",
            comparison_scope="Extraction-internal regression anchor plus forecast audit; not a printed paper value.",
        )

    prose_50 = (
        "Specifically, at pH 3, the Phe release rate exceeded 50% for both CMA and CTA DN gels "
        "(Fig. 3i, l)"
    )
    for formulation in ("CMA_DN", "CTA_DN"):
        claim(
            claim_id=f"phe_over50_ph3_{formulation}",
            formulation_id=formulation,
            condition_id="ph3",
            analyte="Phe",
            metric="endpoint_168h_gte",
            reported_value=50,
            tolerance=5,
            source_locator="Article Results: Acid-responsive and drug release; Fig. 3i/l",
            claim_type="prose_inequality",
            claim_text=prose_50,
        )
    prose_75 = (
        "while the release rates of pesticide and Zn2+ were both over 75% for both CMA and CTA DN gels "
        "(Fig. 3j, k, m, n)"
    )
    for formulation in ("CMA_DN", "CTA_DN"):
        for analyte in ("pesticide", "Zn2+"):
            claim(
                claim_id=f"over75_ph3_{formulation}_{analyte}",
                formulation_id=formulation,
                condition_id="ph3",
                analyte=analyte,
                metric="endpoint_168h_gte",
                reported_value=75,
                tolerance=5,
                source_locator="Article Results: Acid-responsive and drug release; Fig. 3j/k/m/n",
                claim_type="prose_inequality",
                claim_text=prose_75,
            )
    rank_prose = (
        "Moreover, the release rate of Phe and Zn2+ from the CTA DN gels was higher than that from the "
        "CMA DN gels, likely due to the higher number of carboxyl groups on citric acid"
    )
    for analyte in ("Phe", "Zn2+"):
        for condition_id in ("ph3", "ph5", "ph7"):
            claim(
                claim_id=f"rank_cta_gt_cma_{analyte}_{condition_id}",
                formulation_id="CTA_DN",
                condition_id=condition_id,
                analyte=analyte,
                metric="rank_cta_gt_cma_at_168h",
                reported_value="",
                source_locator="Article Results: Acid-responsive and drug release; Fig. 3i-n",
                claim_type="rank_claim",
                claim_text=rank_prose,
                comparison_scope="CTA_DN>CMA_DN",
            )
    agarose_prose = (
        "However, the cumulative release rates of all components in the agarose DN gels at pH 3 "
        "remained below 50%, which was significantly lower than those of the CMA/CTA DN gels"
    )
    for panel, (analyte, _, _) in SUPP14_PANELS.items():
        claim(
            claim_id=f"agarose_below50_ph3_{analyte}",
            formulation_id="agarose_DN",
            condition_id="ph3",
            analyte=analyte,
            metric="endpoint_168h_lte",
            reported_value=50,
            tolerance=5,
            source_locator="Article Results: Acid-responsive and drug release; Supplementary Fig. 14",
            claim_type="agarose_below_50",
            claim_text=agarose_prose
            + f" Panel-analyte mapping for Supplementary Fig. 14 ({panel}) assumed to mirror Fig. 3 order.",
            comparison_scope="assumed_panel_mapping",
        )
    for panel, stats in anova.items():
        if panel not in FIG3_PANELS:
            continue
        claim(
            claim_id=f"anova_F_{panel}",
            formulation_id=stats["formulation"],
            condition_id="",
            analyte=stats["analyte"],
            metric="anova_F",
            reported_value=round(stats["F"], 6),
            tolerance=0.005,
            source_locator=stats["locator"],
            evidence_kind="published_table",
            claim_type="anova_F",
            claim_text=f"Workbook one-way ANOVA F at 168 h across pH groups (df {stats['df_between']},{stats['df_within']}).",
        )
    claim(
        claim_id="bio_assays_not_comparable",
        metric="",
        time="",
        reported_value="",
        source_locator="Article Figs. 4-9; antibacterial, wilt control, plant-growth, earthworm, germination assays",
        evidence_kind="published_metric",
        claim_type="target_mismatch",
        claim_text="Biological efficacy and safety endpoints are not inferable from aqueous release modelling.",
        status="not_comparable",
        comparison_scope="Release-model target excludes in vivo and antimicrobial endpoints.",
    )
    claim(
        claim_id="rhodamine_qualitative_not_comparable",
        metric="",
        time="",
        reported_value="",
        source_locator="Article Fig. 2; rhodamine B fluorescence release",
        evidence_kind="published_metric",
        claim_type="target_mismatch",
        claim_text="Qualitative dye-fluorescence acid-responsiveness; no numerical cargo-release series.",
        status="not_comparable",
        comparison_scope="Different analyte and readout.",
    )

    # --- write ----------------------------------------------------------
    import pandas as pd

    OUT.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(observation_rows).to_csv(OUT / "observations.csv", index=False)
    pd.DataFrame(replicate_rows).to_csv(OUT / "release_replicates.csv", index=False)
    pd.DataFrame(claims).to_csv(OUT / "claims.csv", index=False)

    study = {
        "study_id": STUDY_ID,
        "title": "A pH-responsive double network hydrogel for the efficient and sustainable control of tomato bacterial wilt",
        "authors": "Xiang et al.",
        "year": 2026,
        "journal": "Nature Communications",
        "doi": DOI,
        "url": f"https://doi.org/{DOI}",
        "publication_date": "2026-06-12",
        "domain": "fertilizer",
        "category": "fertilizer/delivery",
        "active": "L-phenylalanine (Phe) and Zn2+",
        "carrier": "CMA DN / CTA DN double-network hydrogels (0.5% w/v; 6.5 mg/mL Phe; 12 mM ZnCl2)",
        "license": "CC BY 4.0 (article)",
        "source_url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-026-73922-3/MediaObjects/41467_2026_73922_MOESM7_ESM.xlsx",
        "selection_reason": (
            "Data-accessible 2026 nutrient-cargo hydrogel with author numerical replicates at three pH "
            "levels; selected per docs/v2_protocol.md before any v2 model run."
        ),
        "counts": {
            "release_means": len(observation_rows),
            "release_replicates": len(replicate_rows),
            "release_series": len({r["curve_id"] for r in observation_rows}),
            "in_target_series": len({r["curve_id"] for r in observation_rows if r["in_target"]}),
            "unique_times_per_series": N_DATA_ROWS,
            "registered_claims": len(claims),
        },
        "target_contract": {
            "analytes_in_target": ["Phe", "Zn2+"],
            "medium": "aqueous solutions at pH 3, 5 and 7",
            "denominator": "percent of own cargo loading; loading not independently measured",
            "cumulative": True,
            "normalization": "none",
            "pesticide_excluded_reason": "zhongshengmycin series archived (in_target=False); protocol restricts target to Zn/PA cargo",
            "plant_pathogen_assays_excluded": True,
        },
        "equations": {
            "release": "No release kinetic equation claimed by the authors; curve fits are our benchmarks.",
            "anova": "One-way ANOVA at the 168 h endpoint across the three pH groups (3 x 3 replicates).",
        },
        "cautions": [
            "Release-assay temperature is not stated in the article text; temperature_c remains null.",
            "Supplementary Figure 14 panel-analyte mapping assumed to mirror Figure 3 order (a=Phe, b=pesticide, c=Zn2+); registered as an assumption.",
            "No t=0 sample: first time point is 12 h with a visible initial burst; persistence baselines start from the 12 h observation.",
            "ANOVA statistics are defined at the 168 h endpoint across pH groups, not over release curves.",
            "Release medium volume and sampling schedule are not stated; no perfect-sink volume claim is made.",
        ],
        "source_files": {
            "41467_2026_73922_MOESM7_ESM.xlsx": {
                "path": "research/v2_fertilizer/41467_2026_73922_MOESM7_ESM.xlsx",
                "sha256": _sha256(WORKBOOK),
                "bytes": WORKBOOK.stat().st_size,
            },
            "article_2026.txt": {
                "path": "research/v2_fertilizer/article_2026.txt",
                "sha256": _sha256(REPO / "research/v2_fertilizer/article_2026.txt"),
            },
            "article.html": {
                "path": "research/v2_fertilizer/article.html",
                "sha256": _sha256(REPO / "research/v2_fertilizer/article.html"),
            },
        },
        "extraction": "Direct openpyxl cell reads with per-row locators; no digitization or generated values.",
        "limitations": [
            "Single study, two gel recipes, three pH conditions; not an external validation dataset.",
            "Percent-of-own-loading denominators are not independently measured loadings.",
            "Agarose control series are out of target and used only for the below-50 prose audit.",
        ],
    }
    with open(OUT / "study.json", "w") as handle:
        json.dump(study, handle, indent=1, sort_keys=True)

    # Extraction self-checks (fail loudly rather than emit a broken dataset).
    times = sorted({r["time"] for r in observation_rows})
    assert times == [12.0, 24.0, 48.0, 72.0, 96.0, 120.0, 144.0, 168.0], times
    assert len(observation_rows) == 27 * 8, len(observation_rows)
    assert len(replicate_rows) == len(observation_rows) * 3
    expected = {"3i": 57.98, "3k": 75.50, "3l": 69.58, "3n": 89.17}
    for panel, value in expected.items():
        analyte, formulation, _ = FIG3_PANELS[panel]
        row = next(
            r for r in observation_rows
            if r["panel"] == panel and r["condition_id"] == "ph3" and r["time"] == 168.0
        )
        assert abs(row["value"] - value) < 0.01, (panel, row["value"], value)
    print(
        f"fertilizer extraction: {len(observation_rows)} means, {len(replicate_rows)} replicates, "
        f"{len(claims)} claims -> {OUT}"
    )


if __name__ == "__main__":
    extract()
