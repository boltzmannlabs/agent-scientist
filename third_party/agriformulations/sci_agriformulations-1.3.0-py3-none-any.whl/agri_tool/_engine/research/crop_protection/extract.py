"""Extract published table values; no digitization or synthetic labels."""
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET
import csv, hashlib, json

ROOT=Path(__file__).resolve().parents[2]
RESEARCH=ROOT/"research/crop_protection"
OUT=ROOT/"data/crop_protection"
DOC=RESEARCH/"41598_2024_53820_MOESM1_ESM.docx"
XLS=RESEARCH/"41598_2024_53820_MOESM2_ESM.xlsx"
DOI="10.1038/s41598-024-53820-8"
URL="https://www.nature.com/articles/s41598-024-53820-8"
NS={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

def celltext(cell):
    return "".join(t.text or "" for t in cell.findall(".//w:t", NS)).strip()

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    root=ET.fromstring(ZipFile(DOC).read("word/document.xml"))
    tables=root.findall(".//w:tbl",NS)
    conditions=[
        ("ph5",5.0,25.0,"water",0.0),
        ("ph7",7.0,25.0,"water",0.0),
        ("ph9",9.0,25.0,"water",0.0),
        ("temp25",None,25.0,"water",0.0),
        ("temp35",None,35.0,"water",0.0),
        ("temp45",None,45.0,"water",0.0),
        ("nacl001",None,None,"NaCl",0.01),
        ("nacl003",None,None,"NaCl",0.03),
        ("cacl2001",None,None,"CaCl2",0.01),
    ]
    records=[]
    for ti,carrier in [(2,"MMT1"),(3,"MMT2")]:
        for ri,row in enumerate(tables[ti].findall("w:tr",NS)):
            cells=[celltext(c) for c in row.findall("w:tc",NS)]
            if not cells or not cells[0].replace(".","",1).isdigit():
                continue
            day=float(cells[0])
            for j,(cid,ph,temp,salt,molarity) in enumerate(conditions):
                ci=2+2*j
                raw=cells[ci]
                missing=raw in ("-","")
                value=spread=None
                status="missing_bead_disintegration" if missing else "accepted"
                note=""
                if not missing:
                    value,spread=map(float,raw.split("±"))
                if carrier=="MMT2" and cid=="temp45" and day==38:
                    status="excluded_suspected_published_typo"
                    note="Published mean 4967 mg/g is discontinuous and exceeds 1000 mg/g; preserved without guessed decimal correction."
                records.append(dict(
                    study_id="paul_2024_24d",doi=DOI,category="crop_protection",
                    active_ingredient="2,4-D",formulation_id=carrier,
                    condition_id=cid,curve_id=f"paul_2024_24d__{carrier}__{cid}",
                    time_day=day,cumulative_release_mg_g=value,
                    reported_plusminus_mg_g=spread,uncertainty_type="unspecified_plusminus",
                    ph=ph,temperature_c=temp,salt=salt,salt_molarity=molarity,
                    medium="repeated_water_replacement",
                    source_table=f"S{ti+1}",source_row_1based=ri+1,
                    source_cell_1based=f"table_{ti+1}:row_{ri+1}:cell_{ci+1}",
                    raw_source_value=raw,included_in_models=status=="accepted",
                    qc_status=status,qc_note=note,source_url=URL
                ))
    with (OUT/"release_observations.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]))
        writer.writeheader();writer.writerows(records)
    accepted=[r for r in records if r["included_in_models"]]
    with (OUT/"release_model_input.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]))
        writer.writeheader();writer.writerows(accepted)
    manifest=dict(study_id="paul_2024_24d",doi=DOI,article_url=URL,publication_date="2024-02-20",
        accessed_utc="2026-10-19",files={p.name:{"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size}
            for p in (DOC,XLS)},
        extraction="Python standard-library XML extraction from DOCX tables S3/S4, direct values.",
        rows_total=len(records),rows_accepted=len(accepted),
        curves=len({r["curve_id"] for r in records}),
        unit="cumulative mg active ingredient per g formulation; do not relabel as percent",
        condition_metadata="pH experiments explicitly at 25 C; unspecified pH for temperature/salt experiments retained null. Temperature not explicitly stated for salt experiments retained null.",
        missingness="Hyphens reflect source omission after bead dissolution for NaCl; not replaced by zero.",
        uncertainty="Plus/minus preserved; no SD/SE interpretation imposed. Study reports two experimental replicates.",
        scope="Independent recent 2024 observed-curve archive; primary reproduction candidate selected elsewhere may be newer.")
    (OUT/"provenance.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps({k:manifest[k] for k in ("rows_total","rows_accepted","curves")}))
    print("Rejected source typo:",[r["source_cell_1based"] for r in records if r["qc_status"].startswith("excluded")])

if __name__=="__main__":
    main()
