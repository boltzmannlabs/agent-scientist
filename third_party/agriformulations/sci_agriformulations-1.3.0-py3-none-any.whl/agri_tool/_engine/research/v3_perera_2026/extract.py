"""Extraction adapter for the Perera et al. 2026 RSC Advances benchmark.

User-directed addition (2026-10-19): the user asked for benchmarks from more
recent work.  This study passes the frozen screening criteria in a declared
modified form: machine-readable kinetic-parameter table (PMC full text),
composition at ratio level, assay stated, unambiguous target - but the RAW
release series sit in RSC ESI behind an access wall, so this enters as a
FIT-STATISTICS benchmark (the photolysis precedent): the 27 reported
Korsmeyer-Peppas (n, k) pairs are registered claims, never observations, and
the audit applies the paper's own equation M_t/M_inf = k t^n to the reported
parameters to flag physically impossible combinations.  observations.csv is
intentionally header-only: no raw series, no fabricated points.
"""

from __future__ import annotations

import hashlib
import json
import re
import xml.etree.ElementTree  # noqa: F401  (kept for symmetry with siblings)
from html import unescape
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[2]
ARTICLE = REPO / "research/v3_perera_2026/article.html"
OUT = REPO / "data" / "v3" / "perera_2026"

STUDY_ID = "perera2026_oxerp_hydrogel"
DOI = "10.1039/d6ra03574d"
OBSERVATION_COLUMNS = [
    "study_id", "formulation_id", "condition_id", "curve_id", "time", "time_unit",
    "value", "unit", "ph", "temperature_c", "condition_name", "source_locator",
    "evidence_kind", "endpoint", "analyte", "in_target", "included_primary", "qc_status",
]
# Bead compositions from Table 1 (nano-Ox-ERP w/w% x HA w/w%)
COMPOSITION = {
    "B1": (20, 1), "B2": (20, 2), "B3": (20, 3),
    "B4": (40, 1), "B5": (40, 2), "B6": (40, 3),
    "B7": (80, 1), "B8": (80, 2), "B9": (80, 3),
}
PH_CONDITIONS = {"A": ("acidic", 3.5), "N": ("neutral", 7.0), "B": ("basic", 8.5)}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _tables(html: str) -> list[list[list[str]]]:
    parsed = []
    for table in re.findall(r"<table[^>]*>.*?</table>", html, re.S):
        rows = []
        for row in re.findall(r"<tr[^>]*>(.*?)</tr>", table, re.S):
            cells = [
                unescape(re.sub(r"<[^>]+>", "", cell)).strip()
                for cell in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)
            ]
            if cells:
                rows.append(cells)
        parsed.append(rows)
    return parsed


def extract() -> None:
    html = ARTICLE.read_text()
    tables = _tables(html)
    kinetic = next(t for t in tables if any("Release exponent" in " ".join(r) for r in t[:2]))

    claims = []
    for row in kinetic[2:]:
        bead, n_a, n_n, n_b, k_a, k_n, k_b = row
        for suffix, (label, ph) in PH_CONDITIONS.items():
            n_value = float({"A": n_a, "N": n_n, "B": n_b}[suffix])
            k_value = float({"A": k_a, "N": k_n, "B": k_b}[suffix])
            claims.append(
                {
                    "claim_id": f"kp_{bead}_{suffix}",
                    "study_id": STUDY_ID,
                    "formulation_id": bead,
                    "condition_id": f"{label}_pH{ph}",
                    "analyte": "phosphate",
                    "metric": "kp_n",
                    "time": "",
                    "time_unit": "h",
                    "reported_value": n_value,
                    "auxiliary_k": k_value,
                    "unit": "dimensionless",
                    "tolerance": 5e-5,  # half the final printed decimal (4 dp)
                    "source_locator": f"PMC13439622 Table (Korsmeyer-Peppas n and k); formulation {bead}; {label} medium",
                    "evidence_kind": "published_fitted",
                    "claim_type": "fit_statistic",
                    "claim_text": f"Reported Korsmeyer-Peppas n={n_value}, k={k_value} for bead {bead} in {label} medium.",
                    "status": "eligible",
                    "comparison_scope": "model-consistency audit: the paper's own equation applied to the reported pair",
                }
            )

    OUT.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(columns=OBSERVATION_COLUMNS).to_csv(OUT / "observations.csv", index=False)
    pd.DataFrame(claims).to_csv(OUT / "claims.csv", index=False)

    def _fraction(value_pct: float, name: str) -> dict:
        return {
            "id": f"{STUDY_ID}__frac_{name}",
            "name": f"{name} w/w fraction",
            "value": value_pct / 100.0,
            "unit": "1",
            "provenance": {
                "kind": "published_measured",
                "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC13439622/",
                "locator": "Table 1 (bead composition)",
                "method": None,
                "parent_ids": [],
                "notes": "recipe-declared w/w percent",
            },
            "uncertainty": None,
        }

    ontology_formulations = [
        {
            "formulation_id": bead,
            "study_id": STUDY_ID,
            "geometry": "sphere",
            "characteristic_length": None,
            "ingredients": [
                {"name": "nano oxalic-acid-modified Eppawala rock phosphate", "role": "active",
                 "cas": None, "mass_fraction": _fraction(erp, "nano_ox_erp"), "particle_d50": None,
                 "loading": None, "crosslink_density": None},
                {"name": "humic acid", "role": "filler",
                 "cas": None, "mass_fraction": _fraction(ha, "humic_acid"), "particle_d50": None,
                 "loading": None, "crosslink_density": None},
                {"name": "sodium alginate / carboxymethyl cellulose matrix", "role": "matrix",
                 "cas": None, "mass_fraction": None, "particle_d50": None,
                 "loading": None, "crosslink_density": None},
            ],
            "process": [],
            "data_source": "literature",
            "notes": f"Bead {bead}: {erp} w/w% nano-Ox-ERP, {ha} w/w% humic acid (recipe fractions).",
        }
        for bead, (erp, ha) in COMPOSITION.items()
    ]

    study = {
        "schema_version": "1.0",
        "study_id": STUDY_ID,
        "title": "A sustainable pH responsive hydrogel-based phosphorus fertilizer using nano oxalic acid-modified rock phosphate and humic acid",
        "authors": "Perera et al.",
        "year": 2026,
        "journal": "RSC Advances",
        "doi": DOI,
        "url": "https://doi.org/" + DOI,
        "data_source": "literature",
        "ingest_channel": "user_directed_2026-10-19_newer_benchmarks",
        "selection_reason": (
            "2026 study with a machine-readable 9-bead x 3-pH Korsmeyer-Peppas parameter table "
            "and composition table; raw release series inaccessible (RSC ESI), so it enters as a "
            "fit-statistics claims benchmark - the v1 screening exclusion is superseded in scope, "
            "not in kind: parameters are never treated as observations."
        ),
        "counts": {
            "release_means": 0,
            "release_series": 0,
            "registered_claims": len(claims),
            "formulations": len(COMPOSITION),
        },
        "target_contract": {
            "analytes_in_target": ["phosphate"],
            "medium": "acidic/neutral/basic aqueous media (HCl/NaOH standardized)",
            "denominator": "fractional phosphorus release of encapsulated load",
            "cumulative": True,
            "normalization": "none",
            "raw_series_accessible": False,
        },
        "protocols": [
            {
                "protocol_id": f"{STUDY_ID}_immersion",
                "assay_type": "immersion_release",
                "target": "cumulative_phosphorus_release",
                "unit": "fraction",
                "time_unit": "h",
                "medium": "aqueous, standardized HCl/NaOH",
                "temperature_c": None,
                "ph": None,
                "sink_condition": "unknown",
                "bath_to_sample_ratio": None,
                "sampling_scheme": "separate sample sets per interval; 24/48/72 h then daily to 15 days; 1.0 mL aliquots",
            }
        ],
        "equations": {
            "release": "M_t/M_inf = k * t^n (Korsmeyer-Peppas, as reported by the authors)",
        },
        "ontology": {"formulations": ontology_formulations},
        "source_files": {
            "article.html": {
                "path": "research/v3_perera_2026/article.html",
                "sha256": _sha256(ARTICLE),
                "note": "PMC13439622 full text; kinetic and composition tables parsed from HTML",
            }
        },
        "extraction": "HTML table parse of the PMC full text; no digitization; parameters are published_fitted values.",
        "cautions": [
            "Raw release series are in RSC ESI behind an access wall; no observations are registered and none are generated from the parameters.",
            "The B2 neutral-medium k value is an order of magnitude above its neighbours; the consistency audit flags rather than corrects it.",
            "v1 screening had excluded this study from raw-data benchmarks; it now enters as a claims-only benchmark at the user's direction.",
        ],
        "limitations": [
            "Fit statistics are audit targets, never observations (v2 rule).",
            "No curve-level forecast or transfer experiments are possible without the raw series.",
        ],
    }
    with open(OUT / "study.json", "w") as handle:
        json.dump(study, handle, indent=1, sort_keys=True)

    assert len(claims) == 27, len(claims)
    b2 = next(c for c in claims if c["claim_id"] == "kp_B2_N")
    assert b2["auxiliary_k"] == 1.0896
    print(f"perera extraction: 0 observations (raw series inaccessible), {len(claims)} fit-statistic claims -> {OUT}")


if __name__ == "__main__":
    extract()
