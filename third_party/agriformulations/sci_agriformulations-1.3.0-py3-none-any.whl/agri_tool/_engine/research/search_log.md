# Literature screening and extraction log

Search date: 2026-10-19 UTC. Queries covered 2025–2026 controlled-release fertilizers, hydrogels with kinetic tables, and biopesticides with publisher source data. Searches were purposive rather than a systematic literature review; “latest” means recent retrieved candidates, not proof of exhaustive coverage.

| Paper | Published | Access observed and decision |
|---|---|---|
| Zhang et al., *Sustainable pest management using plant secondary metabolites regulated azadirachtin nano-assemblies*, [DOI 10.1038/s41467-025-57028-w](https://www.nature.com/articles/s41467-025-57028-w) | 2025-02-18 | Open article and authentic publisher XLSX downloaded. Selected crop-protection dataset. |
| Perera et al., *A sustainable pH responsive hydrogel-based phosphorus fertilizer using nano oxalic acid-modified rock phosphate and humic acid*, [DOI 10.1039/d6ra03574d](https://pubmed.ncbi.nlm.nih.gov/42559034/) | Article 2026-08-05; issue 2026-08-26 | PMC full text and nine formulation × three pH kinetic-parameter table found. Supplementary raw curves were not extracted. Recent alternative, not a raw-data benchmark. |
| He et al., *Data-driven rational design of hydrogel slow-release fertilizers: Integrating machine learning and Bayesian optimization*, [DOI 10.1016/j.colsurfa.2026.140633](https://www.sciencedirect.com/science/article/abs/pii/S0927775726011726) | 2026-09-05 | Abstract preview; full text and raw observations not verified. Excluded from computational replication. |
| Nandal et al., *Synthesis and characterization of κ-carrageenan and guar gum-based hydrogels for controlled release fertilizers: Optimization, release kinetics, and agricultural impact*, [DOI 10.1016/j.indcrop.2025.120587](https://www.sciencedirect.com/science/article/pii/S0926669025001335) | 2025-03 | Publisher preview identifies confidential data. Excluded for inaccessible observations. |

## Selected AZA evidence

[Source workbook](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-57028-w/MediaObjects/41467_2025_57028_MOESM4_ESM.xlsx), [supplement](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-57028-w/MediaObjects/41467_2025_57028_MOESM1_ESM.pdf).

Two carriers (tannic acid or phenylalanine), three pH values, nine times, and three replicates give 54 means and 162 replicate values. Methods specify 25°C, 100 rpm, 5 mL suspension dialyzed into 100 mL phosphate buffer, with 0.5 mL replacement sampling and HPLC analysis. Nonzero time-zero values are preserved.

At 96 h and pH 5, the narrative states 65.57%/89.31%; source means are 81.74703%/98.09281% for AT/AP. The narrative values resemble 48 h source values. Figure 6 and Supplementary Figure 3 agree on the source endpoints. Supplied means differ from recomputed triplicate means by at most 0.00879 percentage points; supplied SE differs by up to 1.49515 percentage points. Figure 6 fit metadata include adjusted R² above one. These remain source discrepancies.

The article states CC BY-NC-ND 4.0; inspect workbook-specific reuse terms before commercial redistribution.

## Extraction and independent checks

- Raw files reside in data/raw/azadirachtin_2025_*; SHA-256 and URLs are in research/azadirachtin_2025_manifest.json.
- research/tools/extract_azadirachtin_2025.py reads workbook XML using Python standard library. Every CSV row includes source sheet and cell address.
- data/curated/azadirachtin_2025_release.csv preserves supplied averages/SE and separately recomputes mean/SE. Replicates are also stored as a long CSV.
- data/curated/azadirachtin_2025_reported_fits.csv stores published fit claims separately from observations.
- No plot digitization, equation-generated measurements, curve smoothing, or interpolation was used to create observed data.
- Analyst check: unweighted least-squares Higuchi-with-intercept fits to all nine provided means return R² 0.662–0.879. The authors’ complete fit weighting/subset is unresolved; published fit R² cannot be assumed reproduced.
- Calibration is not independent validation. Six curves support a narrow pilot; field efficacy, yield, safety, and transfer to new chemistries remain untested.

## Recent RSC alternative

The 2026 RSC study combines alginate/CMC, activated rock phosphate, and humic acid. Its printed table provides n/k parameters rather than an independently extractable time-series dataset. The B2-neutral rate constant 1.0896 is anomalous relative to neighboring entries and should be checked against supporting material. Do not generate training observations from these fitted constants and label them measurements.

## v2 selection registry (2026-10-19, frozen before any v2 model run)

Selection for the three-paper v2 benchmark (docs/v2_protocol.md). Data access outranked recency; no study was replaced after seeing model results.

| Paper | Published | Access observed and decision |
|---|---|---|
| Paul et al., *Controlled release herbicide formulation for effective weed control efficacy*, [DOI 10.1038/s41598-024-53820-8](https://doi.org/10.1038/s41598-024-53820-8) | 2024-02-20 | Open supplement with condition-resolved numerical tables S3/S4 (2,4-D desorption, mg/g). Carried in from the v1 archive as the frozen herbicide study; 18 curves × 16 times extracted. |
| Tang et al., *Deposition and water repelling of temperature-responsive nanopesticides on leaves*, [DOI 10.1038/s41467-023-41878-3](https://doi.org/10.1038/s41467-023-41878-3) | 2023-10-12 | Author source-data ZIP with replicate workbooks (release, photolysis, nanoparticle recipe sweeps). Selected as the frozen fungicide/TEB study; preferred over newer studies whose supplements were inaccessible. |
| Xiang et al., *A pH-responsive double network hydrogel for the efficient and sustainable control of tomato bacterial wilt*, [DOI 10.1038/s41467-026-73922-3](https://doi.org/10.1038/s41467-026-73922-3) | 2026-06-12 | Open MOESM7 workbook with per-cell replicates for Fig. 3i–n and Supplementary Fig. 14 (12, 24, 48, 72, 96, 120, 144, 168 h × 3 replicates × 3 pH). Selected as the frozen fertilizer/delivery study. Target restricted per protocol to aqueous Phe (the protocol's PA) and Zn2+ cargo release; the zhongshengmycin series are archived out of target; the paper's primary subject is bacterial-wilt management, so its release data are not fertilizer-efficacy validation. |
| Unnamed 2025 rhizobacteria-protective hydrogel, [DOI 10.1038/s41467-025-56988-3](https://doi.org/10.1038/s41467-025-56988-3) | 2025 | Article and MOESM4 retrieved during v2 screening. Release evidence is bacterial imaging, not numerical cargo-release series. **Excluded** from the raw-data benchmark; files retained under research/v2_fertilizer/ with hash pinned in tests/test_v2_benchmark.py. |

No pathogen or plant experiments are part of the release-model target for any v2 study.
