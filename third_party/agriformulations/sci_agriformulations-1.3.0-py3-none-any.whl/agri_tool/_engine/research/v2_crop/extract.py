"""Extract author-supplied numerical source data; no plot digitization or invented observations."""
import csv
import hashlib
import json
from pathlib import Path
from statistics import mean, stdev
import zipfile
import openpyxl

BASE = Path(__file__).resolve().parent
OUT = BASE.parents[1] / "data/v2/crop"
STUDY = "tang2023_tebuconazole"
DOI = "10.1038/s41467-023-41878-3"
URL = "https://www.nature.com/articles/s41467-023-41878-3"
SOURCE_URL = "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-023-41878-3/MediaObjects/41467_2023_41878_MOESM4_ESM.zip"

def write(name, rows):
    with (OUT/name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def load(name):
    return openpyxl.load_workbook(next((BASE/"teb2023_source").rglob(name)), data_only=True)

def extract():
    OUT.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE/"teb2023_source.zip") as z:
        z.extractall(BASE/"teb2023_source")
    release, reps, photo, photo_reps, recipes, recipe_reps = [], [], [], [], [], []
    wb = load("Figure 3.xlsx")
    for sheet, conditions in [
        ("Figure 3a", [(6.,30.),(6.,40.),(6.,50.)]),
        ("Figure 3b", [(4.5,30.),(6.,30.),(7.4,30.)]),
    ]:
        ws = wb[sheet]
        for j,(ph,temp) in enumerate(conditions):
            cid=f"{sheet.replace(' ','_')}_pH{ph:g}_T{temp:g}"
            for r in range(4,12):
                time=ws.cell(r,1).value
                vals=[float(ws.cell(r,2+3*j+k).value) for k in range(3)]
                row=dict(study_id=STUDY, formulation_id="TEB_NPs", condition_id=cid, time=time,
                         time_unit="h", value=mean(vals),unit="%",ph=ph,temperature_c=temp,
                         condition_name=f"release; {sheet}; ethanol/water 20:80; 200 rpm",
                         source_locator=f"Figure 3.xlsx::{sheet}!{ws.cell(r,2+3*j).coordinate}:{ws.cell(r,4+3*j).coordinate}",
                         evidence_kind="author_source_data_mean",sd=stdev(vals),n_replicates=3,endpoint="cumulative_release")
                release.append(row)
                for k,v in enumerate(vals):
                    reps.append(dict(row, value=v, replicate_id=k+1,
                                     source_locator=f"Figure 3.xlsx::{sheet}!{ws.cell(r,2+3*j+k).coordinate}",
                                     evidence_kind="author_source_data_replicate"))
    ws=wb["Figure 3e"]
    for j,form in enumerate(["TEB_NPs","Free_TEB","SC","WP"]):
        for r in range(4,12):
            vals=[float(ws.cell(r,2+3*j+k).value) for k in range(3)]
            row=dict(study_id=STUDY,formulation_id=form,condition_id="photolysis_UV254",
                     time=ws.cell(r,1).value,time_unit="h",value=mean(vals),unit="%",
                     ph="",temperature_c="",condition_name="photolysis; UV254nm 16.4 W/m2",
                     source_locator=f"Figure 3.xlsx::Figure 3e!{ws.cell(r,2+3*j).coordinate}:{ws.cell(r,4+3*j).coordinate}",
                     evidence_kind="author_source_data_mean",sd=stdev(vals),n_replicates=3,endpoint="remaining_TEB")
            photo.append(row)
            for k,v in enumerate(vals):
                photo_reps.append(dict(row,value=v,replicate_id=k+1,
                                       source_locator=f"Figure 3.xlsx::Figure 3e!{ws.cell(r,2+3*j+k).coordinate}",
                                       evidence_kind="author_source_data_replicate"))
    wb=load("Figure 2.xlsx")
    for s1,s2,variable,constant,expected_rows in [
        ("Figure 2a","Figure 2b","flow_ml_min",0.05,6),
        ("Figure 2d","Figure 2e","polymer_mg_ml",30.,5),
    ]:
        for r in range(4,4+expected_rows):
            x=wb[s1].cell(r,1).value
            for sheet,endpoint,col,unit in [
                (s1,"diameter",2,"nm"),(s1,"PDI",3,"dimensionless"),
                (s2,"encapsulation_efficiency",2,"%"),(s2,"drug_loading_capacity",3,"%"),
            ]:
                ws=wb[sheet]
                vals=[float(ws.cell(r,col+2*k).value) for k in range(3)]
                row=dict(study_id=STUDY,recipe_id=f"{s1.replace(' ','_')}_{x:g}",
                         process="flash_nanoprecipitation",
                         flow_ml_min=x if variable=="flow_ml_min" else constant,
                         polymer_mg_ml=x if variable=="polymer_mg_ml" else constant,
                         tebuconazole_mg_ml=0.1,
                         endpoint=endpoint,value=mean(vals),unit=unit,sd=stdev(vals),n_replicates=3,
                         source_locator=f"Figure 2.xlsx::{sheet}!{ws.cell(r,col).coordinate}:{ws.cell(r,col+4).coordinate}",
                         evidence_kind="author_source_data_mean")
                recipes.append(row)
                for k,v in enumerate(vals):
                    recipe_reps.append(dict(row,value=v,replicate_id=k+1,
                                            source_locator=f"Figure 2.xlsx::{sheet}!{ws.cell(r,col+2*k).coordinate}",
                                            evidence_kind="author_source_data_replicate"))
    claims=[]
    for cid,val,kind in [
        ("Figure_3a_pH6_T30",73.6,"reported_mean"),
        ("Figure_3a_pH6_T40",80.2,"reported_mean"),
        ("Figure_3a_pH6_T50",94.5,"reported_mean"),
        ("Figure_3b_pH4.5_T30",80.0,"approximate_reported_mean"),
        ("Figure_3b_pH6_T30",73.0,"approximate_reported_mean"),
        ("Figure_3b_pH7.4_T30",44.0,"approximate_reported_mean"),
    ]:
        obs=next(v for v in release if v["condition_id"]==cid and v["time"]==48)
        claims.append(dict(study_id=STUDY,formulation_id="TEB_NPs",condition_id=cid,
                           time=48,time_unit="h",metric="cumulative_release",reported_value=val,unit="%",
                           source_locator="Article Results: Stimuli-response properties; Fig. 3a/b",
                           evidence_kind=kind,absolute_tolerance=2.0,ph=obs["ph"],temperature_c=obs["temperature_c"]))
    for form,k,sd,r2,half in [
        ("TEB_NPs",.0498,.0037,.9272,13.9158),("SC",.0857,.0065,.9392,8.0900),
        ("WP",.1065,.0129,.8459,6.5109),("Free_TEB",.1382,.0187,.8419,5.0159),
    ]:
        for metric,val,unit,tol in [("photolysis_k",k,"h^-1",2e-4),("photolysis_r2",r2,"dimensionless",.01),("photolysis_half_life",half,"h",.1)]:
            claims.append(dict(study_id=STUDY,formulation_id=form,condition_id="photolysis_UV254",
                               time="",time_unit="h",metric=metric,reported_value=val,unit=unit,
                               source_locator="Supplementary Information PDF page 3; Supplementary Table 1",
                               evidence_kind="reported_fit_statistic",absolute_tolerance=tol,ph="",temperature_c=""))
    write("observations.csv",release)
    write("release_replicates.csv",reps)
    write("photolysis.csv",photo)
    write("photolysis_replicates.csv",photo_reps)
    write("recipe_endpoints.csv",recipes)
    write("recipe_endpoint_replicates.csv",recipe_reps)
    write("claims.csv",claims)
    study=dict(study_id=STUDY,title="Deposition and water repelling of temperature-responsive nanopesticides on leaves",
               authors="Tang et al.",year=2023,journal="Nature Communications",doi=DOI,url=URL,
               publication_date="2023-10-12",domain="crop_protection",active="tebuconazole",
               carrier="PDMAEMA-b-PCL (7k-b-8k)",license="CC BY 4.0",
               source_url=SOURCE_URL,source_file="research/v2_crop/teb2023_source.zip",
               selection_reason="Author numerical replicate data, independent recipe sweeps, six environmental release series, exact photolysis equation and fit table; preferred over newer inaccessible publisher supplements.",
               counts=dict(release_means=len(release),release_replicates=len(reps),release_curves=6,
                           distinct_release_conditions=5,recipe_sweep_settings=11,recipe_endpoint_means=len(recipes),
                           photolysis_means=len(photo),reported_claims=len(claims)),
               release_protocol=dict(dialysis_sample_ml=3,dialysate_ml=27,dialysate="ethanol/water 20:80 v/v",
                                     dialysis_mwco_da=3500,agitation_rpm=200,sample_withdrawal_and_replacement_ml=3),
               photolysis_protocol=dict(wavelength_nm=254,irradiance_w_m2=16.4,sample_ml=5,initial_teb_mg_ml=.3,
                                        solvent="THF/water 10:90 v/v",distance_cm=10),
               equations=dict(photolysis="remaining_fraction(t) = exp(-k*t); t_half=ln(2)/k",
                              EE="100 * encapsulated_TEB / total_added_TEB",
                              DLC="100 * encapsulated_TEB / total_NP_mass",
                              release="No release kinetic equation claimed by authors; curve fits are our benchmarks."),
               cautions=[
                   "Figure 3a at 30C/pH6 and Figure 3b at30C/pH6 are separate supplied series: keep in same environmental holdout group.",
                   "Recipe data comprise one-factor sweeps, not 11 chemically independent recipes; one repeated default condition must share holdout groups.",
                   "No cross-study transfer of absolute curves across actives and assays.",
                   "Source data average at50C48h is94.9314%, article reports94.5%; retained without correction.",
                   "Flow-sweep fixed polymer concentration0.05mg/mL follows optimized preparation and mass ratios; no direct header statement in source workbook.",
                   "Narrative names panels2a-c and2d-f inconsistently; extraction follows actual numerical workbook headers.",
                   "Model acceptance tolerances are analyst decisions, recorded for transparency; they are not preregistered.",
               ])
    study["sha256"]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASE/"teb2023_source.zip",BASE/"teb2023_article.html",BASE/"teb2023_supplement.pdf"]}
    (OUT/"study.json").write_text(json.dumps(study,indent=2)+"\n")
    print(json.dumps(study["counts"],indent=2))

if __name__=="__main__":
    extract()
