"""Local audit of the exact published photolysis equation and recipe holdout pilot."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/"data/v2/crop"

def run():
    photo=pd.read_csv(OUT/"photolysis.csv")
    claims=pd.read_csv(OUT/"claims.csv")
    fitted=[]
    for form,g in photo.groupby("formulation_id"):
        t=g.time.to_numpy(float)
        y=g.value.to_numpy(float)/100
        k=float(curve_fit(lambda t,k:np.exp(-k*t),t,y,p0=[.1],bounds=(0,np.inf))[0][0])
        pred=np.exp(-k*t)
        r2=float(1-np.sum((y-pred)**2)/np.sum((y-y.mean())**2))
        entry={"formulation_id":form,"k_h_inv":k,"r2_original_response_space":r2,
               "half_life_h":float(np.log(2)/k),"rmse_percentage_points":float(np.sqrt(np.mean((100*(y-pred))**2))),
               "method":"Unweighted nonlinear least squares on eight source-data means, including t=0; response remaining_fraction"}
        for metric,key in [("photolysis_k","k_h_inv"),("photolysis_r2","r2_original_response_space"),("photolysis_half_life","half_life_h")]:
            c=claims[(claims.formulation_id==form)&(claims.metric==metric)].iloc[0]
            entry["paper_"+key]=float(c.reported_value)
            entry["abs_error_"+key]=float(abs(entry[key]-c.reported_value))
        fitted.append(entry)
    pd.DataFrame(fitted).to_csv(OUT/"photolysis_benchmark.csv",index=False)
    rec=pd.read_csv(OUT/"recipe_endpoints.csv")
    rec["split_group"]=rec.apply(lambda r:f"flow{r.flow_ml_min:g}_polymer{r.polymer_mg_ml:g}",axis=1)
    results=[]
    for endpoint,g in rec.groupby("endpoint"):
        for group in sorted(g.split_group.unique()):
            tr=g[g.split_group!=group];te=g[g.split_group==group]
            xtr=np.log10(tr[["flow_ml_min","polymer_mg_ml"]].to_numpy(float))
            xte=np.log10(te[["flow_ml_min","polymer_mg_ml"]].to_numpy(float))
            model=make_pipeline(StandardScaler(),Ridge(alpha=1.0))
            model.fit(xtr,tr.value)
            predictions={"training_mean":np.full(len(te),tr.value.mean()),"ridge_log_process":model.predict(xte)}
            if endpoint=="drug_loading_capacity":
                ee=rec[(rec.endpoint=="encapsulation_efficiency")&(rec.split_group!=group)].value.mean()/100
                cteb=te.tebuconazole_mg_ml.to_numpy(float)
                cp=te.polymer_mg_ml.to_numpy(float)
                predictions["mass_balance_training_mean_EE"]=100*ee*cteb/(ee*cteb+cp)
            for modelname,pred in predictions.items():
                for (_,row),p in zip(te.iterrows(),pred):
                    results.append(dict(endpoint=endpoint,unit=row.unit,recipe_id=row.recipe_id,
                                        split_group=group,model=modelname,observed=row.value,predicted=float(p),
                                        abs_error=float(abs(row.value-p))))
    pd.DataFrame(results).to_csv(OUT/"recipe_holdout_predictions.csv",index=False)
    metrics=pd.DataFrame(results).groupby(["endpoint","unit","model"]).agg(mae=("abs_error","mean"),n=("abs_error","size")).reset_index()
    metrics.to_csv(OUT/"recipe_holdout_metrics.csv",index=False)
    result={"photolysis":fitted,"recipe_holdout":metrics.to_dict(orient="records"),
            "recipe_protocol":"Leave one unique (flow,polymer concentration) group out; duplicate default recipe from two sweeps held out together. Fixed StandardScaler+Ridge(alpha=1) on log10 process inputs. Report units separately.",
            "scope":"Within-study recipe pilot; 10 unique settings in 11 source rows per endpoint; not external recipe generalization.",
            "mass_balance_assumption":"DLC=100*eta*C_TEB/(eta*C_TEB+C_polymer), eta estimated from training-only mean EE. Assumes quantitative polymer retention. Source endpoint algebraic consistency is not independent mechanistic validation.",
            "device":"CPU: 4 single-parameter photolysis fits and 40 tiny recipe folds; no GPU need.",
            "tolerances_note":"Tolerances were selected after literature inspection and are transparent audit thresholds, not preregistered acceptance criteria."}
    (OUT/"benchmark_results.json").write_text(json.dumps(result,indent=2)+"\n")
    print(metrics.to_string(index=False))
    print(pd.DataFrame(fitted)[["formulation_id","k_h_inv","paper_k_h_inv","half_life_h","paper_half_life_h"]].to_string(index=False))

if __name__=="__main__":
    run()
