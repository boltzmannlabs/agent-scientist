from pathlib import Path
import csv,hashlib,json,statistics,xml.etree.ElementTree as E,zipfile
root=Path.cwd()
raw=root/"data/raw/azadirachtin_2025_source_data.xlsx"
ns={"s":"http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
doi="10.1038/s41467-025-57028-w"
def sheet(z,i,ss):
    cells={}
    for c in E.fromstring(z.read(f"xl/worksheets/sheet{i}.xml")).findall(".//s:sheetData/s:row/s:c",ns):
        v=c.find("s:v",ns)
        if v is not None: cells[c.attrib["r"]]=ss[int(v.text)] if c.attrib.get("t")=="s" else float(v.text)
    return cells
def write(name,rows):
    with (root/"data/curated"/name).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with zipfile.ZipFile(raw) as z:
    ss=["".join(x.itertext()) for x in E.fromstring(z.read("xl/sharedStrings.xml"))]
    s=sheet(z,10,ss);f6=sheet(z,4,ss)
rows=[];long=[]
blocks=[("AT NPs",5,4,"B","CDE","F","G"),("AT NPs",7,4,"J","KLM","N","O"),("AT NPs",9,15,"B","CDE","F","G"),("AP NPs",5,27,"B","CDE","F","G"),("AP NPs",7,27,"J","KLM","N","O"),("AP NPs",9,38,"B","CDE","F","G")]
for form,ph,start,tc,rc,mc,ec in blocks:
    for r in range(start,start+9):
        reps=[s[f"{c}{r}"] for c in rc]
        row=dict(formulation=form,ph=ph,time_h=s[f"{tc}{r}"],release_pct=s[f"{mc}{r}"],se_pct=s[f"{ec}{r}"],replicate_1_pct=reps[0],replicate_2_pct=reps[1],replicate_3_pct=reps[2],recomputed_mean_pct=statistics.mean(reps),recomputed_se_pct=statistics.stdev(reps)/3**0.5,source_sheet="Supplementary Figure 3",source_cells=f"{tc}{r}:{ec}{r}",doi=doi,temperature_c=25,measurement_origin="publisher_source_data")
        rows.append(row)
        for n,val in enumerate(reps,1):long.append(dict(formulation=form,ph=ph,time_h=row["time_h"],replicate=n,release_pct=val,source_sheet=row["source_sheet"],source_cell=f"{rc[n-1]}{r}",doi=doi,temperature_c=25))
write("azadirachtin_2025_release.csv",rows)
write("azadirachtin_2025_release_replicates.csv",long)
claims=[]
for model,r in [("first_order",30),("ritger_peppas",39),("higuchi",48),("peppas_sahlin",58)]:
    for form,cols in [("AT NPs","CDE"),("AP NPs","IJK")]:
        for ph,c in zip([5,7,9],cols):claims.append(dict(formulation=form,ph=ph,model=model,reported_r2=f6[f"{c}{r}"],source_sheet="Figure 6",source_cell=f"{c}{r}",doi=doi,status="reported_fit_metadata_not_observation"))
write("azadirachtin_2025_reported_fits.csv",claims)
manifest=dict(doi=doi,published="2025-02-18",retrieved_utc="2026-10-19",sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),source_url="https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-57028-w/MediaObjects/41467_2025_57028_MOESM4_ESM.xlsx",rows_release_means=len(rows),rows_replicates=len(long),observations_generated_or_digitized=False,license_article="CC BY-NC-ND 4.0; verify workbook/reuse terms before commercial distribution",notes=["Provided means and SE preserved alongside recomputed values despite inconsistencies.","Narrative acidic 96h endpoints disagree with source workbook.","Figure6 fitted R2 metadata are claims to audit, never training observations.","Six curves support in-domain pilot analysis only."])
(root/"research/azadirachtin_2025_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest,indent=2))
