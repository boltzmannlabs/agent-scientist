"""Convert the two v1 curated datasets onto the v3 study contract.

This is a provenance-preserving transform, not a re-extraction: values and
cell locators come from the v1 curated CSVs, whose raw workbooks and SHA-256
hashes were already verified by scripts/reproduce.py.  The emitted study
directories follow the same contract as data/v2/*, add ontology and protocol
blocks, and register the v1-documented source discrepancies as claims.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parents[2]
OUT_ROOT = REPO / "data" / "v3"


def _sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def convert_azadirachtin() -> None:
    study_id = "zhang2025_azadirachtin"
    curated = pd.read_csv(REPO / "data/curated/azadirachtin_2025_release.csv")
    out = OUT_ROOT / "aza_2025"
    out.mkdir(parents=True, exist_ok=True)

    rows, replicate_rows = [], []
    for _, r in curated.iterrows():
        condition = f"ph{int(r['ph'])}"
        curve = f"{study_id}__{r['formulation'].replace(' ', '_')}__{condition}"
        common = {
            "study_id": study_id,
            "formulation_id": r["formulation"].replace(" ", "_"),
            "condition_id": condition,
            "curve_id": curve,
            "time": float(r["time_h"]),
            "time_unit": "h",
            "unit": "%",
            "ph": float(r["ph"]),
            "temperature_c": 25.0,
            "condition_name": f"phosphate buffer pH {int(r['ph'])}, 100 rpm dialysis",
            "source_locator": f"{r['source_sheet']}!{r['source_cells']} (via data/curated/azadirachtin_2025_release.csv)",
            "evidence_kind": "author_source_data_mean",
            "sd": float(r["se_pct"]),
            "n_replicates": 3,
            "endpoint": "cumulative_release",
            "analyte": "azadirachtin",
            "in_target": True,
        }
        rows.append({**common, "value": float(r["release_pct"])})
        for index in (1, 2, 3):
            replicate_rows.append(
                {**common, "replicate_id": index, "value": float(r[f"replicate_{index}_pct"])}
            )

    pd.DataFrame(rows).to_csv(out / "observations.csv", index=False)
    pd.DataFrame(replicate_rows).to_csv(out / "release_replicates.csv", index=False)

    claims = []
    # Narrative endpoint claims (registered v1 discrepancy: prose 65.57/89.31 vs
    # source 81.75/98.09 at 96 h pH 5).
    for formulation, prose in (("AT_NPs", 65.57), ("AP_NPs", 89.31)):
        claims.append(
            {
                "claim_id": f"narrative96_{formulation}_ph5",
                "study_id": study_id,
                "formulation_id": formulation,
                "condition_id": "ph5",
                "analyte": "azadirachtin",
                "metric": "cumulative_release",
                "time": 96,
                "time_unit": "h",
                "reported_value": prose,
                "unit": "%",
                "tolerance": 5,
                "source_locator": "Article Results; narrative endpoint (v1 audit: prose resembles 48 h values)",
                "evidence_kind": "published_text",
                "claim_type": "narrative_endpoint",
                "claim_text": "Narrative states 96 h pH 5 endpoints that resemble the 48 h source values.",
                "status": "eligible",
                "comparison_scope": "prose vs author source data",
            }
        )
    fits = pd.read_csv(REPO / "data/curated/azadirachtin_2025_reported_fits.csv")
    for _, f in fits.iterrows():
        claims.append(
            {
                "claim_id": f"reported_r2_{f['formulation'].replace(' ', '_')}_ph{int(f['ph'])}",
                "study_id": study_id,
                "formulation_id": f["formulation"].replace(" ", "_"),
                "condition_id": f"ph{int(f['ph'])}",
                "analyte": "azadirachtin",
                "metric": "first_order_r2",
                "time": "",
                "time_unit": "h",
                "reported_value": float(f["reported_r2"]),
                "unit": "dimensionless",
                "tolerance": 0.01,
                "source_locator": f"{f['source_sheet']}!{f['source_cell']}",
                "evidence_kind": "published_fitted",
                "claim_type": "fit_statistic",
                "claim_text": "Reported first-order R2 (v1: fit metadata, not observations; author weighting unresolved).",
                "status": "eligible",
                "comparison_scope": "our unweighted first-order refit on the nine means",
            }
        )
    claims.append(
        {
            "claim_id": "fit_metadata_r2_above_one",
            "study_id": study_id,
            "metric": "",
            "time": "",
            "reported_value": "",
            "evidence_kind": "published_source_conflict",
            "claim_type": "source_inconsistency",
            "claim_text": "Figure 6 fit metadata include adjusted R2 above one.",
            "status": "source_inconsistency",
            "comparison_scope": "registered source anomaly",
        }
    )
    pd.DataFrame(claims).to_csv(out / "claims.csv", index=False)

    ontology_formulations = [
        {
            "formulation_id": formulation,
            "study_id": study_id,
            "geometry": "sphere",
            "characteristic_length": None,
            "ingredients": [
                {"name": "azadirachtin", "role": "active", "cas": None, "mass_fraction": None,
                 "particle_d50": None, "loading": None, "crosslink_density": None},
                {"name": carrier, "role": "matrix", "cas": None, "mass_fraction": None,
                 "particle_d50": None, "loading": None, "crosslink_density": None},
            ],
            "process": [],
            "data_source": "literature",
            "notes": "Composition at ratio level only; no measured mass fractions in source.",
        }
        for formulation, carrier in (("AT_NPs", "tannic acid"), ("AP_NPs", "phenylalanine"))
    ]
    study = {
        "schema_version": "1.0",
        "study_id": study_id,
        "title": "Sustainable pest management using plant secondary metabolites regulated azadirachtin nano-assemblies",
        "authors": "Zhang et al.",
        "year": 2025,
        "journal": "Nature Communications",
        "doi": "10.1038/s41467-025-57028-w",
        "data_source": "literature",
        "ingest_channel": "v1_curated_conversion",
        "selection_reason": "Open publisher source data; v1 dataset converted onto the v3 contract.",
        "counts": {
            "release_means": len(rows),
            "release_replicates": len(replicate_rows),
            "release_series": 6,
            "registered_claims": len(claims),
        },
        "target_contract": {
            "analytes_in_target": ["azadirachtin"],
            "medium": "phosphate buffer dialysis, 100 rpm, 5 mL suspension into 100 mL",
            "denominator": "percent release; loading not independently measured",
            "cumulative": True,
            "normalization": "none",
        },
        "protocols": [
            {
                "protocol_id": f"{study_id}_dialysis",
                "assay_type": "dialysis_release",
                "target": "cumulative_release",
                "unit": "%",
                "time_unit": "h",
                "medium": "phosphate buffer",
                "temperature_c": 25.0,
                "ph": None,
                "sink_condition": "finite_bath",
                "bath_to_sample_ratio": 20.0,
                "sampling_scheme": "0.5 mL replacement",
            }
        ],
        "ontology": {"formulations": ontology_formulations},
        "source_files": {
            "azadirachtin_2025_source_data.xlsx": {
                "path": "data/raw/azadirachtin_2025_source_data.xlsx",
                "sha256": _sha256(REPO / "data/raw/azadirachtin_2025_source_data.xlsx"),
            },
            "azadirachtin_2025_release.csv": {
                "path": "data/curated/azadirachtin_2025_release.csv",
                "sha256": _sha256(REPO / "data/curated/azadirachtin_2025_release.csv"),
            },
        },
        "extraction": "Transform of v1 curated CSVs; locators chain to publisher workbook cells.",
        "limitations": [
            "Reported fit metadata are not observations; author weighting unresolved (v1 finding).",
            "Narrative 96 h endpoints conflict with source data; preserved, not corrected.",
        ],
    }
    with open(out / "study.json", "w") as handle:
        json.dump(study, handle, indent=1, sort_keys=True)
    print(f"v3 conversion: aza_2025 -> {len(rows)} means, {len(claims)} claims")


def convert_fla_fertilizer() -> None:
    study_id = "zhu2026_fla_fertilizer"
    curated = pd.read_csv(REPO / "data/curated/fertilizer_2026_release.csv")
    out = OUT_ROOT / "fla_fertilizer_2026"
    out.mkdir(parents=True, exist_ok=True)

    rows = []
    for _, r in curated.iterrows():
        analyte = str(r["active"]).replace("+", "")
        curve = f"{study_id}__{r['formulation']}__{analyte}"
        rows.append(
            {
                "study_id": study_id,
                "formulation_id": r["formulation"],
                "condition_id": "release_assay",
                "curve_id": curve,
                "time": float(r["time_d"]),
                "time_unit": "day",
                "value": float(r["release_pct"]),
                "unit": "%",
                "ph": None,
                "temperature_c": None,
                "condition_name": "soil-contact release assay (conditions not fully stated in source)",
                "source_locator": f"{r['source_sheet']}!{r['source_cells']} (via data/curated/fertilizer_2026_release.csv)",
                "evidence_kind": "published_measured",
                "sd": float(r["sd_pct"]),
                "n_replicates": int(r["n_replicates"]),
                "endpoint": "cumulative_release",
                "analyte": analyte,
                "in_target": True,
            }
        )
    pd.DataFrame(rows).to_csv(out / "observations.csv", index=False)

    claims = [
        {
            "claim_id": f"narrative30_{analyte}",
            "study_id": study_id,
            "formulation_id": "WP_ATP_ASO_SRF",
            "condition_id": "release_assay",
            "analyte": analyte,
            "metric": "cumulative_release",
            "time": 30,
            "time_unit": "day",
            "reported_value": prose,
            "unit": "%",
            "tolerance": 5,
            "source_locator": "Main-text paragraph (v1 provenance: discrepancy note)",
            "evidence_kind": "published_text",
            "claim_type": "narrative_endpoint",
            "claim_text": "Narrative day-30 endpoints; workbook shows both actives at 100% at day 30 and the quoted values at day 25.",
            "status": "eligible",
            "comparison_scope": "prose vs author source data",
        }
        for analyte, prose in (("FLA", 98.15), ("K", 97.7))
    ]
    claims.append(
        {
            "claim_id": "narrative_day30_discrepancy",
            "study_id": study_id,
            "metric": "",
            "time": "",
            "reported_value": "",
            "evidence_kind": "published_source_conflict",
            "claim_type": "source_inconsistency",
            "claim_text": "Narrative quotes day-30 values that match workbook day-25 rows; both actives reach 100% at day 30 in the workbook.",
            "status": "source_inconsistency",
            "comparison_scope": "registered source discrepancy",
        }
    )
    pd.DataFrame(claims).to_csv(out / "claims.csv", index=False)

    study = {
        "schema_version": "1.0",
        "study_id": study_id,
        "title": "Waterborne phosphate-solubilizing biofertilizer formulation (v1 archive)",
        "authors": "Zhu et al.",
        "year": 2026,
        "journal": "Nature Communications",
        "doi": "10.1038/s41467-026-68295-6",
        "data_source": "literature",
        "ingest_channel": "v1_curated_conversion",
        "selection_reason": "v1 fertilizer dataset converted onto the v3 contract for catalog breadth.",
        "counts": {"release_means": len(rows), "release_series": 2, "registered_claims": len(claims)},
        "target_contract": {
            "analytes_in_target": ["FLA", "K"],
            "medium": "release assay; medium details not fully stated in source",
            "denominator": "percent release; loading not independently measured",
            "cumulative": True,
            "normalization": "none",
        },
        "protocols": [
            {
                "protocol_id": f"{study_id}_release",
                "assay_type": "immersion_release",
                "target": "cumulative_release",
                "unit": "%",
                "time_unit": "day",
                "medium": None,
                "temperature_c": None,
                "ph": None,
                "sink_condition": "unknown",
                "bath_to_sample_ratio": None,
                "sampling_scheme": None,
            }
        ],
        "ontology": {
            "formulations": [
                {
                    "formulation_id": "WP_ATP_ASO_SRF",
                    "study_id": study_id,
                    "geometry": "granule",
                    "characteristic_length": None,
                    "ingredients": [
                        {"name": "fulvic-like acid", "role": "active", "cas": None, "mass_fraction": None,
                         "particle_d50": None, "loading": None, "crosslink_density": None},
                        {"name": "potassium", "role": "active", "cas": None, "mass_fraction": None,
                         "particle_d50": None, "loading": None, "crosslink_density": None},
                        {"name": "whey protein / ATP / alginate-silica matrix", "role": "matrix", "cas": None,
                         "mass_fraction": None, "particle_d50": None, "loading": None, "crosslink_density": None},
                    ],
                    "process": [],
                    "data_source": "literature",
                    "notes": "Single recipe; composition at narrative level only.",
                }
            ]
        },
        "source_files": {
            "fertilizer_2026_source_data.xls": {
                "path": "data/raw/fertilizer_2026_source_data.xls",
                "sha256": _sha256(REPO / "data/raw/fertilizer_2026_source_data.xls"),
            },
            "fertilizer_2026_release.csv": {
                "path": "data/curated/fertilizer_2026_release.csv",
                "sha256": _sha256(REPO / "data/curated/fertilizer_2026_release.csv"),
            },
        },
        "extraction": "Transform of v1 curated CSV; locators chain to publisher workbook cells.",
        "limitations": [
            "Single formulation, two analytes; no condition axes.",
            "Release-assay protocol incompletely stated in the source (registered gap).",
        ],
    }
    with open(out / "study.json", "w") as handle:
        json.dump(study, handle, indent=1, sort_keys=True)
    print(f"v3 conversion: fla_fertilizer_2026 -> {len(rows)} means, {len(claims)} claims")


def write_v2_enrichment() -> None:
    """Ontology/protocol blocks for the three frozen v2 studies, kept OUTSIDE
    data/v2 (which stays frozen as v2 benchmark input) and merged at catalog
    load time from data/catalog/enrichment/."""
    enrichment_root = REPO / "data" / "catalog" / "enrichment"
    enrichment_root.mkdir(parents=True, exist_ok=True)

    def ingredient(name, role, note=""):
        return {"name": name, "role": role, "cas": None, "mass_fraction": None,
                "particle_d50": None, "loading": None, "crosslink_density": None,
                "note": note}

    blocks = {
        "crop": {
            "protocols": [
                {
                    "protocol_id": "tang2023_dialysis",
                    "assay_type": "dialysis_release",
                    "target": "cumulative_release",
                    "unit": "%",
                    "time_unit": "h",
                    "medium": "ethanol/water 20:80 v/v",
                    "temperature_c": None,
                    "ph": None,
                    "sink_condition": "finite_bath",
                    "bath_to_sample_ratio": 9.0,
                    "sampling_scheme": "3 mL withdrawn and replaced; 3500 Da MWCO; 200 rpm",
                }
            ],
            "ontology": {
                "formulations": [
                    {
                        "formulation_id": "TEB_NPs",
                        "study_id": "tang2023_tebuconazole",
                        "geometry": "sphere",
                        "characteristic_length": None,
                        "ingredients": [
                            ingredient("tebuconazole", "active"),
                            ingredient("PDMAEMA-b-PCL (7k-b-8k)", "matrix"),
                        ],
                        "process": [
                            {"step": "flash_nanoprecipitation", "parameter": "flow_ml_min",
                             "note": "swept 2-50 mL/min in the recipe-endpoint pilot"},
                            {"step": "flash_nanoprecipitation", "parameter": "polymer_mg_ml",
                             "note": "swept 0.0125-0.2 mg/mL"},
                        ],
                        "data_source": "literature",
                        "notes": "Process parameters swept in the recipe-endpoint pilot; fraction-level composition not measured.",
                    }
                ]
            },
        },
        "herbicide": {
            "protocols": [
                {
                    "protocol_id": "paul2024_desorption",
                    "assay_type": "immersion_release",
                    "target": "cumulative_2_4_D_desorbed",
                    "unit": "mg/g",
                    "time_unit": "day",
                    "medium": "aqueous (pH/salt/temperature vary by condition)",
                    "temperature_c": None,
                    "ph": None,
                    "sink_condition": "unknown",
                    "bath_to_sample_ratio": None,
                    "sampling_scheme": "supernatant replacement; 2 replicates",
                }
            ],
            "ontology": {
                "formulations": [
                    {
                        "formulation_id": formulation,
                        "study_id": "paul_2024_24d",
                        "geometry": "granule",
                        "characteristic_length": None,
                        "ingredients": [
                            ingredient("2,4-D", "active"),
                            ingredient("montmorillonite clay", "matrix",
                                       note="MMT1 vs MMT2 differ in clay modification"),
                            ingredient("biopolymer bead matrix", "matrix"),
                        ],
                        "process": [],
                        "data_source": "literature",
                        "notes": "Two recipes differing in clay treatment; ratio-level composition only.",
                    }
                    for formulation in ("MMT1", "MMT2")
                ]
            },
        },
        "fertilizer": {
            "protocols": [
                {
                    "protocol_id": "xiang2026_release",
                    "assay_type": "immersion_release",
                    "target": "cumulative_release",
                    "unit": "%",
                    "time_unit": "h",
                    "medium": "aqueous solutions at pH 3, 5, 7",
                    "temperature_c": None,
                    "ph": None,
                    "sink_condition": "unknown",
                    "bath_to_sample_ratio": None,
                    "sampling_scheme": "not stated in source",
                }
            ],
            "ontology": {
                "formulations": [
                    {
                        "formulation_id": formulation,
                        "study_id": "xiang2026_dn_gel",
                        "geometry": "cylinder",
                        "characteristic_length": None,
                        "ingredients": [
                            ingredient("L-phenylalanine", "active",
                                       note="secondary network component and released cargo"),
                            ingredient("zinc ion", "crosslinker",
                                       note="network crosslinker and released cargo; 12 mM ZnCl2"),
                            ingredient("zhongshengmycin", "active",
                                       note="pesticide cargo; archived out of target"),
                            ingredient(matrix, "matrix",
                                       note="0.5% w/v primary network"),
                        ],
                        "process": [],
                        "data_source": "literature",
                        "notes": "Double-network hydrogel; composition at concentration level, fractions not measured.",
                    }
                    for formulation, matrix in (("CMA_DN", "carboxymethylated agarose"),
                                                ("CTA_DN", "citrate agarose"))
                ]
            },
        },
    }
    for key, block in blocks.items():
        with open(enrichment_root / f"{key}.json", "w") as handle:
            json.dump({"study_key": key, **block}, handle, indent=1, sort_keys=True)
    print(f"v3 enrichment written for {sorted(blocks)}")


if __name__ == "__main__":
    convert_azadirachtin()
    convert_fla_fertilizer()
    write_v2_enrichment()
