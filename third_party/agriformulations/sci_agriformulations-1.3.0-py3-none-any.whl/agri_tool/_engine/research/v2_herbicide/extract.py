"""Extract the independent herbicide benchmark without changing native units.

Run from repository root: python3 research/v2_herbicide/extract.py
Uses source DOCX tables S3/S4 and preserves all raw entries.
"""
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET
import csv, hashlib, json
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/"data/v2/herbicide"
SRC=ROOT/"research/crop_protection/41598_2024_53820_MOESM1_ESM.docx"
XLS=ROOT/"research/crop_protection/41598_2024_53820_MOESM2_ESM.xlsx"
DOI="10.1038/s41598-024-53820-8"
URL="https://www.nature.com/articles/s41598-024-53820-8"
NS={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
def text(c):
    return "".join(t.text or "" for t in c.findall(".//w:t",NS)).strip()
def dumpcsv(path,rows):
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    root=ET.fromstring(ZipFile(SRC).read("word/document.xml"))
    tables=root.findall(".//w:tbl",NS)
    conditions=[("ph5",5,25,"pH 5 water","ph","water",0),
      ("ph7",7,25,"pH 7 water","ph","water",0),
      ("ph9",9,25,"pH 9 water","ph","water",0),
      ("temp25",None,25,"25 C water; pH unspecified","temperature","water",0),
      ("temp35",None,35,"35 C water; pH unspecified","temperature","water",0),
      ("temp45",None,45,"45 C water; pH unspecified","temperature","water",0),
      ("nacl001",None,None,"NaCl 0.01 M","salt","NaCl",0.01),
      ("nacl003",None,None,"NaCl 0.03 M","salt","NaCl",0.03),
      ("cacl2001",None,None,"CaCl2 0.01 M","salt","CaCl2",0.01)]
    rows=[]
    for ti,formulation in [(2,"MMT1"),(3,"MMT2")]:
        for ri,r in enumerate(tables[ti].findall("w:tr",NS)):
            cells=[text(c) for c in r.findall("w:tc",NS)]
            if not cells or not cells[0].replace(".","",1).isdigit(): continue
            day=float(cells[0])
            for j,(cid,ph,temp,name,axis,salt,molarity) in enumerate(conditions):
                ci=2+2*j; raw=cells[ci]; missing=raw in ("-","")
                value,unc=(None,None) if missing else map(float,raw.split("±"))
                qc="missing_after_disintegration" if missing else "accepted"
                note=""
                if value is not None and value>1000:
                    qc="excluded_impossible_native_mass"
                    note="4967 mg/g preserved; >1000 mg active/g bead impossible if denominator is bead mass. No decimal correction inferred."
                rows.append(dict(study_id="paul_2024_24d",formulation_id=formulation,condition_id=cid,
                  curve_id=f"paul_2024_24d__{formulation}__{cid}",time=day,time_unit="day",
                  value=value,unit="mg/g",ph=ph,temperature_c=temp,condition_name=name,condition_axis=axis,
                  salt=salt,salt_molarity=molarity,source_locator=f"Table S{ti+1}; row {ri+1}; cell {ci+1}",
                  evidence_kind="published_mean",uncertainty=unc,uncertainty_type="unspecified_plusminus",
                  replicate_count=2,raw_source_value=raw,included_primary=qc=="accepted",qc_status=qc,
                  qc_note=note,source_url=URL,target="cumulative_2_4_D_desorbed"))
    dumpcsv(OUT/"observations.csv",rows)
    claims=[]
    fields=["claim_id","study_id","formulation_id","condition_id","time","time_unit","reported_value",
      "unit","tolerance","source_locator","evidence_kind","claim_type","claim_text","status","comparison_scope"]
    def add(**kw):
        rec=dict.fromkeys(fields,""); rec.update(study_id="paul_2024_24d",**kw); claims.append(rec)
    for r in rows:
        if r["time"]==98 and r["value"] is not None:
            add(claim_id=f"endpoint98_{r['formulation_id']}_{r['condition_id']}",
              formulation_id=r["formulation_id"],condition_id=r["condition_id"],time=98,time_unit="day",
              reported_value=r["value"],unit="mg/g",tolerance=0.005,source_locator=r["source_locator"],
              evidence_kind="published_table",claim_type="tabulated_endpoint",
              claim_text="Published day-98 cumulative desorption in native table units.",
              status="eligible_for_transcription_and_forecast_audit",
              comparison_scope="Extraction agreement is a transcription check; forecast comparison is independent heldout prediction.")
    for f in ("MMT1","MMT2"):
        for cid in ("ph5","ph7","ph9","temp25","temp35","temp45"):
            add(claim_id=f"duration_{f}_{cid}",formulation_id=f,condition_id=cid,
              time=98,time_unit="day",reported_value=100,unit="day",tolerance=5,
              source_locator="Article Results: Desorption studies; Fig. 6",
              evidence_kind="published_text",claim_type="approximate_duration",
              claim_text="Release persists over an approximately 100-day experiment.",
              status="eligible_approximate_duration",comparison_scope="Last observed measurement time; not depletion time or a mechanistic half-life.")
    for claim_id,locator,claim in [
      ("conflicting_initial_release_ranking","Article Desorption studies, paragraphs around Fig. 6 and Conclusion",
       "Different passages give opposite initial release rankings for MMT1 and MMT2."),
      ("conflicting_ph_significance","Article Desorption studies, opening and later paragraph",
       "Opening description reports no significant pH variation; later prose describes a significant pH effect."),
      ("unit_conflict_figure_table","Figure 6 caption versus supplementary Tables S3/S4",
       "Figure caption describes percentage while supplementary numerical table describes mg/g."),
      ("source_typo_day38","Table S4; MMT2 45 C; day 38",
       "4967 plus/minus 0.16 mg/g conflicts with native mass bound and adjacent values."),
      ("soil_header_duplicate","Table S5 headings",
       "Both porewater column headings name MMT1; prose assigns the second trajectory to MMT2."),
      ("adsorption_time_unit_conflict","Supplementary adsorption Methods",
       "Experimental times described as seconds, then analysis and discussion as minutes.")]:
        add(claim_id=claim_id,source_locator=locator,evidence_kind="published_source_conflict",
          claim_type="source_inconsistency",claim_text=claim,status="source_inconsistency",
          comparison_scope="Preserve ambiguity; do not choose the convenient version.")
    add(claim_id="adsorption_pso_vs_bead_release",source_locator="Article Table 2 and sorption kinetics Methods",
      evidence_kind="published_metric",claim_type="target_mismatch",
      claim_text="Published PSO/PFO statistics measure clay adsorption before bead formation, not bead desorption.",
      status="not_comparable",comparison_scope="Do not compare these published R-squared values with fitted bead-release R-squared.")
    add(claim_id="soil_duration_mmt1",formulation_id="MMT1",time=57,time_unit="day",
      reported_value=57,unit="day",tolerance=0.5,source_locator="Article Desorption studies; Table S5",
      evidence_kind="published_text",claim_type="different_assay",
      claim_text="2,4-D detected in soil porewater until day 57.",
      status="not_comparable",comparison_scope="Soil porewater concentration cannot be inferred from water cumulative desorption.")
    add(claim_id="soil_duration_mmt2",formulation_id="MMT2",time=48,time_unit="day",
      reported_value=48,unit="day",tolerance=0.5,source_locator="Article Desorption studies; Table S5",
      evidence_kind="published_text",claim_type="different_assay",
      claim_text="2,4-D detected in soil porewater until day 48; second Table S5 header ambiguous.",
      status="not_comparable",comparison_scope="Separate target; source header duplicated.")
    add(claim_id="weed_efficacy_over80",reported_value=80,unit="percent",tolerance=0,
      source_locator="Article Weed control efficacy; Table 4",evidence_kind="published_text",
      claim_type="different_assay",claim_text="Expected greater than 80% weed control reached at condition-specific doses and times.",
      status="not_comparable",comparison_scope="Biological efficacy not inferable from release model without exposure/response validation.")
    dumpcsv(OUT/"claims.csv",claims)
    meta=dict(study_id="paul_2024_24d",title="Controlled release herbicide formulation for effective weed control efficacy",
      authors="Paul, Xi, Sanderson and Naidu",doi=DOI,url=URL,publication_date="2024-02-20",
      category="herbicide",outcome="cumulative_2_4_D_desorbed",unit="mg/g",time_unit="day",
      selected_reason="Independent herbicide/polymer-clay bead paper with direct numerical condition-resolved tables.",
      replicate_count=2,uncertainty_type="unspecified_plusminus",recipe_count=2,condition_count=9,curve_count=18,
      source_files={p.name:dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in (SRC,XLS)},
      extraction="DOCX XML tables S3 and S4; direct values, no digitization or generated labels.",
      observation_count=len(rows),primary_count=sum(r["included_primary"] for r in rows),
      missing_count=sum(r["value"] is None for r in rows),excluded_count=sum(r["value"] is not None and not r["included_primary"] for r in rows),
      target_contract=dict(analyte="2,4-D",medium="repeated water replacement; 10 mL water per 50 mg beads",
        denominator="Supplementary table says active ingredient desorbed from microbeads (mg/g); figure caption says percentage. Preserve table unit, no loading-based conversion.",
        cumulative=True,normalization="none",source_independent_loading_available=False),
      metadata_notes=["pH curves measured at 25 C.","Temperature-curve pH unspecified.","Salt-curve pH/temperature unspecified.","Do not merge pH5 and temp25 as replicates."],
      qc_rules=["Missing post-disintegration entries remain null.","Exclude value >1000 mg/g in primary fits; preserve raw-data sensitivity.","Never silently infer decimal point."],
      published_release_model_parameters=None,
      model_metric_alignment="Published adsorption fits describe a different assay; not compared with release fits.",
      limitations=["Two independent recipes; no recipe-design deployment validation.",
        "Tables provide means and unspecified plus/minus; no invented independent raw replicates.",
        "Source contradictions preclude an unqualified paper-level reproduction claim.",
        "Endpoint transcription is not an independent model validation."])
    (OUT/"study.json").write_text(json.dumps(meta,indent=2)+"\n")
    (ROOT/"research/v2_herbicide/source_audit.md").write_text(
      "# Herbicide source audit\n\nPrimary source: https://doi.org/"+DOI+
      "\n\nDirect numerical observations are Tables S3/S4 in the archived DOCX. "
      "The workbook contains UV-Vis spectra and derived worksheets but is not needed to invent replicates. "
      "The article reports duplicate assays and mean values; plus/minus type is unspecified. "
      "Native table labels, incomplete metadata, missing entries, and contradictions are retained in the adapter. "
      "Paper adsorption kinetics and biological efficacy are separate from the water-release assay.\n")
    print(json.dumps({k:meta[k] for k in ("observation_count","primary_count","missing_count","excluded_count","curve_count")}))
if __name__=="__main__":main()
