# Herbicide source audit

Primary source: https://doi.org/10.1038/s41598-024-53820-8

Direct numerical observations are Tables S3/S4 in the archived DOCX. The workbook contains UV-Vis spectra and derived worksheets but is not needed to invent replicates. The article reports duplicate assays and mean values; plus/minus type is unspecified. Native table labels, incomplete metadata, missing entries, and contradictions are retained in the adapter. Paper adsorption kinetics and biological efficacy are separate from the water-release assay.
