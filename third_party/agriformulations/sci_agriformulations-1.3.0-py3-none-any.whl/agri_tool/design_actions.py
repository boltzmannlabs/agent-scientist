"""Design decisions use the same model engines as individual simulations."""
from copy import deepcopy
import json

from agriformulations.rnd import control, design_studies, simulation_service, formulation_workflow, experiments, bounded_formulation, product_development
from .errors import require, NeedsInput


def remove_old_model_labels(value):
    if isinstance(value, dict):
        value.pop("design_model", None)
        for child in value.values():
            remove_old_model_labels(child)
    elif isinstance(value, list):
        for child in value:
            remove_old_model_labels(child)


def optimize(payload, context):
    request = {"model": "inverse_design", **{k: payload[k] for k in ("recipe_id", "active_name", "assumptions", "name") if k in payload}, "inputs": payload.get("inputs", {})}
    require(request, ["inputs"])
    record = simulation_service.record(context.state, request)
    result = {"optimization": record,
        "note": "Search covers declared physical properties. Whole-study performance requires a complete replay; ingredient-to-property predictions remain unavailable."}
    if payload.get("study"):
        study = deepcopy(payload["study"])
        sid = payload.get("scenario_id")
        if not isinstance(study, dict) or not sid:
            raise ValueError("Study replay needs study object and scenario_id")
        scenario = next((s for s in study.get("scenarios", []) if s["id"] == sid), None)
        if scenario is None or scenario["model"] != request["inputs"].get("base_model"):
            raise ValueError("Replay scenario must match the optimized base model")
        variable_names = {v["parameter"] for v in record["result"]["variables"]}
        if not variable_names <= set(scenario.get("candidate_parameters", [])):
            raise ValueError("Whole-study replay may vary only explicitly declared candidate material properties, not shared test conditions")
        rid = record["recipe_id"]
        if not any(c["recipe_id"] == rid for c in study.get("candidates", [])):
            raise ValueError("Optimized recipe must be present in replay study")
        replays = []
        for i, candidate in enumerate(record["result"]["shortlist"], 1):
            control.check()
            revised = deepcopy(study)
            revised["name"] = study["name"] + " · optimized property hypothesis " + str(i)
            for c in revised["candidates"]:
                if c["recipe_id"] == rid:
                    c.setdefault("inputs", {}).setdefault(sid, {}).update(candidate["parameters"])
                    c.get("fit_ids", {}).pop(sid, None)
            revised.setdefault("assumptions", []).append("Optimized physical properties are explicit hypotheses; they are not inferred from ingredient composition.")
            replays.append(design_studies.record(context.state, revised))
        result["whole_study_replays"] = replays
    context.save()
    return result


def handle(action, payload, context):
    context.require_project()
    if action in ("", "choose"):
        raise NeedsInput("Choose the requested design mode", [{"id": "design_mode", "question": "How would you like to evaluate the recipes?",
            "choices": ["Design — compare declared recipes and scenarios", "AI + Physics Design — search physical parameter settings"], "required": True}])
    if action == "study":
        require(payload, ["study"])
        result = design_studies.record(context.state, payload["study"])
        context.save()
        if result["summary"]["complete_candidates"] < result["summary"]["candidates"]:
            result = {**result, "status": "partial"}
        return result
    if action == "optimize":
        return optimize(payload, context)
    if action == "workflow":
        require(payload, ["workflow"])
        result = formulation_workflow.record(context.state, {"workflow_json": json.dumps(payload["workflow"])}, context.store, payload.get("query", ""))
        # Original recipe authoring metadata names its old studio model. This service does not run it.
        remove_old_model_labels(context.state)
        remove_old_model_labels(result)
        context.save()
        return result
    if action == "complete":
        require(payload, ["request"])
        result = bounded_formulation.record(context.state, payload["request"], context.store, payload.get("query", ""))
        remove_old_model_labels(context.state)
        context.save()
        return result
    if action == "develop":
        require(payload, ["brief", "scenarios", "assumptions"])
        from .recipe_actions import concrete_identity
        concrete_identity(payload["brief"])
        raw = {"brief_json": json.dumps(payload["brief"]), "scenarios_json": json.dumps(payload["scenarios"]),
            "rationale": payload.get("rationale", "User or Agent Scientist hypothesis"), "assumptions": payload["assumptions"], "source_library_ids": payload.get("source_library_ids", [])}
        token = control.current()
        resumed = token.resume_state if token else {}
        if context.recovered_destination and resumed.get("development_request") == raw:
            identity = resumed.get("source_project", {})
            source = context.store.load(identity["project_id"], identity["revision"])["document"] if identity.get("project_id") else {}
        else:
            source, identity = deepcopy(context.state), {"project_id": context.project_id, "revision": context.revision}
            # The initial call creates a fresh child; recovery keeps the existing child.
            context.project_id, context.revision, context.saved_digest, context.initial = None, 0, None, {}
        context.state = product_development.develop(raw, context.store, payload.get("query", ""), source, identity)
        remove_old_model_labels(context.state)
        context.save()
        return {"development": context.state["product_development"], "source_project": identity, "recipes": context.state["recipes"], "scenarios": context.state["analysis_runs"]}
    if action == "experiments":
        ids = payload.get("recipe_ids")
        selected = context.state.get("recipes", [])
        if ids:
            if not isinstance(ids, list) or set(ids) - {r["recipe_id"] for r in selected}:
                raise ValueError("Experiment recipes must belong to this project")
            selected = [r for r in selected if r["recipe_id"] in ids]
        result = experiments.plan({**payload.get("options", {}), "recipes": selected})
        context.state["experiment_result"] = result
        context.save()
        return result
    if action == "studies":
        return {"studies": [{k: r.get(k) for k in ("study_id", "name", "goal", "summary", "pareto_recipe_ids")} for r in context.state.get("design_studies", [])]}
    if action == "get":
        require(payload, ["study_id"])
        result = next((r for r in context.state.get("design_studies", []) if r["study_id"] == payload["study_id"]), None)
        if result is None:
            raise ValueError("Study does not belong to this project")
        return result
    raise ValueError("Unknown design action")
