"""Readable PDF reports and machine-readable scientific result artifacts."""
import json
from pathlib import Path


def scenario_series(record):
    output = record["result"]
    if output.get("series"):
        return output["series"]

    def curve(name, x, y, xlabel, ylabel):
        return {"name": name, "x": x, "y": y, "x_label": xlabel, "y_label": ylabel}

    if record["kind"] == "kinetics" and output.get("times_days"):
        return [curve("Intrinsic release", output["times_days"], output["release_fraction"], "Time (days)", "Released fraction"),
                curve("Available active", output["times_days"], output["available_fraction"], "Time (days)", "Available fraction")]
    if record["kind"] == "stability" and output.get("times_days"):
        return [curve(str(c["temperature_c"]) + " °C", output["times_days"], c["retained_fraction"], "Time (days)", "Retained fraction") for c in output["curves"]]
    if record["kind"] == "dosage" and output.get("deposition_sensitivity"):
        rows = output["deposition_sensitivity"]
        return [curve("Hypothetical product quantity", [r["deposition_fraction"] for r in rows], [r["product_kg_ha"] for r in rows], "Deposited fraction", "Product (kg/ha)")]
    return []


def _plain(value):
    if value is None:
        return "Not provided"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, float):
        return f"{value:.6g}"
    if isinstance(value, (int, str)):
        return str(value)
    if isinstance(value, (list, tuple)):
        rendered = "; ".join(_plain(item) for item in value) or "None"
    else:
        rendered = "; ".join(f"{key.replace('_', ' ').capitalize()}: {_plain(item)}" for key, item in value.items())
    # Keep report tables legible; the complete record is retained in JSON.
    return rendered if len(rendered) <= 500 else rendered[:497] + "..."


def _rows(value, prefix=""):
    rows = []
    if isinstance(value, dict):
        for key, item in value.items():
            label = f"{prefix} / {key.replace('_', ' ')}" if prefix else key.replace("_", " ").capitalize()
            if isinstance(item, dict):
                rows.extend(_rows(item, label))
            else:
                rows.append((label, _plain(item)))
    elif isinstance(value, list):
        rows.append((prefix or "Details", _plain(value)))
    else:
        rows.append((prefix or "Value", _plain(value)))
    return rows


def write_report(state, root):
    """Write a paginated PDF with readable tables and embedded charts."""
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    root = Path(root)
    target = root / "scientific_report.pdf"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="ReportTitle", parent=styles["Title"], alignment=TA_CENTER,
                              textColor=colors.HexColor("#17324d"), spaceAfter=14))
    styles.add(ParagraphStyle(name="Section", parent=styles["Heading2"], textColor=colors.HexColor("#176b62"),
                              spaceBefore=12, spaceAfter=6))
    styles.add(ParagraphStyle(name="Cell", parent=styles["BodyText"], fontSize=8, leading=10,
                              wordWrap="CJK"))
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontSize=8, leading=10,
                              textColor=colors.HexColor("#475569")))

    def safe(value):
        from xml.sax.saxutils import escape
        return escape(str(value)).replace("\n", "<br/>")

    story = [Paragraph(safe(state.get("brief", {}).get("name", "Formulation results")), styles["ReportTitle"]),
             Paragraph("Scientific formulation summary", styles["Heading2"]),
             Paragraph("Numerical results depend on the inputs and assumptions shown. They do not establish compatibility, efficacy, product performance, or experimental validation.", styles["Small"]),
             Spacer(1, 10)]
    brief = state.get("brief", {})
    if brief:
        overview = {key: brief[key] for key in ("name", "format", "active_name", "active_pct", "batch_g", "target", "objective") if brief.get(key) not in (None, "", [])}
        story += [Paragraph("Project overview", styles["Section"]), _table(_rows(overview), styles, colors, inch)]

    recipes = state.get("recipes", [])
    if recipes:
        story.append(Paragraph("Recipe proposals", styles["Section"]))
        for recipe in recipes:
            title = recipe.get("name") or recipe.get("recipe_id") or "Recipe"
            rows = [("Recipe ID", recipe.get("recipe_id", "")), ("Format", recipe.get("format", "")),
                    ("Batch size (g)", recipe.get("batch_g", "")),
                    ("Active content (w/w %)", _plain((recipe.get("active_fraction") or 0) * 100)),
                    ("Evidence status", recipe.get("evidence", recipe.get("performance_status", "")))]
            ingredients = recipe.get("ingredients", [])
            if ingredients:
                story += [Paragraph(safe(title), styles["Heading3"]), _table(rows, styles, colors, inch),
                          Paragraph("Ingredient composition", styles["BodyText"]),
                          _ingredient_table(ingredients, recipe.get("batch_g", 0), styles, colors, inch)]
            else:
                story += [Paragraph(safe(title), styles["Heading3"]), _table(rows, styles, colors, inch)]
            if recipe.get("process"):
                story += [Paragraph("Suggested process", styles["BodyText"]),
                          Paragraph(safe(_plain(recipe["process"])), styles["Small"])]
            if recipe.get("required_tests"):
                story += [Paragraph("Recommended validation", styles["BodyText"]),
                          Paragraph(safe(_plain(recipe["required_tests"])), styles["Small"])]

    for comparison in state.get('cost_comparisons', []):
        story.append(Paragraph('Baseline cost and performance optimization', styles['Section']))
        story.append(_table(_rows({k: comparison.get(k) for k in (
            'comparison_id', 'baseline_id', 'best_evaluated_id', 'selection_status', 'currency',
            'cost_basis', 'pareto_ids', 'scope', 'material_performance_limit')}), styles, colors, inch))
        for iteration in comparison['iterations']:
            story.append(Paragraph(safe(iteration['id'] + ' — ' + iteration['label']), styles['Heading3']))
            story.append(_table(_rows({k: iteration.get(k) for k in (
                'recipe_id', 'cost_id', 'changes', 'cost_per_saleable_kg', 'cost_range',
                'savings_per_kg', 'savings_pct', 'status', 'reasons')}), styles, colors, inch))
            for metric in iteration['performance']:
                story.append(_table(_rows({k: v for k, v in metric.items() if k not in ('input_provenance',)}), styles, colors, inch))
        story.append(Paragraph('Grade and supplier cost comparison', styles['Heading3']))
        for grade in comparison['grade_comparison']:
            story.append(_table(_rows(grade), styles, colors, inch))
        evaluated = [r for r in comparison['iterations'] if r['cost_per_saleable_kg'] is not None]
        if evaluated:
            fig, ax = plt.subplots(figsize=(8, 3.5))
            ax.bar([r['id'] for r in evaluated], [r['cost_per_saleable_kg'] for r in evaluated],
                   color=['#176b62' if r['status'] == 'eligible' else '#ad5a50' for r in evaluated])
            ax.set_ylabel(comparison['currency'] + ' / kg saleable product')
            ax.set_xlabel('Iteration (green: eligible; red: excluded or unresolved)')
            ax.set_title('Total production cost versus baseline')
            fig.tight_layout()
            chart_path = root / (comparison['comparison_id'] + '-costs.png')
            fig.savefig(chart_path, dpi=150)
            plt.close(fig)
            story.append(Image(str(chart_path), width=6.7 * inch, height=3.0 * inch, kind='proportional'))

    runs = state.get("analysis_runs", [])
    for index, record in enumerate(runs, 1):
        output = record.get("result", {})
        story.append(Paragraph(safe(record.get("title", record.get("kind", f"Scenario {index}"))), styles["Section"]))
        summary = [("Scenario ID", record.get("scenario_id", "")), ("Model", record.get("kind", ""))]
        if record.get("recipe_linkage"):
            summary.append(("Recipe", _plain(record["recipe_linkage"])))
        if output.get("evidence"):
            summary.append(("Evidence", _plain(output["evidence"])))
        story.append(_table(summary, styles, colors, inch))
        if output.get("metrics"):
            story.append(Paragraph("Results", styles["Heading3"]))
            story.append(_table(_rows(output["metrics"]), styles, colors, inch))
        if record.get("inputs"):
            story.append(Paragraph("Inputs and assumptions", styles["Heading3"]))
            story.append(_table(_rows(record["inputs"]), styles, colors, inch))
        limitations = output.get("limitations")
        if limitations:
            story.append(Paragraph("Limitations", styles["Heading3"]))
            story.append(_table(_rows(limitations), styles, colors, inch))
        series = scenario_series(record)[:8]
        if series:
            stem = f"scenario-{index}"
            fig, axes = plt.subplots(len(series), 1, figsize=(8, max(3, 2.8 * len(series))), squeeze=False)
            for ax, line in zip(axes.flat, series):
                plot = ax.scatter if line.get("scatter") else ax.plot
                plot(line["x"], line["y"], label=line.get("name", "Result"))
                ax.set_xlabel(line.get("x_label", "")); ax.set_ylabel(line.get("y_label", ""))
                ax.legend(); ax.grid(alpha=.2)
            fig.tight_layout()
            chart_path = root / f"{stem}.png"
            fig.savefig(chart_path, dpi=150)
            plt.close(fig)
            story.append(Image(str(chart_path), width=6.7 * inch, height=3.1 * inch, kind="proportional"))
        if output.get("warnings"):
            story.append(Paragraph("Warnings", styles["Heading3"]))
            story.append(_table(_rows(output["warnings"]), styles, colors, inch))

    for key, heading in (("design_studies", "Design studies"), ("formulation_workflows", "AI + Physics workflows"),
                         ("fit_runs", "Fitted models"), ("cost_estimates", "Cost estimates"),
                         ("research_sources", "Research sources"), ("imports", "Imported data")):
        entries = state.get(key, [])
        if not entries:
            continue
        story.append(Paragraph(heading, styles["Section"]))
        for entry in entries:
            label = entry.get("name") or entry.get("title") or entry.get("study_id") or entry.get("source_id") or heading
            story.append(Paragraph(safe(label), styles["Heading3"]))
            story.append(_table(_rows(entry), styles, colors, inch))

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawString(0.65 * inch, 0.42 * inch, "AgriFormulations • assumptions and model limits apply")
        canvas.drawRightString(letter[0] - 0.65 * inch, 0.42 * inch, f"Page {doc.page}")
        canvas.restoreState()

    SimpleDocTemplate(str(target), pagesize=letter, rightMargin=.65 * inch, leftMargin=.65 * inch,
                      topMargin=.62 * inch, bottomMargin=.68 * inch, title=brief.get("name", "Formulation results"),
                      author="AgriFormulations").build(story, onFirstPage=footer, onLaterPages=footer)
    for index, record in enumerate(runs, 1):
        (root / f"scenario-{index}.json").write_text(json.dumps(record, indent=2, allow_nan=False))
    return target


def _table(rows, styles, colors, inch):
    from reportlab.platypus import Paragraph, Table, TableStyle
    data = [["Field", "Result"]]
    data.extend([[Paragraph(str(label).replace("&", "&amp;").replace("<", "&lt;"), styles["Cell"]),
                  Paragraph(str(value).replace("&", "&amp;").replace("<", "&lt;").replace("\n", "<br/>"), styles["Cell"])]
                 for label, value in rows])
    table = Table(data, colWidths=[1.65 * inch, 5.0 * inch], repeatRows=1, hAlign="LEFT", splitInRow=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17324d")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BACKGROUND", (0, 1), (0, -1), colors.HexColor("#edf3f7")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), .35, colors.HexColor("#cbd5e1")),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return table


def _ingredient_table(ingredients, batch_g, styles, colors, inch):
    from reportlab.platypus import Paragraph, Table, TableStyle
    data = [["Ingredient", "Role", "% w/w", "Mass (g)"]]
    batch_g = batch_g or 0
    for ingredient in ingredients:
        pct = ingredient.get("pct")
        mass = ingredient.get("grams")
        if mass is None:
            mass = batch_g * (ingredient.get("fraction") or 0)
        data.append([Paragraph(str(ingredient.get("name", "Ingredient")).replace("&", "&amp;"), styles["Cell"]),
                     Paragraph(str(ingredient.get("role", "—")).replace("&", "&amp;"), styles["Cell"]),
                     f"{pct:.4g}" if isinstance(pct, (int, float)) else "—",
                     f"{mass:.4g}" if isinstance(mass, (int, float)) else "—"])
    table = Table(data, colWidths=[3.05 * inch, 1.45 * inch, .9 * inch, 1.0 * inch], repeatRows=1, hAlign="LEFT", splitInRow=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#176b62")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), .35, colors.HexColor("#cbd5e1")),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return table
