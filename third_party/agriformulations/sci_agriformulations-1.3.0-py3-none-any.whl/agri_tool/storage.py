"""Profile-local revisions, durable request identities and content-addressed artifacts."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import uuid

from agriformulations.rnd.workspace import Workspace, RevisionConflict
from agriformulations.rnd.common import label


def now():
    return datetime.now(timezone.utc).isoformat()


def identifier(value, name="identifier"):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", value):
        raise ValueError(name + " must be 1–100 letters, digits, underscores or hyphens")
    return value


class Store(Workspace):
    def __init__(self, root):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        super().__init__(self.root / "projects.sqlite3")
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS requests (
                    request_id TEXT PRIMARY KEY, digest TEXT, request TEXT, project_id TEXT,
                    owner INTEGER, status TEXT, initial_state TEXT, working_state TEXT,
                    response TEXT, created TEXT, updated TEXT, cancel_requested INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS request_events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT, created TEXT, event TEXT);
            """)

    def create_for_request(self, document, request_id):
        """Commit project birth and its recovery link in one SQLite transaction."""
        name = label(document.get("brief", {}).get("name"), "project name")
        body = json.dumps(document, sort_keys=True, allow_nan=False)
        if len(body.encode()) > 7_500_000:
            raise ValueError("Project exceeds 7.5MB; export raw data separately")
        project_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "agri-tool/project/" + request_id))
        created = now()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO revisions(project_id,revision,name,created,document) VALUES(?,1,?,?,?)", (project_id, name, created, body))
            db.execute("UPDATE requests SET project_id=?,working_state=?,updated=? WHERE request_id=?", (project_id, body, created, request_id))
        return {"project_id": project_id, "revision": 1, "updated": created}

    def reserve(self, request, digest):
        rid = identifier(request.get("request_id") or uuid.uuid4().hex, "request_id")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT digest,status,owner,response,working_state,initial_state,project_id FROM requests WHERE request_id=?", (rid,)).fetchone()
            if row:
                if row[0] != digest:
                    raise ValueError("request_id belongs to different inputs; reuse it only for an exact retry")
                if row[3]:
                    return rid, json.loads(row[3]), None
                alive = False
                if row[1] != "resume_requested":
                    try:
                        os.kill(row[2], 0)
                        alive = True
                    except ProcessLookupError:
                        pass
                    except PermissionError:
                        alive = True
                if alive:
                    return rid, {"status": "partial", "result": {"request_status": row[1], "request_id": rid,
                        "message": "Execution already exists. Poll project/job; do not submit another request."}}, None
                resume = {"state": json.loads(row[4]) if row[4] else {},
                    "initial_state": json.loads(row[5]) if row[5] else {}, "project_id": row[6]}
                db.execute("UPDATE requests SET owner=?,status='running',cancel_requested=0,updated=? WHERE request_id=?", (os.getpid(), now(), rid))
                return rid, None, resume
            db.execute("INSERT INTO requests(request_id,digest,request,project_id,owner,status,created,updated) VALUES(?,?,?,?,?,'running',?,?)",
                (rid, digest, json.dumps(request, allow_nan=False), request.get("project_id"), os.getpid(), now(), now()))
        return rid, None, None

    def resume(self, rid, digest_request=None):
        job = self.job(rid)
        if job["status"] not in ("cancelled", "interrupted", "error", "partial", "resume_requested"):
            raise ValueError("Only cancelled, interrupted or incomplete requests can be explicitly resumed")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT request,digest FROM requests WHERE request_id=?", (rid,)).fetchone()
            request = json.loads(row[0])
            if digest_request and digest_request(request) != row[1]:
                raise ValueError("Tool or engine code changed since this request. Keep its completed results and submit revised work with a new request_id; old stopped work was not restarted.")
            db.execute("UPDATE requests SET response=NULL,status='resume_requested',cancel_requested=0,updated=? WHERE request_id=?", (now(), rid))
        request["request_id"] = rid
        return request

    def jobs(self, project_id=None):
        with self.connect() as db:
            rows = db.execute("SELECT request_id FROM requests" + (" WHERE project_id=?" if project_id else "") + " ORDER BY created DESC LIMIT 50", (project_id,) if project_id else ()).fetchall()
        return [self.job(row[0]) for row in rows]

    def event(self, rid, event):
        with self.connect() as db:
            db.execute("INSERT INTO request_events(request_id,created,event) VALUES(?,?,?)", (rid, now(), json.dumps(event, allow_nan=False)))

    def checkpoint(self, rid, state, message):
        with self.connect() as db:
            db.execute("UPDATE requests SET working_state=?,updated=? WHERE request_id=?", (json.dumps(state, allow_nan=False), now(), rid))
        self.event(rid, {"kind": "checkpoint", "message": message})

    def finish(self, rid, response):
        with self.connect() as db:
            db.execute("UPDATE requests SET response=?,status=?,project_id=COALESCE(?,project_id),updated=? WHERE request_id=?",
                (json.dumps(response, allow_nan=False), response["status"], response.get("project_id"), now(), rid))

    def job(self, rid):
        identifier(rid, "request_id")
        with self.connect() as db:
            db.row_factory = sqlite3.Row
            row = db.execute("SELECT request_id,project_id,owner,status,created,updated,cancel_requested,response,working_state FROM requests WHERE request_id=?", (rid,)).fetchone()
            if row is None:
                raise ValueError("Request does not belong to this workspace")
            result = dict(row)
            events = db.execute("SELECT seq,created,event FROM request_events WHERE request_id=? ORDER BY seq DESC LIMIT 100", (rid,)).fetchall()
        if result["status"] == "running":
            try:
                os.kill(result["owner"], 0)
            except ProcessLookupError:
                result["status"] = "interrupted"
            except PermissionError:
                pass
        result.pop("owner")
        result["response"] = json.loads(result["response"]) if result["response"] else None
        working = json.loads(result.pop("working_state") or "{}")
        result["checkpoint_counts"] = {key: len(working.get(key, [])) for key in ("recipes", "analysis_runs", "design_studies", "fit_runs")}
        result["events"] = [{"sequence": e[0], "created": e[1], **json.loads(e[2])} for e in reversed(events)]
        return result

    def cancel(self, rid):
        self.job(rid)
        with self.connect() as db:
            db.execute("UPDATE requests SET cancel_requested=1 WHERE request_id=? AND status='running'", (rid,))
        return self.job(rid)

    def cancelled(self, rid):
        with self.connect() as db:
            row = db.execute("SELECT cancel_requested FROM requests WHERE request_id=?", (rid,)).fetchone()
        return bool(row and row[0])

    def artifact(self, path, media_type="application/octet-stream", name=None):
        source = Path(path)
        sha = hashlib.sha256(source.read_bytes()).hexdigest()
        filename = Path(name or source.name).name
        target = self.root / "artifacts" / sha / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.resolve() != target.resolve():
            shutil.copyfile(source, target)
        return {"artifact_id": sha + "/" + filename, "name": filename, "media_type": media_type,
            "sha256": sha, "bytes": target.stat().st_size, "path": str(target)}

    def artifact_path(self, artifact_id):
        if not isinstance(artifact_id, str):
            raise ValueError("Supply artifact_id")
        root = (self.root / "artifacts").resolve()
        path = (root / artifact_id).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError("Artifact does not belong to this workspace")
        return path
