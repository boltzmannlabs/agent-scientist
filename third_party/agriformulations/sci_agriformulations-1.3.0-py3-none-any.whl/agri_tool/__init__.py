"""Single scientific tool, keyed operations, no nested language-model calls."""
__version__ = "1.3.0"


def execute(request, workspace):
    """Execute a structured request using a caller-owned persistent workspace."""
    from .service import execute as run
    return run(request, workspace)
