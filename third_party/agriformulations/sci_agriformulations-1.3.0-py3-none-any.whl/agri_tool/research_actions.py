"""Metadata retrieval and explicit source-review records; no LLM execution."""
import json
from pathlib import Path
import tempfile
from agriformulations.rnd import research
from .errors import require


def handle(action, payload, context):
    context.require_project()
    if action == "search":
        result = research.record(context.state, payload.get("parameters", payload))
        context.save()
        return result
    if action == "list":
        return {"searches": [research.search_preview(s) for s in context.state.get("research_searches", [])]}
    if action == "get":
        require(payload, ["search_id"])
        result = next((s for s in context.state.get("research_searches", []) if s["search_id"] == payload["search_id"]), None)
        if result is None:
            raise ValueError("Search does not belong to this project")
        return result
    if action == "sources":
        return {"sources": context.state.get("research_sources", [])}
    if action == "save_source":
        require(payload, ["search_id", "record_id"])
        result = research.save_source(context.state, payload["search_id"], payload["record_id"], payload.get("notes", ""), payload.get("status", "saved"), payload.get("evidence_stage"))
        context.save()
        return result
    if action == "citations":
        sources = context.state.get("research_sources", [])
        records = [s["source"] for s in sources]
        if payload.get("search_id"):
            result = next((s for s in context.state.get("research_searches", []) if s["search_id"] == payload["search_id"]), None)
            if result is None:
                raise ValueError("Search does not belong to this project")
            records = result["results"]
        citations = [{"id": s["record_id"], "type": "patent" if s["kind"] == "patent" else "article-journal",
            "title": s["title"], "URL": s["url"], **({"DOI": s["doi"]} if s.get("doi") else {}),
            **({"issued": {"date-parts": [[s["year"]]]}} if s.get("year") else {}),
            "author": [{"literal": a} for a in s.get("authors", [])]} for s in records]
        with tempfile.TemporaryDirectory(dir=context.root, prefix="citations-") as folder:
            path = Path(folder) / "citations.csl.json"
            path.write_text(json.dumps(citations, indent=2, ensure_ascii=False))
            artifact = context.artifact(path, "application/vnd.citationstyles.csl+json")
        return {"citations": citations, "artifacts": [artifact], "evidence": "Bibliographic metadata only; claim support requires source review"}
    raise ValueError("Unknown research action")
