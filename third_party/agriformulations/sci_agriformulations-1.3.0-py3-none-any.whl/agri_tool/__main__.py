"""Run the installed scientific worker with python -m agri_tool."""
from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
