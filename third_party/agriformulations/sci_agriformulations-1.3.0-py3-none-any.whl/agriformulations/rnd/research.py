"""Live scholarly and patent discovery with project-owned retrieval snapshots."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import html
import json
import re
import ssl
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

from . import control
from .common import digest, integer, label

MAX_RESPONSE_BYTES = 4_000_000
TIMEOUT_SECONDS = 15
FIELDS = {"kind", "query", "limit", "year_from", "year_to", "country", "cpc", "sort", "focus_terms"}


def validate(raw):
    if not isinstance(raw, dict) or set(raw) - FIELDS:
        raise ValueError("Unsupported research search fields")
    kind = raw.get("kind", "literature")
    if kind not in ("literature", "patent"):
        raise ValueError("Choose literature or patent search")
    query = label(raw.get("query"), "search query", 500)
    if any(ord(c) < 32 for c in query):
        raise ValueError("Search query cannot contain control characters")
    result = {"kind": kind, "query": query, "limit": integer(raw.get("limit", 10), "result limit", 1, 30),
              "sort": raw.get("sort", "relevance")}
    if result["sort"] not in ("relevance", "newest"):
        raise ValueError("Choose relevance or newest sorting")
    focus = raw.get("focus_terms", [])
    if not isinstance(focus, list) or len(focus) > 6:
        raise ValueError("focus_terms must contain up to six aliases for one crop, active or target")
    result["focus_terms"] = []
    for value in focus:
        term = label(value, "focus term", 100)
        if any(ord(c) < 32 for c in term):
            raise ValueError("Focus terms cannot contain control characters")
        if term.casefold() not in {t.casefold() for t in result["focus_terms"]}:
            result["focus_terms"].append(term)
    for key in ("year_from", "year_to"):
        value = raw.get(key)
        result[key] = None if value is None or value == "" else integer(value, key, 1800, 2100)
    if result["year_from"] and result["year_to"] and result["year_from"] > result["year_to"]:
        raise ValueError("Start year must not exceed end year")
    for key, pattern in (("country", r"[A-Z]{2}"), ("cpc", r"[A-HY]\d{2}[A-Z](?:\d{1,4}(?:/\d{1,6})?)?")):
        value = raw.get(key, "")
        if not isinstance(value, str):
            raise ValueError(key + " must be text")
        value = value.strip().upper().replace(" ", "")
        if value and not re.fullmatch(pattern, value):
            raise ValueError("Invalid " + key + " filter")
        if value and kind != "patent":
            raise ValueError(key + " applies only to patents")
        result[key] = value
    return result


def text(value, limit=12000):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]*>", " ", str(value or "")))).strip()[:limit]


def fetch_json(url):
    request = Request(url, headers={"User-Agent": "AgriFormulations/0.3 (research metadata search)", "Accept": "application/json"})
    context = ssl.create_default_context()
    # Conda may ship a separate CA bundle; also trust the host's maintained roots.
    system_roots = Path("/etc/ssl/certs/ca-certificates.crt")
    if system_roots.is_file():
        context.load_verify_locations(cafile=str(system_roots))
    with urlopen(request, timeout=TIMEOUT_SECONDS, context=context) as response:
        body = response.read(MAX_RESPONSE_BYTES + 1)
    if len(body) > MAX_RESPONSE_BYTES:
        raise ValueError("Provider response exceeded the size limit")
    return json.loads(body)


def year_of(value):
    match = re.match(r"(\d{4})", str(value or ""))
    return int(match[1]) if match else None


def crossref(params):
    query = {"query.bibliographic": params["query"], "rows": params["limit"]}
    filters = []
    if params["year_from"]:
        filters.append("from-pub-date:" + str(params["year_from"]) + "-01-01")
    if params["year_to"]:
        filters.append("until-pub-date:" + str(params["year_to"]) + "-12-31")
    if filters:
        query["filter"] = ",".join(filters)
    if params["sort"] == "newest":
        query.update(sort="published", order="desc")
    url = "https://api.crossref.org/works?" + urlencode(query)
    message = fetch_json(url)["message"]
    records = []
    for item in message["items"]:
        doi = text(item.get("DOI"), 300).lower()
        if not doi:
            continue
        parts = (item.get("published") or item.get("issued") or {}).get("date-parts", [[]])[0]
        records.append({"kind": "literature", "provider": "Crossref", "doi": doi,
            "title": text((item.get("title") or [doi])[0], 2000), "url": "https://doi.org/" + quote(doi, safe="/"),
            "year": parts[0] if parts else None,
            "authors": [text(" ".join([a.get("given", ""), a.get("family", "")])) for a in item.get("author", [])[:30]],
            "journal": text((item.get("container-title") or [""])[0]), "abstract": text(item.get("abstract")),
            "publication_type": text(item.get("type")), "publisher": text(item.get("publisher"))})
    return records, {"provider": "Crossref", "url": url, "total": message.get("total-results")}


def europe_pmc(params):
    query = "(" + params["query"] + ")"
    if params["year_from"] or params["year_to"]:
        query += " AND FIRST_PDATE:[%s-01-01 TO %s-12-31]" % (params["year_from"] or 1800, params["year_to"] or 2100)
    if params["sort"] == "newest":
        query += " sort_date:y"
    url = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urlencode(
        {"query": query, "format": "json", "resultType": "core", "pageSize": params["limit"]})
    data = fetch_json(url)
    records = []
    for item in data["resultList"]["result"]:
        doi = text(item.get("doi"), 300).lower()
        source, identifier = item.get("source"), item.get("id")
        if not identifier or not source:
            continue
        records.append({"kind": "literature", "provider": "Europe PMC", "doi": doi,
            "provider_id": str(source) + ":" + str(identifier), "title": text(item.get("title"), 2000),
            "url": "https://doi.org/" + quote(doi, safe="/") if doi else "https://europepmc.org/article/" + quote(str(source), safe="") + "/" + quote(str(identifier), safe=""),
            "year": year_of(item.get("pubYear")), "publication_date": item.get("firstPublicationDate"),
            "authors": [text(a.get("fullName")) for a in item.get("authorList", {}).get("author", [])[:30]],
            "journal": text(item.get("journalInfo", {}).get("journal", {}).get("title")), "abstract": text(item.get("abstractText")),
            "open_access": item.get("isOpenAccess") == "Y"})
    return records, {"provider": "Europe PMC", "url": url, "total": data.get("hitCount")}


def google_patents(params):
    query = {"q": params["query"], "num": 10 if params["limit"] <= 10 else 25 if params["limit"] <= 25 else 50}
    if params["country"]:
        query["country"] = params["country"]
    if params["cpc"]:
        query["cpc"] = params["cpc"]
    if params["year_from"]:
        query["after"] = "publication:" + str(params["year_from"]) + "0101"
    if params["year_to"]:
        query["before"] = "publication:" + str(params["year_to"] + 1) + "0101"
    if params["sort"] == "newest":
        query["sort"] = "new"
    search_url = "https://patents.google.com/?" + urlencode(query)
    data = fetch_json("https://patents.google.com/xhr/query?" + urlencode({"url": urlencode(query), "exp": ""}))
    results = data["results"]
    if not isinstance(results.get("cluster", []), list):
        raise ValueError("Unexpected patent response format")
    records = []
    for cluster in results.get("cluster", []):
        for row in cluster.get("result", []):
            item = row.get("patent", {})
            number = str(item.get("publication_number", ""))
            if not re.fullmatch(r"[A-Z]{2}[A-Z0-9]+", number):
                continue
            records.append({"kind": "patent", "provider": "Google Patents", "publication_number": number,
                "title": text(item.get("title"), 2000), "url": "https://patents.google.com/patent/" + number + "/en",
                "abstract": text(item.get("snippet")), "year": year_of(item.get("publication_date")),
                "publication_date": item.get("publication_date"), "priority_date": item.get("priority_date"),
                "filing_date": item.get("filing_date"), "country": number[:2],
                "assignee": text(item.get("assignee")), "inventors": text(item.get("inventor")),
                "legal_status": "Not verified; consult the relevant patent register"})
    return records, {"provider": "Google Patents", "url": search_url, "total": results.get("total_num_results"),
        "note": "Public website endpoint; availability and response format may change. Results are publication records, not a complete patent-family or claims analysis."}


def search(raw):
    params = validate(raw)
    records, providers, warnings = [], [], []
    functions = (crossref, europe_pmc) if params["kind"] == "literature" else (google_patents,)
    retrieved = datetime.now(timezone.utc).isoformat()
    for function in functions:
        control.check()
        token = control.current()
        if token and token.on_event:
            token.on_event({"kind": "tool_started", "tool": "search_" + params["kind"], "message": "Searching " + function.__name__.replace("_", " ")})
        try:
            retrieval = dict(params)
            if params["focus_terms"]:
                retrieval["limit"] = min(30, params["limit"] * 3)
            found, provider = function(retrieval)
            for rank, item in enumerate(found, 1):
                item["provider_ranks"] = {item["provider"]:rank}
            records.extend(found)
            providers.append(dict(provider, status="ok"))
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, KeyError, TypeError) as exc:
            message = ("HTTP " + str(exc.code)) if isinstance(exc, HTTPError) else str(exc)[:300]
            providers.append({"provider": function.__name__, "status": "unavailable", "error": message})
            warnings.append(function.__name__.replace("_", " ") + ": " + message)
        control.check()
    unique = {}
    for item in records:
        year = item.get("year")
        if (params["year_from"] or params["year_to"]) and (year is None or year < (params["year_from"] or 1800) or year > (params["year_to"] or 2100)):
            continue
        if params["country"] and item.get("country") != params["country"]:
            continue
        identity = item.get("doi") or item.get("publication_number") or item.get("provider_id") or item["url"]
        item["record_id"] = "ref-" + digest({"kind": params["kind"], "identity": identity})
        item["retrieved_at"] = retrieved
        item["evidence"] = "retrieved bibliographic metadata" if params["kind"] == "literature" else "retrieved patent search metadata"
        prior = unique.get(item["record_id"])
        if prior:
            prior["providers"] = sorted(set(prior["providers"] + [item["provider"]]))
            prior["provider_ranks"].update(item["provider_ranks"])
            if not prior.get("abstract"):
                prior["abstract"] = item.get("abstract", "")
        else:
            item["providers"] = [item["provider"]]
            unique[item["record_id"]] = item
    ordered = list(unique.values())
    focus_words = set(re.findall(r"\w+", " ".join(params["focus_terms"]).casefold()))
    query_words = set(re.findall(r"\w+", params["query"].casefold())) - focus_words
    query_words -= {"the", "and", "for", "with", "from", "into", "using"}
    query_words = {word for word in query_words if len(word) > 2}
    for item in ordered:
        item["focus_assessment"] = assess_focus(item, params["focus_terms"])
        item["query_terms_in_title"] = sorted(query_words & set(re.findall(r"\w+", item["title"].casefold())))
    if params["sort"] == "newest":
        ordered.sort(key=lambda r: (r.get("year") or 0, r.get("publication_date") or ""), reverse=True)
    else:
        # Compare each provider's retrieval rank instead of filling the entire
        # shortlist from whichever provider was called first.
        ordered.sort(key=lambda r: (r["focus_assessment"]["priority"], -len(r["query_terms_in_title"]), min(r["provider_ranks"].values())))
    selected = ordered[:params["limit"]]
    encoded = json.dumps(selected, sort_keys=True, ensure_ascii=False).encode()
    ok = sum(p["status"] == "ok" for p in providers)
    return {"search_id": "search-" + digest({"parameters": params, "retrieved_at": retrieved}),
        "parameters": params, "retrieved_at": retrieved, "results": selected, "providers": providers,
        "status": "completed" if ok == len(providers) else "partial" if ok else "unavailable",
        "focus_summary":{"terms":params["focus_terms"],
            "matching_records":sum(r["focus_assessment"]["matched"] for r in selected),
            "basis":"Literal crop/active/target alias matches in titles or supplied abstracts; not an efficacy or quality assessment."},
        "warnings": warnings, "snapshot_sha256": hashlib.sha256(encoded).hexdigest(),
        "evidence": "live search metadata; full text and claims not reviewed",
        "limitations": ["Searches are not exhaustive. Metadata and snippets require source review.",
            "Patent search results do not establish novelty, patentability, freedom to operate or current legal status."]}


def assess_focus(record, terms):
    """Transparent literal relevance check; absence of text is not negative evidence."""
    title, abstract = record.get("title", ""), record.get("abstract", "")
    def matches(value):
        return [term for term in terms if re.search(r"(?<!\w)" + r"\s+".join(re.escape(t) for t in term.split()) + r"(?!\w)", value, re.I)]
    title_matches, abstract_matches = matches(title), matches(abstract)
    priority = 0 if title_matches or not terms else 1 if abstract_matches else 2
    return {"matched":bool(title_matches or abstract_matches), "priority":priority,
            "title_terms":title_matches, "abstract_terms":abstract_matches,
            "label":("Focus appears in title" if title_matches else "Focus appears in abstract" if abstract_matches
                     else "Focus not confirmed in available metadata" if terms else "No focus specified")}


def search_preview(run):
    """Enough saved evidence for a first comparison without repeated discovery calls."""
    return {"search_id":run["search_id"], "parameters":run["parameters"], "status":run["status"],
            "n_results":len(run["results"]), "preview":[
                {"record_id":r["record_id"], "title":r["title"][:500], "url":r["url"], "year":r.get("year"),
                 "abstract_excerpt":r.get("abstract", "")[:600], "focus_assessment":r.get("focus_assessment")}
                for r in run["results"][:3]]}


def agent_snapshot(run):
    snapshot = deepcopy(run)
    for item in snapshot.get("results", []):
        abstract = item.get("abstract", "")
        if len(abstract) > 1600:
            item["abstract"] = abstract[:1600]
            item["abstract_truncated"] = True
    return snapshot


def interrupted_summary(state, trace):
    """Recover concrete source evidence after a failed synthesis, without inventing conclusions."""
    activity = [t for t in trace if t.get("tool") in {"search_literature", "search_patents", "list_research"}
                and not t.get("error")]
    if not activity:
        return ""
    ids = {t.get("result_summary", {}).get("search_id") for t in activity}
    searches = [s for s in state.get("research_searches", []) if s["search_id"] in ids]
    if not searches:
        searches = state.get("research_searches", [])[-2:]
    if not searches:
        return ""
    lines = ["The research stopped before the agent completed its comparison. The saved evidence is available below; these are metadata excerpts, not a completed source review."]
    for search in searches[-2:]:
        lines.append("Search: " + search["parameters"]["query"])
        if not search["results"]:
            lines.append("No records were retrieved." if search["status"] != "unavailable" else "Retrieval failed; this does not establish that no relevant sources exist.")
        for record in search["results"][:3]:
            lines.append("- [" + record["title"].replace("[", "(").replace("]", ")") + "](" + record["url"] + ")")
            focus = record.get("focus_assessment", {})
            if focus.get("label") and search["parameters"].get("focus_terms"):
                lines.append("  " + focus["label"] + ".")
            excerpt = record.get("abstract", "")[:450]
            lines.append("  Retrieved abstract excerpt: “" + excerpt + ("…" if len(record.get("abstract", "")) > 450 else "") + "”" if excerpt else "  No abstract supplied; the title alone cannot establish treatment performance.")
    lines.extend(["What this supports: selecting sources and provisional design directions to investigate. Search hits alone do not validate a formulation or a combination of actives.",
                  "Next step: compare the closest matching sources for target organism, treatment, application route and measured outcome. Use a clearly stated provisional target for an exploratory recipe; keep unverified compatibility and performance assumptions explicit."])
    return "\n\n".join(lines)


def record(state, raw):
    result = search(raw)
    state.setdefault("research_searches", []).append(result)
    control.checkpoint(state, "Saved " + result["parameters"]["kind"] + " search: " + str(len(result["results"])) + " records")
    return result


def save_source(state, search_id, record_id, notes="", status="saved", evidence_stage=None):
    label(search_id, "search ID", 80)
    label(record_id, "record ID", 80)
    if not isinstance(notes, str) or len(notes) > 3000:
        raise ValueError("Source notes must be text up to 3000 characters")
    if status not in ("saved", "reviewed", "excluded"):
        raise ValueError("Choose saved, reviewed or excluded source status")
    evidence_stage=evidence_stage or ("review_scope_unspecified" if status=="reviewed" else "metadata_only")
    if evidence_stage not in {"metadata_only","abstract_reviewed","full_text_reviewed","review_scope_unspecified"}:
        raise ValueError("Choose metadata_only, abstract_reviewed or full_text_reviewed evidence stage")
    if evidence_stage in {"abstract_reviewed","full_text_reviewed"} and (status!="reviewed" or not notes.strip()):
        raise ValueError("A recorded abstract/full-text review needs reviewed status and notes identifying the reviewed evidence and claim limits")
    run = next((r for r in state.get("research_searches", []) if r["search_id"] == search_id), None)
    source = next((r for r in (run or {}).get("results", []) if r["record_id"] == record_id), None)
    if source is None:
        raise ValueError("Search result does not belong to this project")
    entry = {"record_id": record_id, "source": deepcopy(source), "search_id": search_id,
        "snapshot_sha256": run["snapshot_sha256"], "notes": notes.strip(), "status": status,"evidence_stage":evidence_stage,
        "updated_at": datetime.now(timezone.utc).isoformat()}
    state["research_sources"] = [r for r in state.get("research_sources", []) if r["record_id"] != record_id] + [entry]
    return entry
