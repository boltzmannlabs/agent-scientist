"""Create a fresh product project with validated recipes and explicit scenario inputs."""
import json
from copy import deepcopy

from . import recipe_design, kinetics, stability, dosage, control
from .common import clean, digest, integer, label, number

KINETIC_KEYS = {"model", "rate_per_day", "plateau", "lag_days", "tau_days", "beta",
    "horizon_days", "reservoir_half_life_days", "available_half_life_days",
    "release_specs", "parameter_source", "points"}
STABILITY_KEYS = {"reference_rate_per_day", "reference_temperature_c", "activation_energy_kj_mol",
    "temperatures_c", "horizon_days", "minimum_retained_fraction", "temperature_profile", "physical"}
DOSE_KEYS = {"evaluation_day", "target_available_g_ha", "deposition_fraction",
    "maximum_product_kg_ha", "product_density_kg_l", "spray_volume_l_ha", "storage_temperature_c"}

def checked_inputs(value, name, allowed, required):
    if not isinstance(value, dict):
        raise ValueError(name + " must be an object with explicit scenario inputs")
    if set(value) - allowed:
        raise ValueError("Unsupported " + name + " inputs: " + ", ".join(sorted(set(value) - allowed)))
    missing = required - value.keys()
    if missing:
        raise ValueError("Missing " + name + " inputs: " + ", ".join(sorted(missing)))
    return deepcopy(value)

def restore_selection(state):
    """Restore only results belonging to the selected recipe and individual active."""
    for kind in ("kinetics", "stability", "dosage"):
        state.pop(kind + "_result", None)
        entries = [r for r in state.get("analysis_runs", [])
            if r.get("kind") == kind and r.get("recipe_id") == state.get("selected_recipe_id")
            and r.get("active_name") == state.get("selected_active_name")]
        if entries:
            entry = entries[-1]
            state[kind + "_input"] = deepcopy(entry["inputs"])
            state[kind + "_result"] = deepcopy(entry["result"])

def develop(raw, workspace, query="", source_state=None, source_identity=None, on_event=None):
    """Publish each finished recipe/active stage and resume exact matching checkpoints."""
    control.check()
    from .api import bootstrap
    designed = recipe_design.create(raw, workspace, query)
    if not 2 <= designed["generated"] <= 12:
        raise ValueError("Product development requires 2 to 12 distinct feasible recipes")
    try:
        scenarios = json.loads(raw.get("scenarios_json", ""))
    except (TypeError, json.JSONDecodeError):
        raise ValueError("scenarios_json must encode a list of explicit per-active scenarios") from None
    if not isinstance(scenarios, list) or not 1 <= len(scenarios) <= 100:
        raise ValueError("Provide 1 to 100 scenario configurations")
    recipes = designed["recipes"]
    active_names = {c["name"] for r in recipes for c in r["active_components"]}
    for s in scenarios:
        if not isinstance(s, dict) or set(s) - {"active_name", "recipe_index", "assumptions", "kinetics", "stability", "dosage"}:
            raise ValueError("Each scenario needs an active name, assumptions, kinetics, stability and dosage")
        if s.get("active_name") not in active_names:
            raise ValueError("Scenario active_name must match an actual active ingredient name")
        if "recipe_index" in s:
            integer(s["recipe_index"], "recipe_index", 1, len(recipes))
        assumptions = s.get("assumptions")
        if not isinstance(assumptions, list) or not 1 <= len(assumptions) <= 30:
            raise ValueError("Each scenario must state its assumptions and evidence gaps")
        s["assumptions"] = [label(a, "scenario assumption", 2000) for a in assumptions]
    state = deepcopy(bootstrap())
    for key in ("formats", "format_scaffolds", "agent_examples"):
        state.pop(key, None)
    state.update(brief=designed["brief"], recipe_result=designed, recipes=recipes,
        imports=[], conversation=[], analysis_runs=[], agent_reviews={})
    if source_identity and source_identity.get("project_id"):
        state["source_project"] = deepcopy(source_identity)
    source = source_state or {}
    prior = source.get("research_reports", [])[-1:] or source.get("conversation", [])[-1:]
    if prior:
        state["source_assessment"] = {k: deepcopy(prior[0][k])
            for k in ("task", "question", "answer", "sources") if k in prior[0]}
    if not prior and source.get("source_assessment"):
        state["source_assessment"] = deepcopy(source["source_assessment"])
    state["development_request"] = deepcopy(raw)
    state["selected_recipe_id"] = recipes[0]["recipe_id"]
    state["selected_active_name"] = recipes[0]["active_components"][0]["name"]
    state["product_development"] = {"status":"running","candidate_count":len(recipes),
        "active_count":len(active_names),"analysis_count":0,
        "target_count":sum(len(r["active_components"]) for r in recipes)*3}
    resume = control.current().resume_state if control.current() else {}
    if resume:
        # Preserve data and discussion added while an earlier run was stopped or
        # finishing. The batch keeps its exact recipe identities and assumptions.
        for key in ("imports","conversation","research_reports"):
            state[key]=deepcopy(source.get(key,[]))
        generated_ids={r["recipe_id"] for r in recipes}
        state["recipes"].extend(deepcopy(r) for r in source.get("recipes",[])
            if r["recipe_id"] not in generated_ids)
        state["analysis_runs"]=deepcopy([r for r in source.get("analysis_runs",[])
            if r.get("recipe_id") not in generated_ids])
    prior_count=len(state["analysis_runs"])
    retained = {(r["kind"],r["recipe_id"],r.get("active_name"),digest(r["inputs"])):r
        for r in resume.get("analysis_runs",[]) if r.get("engine_version")==control.engine_version()}
    def stage(kind, inputs, function, recipe, active, assumptions):
        control.check()
        key = (kind,recipe["recipe_id"],active,digest(inputs))
        if key in retained:
            result = deepcopy(retained[key]["result"])
            if on_event:
                on_event({"kind":"step_reused","message":"Restored completed "+kind+" result",
                    "recipe_id":recipe["recipe_id"],"active_name":active,"tool":kind})
        else:
            result = control.compute(kind,inputs,function)
        result.update(recipe_id=recipe["recipe_id"],active_name=active,
            scenario_assumptions=deepcopy(assumptions))
        state["analysis_runs"].append({"kind":kind,"recipe_id":recipe["recipe_id"],
            "active_name":active,"inputs":deepcopy(inputs),"result":result,
            "scenario_id":"s-dev-"+digest({"kind":kind,"inputs":inputs,"recipe_id":recipe["recipe_id"],
                "active_name":active,"engine_version":control.engine_version()}),
            "engine_version":control.engine_version(),"assumptions":deepcopy(assumptions)})
        state["product_development"]["analysis_count"] = len(state["analysis_runs"])-prior_count
        restore_selection(state)
        control.checkpoint(state,"Saved "+kind+" for "+recipe["name"]+" / "+active)
        return result
    control.checkpoint(state,"Recipe candidates saved; simulations starting")
    comparison = []
    for index, recipe in enumerate(recipes, 1):
        for component in recipe["active_components"]:
            active = component["name"]
            matching = [s for s in scenarios if s["active_name"] == active
                and s.get("recipe_index", index) == index]
            specific = [s for s in matching if "recipe_index" in s]
            matching = specific or matching
            if len(matching) != 1:
                raise ValueError("Provide exactly one applicable scenario for each recipe and active: "
                    + str(index) + " / " + active)
            scenario = matching[0]
            kin = checked_inputs(scenario.get("kinetics"), "kinetics", KINETIC_KEYS,
                {"model", "plateau", "lag_days", "horizon_days", "parameter_source"})
            required_rate = {"tau_days", "beta"} if kin["model"] == "weibull" else {"rate_per_day"}
            if not required_rate <= kin.keys():
                raise ValueError("Supply the release model rate or Weibull parameters explicitly")
            label(kin["parameter_source"], "kinetic parameter source", 2000)
            store = checked_inputs(scenario.get("stability"), "stability", STABILITY_KEYS,
                {"reference_rate_per_day", "reference_temperature_c", "activation_energy_kj_mol",
                 "temperatures_c", "horizon_days", "minimum_retained_fraction"})
            dose = checked_inputs(scenario.get("dosage"), "dosage", DOSE_KEYS,
                {"evaluation_day", "target_available_g_ha", "deposition_fraction", "storage_temperature_c"})
            if on_event:
                on_event({"kind": "tool_progress", "message": "Simulating recipe " + str(index)
                    + " / " + active, "recipe_id": recipe["recipe_id"], "active_name": active})
            evaluation_day = number(dose["evaluation_day"],"evaluation_day",0,kin["horizon_days"])
            kin["release_specs"] = [*kin.get("release_specs",[]),{"day":evaluation_day}]
            kresult = stage("kinetics",kin,kinetics.simulate,recipe,active,scenario["assumptions"])
            sresult = stage("stability",store,stability.simulate,recipe,active,scenario["assumptions"])
            storage_temp = number(dose.pop("storage_temperature_c"), "storage_temperature_c", -50, 100)
            curve = next((c for c in sresult["curves"] if abs(c["temperature_c"]-storage_temp) < 1e-8), None)
            if curve is None:
                raise ValueError("Dose storage temperature must match a simulated stability temperature")
            dose.update(storage_retained_fraction=curve["retained_at_horizon"],
                active_fraction=component["active_fraction"], kinetics=deepcopy(kin),
                context={"recipe_id": recipe["recipe_id"], "active_name": active,
                    "crop": state["brief"].get("crop", ""), "target": state["brief"].get("target", ""),
                    "storage_temperature_c": storage_temp, "storage_days": store["horizon_days"],
                    "status": "hypothetical exposure target; not a field-use recommendation"})
            dresult = stage("dosage",dose,lambda p:dosage.scenario(p,kinetic_result=kresult),
                recipe,active,scenario["assumptions"])
            comparison.append({"recipe_id": recipe["recipe_id"], "recipe_name": recipe["name"],
                "active_name": active, "active_fraction": component["active_fraction"],
                "release_at_horizon": kresult["release_fraction"][-1],
                "release_horizon_days": kin["horizon_days"],
                "storage_retained_fraction": curve["retained_at_horizon"],
                "storage_temperature_c": storage_temp, "storage_days": store["horizon_days"],
                "product_kg_ha": dresult["product_kg_ha"], "dose_evaluation_day": dose["evaluation_day"],
                "target_available_g_ha": dose["target_available_g_ha"],
                "assumptions": deepcopy(scenario["assumptions"])})
    state["selected_recipe_id"] = recipes[0]["recipe_id"]
    state["selected_active_name"] = recipes[0]["active_components"][0]["name"]
    restore_selection(state)
    state["experiment_input"]["n_recipes"] = min(len(recipes), state["experiment_input"]["n_recipes"])
    state["product_development"] = {"status": "scenarios_completed", "candidate_count": len(recipes),
        "active_count": len(active_names), "analysis_count": len(state["analysis_runs"])-prior_count,
        "comparison": comparison,
        "evidence": "Constraint-checked recipe drafts and explicit assumption-based scenarios",
        "limitations": ["Composition does not establish release rates, chemical stability or biological efficacy.",
            "Shared input assumptions yield shared predictions; no measured performance ranking is inferred.",
            "Dose targets are hypothetical mass-balance benchmarks, not verified application rates."]}
    groups={}
    for entry in state.get("analysis_runs",[]):
        groups.setdefault((entry.get("kind"),digest(entry.get("inputs",{}))),[]).append(entry)
    shared_groups=0
    for entries in groups.values():
        identities={(e.get("recipe_id"),e.get("active_name")) for e in entries}
        if len(identities)<2: continue
        shared_groups+=1
        recipes_used={r for r,_ in identities}
        actives_used={a for _,a in identities}
        scope=[]
        if len(recipes_used)>1: scope.append("candidate recipes")
        if len(actives_used)>1: scope.append("active ingredients")
        note="Identical "+", ".join(scope)+" share identical numerical inputs; this calculation cannot distinguish their chemistry or rank formulations."
        for entry in entries:
            entry["result"]["scenario_scope"]="shared inputs across "+", ".join(scope)
            entry["result"].setdefault("limitations",[]).append(note)
    state["product_development"]["scenario_audit"]={"shared_input_groups":shared_groups,
        "interpretation":"Shared parameter calculations are scenario illustrations, not active-specific or formulation-specific predictions."}
    restore_selection(state)
    control.checkpoint(state,"All candidate scenarios saved")
    return clean(state)

