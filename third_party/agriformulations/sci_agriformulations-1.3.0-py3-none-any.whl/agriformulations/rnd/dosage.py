"""Exposure mass balance and context-specific experimental dose-response fitting."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit
from .kinetics import simulate as simulate_kinetics
from .common import number, label

def scenario(raw, kinetic_result=None):
    kinetic_inputs=dict(raw.get("kinetics",{}))
    day=number(raw.get("evaluation_day",35),"evaluation_day",0,number(kinetic_inputs.get("horizon_days",60),"horizon_days",.001,1e5))
    kinetic_inputs["release_specs"]=[*kinetic_inputs.get("release_specs",[]),{"day":day}]
    kinetics=kinetic_result if kinetic_result is not None else simulate_kinetics(kinetic_inputs)
    availability=float(np.interp(day,kinetics["times_days"],kinetics["available_fraction"]))
    target=number(raw.get("target_available_g_ha",50),"target_available_g_ha",.000001,1e7)
    active=number(raw.get("active_fraction"),"active_fraction",.000001,1)
    retention=number(raw.get("storage_retained_fraction",1),"storage_retained_fraction",.000001,1)
    deposition=number(raw.get("deposition_fraction",1),"deposition_fraction",.000001,1)
    if availability<1e-12:
        raise ValueError("No available active at the chosen day; this scenario cannot meet the target")
    product=target/(1000*active*retention*deposition*availability)
    maximum=raw.get("maximum_product_kg_ha")
    maximum=None if maximum in (None,"") else number(maximum,"maximum_product_kg_ha",.000001,1e8)
    density=raw.get("product_density_kg_l")
    density=None if density in (None,"") else number(density,"product_density_kg_l",.001,100)
    spray=raw.get("spray_volume_l_ha")
    spray=None if spray in (None,"") else number(spray,"spray_volume_l_ha",.001,1e7)
    sensitivity=[]
    for fraction in (.5, .75, 1.):
        # Deposition sensitivity; not statistical uncertainty.
        sensitivity.append({"deposition_fraction":deposition*fraction,"product_kg_ha":product/fraction})
    return {"evaluation_day":day,"available_fraction":availability,"target_available_g_ha":target,
        "initial_active_g_ha":product*1000*active,"product_kg_ha":product,
        "product_l_ha":None if density is None else product/density,
        "tank_product_g_l":None if spray is None else product*1000/spray,
        "within_user_ceiling":None if maximum is None else product<=maximum,
        "deposition_sensitivity":sensitivity,"evidence":"exposure mass-balance scenario",
        "equation":"product kg/ha = target g/ha / (1000 × active fraction × storage retention × deposition × available fraction)",
        "limitations":["The target available-active amount is supplied by the researcher, not an efficacy threshold inferred from release.",
            "No crop uptake, pest mortality, phytotoxicity or field-effective dose is inferred.",
            "User ceiling is a planning constraint, not verification of a product label."],
        "context":raw.get("context",{})}

def fit_response(raw):
    rows=raw.get("observations",[])
    if not isinstance(rows,list) or not 5<=len(rows)<=1000:
        raise ValueError("Provide 5 to 1000 dose-response observations")
    unit=raw.get("dose_unit")
    if unit not in ("g_ai_ha","mg_l"):
        raise ValueError("dose_unit must be g_ai_ha or mg_l; units cannot be transferred")
    context=raw.get("context",{})
    for key in ("recipe_id","crop_or_system","target","assay"):
        label(context.get(key),f"context.{key}")
    doses=np.array([number(r.get("dose"),"dose",0,1e9) for r in rows])
    y=np.array([number(r.get("response_pct"),"response_pct",0,100)/100 for r in rows])
    if 0 not in doses or len(np.unique(doses[doses>0]))<4:
        raise ValueError("Include an untreated control and at least four distinct positive doses")
    baseline=float(np.mean(y[doses==0]))
    if baseline>=.8 or np.max(y)-baseline<.2:
        raise ValueError("Insufficient dose response above the untreated control")
    positive=doses>0
    def response(d,p):
        return baseline+(1-baseline)*expit(p[1]*(np.log(np.maximum(d,1e-300))-p[0]))
    logd=np.log(doses[positive])
    fit=least_squares(lambda p:response(doses,p)-y,[float(np.median(logd)),1],
        bounds=([float(logd.min()-5),.05],[float(logd.max()+5),10]))
    desired=number(raw.get("target_response_pct",80),"target_response_pct",.001,99.999)/100
    corrected=(desired-baseline)/(1-baseline)
    if not 0<corrected<1:
        raise ValueError("Target must exceed the untreated-control response")
    required=float(np.exp(fit.x[0]+np.log(corrected/(1-corrected))/fit.x[1]))
    within=bool(doses[positive].min()<=required<=doses.max() and y.min()<=desired<=y.max())
    grid=np.r_[0,np.geomspace(doses[positive].min(),doses.max(),100)]
    return {"ec50":float(np.exp(fit.x[0])),"slope":float(fit.x[1]),"baseline_pct":baseline*100,
        "target_response_pct":desired*100,"estimated_dose":required if within else None,
        "unvalidated_extrapolated_dose":None if within else required,"within_tested_range":within,
        "dose_unit":unit,"doses":grid.tolist(),"predicted_response_pct":(response(grid,fit.x)*100).tolist(),
        "residuals_pct":((y-response(doses,fit.x))*100).tolist(),"observations":rows,"context":context,
        "evidence":"fit to supplied dose-response observations",
        "limitations":"Descriptive Hill fit with fixed 100% upper asymptote; no field transfer from mg/L and no calibrated confidence interval. Requires independent confirmation trials."}
