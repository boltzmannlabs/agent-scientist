"""Direct artifact edits and dependency-aware reruns without unnecessary model calls."""
from copy import deepcopy
from . import control, kinetics, stability, dosage, recipes
from .common import clean
from .outcomes import build_outcome
from .workspace import RevisionConflict

def run(raw,connection,workspace,on_event=None):
    if raw["_studio_manual"].get("operation") == "research_search":
        from .research import record
        state=deepcopy(raw["state"])
        found=record(state,raw["_studio_manual"]["parameters"])
        unavailable=found["status"]=="unavailable"
        answer=("Search providers are unavailable; see the saved search for errors and retry." if unavailable else
            "Saved "+str(len(found["results"]))+" "+found["parameters"]["kind"]+" search records. Review the sources in Research before using them as evidence.")
        sources=[{"url":r["url"],"title":r["title"]} for r in found["results"]]
        trace=[{"tool":"search_"+found["parameters"]["kind"],"evidence":found["evidence"]}]
        outcome=build_outcome(raw["question"],answer,trace,state,sources,found["warnings"])
        state.setdefault("research_reports",[]).append(outcome)
        control.checkpoint(state,"Search records saved")
        response={"answer":answer,"question":raw["question"],"updates":clean(state),"trace":trace,
            "warnings":found["warnings"],"sources":sources,"outcome":outcome,"intent":"execute","model_calls":[],"mode":"Research search"}
        try:
            identity=raw["project_identity"]
            response["project_saved"]=workspace.commit_run(state,identity["project_id"],identity["revision"],initial=raw["state"])
        except RevisionConflict as exc:
            response["persistence_error"]=str(exc)
            response["warnings"].append("A newer draft was preserved. Search results remain in artifact history.")
        return response
    if raw["_studio_manual"].get("operation"):
        from .simulation_service import run_manual
        return run_manual(raw,connection,workspace,on_event)
    state=deepcopy(raw["state"])
    task=raw["_studio_manual"]
    artifact=task["artifact"]
    kind=artifact["kind"]
    payload=artifact["payload"]
    changes=task.get("overrides",{})
    trace=[]
    related=task.get("related",[])
    selected_recipe=task["recipe"]
    rid=selected_recipe["recipe_id"]
    active=artifact.get("active_name")
    for entry in related:
        if not any(r.get("scenario_id")==entry.get("scenario_id") and r.get("kind")==entry.get("kind")
                and r.get("recipe_id")==entry.get("recipe_id") for r in state.get("analysis_runs",[])):
            state.setdefault("analysis_runs",[]).append(deepcopy(entry))
    if rid not in {r["recipe_id"] for r in state.get("recipes",[])}:
        state.setdefault("recipes",[]).append(deepcopy(selected_recipe))
    def emit(message,**extra):
        if on_event:
            on_event(dict(kind="tool_started",message=message,**extra))
    def record(stage,inputs,function,recipe_id,active_name,assumptions=None):
        control.check()
        emit("Running "+stage+" for "+active_name,tool=stage)
        result=control.compute(stage,inputs,function)
        result.update(recipe_id=recipe_id,active_name=active_name,scenario_assumptions=assumptions or [])
        entry={"kind":stage,"recipe_id":recipe_id,"active_name":active_name,
            "inputs":deepcopy(inputs),"result":result,"engine_version":control.engine_version(),
            "scenario_id":__import__("hashlib").sha256(__import__("json").dumps(inputs,sort_keys=True).encode()).hexdigest()[:16],
            "assumptions":assumptions or []}
        state.setdefault("analysis_runs",[]).append(entry)
        state["selected_recipe_id"]=recipe_id
        state["selected_active_name"]=active_name
        state[stage+"_input"]=deepcopy(inputs)
        state[stage+"_result"]=result
        trace.append({"tool":{"kinetics":"simulate_kinetics","stability":"simulate_stability","dosage":"calculate_dosage"}[stage],
            "agent":"Scientific tools","evidence":result["evidence"],"inputs":inputs})
        control.checkpoint(state,"Saved "+stage+" for "+active_name)
        return result
    def last(stage,active_name):
        return next((deepcopy(r) for r in reversed(related)
            if r["kind"]==stage and r.get("active_name")==active_name),None)
    def dose_after(recipe,active_name,kin_entry,st_entry,dose_entry,overrides=None):
        if not dose_entry:
            return None
        inputs=deepcopy(dose_entry["inputs"])
        inputs.update(overrides or {})
        component=next(c for c in recipe["active_components"] if c["name"]==active_name)
        inputs["active_fraction"]=component["active_fraction"]
        if kin_entry:
            inputs["kinetics"]=deepcopy(kin_entry["inputs"])
        context=deepcopy(inputs.get("context",{}))
        context.update(recipe_id=recipe["recipe_id"],active_name=active_name)
        temp=inputs.pop("storage_temperature_c",context.get("storage_temperature_c"))
        if st_entry and temp is not None:
            curve=next((c for c in st_entry["result"]["curves"] if c["temperature_c"]==float(temp)),None)
            if not curve:
                raise ValueError("Choose a storage temperature included in this stability scenario")
            inputs["storage_retained_fraction"]=curve["retained_at_horizon"]
            context["storage_temperature_c"]=float(temp)
        inputs["context"]=context
        return record("dosage",inputs,dosage.scenario,recipe["recipe_id"],active_name,
            ["User-edited hypothetical exposure scenario; not a field-use recommendation."])
    if kind=="recipe":
        percentages=changes.get("percentages")
        if not isinstance(percentages,dict) or set(percentages)!={i["name"] for i in selected_recipe["ingredients"]}:
            raise ValueError("Supply a mass percentage for every existing ingredient")
        rows=[]
        active_total=0
        for ingredient in selected_recipe["ingredients"]:
            row=deepcopy(ingredient)
            value=float(percentages[row["name"]])
            row.update(min_pct=value,max_pct=value)
            if row["role"]=="active":
                row["target_active_pct"]=value*row["purity_pct"]/100
                active_total+=row["target_active_pct"]
            rows.append(row)
        brief=dict(state["brief"],name=selected_recipe["name"]+" variant",format=selected_recipe["format"],
            ingredients=rows,active_pct=active_total,count=1,batch_g=selected_recipe["batch_g"],
            process=selected_recipe.get("process",[]),process_parameters=selected_recipe.get("process_parameters",[]))
        checked=recipes.suggest(brief)
        variant=checked["recipes"][0]
        if variant["recipe_id"]==rid:
            raise ValueError("Change at least one ingredient percentage to create a variant")
        state.setdefault("recipes",[]).append(variant)
        trace.append({"tool":"create_recipe_candidates","agent":"User and formulation validator",
            "evidence":"User-edited, mass-balanced research draft"})
        control.checkpoint(state,"Validated and saved the recipe variant")
        assumption=["Existing release and storage inputs transferred as explicit unvalidated assumptions; composition does not predict performance."]
        for component in variant["active_components"]:
            name=component["name"]
            ke,se,de=(last(k,name) for k in ("kinetics","stability","dosage"))
            if ke:
                kin=deepcopy(ke["inputs"])
                kin["parameter_source"]="Transferred explicit scenario for a user-edited recipe variant"
                kr=record("kinetics",kin,kinetics.simulate,variant["recipe_id"],name,assumption)
                ke={"inputs":kin,"result":kr}
            if se:
                sr=record("stability",se["inputs"],stability.simulate,variant["recipe_id"],name,assumption)
                se={"inputs":se["inputs"],"result":sr}
            dose_after(variant,name,ke,se,de)
    else:
        inputs=deepcopy(payload["inputs"])
        inputs.update(changes)
        if kind=="kinetics":
            inputs["parameter_source"]="User-edited explicit release scenario"
            result=record(kind,inputs,kinetics.simulate,rid,active)
            dose_after(selected_recipe,active,{"inputs":inputs,"result":result},last("stability",active),last("dosage",active))
        elif kind=="stability":
            if set(changes)&{"reference_rate_per_day","reference_temperature_c","activation_energy_kj_mol"}:
                inputs.pop("calibration",None)
            result=record(kind,inputs,stability.simulate,rid,active)
            de=last("dosage",active)
            temp=(de or {}).get("inputs",{}).get("context",{}).get("storage_temperature_c")
            previous=next((c for c in payload["result"]["curves"] if c["temperature_c"]==temp),None)
            current=next((c for c in result["curves"] if c["temperature_c"]==temp),None)
            if de and (previous is None or current is None or previous["retained_at_horizon"]!=current["retained_at_horizon"]):
                dose_after(selected_recipe,active,last("kinetics",active),{"inputs":inputs,"result":result},de)
        elif kind=="dosage":
            dose_after(selected_recipe,active,last("kinetics",active),last("stability",active),
                {"inputs":payload["inputs"]},changes)
        else:
            raise ValueError("This artifact cannot be rerun")
    answer="Saved the edited "+kind+" and its completed dependent calculations. Previous versions remain available for comparison."
    outcome=build_outcome(raw["question"],answer,trace,state)
    state.setdefault("research_reports",[]).append(outcome)
    control.checkpoint(state,"Edited scenario results saved")
    result={"answer":answer,"question":raw["question"],"updates":clean(state),"trace":trace,
        "warnings":[],"sources":[],"outcome":outcome,"intent":"execute","model_calls":[],"mode":"Scientific tools"}
    try:
        identity=raw["project_identity"]
        result["project_saved"]=workspace.commit_run(state,identity["project_id"],identity["revision"],initial=raw["state"])
    except RevisionConflict as exc:
        result["persistence_error"]=str(exc)
        result["warnings"].append("A newer project draft was preserved. These results remain in artifact history.")
    return result

