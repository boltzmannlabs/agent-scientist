"""Recipe-to-experiment workbench. All scenario assumptions remain explicit."""
