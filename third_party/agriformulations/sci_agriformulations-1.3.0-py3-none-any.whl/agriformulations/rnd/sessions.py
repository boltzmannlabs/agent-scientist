"""Persistent chat projects, artifact history and nonblocking queued execution."""
from copy import deepcopy
import hashlib
import json
import sqlite3
import threading
import uuid

from .api import bootstrap
from .common import clean, digest, label
from .runs import now, snapshot, local_request
from .workspace import RevisionConflict
from . import importing

TERMINAL={"completed","completed_with_warnings","completed_unsaved","failed","cancelled","interrupted"}

class Sessions:
    def __init__(self,workspace,runs):
        self.workspace=workspace
        self.runs=runs
        self._lock=threading.RLock()
        self._dispatching=False
        self._again=False
        self.closed=False
        with workspace.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS studio_sessions(
                    session_id TEXT PRIMARY KEY,project_id TEXT UNIQUE,title TEXT,created TEXT,updated TEXT,synced_revision INTEGER DEFAULT 0,title_locked INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS studio_messages(
                    message_id TEXT PRIMARY KEY,session_id TEXT,role TEXT,content TEXT,run_id TEXT,refs TEXT,created TEXT);
                CREATE INDEX IF NOT EXISTS studio_message_session ON studio_messages(session_id,created);
                CREATE TABLE IF NOT EXISTS studio_requests(
                    request_id TEXT PRIMARY KEY,session_id TEXT,question TEXT,intent TEXT,status TEXT,
                    payload TEXT,run_id TEXT,error TEXT,created TEXT,updated TEXT);
                CREATE INDEX IF NOT EXISTS studio_request_session ON studio_requests(session_id,status);
                CREATE TABLE IF NOT EXISTS studio_artifacts(
                    artifact_id TEXT PRIMARY KEY,session_id TEXT,kind TEXT,title TEXT,recipe_id TEXT,active_name TEXT,
                    input_digest TEXT,run_id TEXT,metadata TEXT,payload TEXT,created TEXT);
                CREATE INDEX IF NOT EXISTS studio_artifact_session ON studio_artifacts(session_id,kind);
                CREATE TABLE IF NOT EXISTS studio_events(
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,session_id TEXT,kind TEXT,payload TEXT,created TEXT);
                CREATE INDEX IF NOT EXISTS studio_event_session ON studio_events(session_id,event_id);
            """)
            columns={row[1] for row in db.execute("PRAGMA table_info(studio_sessions)")}
            if "title_locked" not in columns:
                db.execute("ALTER TABLE studio_sessions ADD COLUMN title_locked INTEGER DEFAULT 0")
        runs.on_checkpoint=self._checkpoint
        runs.on_finished=self._finished
        runs.on_event=self._run_event

    def _session(self,session_id):
        session_id=label(session_id,"session_id",80)
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            row=db.execute("SELECT * FROM studio_sessions WHERE session_id=?",(session_id,)).fetchone()
        if not row:
            raise ValueError("Project session not found")
        return dict(row)

    def _emit(self,session_id,kind,payload):
        with self.workspace.connect() as db:
            db.execute("INSERT INTO studio_events(session_id,kind,payload,created) VALUES(?,?,?,?)",
                (session_id,kind,json.dumps(clean(payload),allow_nan=False),now()))
            db.execute("UPDATE studio_sessions SET updated=? WHERE session_id=?",(now(),session_id))

    def events(self,session_id,after=0):
        self._session(session_id)
        with self.workspace.connect() as db:
            rows=db.execute("SELECT event_id,kind,payload FROM studio_events WHERE session_id=? AND event_id>? ORDER BY event_id LIMIT 100",
                (session_id,int(after))).fetchall()
        return [{"id":r[0],"kind":r[1],"data":json.loads(r[2])} for r in rows]

    def create(self,title="Untitled formulation",source_session_id=None):
        with self._lock:
            return self._create(title,source_session_id)

    def _create(self,title,source_session_id):
        title=label(title,"project title",200)
        state=deepcopy(bootstrap())
        for key in ("formats","format_scaffolds","agent_examples"):
            state.pop(key,None)
        state.update(recipes=[],imports=[],conversation=[])
        state["brief"]={"name":title,"active_name":"","format":"SC","crop":"","target":"",
            "objective":"","ingredients":[],"process":[]}
        if source_session_id:
            source=self._session(source_session_id)
            project=self.workspace.load(source["project_id"])
            state=deepcopy(project["document"])
            state["brief"]["name"]=title
            state["source_project"]={"project_id":source["project_id"],"revision":project["revision"]}
            state["conversation"]=[]
        saved=self.workspace.save(state)
        sid=uuid.uuid4().hex
        stamp=now()
        with self.workspace.connect() as db:
            db.execute("INSERT INTO studio_sessions(session_id,project_id,title,created,updated,synced_revision) VALUES(?,?,?,?,?,?)",
                (sid,saved["project_id"],title,stamp,stamp,saved["revision"]))
        self.ingest(sid,state,None)
        self._emit(sid,"session_created",saved)
        return self.view(sid)

    def sync_legacy(self):
        with self._lock:
            self._sync_legacy()

    def _sync_legacy(self):
        for project in self.workspace.list():
            with self.workspace.connect() as db:
                row=db.execute("SELECT session_id,synced_revision FROM studio_sessions WHERE project_id=?",
                    (project["project_id"],)).fetchone()
                if not row:
                    sid=uuid.uuid4().hex
                    db.execute("INSERT INTO studio_sessions(session_id,project_id,title,created,updated,synced_revision) VALUES(?,?,?,?,?,0)",
                        (sid,project["project_id"],project["name"],project["updated"],project["updated"]))
                    row=(sid,0)
            if row[1]>=project["revision"]:
                continue
            doc=self.workspace.load(project["project_id"])["document"]
            self.ingest(row[0],doc,None)
            for turn in doc.get("conversation",[]):
                with self.workspace.connect() as db:
                    owned=db.execute("SELECT 1 FROM studio_requests WHERE session_id=? AND question=?",
                        (row[0],turn.get("question",""))).fetchone()
                    if owned:
                        continue
                    key=digest(turn)
                    for role,field in (("user","question"),("assistant","answer")):
                        if turn.get(field):
                            db.execute("INSERT OR IGNORE INTO studio_messages VALUES(?,?,?,?,?,?,?)",
                                ("legacy-"+key+"-"+role,row[0],role,turn[field],None,"[]",project["updated"]))
            title=project["name"]
            if title=="New formulation project":
                turns=doc.get("conversation",[])
                title=(" ".join(turns[-1].get("question","").split())[:80] if turns else "") or title
            with self.workspace.connect() as db:
                db.execute("UPDATE studio_sessions SET title=CASE WHEN title_locked=1 OR ?=? THEN title ELSE ? END,synced_revision=? WHERE session_id=?",
                    (project["name"],"Untitled formulation",title,project["revision"],row[0]))

    def recover(self):
        """Settle jobs whose owning process exited; never restart stopped work."""
        with self.workspace.connect() as db:
            rows=db.execute("SELECT run_id FROM studio_requests WHERE status=? AND run_id IS NOT NULL",("running",)).fetchall()
        for row in rows:
            job=self.runs.get(row[0],include_result=False)
            if job["status"] in TERMINAL:
                self._finished(row[0])

    def list(self):
        self.recover()
        self.sync_legacy()
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            rows=db.execute("""SELECT s.*,
                (SELECT COUNT(*) FROM studio_requests q WHERE q.session_id=s.session_id AND q.status IN (?,?)) AS active_count,
                (SELECT COUNT(*) FROM studio_artifacts a WHERE a.session_id=s.session_id AND a.kind=?) AS recipe_versions
                FROM studio_sessions s ORDER BY s.updated DESC""",("queued","running","recipe")).fetchall()
        return [dict(r) for r in rows]

    def _message(self,sid,role,content,request_id,refs=None):
        mid=request_id+"-"+role
        with self.workspace.connect() as db:
            db.execute("INSERT OR IGNORE INTO studio_messages VALUES(?,?,?,?,?,?,?)",
                (mid,sid,role,content,request_id,json.dumps(refs or []),now()))

    def messages(self,sid,before=None):
        self._session(sid)
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            if before and "|" in before:
                stamp,seq=before.rsplit("|",1)
                rows=db.execute("""SELECT rowid AS seq,* FROM studio_messages WHERE session_id=?
                    AND (created<? OR (created=? AND rowid<?)) ORDER BY created DESC,rowid DESC LIMIT 100""",
                    (sid,stamp,stamp,int(seq))).fetchall()
            elif before:
                rows=db.execute("SELECT rowid AS seq,* FROM studio_messages WHERE session_id=? AND created<? ORDER BY created DESC,rowid DESC LIMIT 100",
                    (sid,before)).fetchall()
            else:
                rows=db.execute("SELECT rowid AS seq,* FROM studio_messages WHERE session_id=? ORDER BY created DESC,rowid DESC LIMIT 100",(sid,)).fetchall()
        return [dict(r,refs=json.loads(r["refs"]),cursor=r["created"]+"|"+str(r["seq"])) for r in reversed(rows)]

    def _artifact(self,sid,kind,title,payload,recipe_id=None,active=None,inputs=None,run_id=None):
        fingerprint=digest(inputs if inputs is not None else payload)
        aid="a-"+digest({"session":sid,"kind":kind,"recipe":recipe_id,"active":active,"digest":fingerprint})
        metadata={"evidence":payload.get("result",payload).get("evidence","research draft"),
            "assumptions":payload.get("assumptions",payload.get("scenario_assumptions",[]))}
        metadata["source_kind"]=payload.get("result",payload).get("source_kind","unknown")
        if kind=="design_study":metadata["study_id"]=payload["study_id"]
        if kind=="measurement":
            from .data_tools import identify
            identify(payload)
            metadata.update(dataset_id=payload["dataset_id"],review=payload["review"],measurement_kind=payload["kind"])
        if kind=="fit":
            metadata.update(fit_id=payload["fit_id"],dataset_id=payload["dataset_id"],simulation_key=payload.get("simulation_key"))
        if kind=="recipe":
            metadata.update(active_fraction=payload.get("active_fraction"),format=payload.get("format"),
                batch_g=payload.get("batch_g"),actives=payload.get("active_components",[]))
        with self.workspace.connect() as db:
            db.execute("INSERT OR IGNORE INTO studio_artifacts VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (aid,sid,kind,title,recipe_id,active,fingerprint,run_id,json.dumps(clean(metadata)),
                 json.dumps(snapshot(payload),allow_nan=False),now()))
        return aid

    def ingest(self,sid,state,run_id):
        for workflow in state.get("formulation_workflows",[]):
            self._artifact(sid,"report","Computed workflow · "+workflow["name"],workflow,run_id=run_id)
        if state.get("partial_synthesis"):
            self._artifact(sid,"report",state["partial_synthesis"]["task"],state["partial_synthesis"],run_id=run_id)
        for entry in state.get("cost_estimates",[]):
            self._artifact(sid,"cost", "Estimated cost · "+entry["recipe_name"],entry,entry["recipe_id"],run_id=run_id)
        for study in state.get("design_studies",[]):
            self._artifact(sid,"design_study",study["name"],study,run_id=run_id)
        for search in state.get("research_searches",[]):
            self._artifact(sid,"research_search",search["parameters"]["kind"].capitalize()+" search · "+search["parameters"]["query"],
                search,run_id=run_id)
        for source in state.get("research_sources",[]):
            self._artifact(sid,"research_source",source["source"]["title"],source,run_id=run_id)
        brief=state.get("brief")
        if brief:
            self._artifact(sid,"brief","Product brief",brief,run_id=run_id)
        development=state.get("product_development") or {}
        if development.get("status")=="scenarios_completed":
            self._artifact(sid,"development","Candidate comparison",development,run_id=run_id)
        if state.get("agent_plan"):
            self._artifact(sid,"plan",state["agent_plan"].get("summary","Proposed research plan"),
                state["agent_plan"],run_id=run_id)
        for recipe in state.get("recipes",[]):
            self._artifact(sid,"recipe",recipe["name"],recipe,recipe["recipe_id"],run_id=run_id)
        for entry in state.get("analysis_runs",[]):
            self._artifact(sid,entry["kind"],entry.get("title",entry["kind"].capitalize())+" · "+str(entry.get("active_name","")),
                entry,entry.get("recipe_id"),entry.get("active_name"),
                inputs=({"inputs":entry["inputs"],"engine":entry.get("engine_version","legacy"),"scenario":entry["scenario_id"]}
                    if entry.get("simulation_key") else {"inputs":entry["inputs"],"engine":entry.get("engine_version","legacy")}),run_id=run_id)
        for key,kind in (("experiment_result","experiments"),("release_fit","release_fit"),
                ("dose_response_result","dose_response"),("stability_fit","stability_fit"),("learning_result","learning")):
            if state.get(key):
                value=state[key]
                self._artifact(sid,kind,kind.replace("_"," ").capitalize(),value,
                    value.get("recipe_id"),value.get("active_name"),run_id=run_id)
        for fitted in state.get("fit_runs",[]):
            self._artifact(sid,"fit",fitted.get("source_kind","Unknown").capitalize()+" fit · "+fitted["kind"],fitted,fitted["recipe_id"],fitted["active_name"],run_id=run_id)
        for report in state.get("research_reports",[]):
            self._artifact(sid,"report",report.get("task","Research outcome")[:150],report,run_id=run_id)
        if state.get("source_assessment"):
            self._artifact(sid,"evidence","Source assessment",state["source_assessment"],run_id=run_id)
        for item in state.get("imports",[]):
            self._artifact(sid,"measurement",item.get("source",{}).get("filename","Measured dataset"),
                item,item.get("recipe_id"),item.get("active_name"),run_id=run_id)

    def artifact(self,sid,aid):
        self._session(sid)
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            row=db.execute("SELECT * FROM studio_artifacts WHERE session_id=? AND artifact_id=?",(sid,aid)).fetchone()
        if not row:
            raise ValueError("Artifact does not belong to this project")
        value=dict(row)
        value["metadata"]=json.loads(value["metadata"])
        value["payload"]=json.loads(value["payload"])
        return value

    def view(self,sid):
        session=self._session(sid)
        project=self.workspace.load(session["project_id"])
        doc=project["document"]
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            artifacts=[dict(r) for r in db.execute("""SELECT artifact_id,kind,title,recipe_id,active_name,
                input_digest,run_id,metadata,created FROM studio_artifacts WHERE session_id=? ORDER BY rowid""",(sid,))]
            requests=[dict(r) for r in db.execute("""SELECT request_id,question,intent,status,run_id,error,created,updated
                FROM studio_requests WHERE session_id=? ORDER BY created""",(sid,))]
            version=db.execute("SELECT COALESCE(MAX(event_id),0) FROM studio_events WHERE session_id=?",(sid,)).fetchone()[0]
        for item in artifacts:
            item["metadata"]=json.loads(item["metadata"])
        # Project readable labels onto old artifacts without rewriting their
        # stored scientific inputs, outputs, titles or timestamps.
        from .scenario_presentation import describe
        with self.workspace.connect() as db:
            details=db.execute("""SELECT artifact_id,kind,json_extract(payload,'$.scenario_id'),
                json_extract(payload,'$.inputs'),json_extract(payload,'$.request.name')
                FROM studio_artifacts WHERE session_id=? AND json_extract(payload,'$.scenario_id') IS NOT NULL""",(sid,)).fetchall()
        presented={aid:describe(kind,json.loads(inputs or '{}'),scenario,name) for aid,kind,scenario,inputs,name in details}
        for item in artifacts:item["metadata"].update(presented.get(item["artifact_id"],{}))
        active=[]
        for req in requests:
            if req["status"]=="running" and req["run_id"]:
                job=self.runs.get(req["run_id"],include_result=False)
                active.append(job)
                if job["status"] in TERMINAL:
                    self._finished(req["run_id"])
                    req["status"]=job["status"]
        return {"session":session,"project":{"project_id":project["project_id"],"revision":project["revision"],
                "brief":doc.get("brief",{}),"source_project":doc.get("source_project")},
            "messages":self.messages(sid),"artifacts":artifacts,"requests":requests,
            "active_runs":active,"version":version}

    def enqueue(self,sid,question,intent="auto",refs=None,request_id=None,extra=None):
        session=self._session(sid)
        question=label(question,"message",6000)
        if intent not in ("auto","discussion","execute","develop_product"):
            raise ValueError("Choose Auto, Discuss or Develop")
        refs=refs or []
        if not isinstance(refs,list) or len(refs)>12:
            raise ValueError("Attach up to twelve project artifacts")
        for ref in refs:
            self.artifact(sid,ref)
        rid=request_id or uuid.uuid4().hex
        if not isinstance(rid,str) or not rid or len(rid)>70 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in rid):
            raise ValueError("Invalid message request ID")
        payload={"question":question,"intent":intent,"refs":refs}
        if extra:
            payload.update(extra)
        with self.workspace.connect() as db:
            prior=db.execute("SELECT session_id,payload FROM studio_requests WHERE request_id=?",(rid,)).fetchone()
            if prior:
                if prior[0]!=sid or json.loads(prior[1])!=payload:
                    raise ValueError("Request ID belongs to a different message")
                return {"request_id":rid,"session_id":sid,"status":"accepted"}
            stamp=now()
            db.execute("INSERT INTO studio_requests VALUES(?,?,?,?,?,?,?,?,?,?)",
                (rid,sid,question,intent,"queued",json.dumps(payload),None,None,stamp,stamp))
        self._message(sid,"user",question,rid,refs)
        if session["title"]=="Untitled formulation":
            title=" ".join(question.split())[:70]
            with self.workspace.connect() as db:
                db.execute("UPDATE studio_sessions SET title=? WHERE session_id=?",(title,sid))
        self._emit(sid,"queued",{"request_id":rid})
        self.kick()
        return {"request_id":rid,"session_id":sid,"status":"queued"}

    def kick(self):
        with self._lock:
            if self.closed:
                return
            if self._dispatching:
                self._again=True
                return
            self._dispatching=True
        threading.Thread(target=self._dispatch,daemon=True,name="studio-queue").start()

    def _payload(self,row):
        session=self._session(row["session_id"])
        project=self.workspace.load(session["project_id"])
        state=deepcopy(project["document"])
        payload=json.loads(row["payload"])
        # Planning conversations persist without creating scientific revisions.
        history=[]
        pending=None
        for message in self.messages(row["session_id"]):
            if message["run_id"]==row["request_id"]:
                continue
            if message["role"]=="user":
                pending=message["content"]
            elif pending is not None:
                history.append({"question":pending,"answer":message["content"],"focus":"research"})
                pending=None
        if history:
            state["conversation"]=history[-30:]
        context=[]
        for ref in payload.get("refs",[]):
            artifact=self.artifact(row["session_id"],ref)
            context.append({k:artifact[k] for k in ("artifact_id","kind","title","recipe_id","active_name")})
            rid=artifact.get("recipe_id")
            if rid:
                recipe=next((r for r in state.get("recipes",[]) if r["recipe_id"]==rid),None)
                if recipe is None:
                    with self.workspace.connect() as db:
                        stored=db.execute("SELECT payload FROM studio_artifacts WHERE session_id=? AND kind=? AND recipe_id=? ORDER BY rowid DESC LIMIT 1",
                            (row["session_id"],"recipe",rid)).fetchone()
                    if stored:
                        recipe=json.loads(stored[0])
                        state.setdefault("recipes",[]).append(recipe)
                if recipe:
                    state["selected_recipe_id"]=rid
                    state["selected_active_name"]=artifact.get("active_name") or recipe["active_components"][0]["name"]
            if artifact["kind"] in ("kinetics","stability","dosage"):
                context[-1]["inputs"]=artifact["payload"]["inputs"]
                state[artifact["kind"]+"_input"]=deepcopy(artifact["payload"]["inputs"])
                state[artifact["kind"]+"_result"]=deepcopy(artifact["payload"]["result"])
            elif artifact["kind"]=="plan":
                state["agent_plan"]=deepcopy(artifact["payload"])
                context[-1]["plan"]=artifact["payload"]
        state["_artifact_context"]=context
        intent="execute" if payload["intent"]=="auto" else payload["intent"]
        raw={"question":row["question"],"state":state,"intent":intent,"focus":"research",
            "project_identity":{"project_id":session["project_id"],"revision":project["revision"]},
            "client_request_id":row["request_id"],"web_research":payload.get("web_research",False),
            "_session_id":row["session_id"],"_session_scope":True}
        if payload.get("manual"):
            self._resources(row["session_id"],state,payload["manual"].get("requests",[]))
        if payload.get("resume_from"):
            prior=self.runs.get(payload["resume_from"])
            working=prior.get("working_state") or {}
            if payload.get("manual"):
                raw["_resume_state"]=working
            elif working.get("development_request"):
                raw["_resume_state"]=working
                raw["_resume_product"]=working["development_request"]
            elif working and not payload.get("manual"):
                # Latest saved state remains authoritative; recovered outputs are attached
                # only while the project still matches the stopped checkpoint revision.
                if project["revision"]==prior.get("initial_identity",{}).get("revision"):
                    raw["state"]=working
        if payload.get("manual"):
            raw["_studio_manual"]=payload["manual"]
        return raw

    def _dispatch(self):
        try:
            with self.workspace.connect() as db:
                db.row_factory=sqlite3.Row
                queued=[dict(r) for r in db.execute("SELECT * FROM studio_requests WHERE status=? ORDER BY created",("queued",))]
            for row in queued:
                with self._lock:
                    if self.closed:
                        break
                    local=local_request(json.loads(row["payload"]))
                    if not self.runs.has_capacity(local):
                        continue
                    with self.workspace.connect() as db:
                        pending=db.execute("SELECT status FROM studio_requests WHERE request_id=?",(row["request_id"],)).fetchone()
                        running=db.execute("SELECT payload FROM studio_requests WHERE session_id=? AND status=?",
                            (row["session_id"],"running")).fetchall()
                        busy=any(local_request(json.loads(r[0]))==local for r in running)
                    if not pending or pending[0]!="queued" or busy:
                        continue
                    try:
                        raw=self._payload(row)
                        started=self.runs.start(raw)
                        with self.workspace.connect() as db:
                            db.execute("UPDATE studio_requests SET status=?,run_id=?,updated=? WHERE request_id=? AND status=?",
                                ("running",started["run_id"],now(),row["request_id"],"queued"))
                        self._emit(row["session_id"],"started",{"run_id":started["run_id"]})
                        if self.runs.get(started["run_id"],include_result=False)["status"] in TERMINAL:
                            self._finished(started["run_id"])
                    except (ValueError,RevisionConflict) as exc:
                        with self.workspace.connect() as db:
                            db.execute("UPDATE studio_requests SET status=?,error=?,updated=? WHERE request_id=?",
                                ("failed",str(exc),now(),row["request_id"]))
                        self._message(row["session_id"],"assistant",str(exc),row["request_id"])
                        self._emit(row["session_id"],"failed",{"request_id":row["request_id"]})
        finally:
            with self._lock:
                self._dispatching=False
                again=self._again
                self._again=False
            if again:
                self.kick()

    def _run_event(self,run_id,event):
        row=self.runs._row(run_id,include_result=False)
        if row.get("session_id"):
            self._emit(row["session_id"],"run_event",dict(event,run_id=run_id))

    def _checkpoint(self,run_id,state):
        row=self.runs._row(run_id,include_result=False)
        if row.get("session_id"):
            self.ingest(row["session_id"],state,run_id)
            self._emit(row["session_id"],"artifacts",{"run_id":run_id,"checkpoint":row["checkpoint_no"]})

    def _finished(self,run_id):
        job=self.runs.get(run_id)
        if job["status"] not in TERMINAL:
            return
        with self._lock:
            with self.workspace.connect() as db:
                db.row_factory=sqlite3.Row
                row=db.execute("SELECT * FROM studio_requests WHERE run_id=?",(run_id,)).fetchone()
                if not row or row["status"] in TERMINAL:
                    return
                row=dict(row)
            sid=row["session_id"]
            result=job.get("result") or {}
            working=job.get("working_state")
            if working:
                self.ingest(sid,working,run_id)
            saved=result.get("project_saved")
            if not saved and working and row["intent"]!="discussion":
                session=self._session(sid)
                identity=job.get("initial_identity") or {}
                latest=self.workspace.load(session["project_id"])
                try:
                    saved=self.workspace.commit_run(working,session["project_id"],identity.get("revision",latest["revision"]),initial=job.get("initial_state"))
                except RevisionConflict:
                    pass
            text=result.get("answer") or job.get("error") or "Investigation finished"
            if job["status"]=="cancelled":
                text="Stopped. Completed recipes and step results remain in this project. You can resume unfinished work."
            self._message(sid,"assistant",text,row["request_id"],[])
            with self.workspace.connect() as db:
                db.execute("UPDATE studio_requests SET status=?,error=?,updated=? WHERE request_id=?",
                    (job["status"],job.get("error"),now(),row["request_id"]))
                if saved:
                    db.execute("UPDATE studio_sessions SET synced_revision=? WHERE session_id=?",(0,sid))
            self.sync_legacy()
            self._emit(sid,"finished",{"run_id":run_id,"status":job["status"]})
        self.kick()

    def stop(self,sid,request_id=None):
        self._session(sid)
        with self._lock:
            with self.workspace.connect() as db:
                db.row_factory=sqlite3.Row
                rows=[dict(r) for r in db.execute("SELECT * FROM studio_requests WHERE session_id=? AND status IN (?,?)",
                    (sid,"queued","running"))]
                if request_id:
                    rows=[r for r in rows if r["request_id"]==request_id]
                for row in rows:
                    if row["status"]=="queued":
                        db.execute("UPDATE studio_requests SET status=?,error=?,updated=? WHERE request_id=?",
                            ("cancelled","Stopped before execution",now(),row["request_id"]))
            for row in rows:
                if row["status"]=="running" and row["run_id"]:
                    self.runs.cancel(row["run_id"])
        self._emit(sid,"stopping",{"request_ids":[r["request_id"] for r in rows]})
        return {"stopped_requests":[r["request_id"] for r in rows]}

    def stop_all(self):
        with self.workspace.connect() as db:
            ids=[r[0] for r in db.execute("SELECT DISTINCT session_id FROM studio_requests WHERE status IN (?,?)",("queued","running"))]
        for sid in ids:
            self.stop(sid)
        self.runs.cancel_all()
        return {"sessions":ids}

    def resume(self,sid,run_id):
        self._session(sid)
        row=self.runs._row(run_id)
        if row.get("session_id")!=sid:
            raise ValueError("Run does not belong to this project")
        if row["status"] not in ("cancelled","interrupted","failed","completed_unsaved"):
            raise ValueError("Only stopped, interrupted or failed work can be resumed")
        with self.workspace.connect() as db:
            stored=db.execute("SELECT payload FROM studio_requests WHERE session_id=? AND run_id=?",(sid,run_id)).fetchone()
        previous=json.loads(stored[0]) if stored else {}
        extra={"resume_from":run_id,"web_research":previous.get("web_research",False)}
        if previous.get("manual"):
            extra["manual"]=previous["manual"]
        return self.enqueue(sid,row["question"],row["intent"],previous.get("refs"),extra=extra)

    def rename(self,sid,title):
        session=self._session(sid)
        title=label(title,"project title",200)
        with self.workspace.connect() as db:
            db.execute("UPDATE studio_sessions SET title=?,title_locked=1 WHERE session_id=?",(title,sid))
        self._emit(sid,"renamed",{"title":title})
        return {"title":title,"session_id":sid}

    def import_data(self,sid,raw):
        session=self._session(sid)
        project=self.workspace.load(session["project_id"])
        doc=project["document"]
        recipe=next((r for r in doc.get("recipes",[]) if r["recipe_id"]==raw.get("recipe_id")),None)
        if recipe is None:
            with self.workspace.connect() as db:
                stored=db.execute("SELECT payload FROM studio_artifacts WHERE session_id=? AND kind=? AND recipe_id=? ORDER BY rowid DESC LIMIT 1",
                    (sid,"recipe",raw.get("recipe_id"))).fetchone()
            if stored:
                recipe=json.loads(stored[0])
                doc.setdefault("recipes",[]).append(recipe)
        if not recipe or raw.get("active_name") not in {a["name"] for a in recipe["active_components"]}:
            raise ValueError("Choose the matching project recipe and individual active")
        if raw.get("kind")=="mixture_response":
            second=raw.get("active_b_name")
            if second==raw.get("active_name") or second not in {a["name"] for a in recipe["active_components"]}:
                raise ValueError("Choose a different second active in this recipe")
        item=importing.ingest(raw)
        from .data_tools import identify
        identify(item)
        if any(identify(i)["dataset_id"]==item["dataset_id"] for i in doc.get("imports",[])):
            raise ValueError("This dataset and mapping are already imported in the project")
        doc.setdefault("imports",[]).append(item)
        self.workspace.save(doc,session["project_id"],project["revision"])
        self.ingest(sid,doc,None)
        self._emit(sid,"measurement",{"filename":item["source"]["filename"]})
        return {"index":len(doc["imports"])-1,"dataset":item}

    def export(self,sid):
        from .api import export
        import base64
        import io
        import zipfile
        session=self._session(sid)
        project=self.workspace.load(session["project_id"])
        result=export({"document":project["document"]})
        target=io.BytesIO(base64.b64decode(result["archive_base64"]))
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            messages=[dict(r) for r in db.execute("SELECT * FROM studio_messages WHERE session_id=? ORDER BY created,rowid",(sid,))]
            requests=[dict(r) for r in db.execute("SELECT request_id,question,intent,status,run_id,error,created,updated FROM studio_requests WHERE session_id=? ORDER BY created",(sid,))]
            artifacts=[self.artifact(sid,r[0]) for r in db.execute("SELECT artifact_id FROM studio_artifacts WHERE session_id=? ORDER BY rowid",(sid,))]
        for message in messages:
            message["refs"]=json.loads(message["refs"])
        with zipfile.ZipFile(target,"a",zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("session.json",json.dumps({"session":session,"messages":messages,"requests":requests},indent=2))
            archive.writestr("artifact_history.json",json.dumps(artifacts,indent=2,allow_nan=False))
        result["archive_base64"]=base64.b64encode(target.getvalue()).decode()
        return result


    def rerun(self,sid,artifact_id,overrides):
        artifact=self.artifact(sid,artifact_id)
        kind=artifact["kind"]
        from .product_development import KINETIC_KEYS,STABILITY_KEYS,DOSE_KEYS
        allowed={"kinetics":KINETIC_KEYS,"stability":STABILITY_KEYS,
            "dosage":DOSE_KEYS-{"active_fraction","context","kinetics"},"recipe":{"percentages"}}
        if kind not in allowed or not isinstance(overrides,dict) or set(overrides)-allowed[kind]:
            raise ValueError("Unsupported edits for this artifact")
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            rows=[dict(r) for r in db.execute("SELECT * FROM studio_artifacts WHERE session_id=? AND recipe_id=? ORDER BY rowid",
                (sid,artifact["recipe_id"]))]
        recipes_found=[json.loads(r["payload"]) for r in rows if r["kind"]=="recipe"]
        if not recipes_found:
            raise ValueError("The source recipe is unavailable")
        related={}
        for row in rows:
            if row["kind"] in ("kinetics","stability","dosage"):
                related[(row["kind"],row["active_name"])]=json.loads(row["payload"])
        task={"artifact":artifact,"overrides":overrides,"recipe":recipes_found[-1],"related":list(related.values())}
        return self.enqueue(sid,"Rerun "+artifact["title"]+" with edited inputs","execute",[artifact_id],
            extra={"manual":task})

    def _resources(self,sid,state,requests=()):
        """Resolve immutable project artifacts without accepting client project state."""
        if any(not isinstance(r,dict) for r in requests):
            raise ValueError("Simulation requests must be objects")
        wanted={r.get("recipe_id") for r in requests}
        with self.workspace.connect() as db:
            rows=db.execute("SELECT kind,recipe_id,payload FROM studio_artifacts WHERE session_id=? AND kind IN (?,?) ORDER BY rowid",
                (sid,"recipe","fit")).fetchall()
        recipes_known={r["recipe_id"] for r in state.get("recipes",[])}
        fits_known={f["fit_id"] for f in state.get("fit_runs",[])}
        for kind,rid,payload in rows:
            item=json.loads(payload)
            if kind=="recipe" and rid in wanted and rid not in recipes_known:
                state.setdefault("recipes",[]).append(item);recipes_known.add(rid)
            elif kind=="fit" and item["fit_id"] not in fits_known:
                state.setdefault("fit_runs",[]).append(item);fits_known.add(item["fit_id"])
        return state

    def add_recipe(self,sid,raw,expected_revision=None):
        from .recipe_inputs import apply
        session=self._session(sid)
        with self._lock:
            project=self.workspace.load(session["project_id"])
            if expected_revision is not None and project["revision"]!=expected_revision:
                raise RevisionConflict("Project changed; refresh before saving the recipe")
            state=project["document"]
            created=apply(state,raw)
            saved=self.workspace.save(state,session["project_id"],project["revision"])
            self.ingest(sid,state,None)
            if session["title"]=="Untitled formulation":
                with self.workspace.connect() as db:
                    db.execute("UPDATE studio_sessions SET title=? WHERE session_id=?",(raw["name"],sid))
        self._emit(sid,"recipes",{"count":len(created["recipes"]),"revision":saved["revision"]})
        return {"recipes":created["recipes"],"warnings":created["warnings"],"saved":saved}

    def calculate_cost(self,sid,raw,expected_revision=None):
        from .cost_service import record
        session=self._session(sid)
        with self._lock:
            project=self.workspace.load(session["project_id"])
            if expected_revision is not None and project["revision"]!=expected_revision:
                raise RevisionConflict("Project changed; refresh before saving the cost scenario")
            state=project["document"]
            result=record(state,raw)
            saved=self.workspace.save(state,session["project_id"],project["revision"])
            self.ingest(sid,state,None)
        self._emit(sid,"cost",{"cost_id":result["cost_id"],"revision":saved["revision"]})
        return {"cost":result,"saved":saved}

    def datasets(self,sid):
        from .data_tools import identify,observations
        session=self._session(sid)
        state=self.workspace.load(session["project_id"])["document"]
        output=[]
        for item in state.get("imports",[]):
            identify(item)
            output.append({k:deepcopy(item.get(k)) for k in ("dataset_id","kind","recipe_id","active_name","active_b_name","instrument","review","warnings","x_unit","original_value_unit","mapping","context","source_kind","evidence","time_conversion","original_x_unit")})
            output[-1].update(filename=item["source"]["filename"],source_sha256=item["source"]["sha256"],
                n_rows=len(item["observations"]),n_qc_excluded=len(item.get("excluded",[])),
                n_review_excluded=len(item.get("review",{}).get("excluded_source_rows",[])))
        return output

    def review_data(self,sid,dataset_id,review,expected_revision=None):
        from .simulation_service import dataset
        from .common import integer
        session=self._session(sid)
        if not isinstance(review,dict) or set(review)-{"status","notes","excluded_source_rows","source_kind"}:
            raise ValueError("Unsupported review fields")
        if review.get("status") not in ("unreviewed","reviewed","rejected"):
            raise ValueError("Choose unreviewed, reviewed or rejected")
        notes=review.get("notes","")
        if not isinstance(notes,str) or len(notes)>3000:raise ValueError("Review notes must be text up to 3000 characters")
        with self._lock:
            project=self.workspace.load(session["project_id"])
            if expected_revision is not None and expected_revision!=project["revision"]:
                raise RevisionConflict("Project changed; refresh before updating the dataset review")
            state=project["document"];item=dataset(state,dataset_id)
            if "source_kind" in review:
                from .data_provenance import source_kind,evidence
                item["source_kind"]=source_kind(review)
                item["source"]["source_kind"]=item["source_kind"]
                item["evidence"]=evidence(item)
            valid={r["source_row"] for r in item["observations"]}
            excluded=review.get("excluded_source_rows",[])
            if not isinstance(excluded,list) or len(excluded)>20000:raise ValueError("Supply a list of observation source-row numbers")
            excluded=sorted(set(integer(r,"source row",2,20001) for r in excluded))
            if set(excluded)-valid:raise ValueError("An excluded row does not belong to the imported observations")
            item["review"]={"status":review["status"],"notes":notes.strip(),"excluded_source_rows":excluded,"updated":now()}
            saved=self.workspace.save(state,session["project_id"],project["revision"])
            self.ingest(sid,state,None)
        self._emit(sid,"dataset_review",{"dataset_id":dataset_id,"revision":saved["revision"]})
        return {"review":item["review"],"saved":saved}

    def fit_data(self,sid,dataset_id,options=None):
        if options is not None and (not isinstance(options,dict) or set(options)-{"model","reference_temperature_c"}):
            raise ValueError("Unsupported fit options")
        from .simulation_service import dataset
        session=self._session(sid)
        state=self.workspace.load(session["project_id"])["document"]
        item=dataset(state,dataset_id)
        if item.get("review",{}).get("status")=="rejected":raise ValueError("Rejected datasets cannot be fitted")
        return self.enqueue(sid,"Fit "+item.get("source_kind","unknown")+" dataset "+item["source"]["filename"],"execute",
            extra={"manual":{"operation":"fit_dataset","dataset_id":dataset_id,"options":options or {}}})

    def simulate(self,sid,requests):
        from .simulation_service import prepare
        if not isinstance(requests,list) or not 1<=len(requests)<=50:
            raise ValueError("Submit 1 to 50 simulation requests")
        session=self._session(sid)
        state=self.workspace.load(session["project_id"])["document"]
        self._resources(sid,state,requests)
        for request in requests:prepare(state,request)
        from .simulation_catalog import spec
        title=spec(requests[0]["model"])["title"] if len(requests)==1 else str(len(requests))+" selected simulations"
        return self.enqueue(sid,"Run "+title,"execute",
            extra={"manual":{"operation":"simulation_batch","requests":requests}})

    def design_study(self,sid,raw):
        from .design_studies import prepare,objects
        session=self._session(sid)
        state=self.workspace.load(session["project_id"])["document"]
        if not isinstance(raw,dict) or not isinstance(raw.get("candidates"),list):
            raise ValueError("Supply a study with candidate recipes")
        references=[{"recipe_id":label(c.get("recipe_id"),"candidate recipe ID",200)} for c in objects(raw["candidates"],"candidates",8)]
        self._resources(sid,state,references)
        config,planned=prepare(state,raw)
        requests=[item["request"] for candidate in planned for item in candidate["requests"]]
        return self.enqueue(sid,"Evaluate design study: "+config["name"],"execute",
            extra={"manual":{"operation":"design_study","study":config,"requests":requests}})

    def research(self,sid):
        session=self._session(sid)
        state=self.workspace.load(session["project_id"])["document"]
        # Include checkpointed searches even when an unrelated newer revision was preserved.
        searches={r["search_id"]:r for r in state.get("research_searches",[])}
        with self.workspace.connect() as db:
            for row in db.execute("SELECT payload FROM studio_artifacts WHERE session_id=? AND kind=? ORDER BY rowid",
                    (sid,"research_search")):
                item=json.loads(row[0]);searches[item["search_id"]]=item
        return {"searches":list(searches.values()),"sources":state.get("research_sources",[])}

    def search_research(self,sid,parameters):
        from .research import validate
        self._session(sid)
        parameters=validate(parameters)
        return self.enqueue(sid,"Search "+parameters["kind"]+": "+parameters["query"],"execute",
            extra={"manual":{"operation":"research_search","parameters":parameters}})

    def save_research_source(self,sid,search_id,record_id,notes="",status="saved",expected_revision=None,expected_source_version=None,evidence_stage=None):
        from .research import save_source
        session=self._session(sid)
        with self._lock:
            project=self.workspace.load(session["project_id"])
            if expected_revision is not None and expected_revision!=project["revision"]:
                raise RevisionConflict("Project changed; refresh before saving source notes")
            state=project["document"]
            current=next((s for s in state.get("research_sources",[]) if s["record_id"]==record_id),None)
            if expected_source_version is not None and expected_source_version!=(current or {}).get("updated_at",""):
                raise RevisionConflict("This source review changed. Reopen it before saving your notes.")
            searches=self.research(sid)["searches"]
            state["research_searches"]=searches
            source=save_source(state,search_id,record_id,notes,status,evidence_stage)
            saved=self.workspace.save(state,session["project_id"],project["revision"])
            self.ingest(sid,state,None)
        self._emit(sid,"research_source",{"record_id":record_id,"revision":saved["revision"]})
        return {"source":source,"saved":saved}

    def close(self):
        self.closed=True

