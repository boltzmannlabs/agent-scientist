"""Local formulation scenarios with explicit equations and conservative balances.

All new models are screening calculations under supplied parameters, not
composition-to-performance predictors. No external simulator is impersonated.
"""
from copy import deepcopy
import math
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import brentq
from scipy.special import expit,ndtr,ndtri
from . import control,kinetics,stability,dosage
from .simulation_catalog import spec,validate
from .common import clean,number,integer
R=8.314462618

def curve(name,x,y,x_label,y_label):
    return {"name":name,"x":np.asarray(x).tolist(),"y":np.asarray(y).tolist(),"x_label":x_label,"y_label":y_label}
def result(metrics,series=(),rows=(),**extra):
    return dict(metrics=metrics,series=list(series),rows=list(rows),**extra)
def days(p):
    return np.linspace(0,p["horizon_days"],161)

def suspension(p):
    d=np.array(p["particle_sizes_um"])*1e-6
    w=np.array(p["particle_weights"],float)
    if len(d)!=len(w) or w.sum()<=0:
        raise ValueError("Particle sizes and positive total weights must have matching lengths")
    w/=w.sum()
    viscosity=p["viscosity_mpa_s"]*.001
    free=p["density_difference_kg_m3"]*9.80665*d*d/(18*viscosity)
    stress=np.abs(p["density_difference_kg_m3"])*9.80665*d/6
    moving=stress>p["yield_stress_pa"]
    velocity=free*(1-p["solids_volume_fraction"])**p["hindered_exponent"]*moving
    reynolds=np.abs(velocity)*d*1000/viscosity
    if np.max(reynolds)>1:
        raise ValueError("Stokes approximation exceeds Re=1. Increase viscosity or use smaller particles.")
    t=days(p)
    fractions=np.minimum(np.abs(velocity)[:,None]*86400*t/(p["container_height_cm"]*.01),1)
    separated=w@fractions
    rows=[{"diameter_um":float(size*1e6),"weight":float(weight),"velocity_mm_day":float(v*86400*1000),
        "yield_stress_arrested":not bool(m)} for size,weight,v,m in zip(d,w,velocity,moving)]
    return result({"separated_fraction":float(separated[-1]),"mass_balance_error":float(np.max(np.abs(separated+(1-separated)-1)))},
        [curve("Separated fraction",t,separated,"Time (days)","Fraction"),
         curve("Suspended fraction",t,1-separated,"Time (days)","Fraction")],rows,
        direction="settling" if p["density_difference_kg_m3"]>=0 else "creaming")

def nominal_pipe_shear_rate(p):
    return 4 * (p["flow_l_min"] * .001 / 60) / (np.pi * (p["pipe_radius_mm"] * .001)**3)


def rheology_query_shear_rates(p):
    # Constitutive queries include derived metrics as well as the displayed grid.
    return [*p["shear_rates_s"], 100., float(nominal_pipe_shear_rate(p))]


def rheology(p):
    shear=np.unique(p["shear_rates_s"])
    stress=p["yield_stress_pa"]+p["consistency_pa_sn"]*shear**p["flow_index"]
    viscosity=stress/shear
    radius=p["pipe_radius_mm"]*.001
    nominal=nominal_pipe_shear_rate(p)
    pressure=2*p["pipe_length_m"]*(p["yield_stress_pa"]+p["consistency_pa_sn"]*nominal**p["flow_index"])/radius
    rows=[{"shear_rate_s":float(x),"stress_pa":float(y),"viscosity_pa_s":float(v)} for x,y,v in zip(shear,stress,viscosity)]
    return result({"pressure_bar":float(pressure/1e5),"viscosity_at_100_s_pa_s":float((p["yield_stress_pa"]+p["consistency_pa_sn"]*100**p["flow_index"])/100)},
        [curve("Shear stress",shear,stress,"Shear rate (1/s)","Stress (Pa)"),
         curve("Apparent viscosity",shear,viscosity,"Shear rate (1/s)","Viscosity (Pa·s)")],rows,
        nominal_pipe_shear_rate_s=float(nominal),
        evaluated_shear_range_s=[min(rheology_query_shear_rates(p)),max(rheology_query_shear_rates(p))])

def solubility(p):
    temps=np.unique(p["temperatures_c"])
    ion=1
    if p["ionization"]=="acid":ion=1+10**(p["ph"]-p["pka"])
    if p["ionization"]=="base":ion=1+10**(p["pka"]-p["ph"])
    ln_s=np.log(p["intrinsic_solubility_mg_l"])-p["dissolution_enthalpy_kj_mol"]*1000/R*(1/(temps+273.15)-1/(p["reference_temperature_c"]+273.15))
    ln_s+=np.log(ion)+np.log(10)*p["cosolvency_log10"]*p["cosolvent_fraction"]
    if np.max(ln_s)>700:raise ValueError("Solubility scenario exceeds numerical range")
    capacity=np.exp(ln_s)
    t=days(p)
    series=[]
    rows=[]
    fractions=[]
    for temp,s in zip(temps,capacity):
        eq=max(0,1-s/p["loading_mg_l"])
        f=eq*(-np.expm1(-p["precipitation_rate_per_day"]*t))
        fractions.append(f[-1])
        series.append(curve(str(temp)+" °C precipitated",t,f,"Time (days)","Precipitated fraction"))
        rows.append({"temperature_c":float(temp),"solubility_mg_l":float(s),"supersaturation":float(p["loading_mg_l"]/s),
            "equilibrium_precipitated_fraction":float(eq),"horizon_precipitated_fraction":float(f[-1])})
    return result({"maximum_precipitated_fraction":float(max(fractions))},series,rows,
        solubility_curve=curve("Equilibrium solubility",temps,capacity,"Temperature (°C)","Solubility (mg/L)"))

def dilution(p):
    factors=np.unique(p["dilution_factors"])
    concentration=1e6*p["product_density_kg_l"]*p["_active_fraction"]/factors
    solubility=p["solubility_mg_l"]
    if p["ionization"]=="acid":solubility*=1+10**(p["ph"]-p["pka"])
    elif p["ionization"]=="base":solubility*=1+10**(p["pka"]-p["ph"])
    precip=np.maximum(0,1-solubility/concentration)
    calcium=p["hardness_mg_l_caco3"]/100090*p["calcium_fraction"]
    carbonate=p["carbonate_mmol_l"]*.001
    saturation=calcium*carbonate/p["caco3_ksp"]
    rows=[{"dilution_factor":float(d),"active_mg_l":float(c),"active_solubility_mg_l":float(solubility),"active_supersaturation":float(c/solubility),
        "aqueous_only_excess_fraction":float(f),"caco3_saturation_ratio":float(saturation)} for d,c,f in zip(factors,concentration,precip)]
    return result({"maximum_precipitated_fraction":float(max(precip)),"caco3_saturation_ratio":float(saturation)},
        [curve("Active concentration",factors,concentration,"Dilution factor","Active (mg/L)"),
         curve("pH-adjusted solubility ceiling",factors,np.full(len(factors),solubility),"Dilution factor","Active (mg/L)")],rows,
        active_solubility_mg_l=float(solubility),ionization=p["ionization"],dilution_water_ph=p["ph"],
        metric_labels={"maximum_precipitated_fraction":"Aqueous-only excess fraction (hypothetical)",
                       "caco3_saturation_ratio":"Calcium-carbonate saturation ratio (screen)"},
        interpretation="Aqueous-only screening calculation: assumes all diluted active enters water. Oil-phase partitioning, emulsifier binding and emulsion behavior are not resolved. The excess fraction is not predicted product precipitation or emulsion stability.",
        product_predictions={"precipitated_fraction":None,"emulsion_stability":None,"compatibility":None},
        metric_interpretations={"maximum_precipitated_fraction":"max(0,1−aqueous solubility/total active concentration), conditional on the all-in-water assumption; not a product precipitation prediction."})

def powder_dilution(p):
    product=np.unique(p["product_concentrations_g_l"])
    active=product*p["_active_fraction"]*1000
    solubility=p["solubility_mg_l"]
    excess=np.maximum(0,1-np.divide(solubility,active,out=np.full_like(active,np.inf),where=active>0))
    return result({"maximum_active_mg_l":float(max(active)),"maximum_aqueous_excess_fraction":float(max(excess))},
        [curve("Individual active mass balance",product,active,"Product (g/L)","Active (mg/L)"),
         curve("Assumed aqueous ceiling",product,np.full_like(product,solubility),"Product (g/L)","Active (mg/L)")],
        [{"product_g_l":float(c),"active_mg_l":float(a),"assumed_solubility_mg_l":float(solubility),"aqueous_only_excess_fraction":float(e)} for c,a,e in zip(product,active,excess)],
        metric_labels={"maximum_active_mg_l":"Maximum individual-active concentration (mass balance)","maximum_aqueous_excess_fraction":"Aqueous-only excess fraction (hypothetical)"},
        interpretation="Dry-product mass/volume arithmetic with an assumed aqueous ceiling. No liquid density is used. This does not predict dissolution rate, insoluble residue, excipient compatibility or stable product clarity.",
        product_predictions={"dissolution_time":None,"insoluble_residue":None,"compatibility":None,"physical_stability":None})

def terminal_velocity(d,p):
    if d<=0:return 0.
    dr=p["liquid_density_kg_m3"]-p["air_density_kg_m3"]
    if dr<=0:raise ValueError("Liquid density must exceed air density")
    velocity=dr*9.80665*d*d/(18*p["air_viscosity_pa_s"])
    for _ in range(25):
        re=max(1e-12,p["air_density_kg_m3"]*velocity*d/p["air_viscosity_pa_s"])
        cd=24/re*(1+.15*re**.687) if re<1000 else .44
        next_v=math.sqrt(4*dr*9.80665*d/(3*cd*p["air_density_kg_m3"]))
        velocity=.5*(velocity+next_v)
    return velocity

def spray(p):
    t=np.linspace(0,p["horizon_seconds"],601)
    series=[];rows=[]
    for initial in sorted(set(p["droplet_sizes_um"])):
        control.check()
        dry=initial*p["nonvolatile_volume_fraction"]**(1/3)
        sizes=np.sqrt(np.maximum(dry*dry,initial*initial-p["evaporation_um2_s"]*t))
        velocities=np.array([terminal_velocity(d*1e-6,p) for d in sizes])
        descent=np.r_[0,np.cumsum((velocities[1:]+velocities[:-1])*.5*np.diff(t))]
        reached=bool(descent[-1]>=p["release_height_m"])
        end=float(np.interp(p["release_height_m"],descent,t)) if reached else float(t[-1])
        idx=t<end
        tt=np.r_[t[idx],end]
        zz=np.r_[p["release_height_m"]-descent[idx],0 if reached else p["release_height_m"]-descent[-1]]
        distance=p["wind_m_s"]*tt
        series.append(curve(str(initial)+" µm trajectory",distance,zz,"Downwind displacement (m)","Height (m)"))
        rows.append({"initial_diameter_um":initial,"reached_ground":reached,"flight_time_s":end,
            "downwind_m":float(distance[-1]),"final_diameter_um":float(np.interp(end,t,sizes))})
    return result({"maximum_downwind_m":max(r["downwind_m"] for r in rows)},series,rows)

def spreading(p):
    theta=np.deg2rad(p["contact_angle_deg"])
    volume=np.pi/6*p["droplet_diameter_um"]**3
    radius=(3*volume*np.sin(theta)**3/(np.pi*(2-3*np.cos(theta)+np.cos(theta)**3)))**(1/3)
    area_um2=np.pi*radius*radius
    initial=1-np.exp(-p["droplets_per_cm2"]*area_um2/1e8)
    k=p["evaporation_um2_s"]*(1-p["relative_humidity"])
    dry_time=None if k==0 else p["droplet_diameter_um"]**2/k
    t=np.linspace(0,p["horizon_seconds"],161)
    ratio=np.maximum(0,1-k*t/p["droplet_diameter_um"]**2)
    cover=1-np.exp(-p["droplets_per_cm2"]*area_um2*ratio/1e8)
    return result({"initial_coverage_fraction":float(initial),"drying_time_s":dry_time,"footprint_area_mm2":float(area_um2/1e6)},
        [curve("Wet surface coverage",t,cover,"Time (s)","Covered fraction"),
         curve("Remaining liquid volume",t,ratio**1.5,"Time (s)","Fraction of initial volume")])

def rainfastness(p):
    t=np.linspace(0,p["horizon_hours"],161)
    rain=p["rainfall_mm_hour"]*t
    bound=p["maximum_bound_fraction"]*(-np.expm1(-p["binding_rate_per_hour"]*p["drying_hours"]))
    remaining=bound*np.exp(-p["bound_washoff_per_mm"]*rain)+(1-bound)*np.exp(-p["labile_washoff_per_mm"]*rain)
    return result({"retained_fraction":float(remaining[-1]),"bound_fraction_before_rain":float(bound)},
        [curve("Retained deposit",rain,remaining,"Cumulative rain (mm)","Fraction"),
         curve("Washed off",rain,1-remaining,"Cumulative rain (mm)","Fraction")],
        mass_balance_error=float(np.max(np.abs(remaining+1-remaining-1))))

def manufacturing(p):
    if p["limiting_size_um"]>p["initial_size_um"]:
        raise ValueError("Limiting particle size cannot exceed initial size")
    t=np.linspace(0,p["horizon_minutes"],161)
    energy=p["power_w"]/1000*(t/60)/p["batch_kg"]
    size=p["limiting_size_um"]+(p["initial_size_um"]-p["limiting_size_um"])*np.exp(-p["milling_rate_per_kwh_kg"]*energy)
    source=p["heating_fraction"]*p["power_w"]
    capacity=p["batch_kg"]*p["heat_capacity_j_kg_k"]
    conductance=p["heat_transfer_w_k"]
    if conductance==0:
        temp=p["initial_temperature_c"]+source*t*60/capacity
    else:
        equilibrium=p["ambient_temperature_c"]+source/conductance
        temp=equilibrium+(p["initial_temperature_c"]-equilibrium)*np.exp(-conductance*t*60/capacity)
    cv=p["initial_cv"]*np.exp(-p["mixing_rate_per_min"]*t)
    return result({"final_size_um":float(size[-1]),"final_temperature_c":float(temp[-1]),"final_cv":float(cv[-1]),"energy_kwh_kg":float(energy[-1])},
        [curve("Particle size",t,size,"Process time (min)","Size (µm)"),
         curve("Batch temperature",t,temp,"Process time (min)","Temperature (°C)"),
         curve("Concentration CV",t,cv,"Process time (min)","CV")])

def packaging(p):
    capacity=p["dry_product_kg"]*p["moisture_capacity_g_kg_aw"]
    if p["initial_moisture_g"]>capacity:
        raise ValueError("Initial moisture exceeds the linear sorption model's aw=1 capacity")
    conductance=p["wvtr_g_m2_day"]*p["area_m2"]/p["wvtr_reference_rh_difference"]
    t=days(p)
    equilibrium=capacity*p["external_rh"]
    water=equilibrium+(p["initial_moisture_g"]-equilibrium)*np.exp(-conductance*t/capacity)
    solvent=p["initial_solvent_g"]*np.exp(-p["solvent_loss_rate_per_day"]*t)
    total=p["dry_product_kg"]*1000+water+solvent
    return result({"final_moisture_g":float(water[-1]),"final_solvent_g":float(solvent[-1]),"final_water_activity":float(water[-1]/capacity)},
        [curve("Water in package",t,water,"Time (days)","Water (g)"),
         curve("Volatile solvent retained",t,solvent,"Time (days)","Solvent (g)"),
         curve("Product mass",t,total,"Time (days)","Mass (g)")])

def mixture_response(p):
    aa=np.unique(p["doses_a"]);bb=np.unique(p["doses_b"])
    def effect(d,ec,h):
        if d==0:return 0.
        return float(expit(h*(np.log(d)-np.log(ec))))
    def reference(da,db):
        ea=effect(da,p["ec50_a"],p["hill_a"])
        eb=effect(db,p["ec50_b"],p["hill_b"])
        if p["reference_model"]=="bliss":return ea+eb-ea*eb
        if da==0:return eb
        if db==0:return ea
        def equation(e):
            odds=e/(1-e)
            return da/(p["ec50_a"]*odds**(1/p["hill_a"]))+db/(p["ec50_b"]*odds**(1/p["hill_b"]))-1
        return float(brentq(equation,1e-12,1-1e-12))
    rows=[];series=[]
    matrix=[]
    if len(aa)*len(bb)>1600:raise ValueError("Use at most 1600 response-grid cells")
    for db in bb:
        control.check()
        ys=[100*reference(da,db) for da in aa]
        matrix.append(ys)
        series.append(curve("B = "+str(db)+" "+p["dose_unit"],aa,ys,"Active A ("+p["dose_unit"]+")","Reference response (%)"))
        rows.extend({"dose_a":float(da),"dose_b":float(db),"reference_response_pct":float(y)} for da,y in zip(aa,ys))
    return result({"maximum_reference_response_pct":float(np.max(matrix))},series,rows,
        heatmap={"x":aa.tolist(),"y":bb.tolist(),"values":matrix,"x_label":"Active A","y_label":"Active B"},
        interaction_status="Reference only; no observed interaction has been established")

def soil_fate(p):
    t=days(p)
    retardation=1+p["bulk_density_kg_l"]*p["koc_l_kg"]*p["organic_carbon_fraction"]/p["volumetric_water_fraction"]
    water_mm=p["soil_depth_cm"]*10*p["volumetric_water_fraction"]
    kl=p["drainage_mm_day"]/(water_mm*retardation)
    kr=p["runoff_mm_day"]/(water_mm*retardation)
    kd=np.log(2)/p["degradation_half_life_days"]
    total=kl+kr+kd
    soil=np.exp(-total*t)
    removed=-np.expm1(-total*t)
    leached=removed*kl/total;runoff=removed*kr/total;degraded=removed*kd/total
    error=float(np.max(np.abs(soil+leached+runoff+degraded-1)))
    rows=[{"time_days":float(tt),"soil_g_ha":float(s*p["initial_active_g_ha"]),
        "leached_g_ha":float(l*p["initial_active_g_ha"]),"runoff_g_ha":float(r*p["initial_active_g_ha"]),
        "degraded_g_ha":float(d*p["initial_active_g_ha"])} for tt,s,l,r,d in zip(t,soil,leached,runoff,degraded)]
    return result({"leached_fraction":float(leached[-1]),"runoff_fraction":float(runoff[-1]),"retardation_factor":float(retardation),
        "closed_water_runoff_mg_l":float(runoff[-1]*p["initial_active_g_ha"]/p["receiving_water_m3_ha"]),"mass_balance_error":error},
        [curve(name,t,value,"Time (days)","Fraction of initial active") for name,value in
            (("Remaining soil",soil),("Leached",leached),("Runoff",runoff),("Degraded",degraded))],rows)

def geometry_release(p):
    from ..physics.geometry import analytic_release_fraction
    t=days(p)
    tau=p["diffusivity_m2_s"]*86400*t/(p["length_um"]*1e-6)**2
    f=analytic_release_fraction(tau,p["geometry"])
    # Series truncation at exactly zero must not create an artificial burst.
    f[0]=0.
    return result({"release_at_horizon":float(f[-1])},[curve("Released",t,f,"Time (days)","Released fraction")])

def finite_bath(p):
    from ..physics.geometry import fv_operator
    cells=40
    op,volumes=fv_operator(cells,p["geometry"])
    conductance=2*cells
    bath=p["bath_ratio"]
    A=np.zeros((cells+1,cells+1))
    A[:cells,:cells]=op
    A[cells-1,cells]=conductance/volumes[-1]
    A[cells,cells-1]=conductance/(volumes.sum()*bath)
    A[cells,cells]=-conductance/(volumes.sum()*bath)
    weights=np.r_[volumes/volumes.sum(),bath]
    root=np.sqrt(weights)
    symmetric=root[:,None]*A/root[None,:]
    eig,V=eigh((symmetric+symmetric.T)/2)
    if eig[-1]>1e-7:raise ValueError("Finite-bath diffusion operator is not dissipative")
    eig=np.minimum(eig,0)
    # The conservative particle/bath system has one exact zero eigenvalue.
    # A tiny negative eigensolver residual otherwise decays total mass at long
    # physical times, even when every transient has already equilibrated.
    eig[-1]=0.
    initial=np.r_[np.ones(cells),0.]
    t=days(p)
    tau=p["diffusivity_m2_s"]*86400*t/(p["length_um"]*1e-6)**2
    X=(V@((V.T@(root*initial))[:,None]*np.exp(eig[:,None]*tau)))/root[:,None]
    release=bath*X[-1]
    release[0]=0
    total=weights@X
    mass_error=float(np.max(np.abs(total-1)))
    equilibrium=bath/(1+bath)
    if mass_error>1e-8 or np.min(X)<-1e-8 or np.max(X)>1+1e-8 or np.max(release)>equilibrium+1e-8:
        raise ValueError("Finite-bath solution failed conservation or concentration bounds")
    # Remove only floating-point excursions after checking the physical limits.
    release=np.clip(release,0,equilibrium)
    return result({"release_at_horizon":float(release[-1]),"equilibrium_release_fraction":float(equilibrium),
        "mass_balance_error":mass_error},
        [curve("Mass in receiving bath",t,np.clip(release,0,1),"Time (days)","Fraction of initial active")])

def swelling_release(p):
    from ..physics.geometry import analytic_release_fraction
    from ..physics.swelling import effective_tau
    t=days(p)
    rate=p["diffusivity_m2_s"]*86400/(p["length_um"]*1e-6)**2
    tau=effective_tau(t,rate=rate,swelling_rate=p["swelling_rate"],swelling_exponent=p["swelling_exponent"])
    f=analytic_release_fraction(tau,p["geometry"]);f[0]=0.
    return result({"release_at_horizon":float(f[-1]),"final_length_um":float(p["length_um"]*(1+p["swelling_rate"]*t[-1]**p["swelling_exponent"]))},
        [curve("Swelling-adjusted release",t,f,"Time (days)","Released fraction")])

def robustness(p):
    base=p["base_model"]
    if base in {"robustness","inverse_design","sensitivity"}:raise ValueError("Robustness cannot recursively sample another analysis or itself")
    definition=spec(base)
    template=validate(base,p["base_inputs"])
    params=p["parameters"]
    if not 1<=len(params)<=8:raise ValueError("Choose 1 to 8 uncertain numeric parameters")
    names=[v.get("parameter") for v in params]
    if len(set(names))!=len(names):raise ValueError("Uncertain parameters must be unique")
    fields={f["key"]:f for f in definition["fields"] if f["type"]=="number"}
    if set(names)-set(fields):raise ValueError("Only declared scalar numeric inputs can be sampled")
    count=integer(p["samples"],"samples",10,1000)
    if base in ("spray","finite_bath") and count>200:
        raise ValueError("Use at most 200 samples for flight or finite-bath models")
    if p["minimum"]>p["maximum"]:raise ValueError("Acceptance minimum exceeds maximum")
    corr=np.asarray(p["correlation"] if p["correlation"] else np.eye(len(params)),float)
    if corr.shape!=(len(params),len(params)) or not np.isfinite(corr).all() or not np.allclose(corr,corr.T) or not np.allclose(np.diag(corr),1) or np.linalg.eigvalsh(corr).min()<-1e-9:
        raise ValueError("Correlation must be a symmetric positive-semidefinite matrix with unit diagonal")
    rng=np.random.default_rng(integer(p["seed"],"seed",0,2**32-1))
    z=rng.multivariate_normal(np.zeros(len(params)),corr,size=count)
    uniforms=np.clip(ndtr(z),1e-10,1-1e-10)
    samples=np.zeros_like(z)
    for col,param in enumerate(params):
        f=fields[param["parameter"]]
        lo=number(param.get("low",f["min"]),"distribution low",f["min"],f["max"])
        hi=number(param.get("high",f["max"]),"distribution high",f["min"],f["max"])
        if hi<=lo:raise ValueError("Distribution high must exceed low")
        if param.get("distribution")=="uniform":
            samples[:,col]=lo+(hi-lo)*uniforms[:,col]
        elif param.get("distribution")=="normal":
            mean=number(param.get("mean"),"normal mean",lo,hi)
            sd=number(param.get("sd"),"normal standard deviation",1e-12,1e12)
            l=ndtr((lo-mean)/sd);h=ndtr((hi-mean)/sd)
            if h-l<1e-12:raise ValueError("Normal truncation range has negligible probability")
            samples[:,col]=mean+sd*ndtri(l+(h-l)*uniforms[:,col])
        else:raise ValueError("Distribution must be uniform or normal")
    values=[]
    rows=[]
    for i,row in enumerate(samples):
        control.check()
        inputs=dict(template,**dict(zip(names,row)))
        outcome=run(base,inputs,active_fraction=p.get("_active_fraction",.1))
        value=outcome["metrics"].get(p["metric"])
        if value is None or not np.isfinite(value):raise ValueError("Choose an available finite scalar output metric")
        values.append(float(value))
        rows.append({"sample":i+1,"value":float(value),**{name:float(v) for name,v in zip(names,row)}})
        token=control.current()
        if token and token.on_event and (i+1)%25==0:
            token.on_event({"kind":"tool_progress","tool":"robustness","message":str(i+1)+"/"+str(count)+" robustness samples completed"})
    values=np.array(values);q=np.quantile(values,[.05,.5,.95])
    passing=(values>=p["minimum"])&(values<=p["maximum"])
    hist,edges=np.histogram(values,bins=min(30,max(5,count//10)))
    return result({"pass_probability":float(passing.mean()),"p05":float(q[0]),"median":float(q[1]),"p95":float(q[2]),"samples":count},
        [curve("Sampled output distribution",(edges[:-1]+edges[1:])/2,hist,p["metric"],"Sample count")],rows,
        parameter_names=names,uncertainty_basis="Supplied marginal distributions with Gaussian-copula dependence")

FUNCTIONS={name:globals()[name] for name in ("suspension","rheology","solubility","dilution","powder_dilution","spray","spreading",
    "rainfastness","manufacturing","packaging","mixture_response","soil_fate","geometry_release","finite_bath","swelling_release","robustness")}

def run(key,raw,active_fraction=.1):
    control.check()
    p=validate(key,raw)
    if key=="wettability":
        from .wettability import predict
        output=predict(p)
        model=spec(key)
        output.update(model_key=key,model_title=model["title"],equation=model["equation"],evidence="assumed scenario",limitations=model["limits"],sources=[])
        return output
    if key in ("dosage","dilution","powder_dilution","robustness","inverse_design","sensitivity"):
        p["_active_fraction"]=number(active_fraction,"individual active fraction",1e-8,1)
    if key=="sensitivity":
        from .sensitivity import analyze
        output=analyze(p,active_fraction)
    elif key=="inverse_design":
        from .inverse_design import optimize
        output=optimize(p,active_fraction)
    elif key=="kinetics":
        native=kinetics.simulate(p)
        output=result({"release_at_horizon":native["release_fraction"][-1],"available_at_horizon":native["available_fraction"][-1]},
            [curve("Cumulative release",native["times_days"],native["release_fraction"],"Time (days)","Fraction"),
             curve("Available active",native["times_days"],native["available_fraction"],"Time (days)","Fraction")],native=native)
    elif key=="stability":
        native=stability.simulate(p)
        series=[curve(str(c["temperature_c"])+" °C",native["times_days"],c["retained_fraction"],"Time (days)","Retained fraction") for c in native["curves"]]
        if native.get("temperature_profile"):
            v=native["temperature_profile"]
            series.append(curve("Temperature profile",v["times_days"],v["retained_fraction"],"Time (days)","Retained fraction"))
        output=result({"retention_at_first_temperature":native["curves"][0]["retained_at_horizon"]},series,native=native)
    elif key=="dosage":
        if p["evaluation_day"]>p["release_horizon_days"]:raise ValueError("Evaluation day must fall within release horizon")
        native=dosage.scenario({"kinetics":{"model":"first_order","rate_per_day":p["release_rate_per_day"],
            "horizon_days":p["release_horizon_days"],"plateau":1,"lag_days":0},"active_fraction":active_fraction,
            **{k:p[k] for k in ("evaluation_day","target_available_g_ha","storage_retained_fraction","deposition_fraction","spray_volume_l_ha")}})
        sensitivity=native["deposition_sensitivity"]
        output=result({"product_kg_ha":native["product_kg_ha"],"available_fraction":native["available_fraction"]},
            [curve("Hypothetical product quantity",[v["deposition_fraction"] for v in sensitivity],[v["product_kg_ha"] for v in sensitivity],
                "Deposited fraction","Product (kg/ha)")],native=native)
    else:
        output=FUNCTIONS[key](p)
    model=spec(key)
    output.update(model_key=key,model_title=model["title"],equation=model["equation"],
        evidence="assumed scenario",limitations=deepcopy(model["limits"]),sources=model.get("sources",[]))
    # Detect numerical failures before generic JSON cleaning could hide them.
    def finite(value):
        if isinstance(value,dict):return all(finite(v) for v in value.values())
        if isinstance(value,(list,tuple,np.ndarray)):return all(finite(v) for v in value)
        return not isinstance(value,(float,np.floating)) or bool(np.isfinite(value))
    if not finite(output):raise ValueError("Scenario exceeded its numerical domain; reduce the parameter range")
    control.check()
    return clean(output)
