"""Execute a declared recipe-to-scenario workflow and publish its comparison."""
from copy import deepcopy
import json

from . import control, recipe_design, simulation_catalog, simulation_service
from .common import digest, label

UNITS={"maximum_active_mg_l":"mg/L","maximum_aqueous_excess_fraction":"fraction (aqueous-only hypothetical)","separated_fraction":"fraction","maximum_velocity_mm_day":"mm/day","mass_balance_error":"fraction",
    "final_size_um":"µm","final_temperature_c":"°C","final_cv":"dimensionless","energy_kwh_kg":"kWh/kg",
    "maximum_precipitated_fraction":"fraction (aqueous-only hypothetical)","caco3_saturation_ratio":"dimensionless"}

def parse(raw):
    try:value=json.loads(raw.get("workflow_json",""))
    except (TypeError,ValueError):raise ValueError("workflow_json must encode a complete workflow object") from None
    if not isinstance(value,dict) or set(value)-{"name","goal","designs","recipe_ids","scenarios","research"}:
        raise ValueError("Unsupported formulation workflow fields")
    value["name"]=label(value.get("name"),"workflow name",200)
    value["goal"]=label(value.get("goal"),"workflow goal",3000)
    if bool(value.get("designs"))==bool(value.get("recipe_ids")):
        raise ValueError("Supply either independent designs or existing recipe_ids")
    scenarios=value.get("scenarios")
    if not isinstance(scenarios,list) or not 1<=len(scenarios)<=12 or any(not isinstance(s,dict) for s in scenarios):
        raise ValueError("Declare 1 to 12 physical scenarios")
    names=set()
    for scenario in scenarios:
        if set(scenario)-{"name","model","inputs","active_name","assumptions"}:
            raise ValueError("Unsupported workflow scenario fields")
        scenario["name"]=label(scenario.get("name"),"scenario name",200)
        if scenario["name"] in names:raise ValueError("Workflow scenario names must be distinct")
        names.add(scenario["name"])
        if simulation_catalog.spec(scenario.get("model"))["key"] in {"inverse_design","robustness","sensitivity","mixture_response"}:
            raise ValueError("Workflow stages use base physical models; run nested analyses separately")
    if value.get("research"):
        from .research import validate
        value["research"]=validate(value["research"])
    return value

def render(workflow,state):
    def cell(value):return str(value).replace("|","/").replace("\n"," ")
    summary=workflow["summary"]
    lines=[("Computed formulation workflow: " if summary["evaluated"]==summary["requested_scenarios"] else "Partial formulation workflow: ")+str(summary["recipe_count"])+" recipes, "+str(summary["evaluated"])+"/"+str(summary["requested_scenarios"])+" declared physical scenarios evaluated.",
        workflow["goal"],"These are mass-balanced research drafts and conditional numerical scenarios. No compatibility, physical stability, shelf life, efficacy or manufacturing readiness has been established.",
        "| Recipe | Ingredient / supplied grade | Supplied wt% | Pure-active wt% |",
        "|---|---|---:|---:|"]
    for recipe in workflow["recipes"]:
        for i in recipe["ingredients"]:
            active=i["pct"]*i["purity_pct"]/100 if i["role"]=="active" else "—"
            lines.append("| "+" | ".join(map(cell,[recipe["name"],i["name"],f"{i['pct']:.6g}",f"{active:.6g}" if isinstance(active,float) else active]))+" |")
    lines.extend(["Supplied technical masses include their impurities. Supplied excipient solutions include their carrier; purity is not applied twice.",
        "| Recipe | Scenario | Output | Value | Unit / basis |","|---|---|---|---:|---|"])
    for case in workflow["cases"]:
        if case["status"]!="evaluated":
            lines.append("| "+" | ".join(map(cell,[case["recipe_name"],case["name"],"Model domain rejected",case["reason"],"No prediction"]))+" |")
            continue
        for key,value in case["metrics"].items():
            unit=UNITS.get(key,simulation_catalog.spec(case["model"])["metric_unit"] if key==simulation_catalog.spec(case["model"])["metric"] else "see model metric / exact inputs")
            lines.append("| "+" | ".join(map(cell,[case["recipe_name"],case["name"],case["metric_labels"].get(key,key),f"{value:.6g}" if isinstance(value,(int,float)) else "unavailable",unit]))+" |")
    lines.extend(["Comparison: every candidate was evaluated under the same declared scenario inputs. Where composition does not parameterize the model, identical outputs cannot rank different excipient systems."])
    for note in dict.fromkeys(c.get("interpretation") for c in workflow["cases"] if c.get("interpretation")):
        lines.append(note)
    lines.append("Exact inputs, recipe versions, input provenance, model limitations and engine identities are saved with each scenario. A completed calculation is not experimental validation.")
    if workflow.get("research_search_id"):
        search=next(s for s in state["research_searches"] if s["search_id"]==workflow["research_search_id"])
        lines.append("Literature discovery: "+str(len(search["results"]))+" records; retrieval status "+search["status"]+". Metadata and available abstracts only; full text and compatibility claims are not verified.")
        lines.extend("- ["+s["title"].replace("[","(").replace("]",")")+"]("+s["url"]+")" for s in search["results"][:4])
    else:lines.append("No literature review was executed in this workflow. Ingredient grades, availability and claim support remain unverified.")
    lines.append("Next decision: check the candidate-specific properties that could distinguish these hypotheses. For SC this includes particle-size distribution and rheology; for EC/OD/EW it includes concentrate phase behavior and dilution-emulsion behavior. No detailed experiment plan or laboratory execution is implied.")
    parts=[];previous_table=False
    for line in lines:
        table=line.startswith("|")
        if parts:parts.append("\n" if table and previous_table else "\n\n")
        parts.append(line);previous_table=table
    return "".join(parts)

def record(state,raw,workspace,question=""):
    config=parse(raw);planned=deepcopy(state);generated=0
    if config.get("designs"):
        portfolio=recipe_design.portfolio({"designs_json":json.dumps(config["designs"])},workspace,question)
        targets=portfolio["recipes"];known={r["recipe_id"] for r in planned.get("recipes",[])}
        additions=[r for r in targets if r["recipe_id"] not in known]
        generated=len(additions);planned.setdefault("recipes",[]).extend(additions)
        planned["recipe_result"]=portfolio
        planned["brief"]={**portfolio["brief"],"name":state.get("brief",{}).get("name") or portfolio["brief"]["name"]}
    else:
        ids=config["recipe_ids"]
        if not isinstance(ids,list) or not 1<=len(ids)<=12 or len(set(ids))!=len(ids):raise ValueError("Choose 1 to 12 distinct existing recipe IDs")
        by_id={r["recipe_id"]:r for r in planned.get("recipes",[])}
        if any(rid not in by_id for rid in ids):raise ValueError("Workflow recipe does not belong to this project")
        targets=[by_id[rid] for rid in ids]
    if len(targets)*len(config["scenarios"])>96:raise ValueError("A workflow supports at most 96 recipe/scenario cases")
    requests=[]
    for recipe in targets:
        for scenario in config["scenarios"]:
            active=scenario.get("active_name") or (recipe["active_components"][0]["name"] if len(recipe["active_components"])==1 else None)
            if not active:raise ValueError("Choose an individual active for every scenario in a mixture workflow")
            request={**scenario,"recipe_id":recipe["recipe_id"],"active_name":active}
            simulation_service.prepare(planned,request)
            requests.append((recipe,request))
    version=control.engine_version();wid="workflow-"+digest({"request":config,"engine":version})
    previous=next((w for w in planned.get("formulation_workflows",[]) if w["workflow_id"]==wid),None)
    if previous:return previous
    # Validation is atomic; once all declared requests validate, every completed
    # numerical step is durably checkpointed even if later work is stopped.
    state.update(planned);control.checkpoint(state,"Validated recipe and physical-scenario workflow")
    cases=[]
    for recipe,request in requests:
        control.check()
        case={"recipe_id":recipe["recipe_id"],"recipe_name":recipe["name"],"name":request["name"],"model":request["model"]}
        try:
            entry=simulation_service.record(state,request);output=entry["result"]
            case.update(status="evaluated",scenario_id=entry["scenario_id"],metrics=output["metrics"],metric_labels=output.get("metric_labels",{}),interpretation=output.get("interpretation"),evidence=output["evidence"])
        except (ValueError,ArithmeticError) as exc:case.update(status="model domain rejected",reason=str(exc))
        cases.append(case)
    workflow={"workflow_id":wid,"name":config["name"],"goal":config["goal"],"task":question,"request":config,
        "generated_recipes":generated,"recipes":deepcopy(targets),"cases":cases,
        "summary":{"recipe_count":len(targets),"requested_scenarios":len(cases),"evaluated":sum(c["status"]=="evaluated" for c in cases)},
        "engine_version":version,"engine_manifest":control.engine_manifest(),"evidence":"Computed scenario comparison; product performance unmeasured"}
    if config.get("research"):
        from .research import record as search
        found=search(state,config["research"]);workflow["research_search_id"]=found["search_id"]
    workflow["status"]="computed" if workflow["summary"]["evaluated"]==len(cases) else "partial"
    workflow["answer"]=render(workflow,state)
    state.setdefault("formulation_workflows",[]).append(workflow)
    control.checkpoint(state,"Formulation workflow comparison published")
    return workflow
