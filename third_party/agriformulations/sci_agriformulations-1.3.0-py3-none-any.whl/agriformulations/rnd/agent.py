"""Local specialist-tool agent with visible routing and deterministic execution.

No external model or network is used. Natural-language coverage is deliberately
bounded; tool results and their assumptions are returned rather than invented.
"""
import re
from copy import deepcopy
from .recipes import suggest
from .kinetics import simulate as kinetics
from .stability import simulate as stability
from .dosage import scenario as dosage
from .experiments import plan
from .common import label, digest

CAPABILITIES = [
    "Suggest 12 recipes with 20% active and a 1000 g batch",
    "Simulate release kinetics for 60 days",
    "Simulate stability at 25, 40 and 54 C for 180 days",
    "Calculate a dose scenario for 50 g/ha available active at day 35",
    "Plan experiments for 6 recipes with 3 independent batches",
    "Run the complete workflow",
    "Why is this recipe ranked first?",
    "What evidence is missing before experimentation?",
]
def answer(raw):
    question=label(raw.get("question"),"question",2000)
    q=question.lower()
    state=deepcopy(raw.get("state",{}))
    updates={}; trace=[]; text=[]; warnings=[]
    def run(agent,tool,inputs,fn,key):
        value=fn(inputs)
        updates[key]=value
        trace.append({"agent":agent,"tool":tool,"input_digest":digest(inputs),
                      "evidence":value.get("evidence",value.get("ranking_basis",value.get("design","computed"))),
                      "inputs":{k:([r["recipe_id"] for r in v] if k=="recipes" else v) for k,v in inputs.items()},
                      "assumptions":value.get("assumptions",value.get("limitations",value.get("warnings",[])))})
        return value
    if any(s in q for s in ("how are recipes", "how do you suggest", "how are you suggesting", "how does recipe", "explain recipe")):
        return {"answer":"Recipe drafts satisfy the ingredient bounds, sum to 100% by mass, and correct each active target for technical purity. Known ingredient prices determine cost ranking. Performance ranking requires local measured recipe-response data and a passing recipe-held-out validation gate. No chemistry-to-release relationship is invented.",
            "trace":[{"agent":"Recipe designer","tool":"recipes.explain","evidence":"constraint solver and local learning gate"}],
            "updates":{},"warnings":[],"examples":CAPABILITIES,"mode":"local deterministic tool agent","question":question}
    if any(s in q for s in ("what is t50", "what is the t50", "release milestone", "what is t90")):
        result=state.get("kinetics_result")
        return {"answer":("Current scenario milestones: "+str(result["milestones"]) if result else "Run a release simulation first to calculate milestones."),
            "trace":[{"agent":"Kinetics modeler","tool":"kinetics.milestones","evidence":"current project scenario"}],
            "updates":{},"warnings":[],"examples":CAPABILITIES,"mode":"local deterministic tool agent","question":question}
    all_steps=any(s in q for s in ("complete workflow","full workflow","end to end","end-to-end"))
    recipe_intent=all_steps or any(s in q for s in ("suggest","generate","design recipes","new recipes","propose recipes","formulate","recommend recipe","build recipe","propose formulation"))
    kinetic_intent=all_steps or any(s in q for s in ("kinetic","simulate release","release curve"))
    stability_intent=all_steps or any(s in q for s in ("stability","shelf life","shelf-life"))
    dose_intent=all_steps or any(s in q for s in ("dose scenario","dosage","calculate a dose","calculate dose"))
    experiment_intent=all_steps or any(s in q for s in ("plan experiment","design experiment","next experiment"))
    brief=deepcopy(state.get("brief",{}))
    if recipe_intent:
        for pattern,key,cast in [
            (r"(\d+)\s+recipes","count",int),
            (r"([\d.]+)\s*%\s*(?:active|a\.?i\.?|nutrient)","active_pct",float),
            (r"([\d.]+)\s*(?:g|grams?)\s+batch","batch_g",float),
        ]:
            m=re.search(pattern,q)
            if m: brief[key]=cast(m[1])
        result=run("Recipe designer","recipes.suggest",brief,suggest,"recipe_result")
        updates["brief"]=brief
        state["recipes"]=result["recipes"]
        state["selected_recipe_id"]=result["recipes"][0]["recipe_id"]
        # Parameters from a previous recipe become an explicit transfer assumption.
        state.setdefault("kinetics_input",{})["parameter_source"]="user scenario for new recipe; no composition-to-rate model"
        state.setdefault("stability_input",{}).pop("calibration",None)
        updates["invalidate_recipe_results"]=True

        updates["selected_recipe_id"]=state["selected_recipe_id"]
        state["selected_active_name"]=result["recipes"][0]["active_components"][0]["name"]
        updates["selected_active_name"]=state["selected_active_name"]
        text.append(f"Generated {result['generated']} mass-balanced recipe drafts. Ranking uses known cost; formulation performance remains unmeasured.")
    selected=next((r for r in state.get("recipes",[]) if r["recipe_id"]==state.get("selected_recipe_id")),None)
    if kinetic_intent:
        inputs=deepcopy(state.get("kinetics_input",{}))
        m=re.search(r"(?:for|over)\s+([\d.]+)\s+days",q)
        if m: inputs["horizon_days"]=float(m[1])
        result=run("Kinetics modeler","kinetics.simulate",inputs,kinetics,"kinetics_result")
        updates["kinetics_input"]=inputs
        text.append(f"Simulated {result['model']} release. Final modeled release: {result['release_fraction'][-1]:.1%}.")
    if stability_intent:
        inputs=deepcopy(state.get("stability_input",{}))
        m=re.search(r"(?:for|over)\s+([\d.]+)\s+days",q)
        if m and not all_steps: inputs["horizon_days"]=float(m[1])
        m=re.search(r"at\s+([\d.,\s]+(?:and\s+[\d.]+)?)\s*(?:°?c|celsius)",q)
        if m: inputs["temperatures_c"]=[float(x) for x in re.findall(r"\d+(?:\.\d+)?",m[1])]
        result=run("Stability analyst","stability.simulate",inputs,stability,"stability_result")
        updates["stability_input"]=inputs
        text.append("Computed chemical-retention curves. Physical stability still requires its own tests; chemical retention does not establish shelf life.")
    if dose_intent:
        if selected is None:
            raise ValueError("Generate and select a recipe before calculating a dose scenario")
        inputs=deepcopy(state.get("dosage_input",{}))
        component=next((c for c in selected.get("active_components",[]) if c["name"]==state.get("selected_active_name")),None)
        if component is None: component=selected.get("active_components",[{"name":"total active","active_fraction":selected["active_fraction"]}])[0]
        inputs["active_fraction"]=component["active_fraction"]
        inputs["context"]={"active_name":component["name"],"recipe_id":selected["recipe_id"]}
        inputs["kinetics"]=updates.get("kinetics_input",state.get("kinetics_input",{}))
        m=re.search(r"([\d.]+)\s*g\s*/\s*ha",q)
        if m: inputs["target_available_g_ha"]=float(m[1])
        m=re.search(r"(?:at\s+)?day\s+([\d.]+)",q)
        if m: inputs["evaluation_day"]=float(m[1])
        result=run("Dose scenario analyst","dosage.scenario",inputs,dosage,"dosage_result")
        updates["dosage_input"]=inputs
        text.append(f"The supplied exposure target requires {result['product_kg_ha']:.4g} kg product/ha under this scenario. This is not a field-effective dose prediction.")
    if experiment_intent:
        inputs=deepcopy(state.get("experiment_input",{})); inputs["recipes"]=state.get("recipes",[])
        m=re.search(r"(?:for|with)\s+(\d+)\s+recipes",q)
        if m: inputs["n_recipes"]=int(m[1])
        elif inputs["recipes"]:
            inputs["n_recipes"]=min(inputs.get("n_recipes",6),len(inputs["recipes"]))
        m=re.search(r"(\d+)\s+independent batches",q)
        if m: inputs["independent_batches"]=int(m[1])
        result=run("Experiment planner","experiments.plan",inputs,plan,"experiment_result")
        text.append(f"Prepared {result['n_independent_batches']} independent batch runs with randomized order and a test queue.")
    if any(s in q for s in ("why","rank","best recipe","compare")) and not trace:
        text.append("Recipe ranking uses ingredient cost where every price is available, then a stable identifier. No learned composition-to-performance model has passed validation. Compare measured assay results before choosing a winner.")
    if any(s in q for s in ("evidence","missing","trust","assumptions","limitation")) or all_steps:
        text.append("Missing evidence: validated ingredient compatibility, linked recipe/process/batch results, independent stability assays, and context-matched dose-response experiments. Release curves alone cannot establish efficacy or physical shelf life.")
        trace.append({"agent":"Evidence reviewer","tool":"evidence.gap_review","evidence":"catalog composition/performance overlap is currently zero"})
    if not text and any(word in q for word in ("campaign", "sulfoxaflor", "benzovindiflupyr", "blocked", "enantiomer", "fickian ceiling", "claim")):
        from ..gui.qa import answer as historical_answer
        historical=historical_answer(question)
        if historical.get("route") != "help":
            text.append(historical["answer"])
            trace.append({"agent":"Evidence reviewer","tool":historical.get("engine","historical engines"),"evidence":"frozen campaign or verified kernel"})
    if not text:
        text.append("I can run the local specialist tools using the active project's inputs. Choose an example below; I do not have a general language model or external literature connection.")
    if trace:
        warnings.append("Review the interpreted inputs in the relevant panel. Unspecified inputs retain the visible project settings.")
    return {"answer":"\n\n".join(text),"trace":trace,"updates":updates,"warnings":warnings,
        "examples":CAPABILITIES,"mode":"local deterministic tool agent","question":question}
