"""Selectable source-linked formulations, design starters and private saved recipes."""
from copy import deepcopy
from dataclasses import asdict
import json
from pathlib import Path
from .common import label, number, digest
from .recipes import default_brief, suggest

from agriformulations._paths import resource_root
ROOT = resource_root()
ROLE_MAP={"active":"active","matrix":"matrix","crosslinker":"stabilizer","filler":"filler","surfactant":"surfactant",
          "coating":"coating","plasticizer":"other","solvent":"solvent","dispersant":"dispersant","control":"other","other":"other"}

def _starter(fmt,name,rows,notes):
    brief=default_brief()
    brief.update(name=name,format=fmt,active_name="Choose active / nutrient grade",count=12)
    brief["ingredients"]=[dict(name=nm,role=role,min_pct=lo,max_pct=hi,purity_pct=purity,
        cost_per_kg=None,supplier="",lot="") for nm,role,lo,hi,purity in rows]
    brief["bounds_source"]="Illustrative internal design bounds; not a published or validated recipe"
    brief["process"]=[{"step":1,"instruction":"Assign a laboratory preparation method for the selected active and grades."}]
    return {"library_id":"starter-"+fmt.lower(),"name":name,"format":fmt,"active":"user-selected active",
        "origin":"design_starter","validation_status":"unvalidated design starter","composition_status":"bounded design space",
        "source":{"kind":"internal_design","locator":"Authored workbench scaffold; numeric ranges are design assumptions"},
        "ingredients":brief["ingredients"],"notes":notes,"brief":brief,"can_generate":True}

def starters():
    active=("Technical active (select identity and grade)","active",20,25,95)
    return [
        _starter("SC","SC · aqueous suspension starting space",[active,
            ("Sodium lignosulfonate (select grade)","dispersant",1,4,100),
            ("Xanthan gum (select grade)","stabilizer",.1,.5,100),("Water","solvent",70,80,100)],
            "Material choices and ranges are hypotheses. Confirm active solubility, wetting, rheology and suspensibility."),
        _starter("EC","EC · emulsifiable concentrate starting space",[active,
            ("Emulsifier package (select chemistry)","surfactant",4,12,100),
            ("Solvent blend (select for active solubility)","solvent",60,80,100)],
            "No solvent-active compatibility or solubility is assumed. Select a justified solvent/emulsifier system."),
        _starter("WG","WG · dispersible granule starting space",[active,
            ("Sodium lignosulfonate (select grade)","dispersant",2,6,100),
            ("PVP binder (select grade)","binder",1,4,100),("Kaolin (select grade)","filler",60,78,100)],
            "Confirm wetting, granulation, disintegration and wet-sieve behavior experimentally."),
        _starter("CR","CR · polymer-matrix starting space",[active,
            ("Sodium alginate (select grade)","matrix",5,15,100),
            ("PVA (select grade)","binder",1,5,100),("Water","solvent",55,75,100)],
            "Preparation bath, crosslinking, final dry composition and active compatibility need definition. No release rate is assigned from ingredients."),
        _starter("FERT","Fertilizer · coated nutrient starting space",[
            ("Nutrient-bearing material (supply nutrient assay)","active",20,25,95),
            ("Attapulgite (select grade)","carrier",55,72,100),
            ("Binder / coating (select chemistry)","coating",2,8,100),("Balance material (select)","filler",1,20,100)],
            "The example 95% nutrient assay must be replaced with the actual grade assay. Do not equate ingredient loading with elemental nutrient content.")
    ]

def published():
    # Uses the existing curated registry and source provenance, never source-fit curves as measurements.
    from ..catalog import load_catalog
    result=[]
    catalog=load_catalog()
    for form in catalog.formulations:
        ingredients=[]; sources=[]
        for item in form.ingredients:
            measurement=item.mass_fraction
            source=asdict(measurement.provenance) if measurement else None
            if source and source.get("source_url"):sources.append(source)
            ingredients.append({"name":item.name,"role":ROLE_MAP.get(item.role,"other"),
                "mass_fraction":measurement.value if measurement else None,
                "purity_pct":None,"fraction_source":source})
        meta=next((x["meta"] for x in catalog.studies.values() if x["meta"].get("study_id")==form.study_id),{})
        source_url=(sources[0]["source_url"] if sources else meta.get("source_url") or
            ("https://doi.org/"+meta["doi"] if meta.get("doi") else None))
        fertilizer=any(s in form.study_id.lower() for s in ("fert","xiang","perera","zhu"))
        result.append({"library_id":"published-"+digest([form.study_id,form.formulation_id]),
            "name":form.formulation_id+" · "+form.study_id,"format":"FERT" if fertilizer else "CR",
            "active":", ".join(i.name for i in form.ingredients if i.role=="active"),
            "origin":"published","validation_status":"source-recorded; not independently replicated",
            "composition_status":"partial" if any(i["mass_fraction"] is None for i in ingredients) else "declared fractions",
            "source":{"kind":"curated_literature","study_id":form.study_id,"formulation_id":form.formulation_id,
                "url":source_url,"locator":"Curated ontology and ingredient provenance","doi":meta.get("doi"),
                "cautions":meta.get("cautions",[]),"limitations":meta.get("limitations",[])},
            "ingredients":ingredients,"notes":form.notes,"process":[{"step":p.step,"parameter":p.parameter,
                "value":p.value.to_dict() if p.value else None,"note":p.note} for p in form.process],
            "can_generate":False})
    return result

def entries(workspace=None,query="",fmt="",origin=""):
    records=starters()+published()+(workspace.library_list() if workspace else [])
    query=str(query or "").lower().strip()
    return [r for r in records if (not fmt or r.get("format")==fmt)
        and (not origin or r.get("origin")==origin)
        and (not query or query in json.dumps(r,ensure_ascii=False).lower())]

def get(entry_id,workspace=None):
    for entry in entries(workspace):
        if entry["library_id"]==entry_id:return deepcopy(entry)
    raise ValueError("Recipe library entry not found")

def apply(entry_id,current_brief=None,workspace=None):
    entry=get(entry_id,workspace)
    brief=deepcopy(current_brief or default_brief())
    if entry.get("brief"):
        # Keep project identity and application context while importing the recipe design.
        incoming=deepcopy(entry["brief"])
        for key in ("name","crop","target","application","objective"):
            if key in brief:incoming[key]=brief[key]
        if brief.get("batch_g") is not None:incoming["batch_g"]=brief["batch_g"]
        brief=incoming
    elif entry.get("recipe"):
        r=entry["recipe"]
        brief.update(format=r["format"],active_pct=r["active_fraction"]*100,
            active_name=", ".join(c["name"] for c in r.get("active_components",[])),
            ingredients=[dict(i,min_pct=i["pct"],max_pct=i["pct"]) for i in r["ingredients"]],
            process=r.get("process",[]),process_parameters=r.get("process_parameters",[]),
            bounds_source="Saved recipe: "+entry["library_id"])
    else:
        brief.update(format=entry["format"],active_name=entry.get("active",""),active_pct=None,
            ingredients=[{"name":i["name"],"role":i["role"],
                "min_pct":None if i["mass_fraction"] is None else i["mass_fraction"]*100,
                "max_pct":None if i["mass_fraction"] is None else i["mass_fraction"]*100,
                "purity_pct":None,"cost_per_kg":None,"supplier":"","lot":""}
                for i in entry["ingredients"]],
            process=entry.get("process",[]),
            bounds_source="Published partial record; unknown fractions and active assay must be supplied")
    brief["library_reference"]={"library_id":entry["library_id"],"source":entry["source"],
        "validation_status":entry["validation_status"]}
    return {"brief":brief,"entry":entry,"warnings":(
        ["Published quantities are preserved; fill missing composition and active assay before generating candidates."]
        if entry["origin"]=="published" else ["This recipe remains a draft unless your own experimental evidence supports it."])}

def save(raw,workspace,author="user",sources=None):
    recipe=deepcopy(raw.get("recipe",{}))
    name=label(raw.get("name") or recipe.get("name"),"library recipe name")
    if recipe.get("status") not in ("draft_for_experiment","draft"):
        raise ValueError("Save a generated recipe draft; validation status cannot be asserted by this action")
    rows=recipe.get("ingredients",[])
    if not rows:raise ValueError("Recipe ingredients are required")
    total=sum(number(i.get("fraction"),"ingredient fraction",0,1) for i in rows)
    if abs(total-1)>1e-8:raise ValueError("A saved recipe must sum to 100%")
    # Revalidate purity, targets and current component bounds rather than trusting client totals.
    brief=default_brief()
    brief.update(name=name,format=recipe.get("format"),active_pct=recipe.get("active_fraction",0)*100,
        batch_g=recipe.get("batch_g"),ingredients=[dict(i,min_pct=i["fraction"]*100,max_pct=i["fraction"]*100,
            target_active_pct=next((c["active_fraction"]*100 for c in recipe.get("active_components",[]) if c["name"]==i["name"]),None))
            for i in rows],process=recipe.get("process",[]),count=1)
    validated=suggest(brief)["recipes"][0]
    for key in ("design_query","design_assumptions","design_sources","design_model","agent_rationale"):
        if key in recipe:validated[key]=deepcopy(recipe[key])
    agent=author=="agent"
    entry={"library_id":("agent-" if agent else "saved-")+digest(validated),"name":name,"format":validated["format"],
        "active":", ".join(c["name"] for c in validated["active_components"]),
        "origin":"agent" if agent else "saved","validation_status":"agent-generated draft; unvalidated" if agent else "user-saved draft","composition_status":"complete declared recipe",
        "source":{"kind":"agent_generated" if agent else "user_saved","model":"gpt-6.1-sol" if agent else None,
            "sources":sources or [],"locator":"Saved from constraint-checked workbench candidate","parent_recipe_id":recipe.get("recipe_id"),"parent_library_reference":recipe.get("library_reference")},
        "notes":str(raw.get("notes",""))[:4000],"recipe":validated,"ingredients":validated["ingredients"],"can_generate":True}
    workspace.library_save(entry)
    return entry
