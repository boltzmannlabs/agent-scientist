"""Preview CSV/Excel measurements without losing units, exclusions or provenance."""
import base64
import csv
import hashlib
import io
import numpy as np
import pandas as pd
from .common import label, number
from . import data_provenance, import_units

def read_file(raw):
    name=label(raw.get("filename"),"filename",200)
    try:
        content=base64.b64decode(raw.get("content_base64",""),validate=True)
    except Exception as exc:
        raise ValueError("Invalid base64 file content") from exc
    if not content or len(content)>4_000_000:
        raise ValueError("Upload a nonempty file up to 4 MB")
    lower=name.lower()
    try:
        if lower.endswith(".csv"):
            frame=pd.read_csv(io.BytesIO(content))
        elif lower.endswith(".xlsx"):
            frame=pd.read_excel(io.BytesIO(content),sheet_name=raw.get("sheet",0))
        else:
            raise ValueError("Use CSV or XLSX files")
    except Exception as exc:
        raise ValueError(f"Could not read measurement file: {exc}") from exc
    if not 1<=len(frame)<=20000 or len(frame.columns)>100:
        raise ValueError("File must have 1 to 20000 rows and at most 100 columns")
    frame=frame.replace([np.inf,-np.inf],np.nan)
    return frame,{"filename":name,"sha256":hashlib.sha256(content).hexdigest(),
                  "content_base64":raw["content_base64"],"n_rows":len(frame)}

def preview(raw):
    frame,source=read_file(raw)
    return {"columns":[str(c) for c in frame.columns],"preview":frame.head(12).where(pd.notna(frame),None).to_dict(orient="records"),
            "source":{k:v for k,v in source.items() if k!="content_base64"},
            "time_conversion":import_units.describe(frame,raw)}

def ingest(raw):
    if raw.get("kind","release") not in ("release","stability","dose_response"):
        from .data_tools import ingest as ingest_property
        return ingest_property(raw)
    frame,source=read_file(raw)
    origin=data_provenance.source_kind(raw)
    source["source_kind"]=origin
    conversion=import_units.conversion(frame,raw)
    mapping=raw.get("mapping",{})
    kind=raw.get("kind","release")
    requirements={"release":["time","value"],"stability":["time","value","temperature"],"dose_response":["dose","value"]}
    if kind not in requirements:
        raise ValueError("Unknown measurement kind")
    for key in requirements[kind]:
        if mapping.get(key) not in frame.columns:
            raise ValueError(f"Map a column for {key}")
    for key,col in mapping.items():
        if col and col not in frame.columns:
            raise ValueError(f"Mapped column does not exist: {col}")
    unit=raw.get("value_unit","percent")
    if kind=="release" and unit not in ("percent","fraction"):
        raise ValueError("Release must be fraction or percent; mg/g needs independently measured initial loading")
    if kind in ("stability","dose_response") and unit!="percent":
        raise ValueError("Chemical assay and response use percent units")
    time_factor=(conversion or {}).get("factor_to_days",1)
    if time_factor is None:
        raise ValueError("Unknown time unit")
    recipe_id=label(raw.get("recipe_id"),"recipe_id")
    included=[]; excluded=[]
    recipe_column=mapping.get("recipe")
    recipe_value=raw.get("recipe_value") or recipe_id
    condition_column=mapping.get("condition")
    condition_value=raw.get("condition_value")
    if condition_column and frame[condition_column].dropna().astype(str).nunique()>1 and not condition_value:
        raise ValueError("Choose one assay condition before importing a multi-condition file")

    for index,row in frame.iterrows():
        if recipe_column and str(row[recipe_column]) != str(recipe_value):
            excluded.append({"row":int(index)+2,"reason":"different recipe"}); continue
        if condition_column and condition_value and str(row[condition_column]) != str(condition_value):
            excluded.append({"row":int(index)+2,"reason":"different assay condition"}); continue

        qc=str(row.get(mapping.get("qc",""),"accepted")).strip().lower()
        if qc in ("exclude","excluded","fail","rejected","false","0"):
            excluded.append({"row":int(index)+2,"reason":"explicit QC exclusion"}); continue
        try:
            value=number(row[mapping["value"]],"value",0,200 if kind=="stability" else (1 if unit=="fraction" else 100))
            batch=str(row.get(mapping.get("batch",""),"unspecified"))
            record={"batch_id":batch,"replicate_id":str(row.get(mapping.get("replicate",""),"unspecified")),
                    "source_row":int(index)+2,"recipe_id":recipe_id,
                    "condition_id":str(row[condition_column]) if condition_column else "single_assay"}
            if kind=="release":
                record.update(time_days=number(row[mapping["time"]],"time",0,1e7)*time_factor,
                              fraction=value/(100 if unit=="percent" else 1))
            elif kind=="stability":
                record.update(time_days=number(row[mapping["time"]],"time",0,1e7)*time_factor,
                    assay_pct=value,temperature_c=number(row[mapping["temperature"]],"temperature",-50,100))
            else:
                record.update(dose=number(row[mapping["dose"]],"dose",0,1e9),response_pct=value)
            included.append(record)
        except (ValueError,TypeError):
            excluded.append({"row":int(index)+2,"reason":"missing, nonfinite or out-of-range measurement"})
    if not included:
        raise ValueError("No valid observations remain after mapping")
    return {"kind":kind,"recipe_id":recipe_id,"active_name":raw.get("active_name"),"observations":included,"excluded":excluded,"source":source,
        "mapping":mapping,"time_unit":"days","original_time_unit":conversion["source_unit"] if conversion else raw.get("time_unit","days"),
        "original_value_unit":unit,"dose_unit":raw.get("dose_unit"),
        "context":raw.get("context",{}),"instrument":label(raw.get("instrument"),"instrument / method"),
        "source_kind":origin,"evidence":data_provenance.evidence(raw),"time_conversion":conversion,
        "warnings":["Independent batch IDs were not supplied; replication is unknown"] if not mapping.get("batch") else []}
