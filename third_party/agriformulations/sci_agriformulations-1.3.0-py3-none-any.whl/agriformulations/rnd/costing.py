"""Transparent recipe costing; price estimates are not supplier quotations."""
from copy import deepcopy
import json
import math
import re


ASSUMPTION_FIELDS = (
    "yield_pct", "processing_per_input_kg", "packaging_per_saleable_kg",
    "fixed_batch_cost", "overhead_pct", "freight_per_batch", "tax_pct",
)
LEVELS = ("low", "base", "high")


def _number(value, name, positive=False):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite nonnegative number")
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite nonnegative number") from exc
    if not math.isfinite(value) or value < 0 or (positive and value == 0):
        raise ValueError(f"{name} must be finite and {'positive' if positive else 'nonnegative'}")
    return value


def _currency(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Z]{3}", value):
        raise ValueError("currency must be an explicit three-letter uppercase currency code, such as INR")
    return value


def _missing(value):
    return value is None or value == ""


def estimate(recipe, assumptions=None):
    """Cost supplied ingredient masses, with explicit yield and production costs.

    Low/high totals propagate the declared price bounds together, not a statistical
    confidence interval. There is no purity correction: recipe masses already
    describe the technical grades being purchased. Missing assumptions or positive
    ingredient prices prevent a final total, while known material subtotals remain.
    """
    if assumptions is not None and (not isinstance(assumptions, dict) or set(assumptions)-set(ASSUMPTION_FIELDS)-{"currency", "pack_size_kg"}):
        raise ValueError("Unsupported cost assumptions; use the declared production cost fields")
    supplied = deepcopy(assumptions or {})
    currency = _currency(supplied.get("currency", recipe.get("currency", "INR")))
    if recipe.get("currency") is not None and _currency(recipe["currency"]) != currency:
        raise ValueError("Recipe and costing currencies differ; currency conversion is not supported")
    cleaned = {"currency": currency}
    for key in ASSUMPTION_FIELDS + ("pack_size_kg",):
        value = supplied.get(key)
        cleaned[key] = None if _missing(value) else _number(value, key, key in {"yield_pct", "pack_size_kg"})
    if cleaned["yield_pct"] is not None and cleaned["yield_pct"] > 100:
        raise ValueError("yield_pct must be greater than zero and no more than 100")
    batch_kg = _number(recipe.get("batch_g"), "batch_g", True) / 1000
    if batch_kg == 0:
        raise ValueError("batch_g is too small to represent its input mass in kg")
    ingredients = recipe.get("ingredients")
    if not isinstance(ingredients, list) or not ingredients:
        raise ValueError("A recipe needs ingredient masses or fractions")
    details, missing_prices = [], []
    subtotal = dict.fromkeys(LEVELS, 0.0)
    coverage, mass_fraction = 0.0, 0.0
    for index, row in enumerate(ingredients):
        name = str(row.get("name") or f"Ingredient {index + 1}")
        if not _missing(row.get("fraction")):
            fraction = _number(row["fraction"], f"{name} fraction")
        elif not _missing(row.get("grams")):
            fraction = _number(row["grams"], f"{name} grams") / (batch_kg * 1000)
        else:
            raise ValueError(f"{name} needs a mass fraction or grams")
        if fraction > 1:
            raise ValueError(f"{name} fraction cannot exceed one")
        if not _missing(row.get("grams")):
            grams = _number(row["grams"], f"{name} grams")
            if not math.isclose(grams, fraction * batch_kg * 1000, rel_tol=1e-8, abs_tol=1e-8):
                raise ValueError(f"{name} grams disagree with its fraction and batch size")
        mass_fraction += fraction
        price, origin, provenance = None, "missing", None
        if not _missing(row.get("cost_per_kg")):
            value = _number(row["cost_per_kg"], f"{name} cost_per_kg")
            if row.get("currency") is not None and _currency(row["currency"]) != currency:
                raise ValueError(f"{name} price currency differs; currency conversion is not supported")
            price = dict.fromkeys(LEVELS, value)
            origin = "user supplied unit price"
        elif row.get("price_estimate") is not None:
            quote = row["price_estimate"]
            if not isinstance(quote, dict):
                raise ValueError(f"{name} price_estimate must be an object")
            if _currency(quote.get("currency")) != currency:
                raise ValueError(f"{name} estimate currency differs; currency conversion is not supported")
            base = _number(quote.get("base"), f"{name} base price")
            price = {level: _number(quote.get(level, base), f"{name} {level} price") for level in LEVELS}
            if not price["low"] <= price["base"] <= price["high"]:
                raise ValueError(f"{name} price range must satisfy low <= base <= high")
            provenance = deepcopy(quote)
            origin = "approximate price estimate"
        # A stale estimate must not override an explicitly supplied unit price.
        mass = fraction * batch_kg
        contribution = (dict.fromkeys(LEVELS, 0.0) if fraction == 0 else None) if price is None else {k: price[k] * mass for k in LEVELS}
        if price is None and fraction > 0:
            missing_prices.append(name)
        elif price is not None:
            coverage += fraction
            for level in LEVELS:
                subtotal[level] += fraction * price[level]
        details.append({"name": name, "fraction": fraction, "input_mass_kg": mass,
                        "price_per_kg": price, "material_cost_batch": contribution,
                        "price_origin": origin, "price_estimate": provenance})
    if not math.isclose(mass_fraction, 1, rel_tol=0, abs_tol=1e-8):
        raise ValueError("Ingredient mass fractions must sum to one")
    missing_assumptions = [key for key in ASSUMPTION_FIELDS if cleaned[key] is None]
    saleable = None if cleaned["yield_pct"] is None else batch_kg * (cleaned["yield_pct"] / 100)
    if saleable == 0:
        raise ValueError("yield_pct and batch_g imply a saleable mass too small to represent")
    ranges = {"known_material_subtotal_per_input_kg": subtotal,
              "known_material_subtotal_batch": {k: subtotal[k] * batch_kg for k in LEVELS},
              "material_cost_per_input_kg": None, "material_cost_batch": None,
              "pre_tax_cost_per_saleable_kg": None, "final_cost_per_saleable_kg": None,
              "final_batch_cost": None, "cost_per_pack": None}
    if not missing_prices:
        ranges["material_cost_per_input_kg"] = dict(subtotal)
        ranges["material_cost_batch"] = {k: subtotal[k] * batch_kg for k in LEVELS}
    if not missing_prices and not missing_assumptions:
        for key in ("pre_tax_cost_per_saleable_kg", "final_cost_per_saleable_kg", "final_batch_cost"):
            ranges[key] = {}
        if cleaned["pack_size_kg"] is not None:
            ranges["cost_per_pack"] = {}
        for level in LEVELS:
            manufacturing = (ranges["material_cost_batch"][level]
                             + cleaned["processing_per_input_kg"] * batch_kg
                             + cleaned["fixed_batch_cost"])
            pre_tax = (manufacturing * (1 + cleaned["overhead_pct"] / 100)
                       + cleaned["freight_per_batch"]
                       + cleaned["packaging_per_saleable_kg"] * saleable)
            final = pre_tax * (1 + cleaned["tax_pct"] / 100)
            ranges["pre_tax_cost_per_saleable_kg"][level] = pre_tax / saleable
            ranges["final_cost_per_saleable_kg"][level] = final / saleable
            ranges["final_batch_cost"][level] = final
            if ranges["cost_per_pack"] is not None:
                ranges["cost_per_pack"][level] = final / saleable * cleaned["pack_size_kg"]
    result = {"currency": currency, "assumptions": cleaned, "input_batch_kg": batch_kg,
              "saleable_batch_kg": saleable, "ingredients": details,
              "coverage_mass_fraction": min(1.0, coverage), "missing_ingredients": missing_prices,
              "missing_assumptions": missing_assumptions, "ranges": ranges,
              **{key: None if value is None else value["base"] for key, value in ranges.items()},
              "basis": "Supplied technical ingredient masses; no additional purity correction. Costs per kg, not per litre.",
              "evidence": "Cost model using declared prices or approximate estimates; not a supplier quote or selling price.",
              "range_basis": "Declared unit-price bounds propagated together; not a confidence interval. Production assumptions are fixed.",
              "exclusions": ["Profit margin, financing, distributor and retailer margins are not included.",
                             "Only explicitly declared processing, packaging, freight, overhead and tax costs are included."]}
    try:
        json.dumps(result, allow_nan=False)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError("Cost inputs or calculated totals are not finite JSON-safe values") from exc
    return result
