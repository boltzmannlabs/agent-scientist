"""Report saved deliverables, including bounded-run shortfalls, without prose claims."""
import re
from .common import digest

def requested_recipe_count(question):
    words={"one":1,"two":2,"three":3,"four":4,"five":5,"six":6}
    # Only explicit recipe/candidate counts; active counts are not recipe counts.
    pattern=r"\b(one|two|three|four|five|six|[1-9][0-9]?)\s+(?:(?:distinct|concrete|new|candidate|excipient-family|solvent/emulsifier|recipe|family|research|draft|editable)\s+){0,5}(?:recipes?|candidates?|hypotheses|families)\b"
    matches=re.findall(pattern,question,re.I)
    if not matches:return None
    value=matches[0].lower()
    return words[value] if value in words else int(value)

def audit(question,initial,state,trace):
    requested=requested_recipe_count(question)
    workflow=next((w for w in reversed(state.get("formulation_workflows",[])) if w.get("task")==question),None)
    if requested is None and workflow:requested=len(workflow.get("recipes",[]))
    before={r["recipe_id"] for r in initial.get("recipes",[])}
    saved=len({r["recipe_id"] for r in state.get("recipes",[])}-before)
    if workflow:saved=len(workflow.get("recipes",[]))
    result={"requested_recipes":requested,"saved_recipes":saved,"requested_cases":None,"saved_cases":0,"unmet":[]}
    if requested is not None and saved<requested:result["unmet"].append(f"{requested-saved} requested recipe(s) were not saved")
    explicit=re.search(r"\b(one|two|three|four|five|six|[1-9][0-9]?)\s*(?:physical\s+)?cases\b",question,re.I)
    explicit_cases=None
    if explicit:
        token=explicit[1].lower();explicit_cases={"one":1,"two":2,"three":3,"four":4,"five":5,"six":6}.get(token)
        if explicit_cases is None:explicit_cases=int(token)
    if workflow:
        result.update(requested_cases=explicit_cases or workflow["summary"]["requested_scenarios"],saved_cases=workflow["summary"]["evaluated"])
        if result["saved_cases"]<result["requested_cases"]:result["unmet"].append("Some declared physical cases were rejected; see domain reasons")
    else:
        old={e.get("scenario_id") or digest(e) for e in initial.get("analysis_runs",[])}
        result["saved_cases"]=len({e.get("scenario_id") or digest(e) for e in state.get("analysis_runs",[])}-old)
        if explicit_cases:
            result["requested_cases"]=explicit_cases
            if result["saved_cases"]<explicit_cases:result["unmet"].append("Explicit requested case count has not been saved")
        if requested is not None and re.search(r"workflow|physical scenarios|physical calculations|simulations",question,re.I) and not result["saved_cases"]:
            result["unmet"].append("Requested physical workflow has no saved numerical cases")
    result["status"]="partial" if result["unmet"] else "recorded"
    return result

def render(result):
    if result["requested_recipes"] is None:return ""
    cases=str(result["requested_cases"]) if result["requested_cases"] is not None else "not fully declared"
    text=f"Requested / saved outputs: {result['requested_recipes']} / {result['saved_recipes']} recipes; {cases} / {result['saved_cases']} physical cases."
    if result["unmet"]:text+=" Unmet: "+"; ".join(result["unmet"])+". This request is incomplete."
    return text
