"""Validated manual/CSV recipe entry shared by studio actions and agents."""
from copy import deepcopy
from . import recipes,importing
from .common import number,integer,label,digest
def preview(raw):
    frame,source=importing.read_file(raw)
    mapping=raw.get("mapping",{})
    aliases={"name":["name","ingredient","ingredient_name"],"role":["role"],"pct":["pct","percentage","percent","wt_pct"],
        "purity_pct":["purity_pct","purity"],"min_pct":["min_pct"],"max_pct":["max_pct"],
        "cost_per_kg":["cost_per_kg","cost"],"supplier":["supplier"],"lot":["lot"]}
    columns={str(c).lower().strip():c for c in frame.columns}
    chosen={key:mapping.get(key) or next((columns[a] for a in names if a in columns),None) for key,names in aliases.items()}
    if chosen["name"] is None or chosen["pct"] is None:
        raise ValueError("Recipe files need name and pct columns, or an explicit column mapping")
    output=[]
    for index,row in frame.iterrows():
        if len(output)>=20:raise ValueError("Recipes support at most 20 ingredients")
        item={}
        for key,col in chosen.items():
            if col is not None and not __import__("pandas").isna(row[col]):
                item[key]=row[col].item() if hasattr(row[col],"item") else row[col]
        item.setdefault("role","other");item.setdefault("purity_pct",100)
        output.append(item)
    return {"ingredients":output,"source":{k:v for k,v in source.items() if k!="content_base64"},"columns":list(map(str,frame.columns))}
def create(raw):
    if not isinstance(raw,dict):raise ValueError("Recipe input must be an object")
    name=label(raw.get("name"),"Recipe name",200)
    mode=raw.get("mode","fixed")
    if mode not in ("fixed","ranges"):raise ValueError("Choose fixed composition or bounded candidates")
    ingredients=raw.get("ingredients")
    if not isinstance(ingredients,list) or not 2<=len(ingredients)<=20:
        raise ValueError("Enter 2 to 20 ingredients")
    rows=[];total=0;active=0
    for ingredient in ingredients:
        if not isinstance(ingredient,dict):raise ValueError("Each ingredient must be an object")
        supplied=ingredient.get("pct")
        if mode=="ranges" and supplied in (None,"") and ingredient.get("role")!="active":
            pct=None
        else:
            pct=number(supplied,"technical active target percentage" if mode=="ranges" and ingredient.get("role")=="active" else "ingredient percentage",0,100)
        purity=number(ingredient.get("purity_pct",100),"purity",.001,100)
        row={"name":label(ingredient.get("name"),"ingredient name",200),"role":ingredient.get("role","other"),
            "purity_pct":purity,"min_pct":pct,"max_pct":pct}
        if mode=="ranges":
            row.update(min_pct=number(ingredient["min_pct"] if ingredient.get("min_pct") is not None else pct,"minimum percentage",0,100),
                max_pct=number(ingredient["max_pct"] if ingredient.get("max_pct") is not None else pct,"maximum percentage",0,100))
            if pct is not None and not row["min_pct"]-1e-8<=pct<=row["max_pct"]+1e-8:
                if row["min_pct"]>row["max_pct"]:raise ValueError("Ingredient minimum exceeds maximum")
                raise ValueError("Reference amount must lie within the ingredient bounds; omit non-active reference amounts when unnecessary")
        if row["role"]=="active":
            row["target_active_pct"]=pct*purity/100
            active+=row["target_active_pct"]
        for key in ("supplier","lot"):
            value=ingredient.get(key,"")
            if not isinstance(value,str) or len(value)>200:raise ValueError(key+" must be text up to 200 characters")
            row[key]=value.strip()
        cost=ingredient.get("cost_per_kg")
        row["cost_per_kg"]=None if cost in (None,"") else number(cost,"price per kg",0,1e9)
        if ingredient.get("price_estimate") is not None:
            row["price_estimate"]=deepcopy(ingredient["price_estimate"])
        source=ingredient.get("grade_source","")
        if not isinstance(source,str) or len(source)>2000:raise ValueError("Grade source must be text up to 2000 characters")
        row.update(grade_source=source.strip(),grade_status="source declared; availability unverified" if source.strip() else "hypothetical or unverified grade")
        rows.append(row);total+=pct or 0
    if mode=="fixed" and abs(total-100)>1e-7:
        raise ValueError("Ingredient percentages must sum to 100%; current total is "+str(round(total,6))+"%")
    process=deepcopy(raw.get("process",[]))
    if isinstance(process,str):
        process=[{"step":i+1,"instruction":label(line,"process step",2000)} for i,line in enumerate(process.splitlines()) if line.strip()]
    if not isinstance(process,list) or len(process)>50:raise ValueError("Enter up to 50 preparation steps")
    for i,step in enumerate(process):
        if not isinstance(step,dict):raise ValueError("Preparation steps must be objects")
        step["instruction"]=label(step.get("instruction"),"preparation instruction",2000)
        step["step"]=i+1
    brief={"name":name,"format":raw.get("format","SC"),"active_name":" + ".join(r["name"] for r in rows if r["role"]=="active"),
        "active_pct":active,"batch_g":number(raw.get("batch_g"),"batch size",.001,1e9),
        "count":1 if mode=="fixed" else integer(raw.get("count",3),"candidate count",1,12),
        "seed":integer(raw.get("seed",2026),"seed",0,2**32-1),"ingredients":rows,"process":process,
        "bounds_source":"User-entered "+("fixed composition" if mode=="fixed" else "design bounds")+"; performance unmeasured",
        "crop":str(raw.get("crop",""))[:200],"target":str(raw.get("target",""))[:200],
        "objective":str(raw.get("objective",""))[:2000],"currency":str(raw.get("currency","INR"))[:100],
        "cost_assumptions":deepcopy(raw.get("cost_assumptions",{})),
        "cost_limit":raw.get("cost_limit")}
    checked=recipes.suggest(brief)
    for recipe in checked["recipes"]:
        recipe["evidence"]="user-entered, mass-balanced research draft" if mode=="fixed" else "user-bounded, constraint-generated research draft"
        recipe["input_origin"]="user"
        recipe["recipe_id"]="R-"+digest({"composition_version":recipe["recipe_id"],"name":name})
        if raw.get("source"):
            _,source=importing.read_file(raw["source"])
            recipe["import_source"]=source
    return checked
def apply(state,raw):
    created=create(raw)
    known={r["recipe_id"] for r in state.get("recipes",[])}
    state.setdefault("recipes",[]).extend(r for r in created["recipes"] if r["recipe_id"] not in known)
    selected=created["recipes"][0]
    state.update(selected_recipe_id=selected["recipe_id"],selected_active_name=selected["active_components"][0]["name"])
    if not state.get("brief",{}).get("active_name"):
        state["brief"]=deepcopy(created["brief"])
    state["recipe_result"]=created
    return created
