"""Shared project actions used identically by form submissions and agent tools."""
from copy import deepcopy
import json
from . import control,simulation_catalog,simulation_models,data_tools
from . import data_provenance
from .common import digest,label,clean
from .workspace import RevisionConflict
from .outcomes import build_outcome

def recipe(state,recipe_id=None,active_name=None):
    rid=recipe_id or state.get("selected_recipe_id")
    value=next((r for r in state.get("recipes",[]) if r["recipe_id"]==rid),None)
    if value is None:raise ValueError("Choose a recipe belonging to this project")
    name=active_name or state.get("selected_active_name")
    components=value["active_components"]
    if not name and len(components)==1:name=components[0]["name"]
    active=next((a for a in components if a["name"]==name),None)
    if active is None:raise ValueError("Choose an individual active in the selected recipe")
    return value,active
def dataset(state,dataset_id):
    for item in state.get("imports",[]):
        data_tools.identify(item)
        if item["dataset_id"]==dataset_id:return item
    raise ValueError("Dataset does not belong to this project")
def record_fit(state,dataset_id,options=None):
    item=dataset(state,dataset_id)
    fingerprint=digest({"dataset":item,"options":options or {},"engine":control.engine_version()})
    fit_id="f-"+fingerprint
    existing=next((f for f in state.get("fit_runs",[]) if f["fit_id"]==fit_id),None)
    if existing:return existing
    fitted=control.compute("dataset_fit",{"dataset":item,"options":options or {}},
        lambda _:data_tools.fit(item,options))
    fitted.update(fit_id=fit_id,engine_version=control.engine_version(),engine_manifest=control.engine_manifest())
    state.setdefault("fit_runs",[]).append(fitted)
    control.checkpoint(state,"Saved "+data_provenance.source_kind(item)+"-data fit for "+item["source"]["filename"])
    return fitted
def prepare(state,request):
    if not isinstance(request,dict) or set(request)-{"model","inputs","recipe_id","active_name","active_b_name","fit_id","comparison_dataset_id","allow_extrapolation","assumptions","name"}:
        raise ValueError("Unsupported simulation request fields")
    if "allow_extrapolation" in request and not isinstance(request["allow_extrapolation"],bool):
        raise ValueError("allow_extrapolation must be true or false")
    if "assumptions" in request:
        notes=request["assumptions"]
        if not isinstance(notes,list) or len(notes)>30:
            raise ValueError("Supply up to 30 assumption notes")
        for note in notes:label(note,"assumption note",2000)
    for name in ("recipe_id","active_name","active_b_name","fit_id","comparison_dataset_id"):
        if name in request and request[name] is not None:
            label(request[name],name,200)
    if request.get("name") is not None:label(request["name"],"scenario name",200)
    key=request.get("model")
    simulation_catalog.spec(key)
    selected,component=recipe(state,request.get("recipe_id"),request.get("active_name"))
    supplied=deepcopy(request.get("inputs",{}))
    if not isinstance(supplied,dict):raise ValueError("Simulation inputs must be an object")
    user_input_names=set(supplied)
    fit=None
    if request.get("fit_id"):
        fit=next((f for f in state.get("fit_runs",[]) if f["fit_id"]==request["fit_id"]),None)
        if not fit or fit.get("simulation_key")!=key or fit["recipe_id"]!=selected["recipe_id"] or fit["active_name"]!=component["name"]:
            raise ValueError("Choose a matching model fit for this exact recipe and active")
        if fit.get("engine_version")!=control.engine_version():
            raise ValueError("The fit was produced by an earlier engine version. Refit the source dataset before reuse.")
        current=dataset(state,fit["dataset_id"])
        if digest(current)!=fit["dataset_digest"]:raise ValueError("Dataset or QC review changed. Refit before applying these parameters.")
        supplied={**fit["parameters"],**supplied}
    values=simulation_catalog.validate(key,supplied)
    # Parameter-level provenance: fitted values, explicit overrides, or model defaults.
    provenance={}
    fitted_names=set((fit or {}).get("parameters",{}))
    for name in values:
        if name in user_input_names: source="user-supplied scenario"
        elif fit and name in fitted_names: source="fitted from "+data_provenance.source_kind(fit)+" dataset"
        else: source="catalogue default"
        provenance[name]={"source":source,"value":deepcopy(values[name])}
        if fit and name in fitted_names:
            provenance[name].update(source_kind=data_provenance.source_kind(fit),dataset_id=fit["dataset_id"],fit_id=fit["fit_id"])
    if key=="mixture_response":
        b=request.get("active_b_name") or (fit or {}).get("active_b_name")
        if fit and fit.get("active_b_name")!=b:
            raise ValueError("Measured fit belongs to a different second active")
        if b==component["name"] or b not in {a["name"] for a in selected["active_components"]}:
            raise ValueError("Choose a different second active present in this recipe")
    if fit:
        if key=="rheology":
            queried=simulation_models.rheology_query_shear_rates(values)
            domain=fit.get("calibration_domain",{})
            lo,hi=domain.get("x_min"),domain.get("x_max")
            outside=lo is not None and hi is not None and (min(queried)<lo-1e-10 or max(queried)>hi+1e-10)
            fit=dict(fit,scenario_domain={"requested_shear_range_s":[min(queried),max(queried)],
                "calibrated_shear_range_s":[lo,hi],"outside_calibration":bool(outside),
                "queries":"Flow-curve grid, viscosity at 100 s⁻¹ and nominal pipe-pressure shear",
                "extrapolation_enabled":request.get("allow_extrapolation") is True})
        changes=[k for k,v in fit["parameters"].items() if values.get(k)!=v]
        if changes:
            fit=dict(fit,parameters_edited=changes)
        elif not request.get("allow_extrapolation"):
            domain=fit.get("calibration_domain",{})
            lo,hi=domain.get("x_min"),domain.get("x_max")
            target=None
            if key=="kinetics":target=[values["horizon_days"]]
            elif key=="rheology":target=simulation_models.rheology_query_shear_rates(values)
            elif key=="solubility":target=values["temperatures_c"]
            elif key=="rainfastness":target=[values["rainfall_mm_hour"]*values["horizon_hours"]]
            elif key=="manufacturing":target=[values["power_w"]/1000*values["horizon_minutes"]/60/values["batch_kg"]]
            if target and lo is not None and hi is not None and (min(target)<lo-1e-10 or max(target)>hi+1e-10):
                details=(" Derived shear queries span "+str(min(target))+" to "+str(max(target))+" s⁻¹; calibration spans "+str(lo)+" to "+str(hi)+" s⁻¹.") if key=="rheology" else ""
                raise ValueError("Simulation extends beyond the fitted measurement range."+details+" Adjust inputs or explicitly enable extrapolation.")
            if key=="mixture_response":
                for axis in ("a","b"):
                    limits=[domain.get("dose_"+axis+"_min"),domain.get("dose_"+axis+"_max")]
                    values_axis=values["doses_"+axis]
                    if None not in limits and (min(values_axis)<limits[0] or max(values_axis)>limits[1]):
                        raise ValueError("Combination doses exceed the measured reference range")
            if key=="stability":
                limits=fit.get("native",{}).get("calibrated_temperature_range_c")
                if limits and any(t<limits[0] or t>limits[1] for t in [*values["temperatures_c"],*[s.get("temperature_c",25) for s in values["temperature_profile"]]]):
                    raise ValueError("Storage temperatures exceed the fitted range; enable explicit extrapolation to proceed")
    if request.get("comparison_dataset_id"):
        measured=dataset(state,request["comparison_dataset_id"])
        if measured["recipe_id"]!=selected["recipe_id"] or measured["active_name"]!=component["name"]:
            raise ValueError("Comparison measurements must match the selected recipe and active")
        if key=="mixture_response" and measured.get("active_b_name")!=b:
            raise ValueError("Comparison dataset has a different second active")
    return selected,component,values,fit,provenance
def record(state,request):
    selected,component,values,fit,provenance=prepare(state,request)
    key=request["model"]
    version=control.engine_version()
    identity={"model":key,"inputs":values,"recipe":selected["recipe_id"],"active":component["name"],
        "active_b_name":request.get("active_b_name"),"fit":request.get("fit_id"),
        "comparison":request.get("comparison_dataset_id"),"allow_extrapolation":request.get("allow_extrapolation") is True,
        "assumptions":request.get("assumptions",[]),"name":request.get("name"),"engine":version}
    scenario_id="s-"+digest(identity)
    prior=control.current().resume_state if control.current() else {}
    existing=next((e for e in [*state.get("analysis_runs",[]),*prior.get("analysis_runs",[])] if e.get("scenario_id")==scenario_id),None)
    if existing:
        if not any(e.get("scenario_id")==scenario_id for e in state.get("analysis_runs",[])):
            state.setdefault("analysis_runs",[]).append(deepcopy(existing))
        token=control.current()
        if token and token.on_event:token.on_event({"kind":"step_reused","message":"Reused completed "+simulation_catalog.spec(key)["title"],"tool":key})
        control.checkpoint(state,"Completed result reused")
        return existing
    output=control.compute("catalogue:"+key,{"inputs":values,"active_fraction":component["active_fraction"]},
        lambda _:simulation_models.run(key,values,component["active_fraction"]))
    # Keep legacy canvas charts usable for the original three model families.
    output={**output.get("native",{}),**output}
    model_info=simulation_catalog.spec(key)
    output.update(model_maturity=model_info["maturity"],decision_support=model_info["decision_support"],critical_inputs=model_info["critical_inputs"])
    output["input_provenance"]=deepcopy(provenance)
    composition_coupled=key in {"dosage","dilution","powder_dilution"} or (key in {"robustness","inverse_design","sensitivity"} and values.get("base_model") in {"dosage","dilution","powder_dilution"})
    output["recipe_linkage"]={"recipe_id":selected["recipe_id"],"recipe_name":selected.get("name"),
        "formulation_format":selected.get("format"),
        "active_name":component["name"],"active_fraction":component["active_fraction"],
        "composition_digest":digest(selected.get("ingredients",[])),
        "composition_used_by_model":composition_coupled,
        "note":"This model directly uses the recipe active fraction." if composition_coupled else
            "Recipe is linked for traceability; composition does not parameterize this model. Identical physical inputs cannot rank different excipient systems."}
    if key=="dilution" and selected.get("format") in {"EC","OD","EW"}:
        output["interpretation"]=selected["format"]+" multiphase gate: "+output["interpretation"]
        output["prediction_gate"]={"status":"product prediction unavailable","formulation_format":selected["format"],
            "reason":"Oil/water partitioning and interfacial behavior are not represented. Use this only as a conditional aqueous screen."}
    if fit and not fit.get("parameters_edited"):
        output["source_kind"]=data_provenance.source_kind(fit)
        output["evidence"]=data_provenance.source_kind(fit)+"-fit parameters + scenario; no empirical validation established"
        output["calibration"]={k:deepcopy(fit.get(k)) for k in ("fit_id","dataset_id","source_sha256","calibration_domain","n_independent_batches","source_kind","prediction_gate")}
        output["calibration_prediction_gate"]=data_provenance.gate(fit)
        if fit.get("scenario_domain"):
            output["calibration"]["scenario_domain"]=deepcopy(fit["scenario_domain"])
        output["limitations"].extend(fit.get("warnings",[]))
        if request.get("allow_extrapolation"):
            output["limitations"].append("Explicit scenario extrapolation beyond the calibration domain was enabled.")
    elif fit:
        output["source_kind"]=data_provenance.source_kind(fit)
        output["calibration_prediction_gate"]=data_provenance.gate(fit)
        output["limitations"].append("Fitted parameters were edited: "+", ".join(fit["parameters_edited"])+". This is an assumed scenario.")
    if request.get("comparison_dataset_id"):
        measured=dataset(state,request["comparison_dataset_id"])
        output["comparison_source_kind"]=data_provenance.source_kind(measured)
        output["comparison_prediction_gate"]=data_provenance.gate(measured)
        actual=data_tools.observations(measured)
        if key=="mixture_response":
            # Evaluate the reference at each measured combination without changing units.
            if measured.get("x_unit")!=values["dose_unit"]:
                raise ValueError("Comparison dose units do not match the reference simulation")
            observations=[]
            for row in actual:
                control.check()
                point=simulation_models.run(key,dict(values,doses_a=[row["dose_a"]],doses_b=[row["dose_b"]]),component["active_fraction"])
                expected=point["rows"][0]["reference_response_pct"]
                observations.append({**row,"reference_response_pct":expected,"observed_minus_reference_pct":row["value"]-expected})
            output["comparison_rows"]=observations
            output["limitations"].append("Observed-minus-reference differences are descriptive; no automatic synergy classification or significance test is made.")
        else:
            raise ValueError("Direct observed/reference matrix comparison is available for combined-active response; use fit charts for other measured models")
    entry={"scenario_id":scenario_id,"kind":key,"simulation_key":key,"title":request.get("name") or simulation_catalog.spec(key)["title"],
        "recipe_id":selected["recipe_id"],"active_name":component["name"],"active_b_name":request.get("active_b_name"),
        "inputs":values,"input_provenance":provenance,"request":deepcopy(request),"result":output,"engine_version":version,
        "engine_manifest":control.engine_manifest(),
        "assumptions":request.get("assumptions",["Inputs not supplied by an unchanged measured fit are explicit unvalidated scenario assumptions."])}
    state.setdefault("analysis_runs",[]).append(entry)
    state.update(selected_recipe_id=selected["recipe_id"],selected_active_name=component["name"])
    control.checkpoint(state,"Saved "+entry["title"]+" for "+component["name"])
    return entry

def run_manual(raw,connection,workspace,on_event=None):
    state=deepcopy(raw["state"]);task=raw["_studio_manual"]
    trace=[];operation=task["operation"]
    if operation=="design_study":
        from .design_studies import record as study_record
        study=study_record(state,task["study"])
        trace.append({"tool":"run_design_study","evidence":study["evidence"]})
        summary=study["summary"]
        answer=("Saved design study “"+study["name"]+"”: "+str(summary["complete_candidates"])+"/"+str(summary["candidates"])+
                " candidates fully evaluated; "+(str(summary["meeting_specifications"])+" meet the declared model specifications. " if summary["has_acceptance_limits"] else
                "no acceptance limits were declared. ")+str(summary["pareto_candidates"])+" Pareto candidates. Review tradeoffs, assumptions and next design steps in Design studies.")
    elif operation=="simulation_batch":
        outputs=[]
        for index,request in enumerate(task["requests"],1):
            control.check()
            if on_event:on_event({"kind":"tool_started","tool":"run_simulation","message":"Simulation "+str(index)+"/"+str(len(task["requests"]))+": "+simulation_catalog.spec(request["model"])["title"]})
            entry=record(state,request);outputs.append(entry)
            trace.append({"tool":"run_simulation","evidence":entry["result"]["evidence"],"inputs":{"model":entry["kind"]}})
        answer="Saved "+str(len(outputs))+" simulation result"+("" if len(outputs)==1 else "s")+" with exact inputs, recipe versions and assumptions."
    elif operation=="fit_dataset":
        fitted=record_fit(state,task["dataset_id"],task.get("options"))
        trace.append({"tool":"fit_dataset","evidence":fitted["evidence"],"source_kind":fitted["source_kind"]})
        answer="Saved the "+fitted["source_kind"]+"-data descriptive fit for "+fitted["kind"]+". "+fitted["prediction_gate"]["reason"]+" Review the fitted range and limitations before reuse."
    else:raise ValueError("Unknown scientific workspace action")
    outcome=build_outcome(raw["question"],answer,trace,state)
    state.setdefault("research_reports",[]).append(outcome)
    control.checkpoint(state,"Scientific workspace results saved")
    response={"answer":answer,"question":raw["question"],"trace":trace,"updates":clean(state),"outcome":outcome,
        "warnings":[],"sources":[],"intent":"execute","mode":"Scientific tools","model_calls":[]}
    if operation=="simulation_batch":response["selected_scenario_ids"]=[entry["scenario_id"] for entry in outputs]
    if operation=="design_study":response["selected_study_ids"]=[study["study_id"]]
    try:
        identity=raw["project_identity"]
        response["project_saved"]=workspace.commit_run(state,identity["project_id"],identity["revision"],initial=raw["state"])
    except RevisionConflict as exc:
        response["persistence_error"]=str(exc)
        response["warnings"].append("A newer draft was preserved. Completed outputs remain available in project history.")
    return response
