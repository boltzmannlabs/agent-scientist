"""Merge completed run artifacts without overwriting newer project settings."""
from copy import deepcopy
from .common import digest
from .workspace import RevisionConflict

COLLECTIONS={"recipes":"recipe_id","analysis_runs":"scenario_id","fit_runs":"fit_id","formulation_workflows":"workflow_id",
    "design_studies":"study_id","cost_estimates":"cost_id","cost_comparisons":"comparison_id","research_searches":"search_id",
    "research_sources":"record_id","research_reports":"report_id","imports":"dataset_id",
    "conversation":None}

def merge(latest, initial, proposed):
    merged=deepcopy(latest)
    for key,value in proposed.items():
        if key in COLLECTIONS and isinstance(value,list):
            identity=COLLECTIONS[key]
            def identifier(item):
                return str(item.get(identity)) if identity and isinstance(item,dict) and item.get(identity) else digest(item)
            current=deepcopy(latest.get(key,[]));positions={identifier(item):i for i,item in enumerate(current)}
            base={identifier(item):item for item in initial.get(key,[])}
            for item in value:
                rid=identifier(item)
                if rid not in positions:
                    positions[rid]=len(current);current.append(deepcopy(item));continue
                existing=current[positions[rid]]
                if existing==item or item==base.get(rid):continue
                if existing!=base.get(rid):
                    raise RevisionConflict("Conflicting updates to "+key+" record "+rid+"; both run artifacts are retained for review")
                current[positions[rid]]=deepcopy(item)
            merged[key]=current
        elif key not in latest or latest.get(key)==initial.get(key):
            merged[key]=deepcopy(value)
        # Conflicting settings stay at the latest revision. Artifact snapshots
        # retain the inputs actually used by this completed run.
    return merged
