"""Measured-property import, review and descriptive fitting with source provenance."""
from copy import deepcopy
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit
from .common import number,label,digest,clean
from . import control,kinetics,stability,dosage
from . import data_provenance, import_units

KINDS={
 "release":{"title":"Release kinetics","x_label":"Time","x_unit":"days","value_unit":"fraction"},
 "stability":{"title":"Chemical assay","x_label":"Time","x_unit":"days","value_unit":"percent"},
 "dose_response":{"title":"Dose response","x_label":"Dose","x_unit":"mg_l","value_unit":"percent"},
 "rheology":{"title":"Rheology","x_label":"Shear rate","x_unit":"1/s","value_unit":"Pa"},
 "solubility":{"title":"Solubility","x_label":"Temperature","x_unit":"C","value_unit":"mg/L"},
 "rainfastness":{"title":"Rainfastness","x_label":"Cumulative rain","x_unit":"mm","value_unit":"fraction"},
 "milling":{"title":"Milling energy response","x_label":"Specific milling energy","x_unit":"kWh/kg","value_unit":"um"},
 "suspension":{"title":"Suspension separation","x_label":"Time","x_unit":"days","value_unit":"fraction"},
 "packaging":{"title":"Packaging water content","x_label":"Time","x_unit":"days","value_unit":"g"},
 "mixture_response":{"title":"Combined-active observations","x_label":"Active A dose","x_unit":"mg/L","value_unit":"percent"},
 "property":{"title":"Other measured property","x_label":"Independent variable","x_unit":"","value_unit":""},
}
def ingest(raw):
    from .importing import read_file
    import pandas as pd
    kind=raw.get("kind")
    if kind not in KINDS:raise ValueError("Unknown measurement type")
    frame,source=read_file(raw)
    origin=data_provenance.source_kind(raw);source["source_kind"]=origin
    conversion=import_units.conversion(frame,raw)
    mapping=raw.get("mapping",{})
    required=["dose_a","dose_b","value"] if kind=="mixture_response" else ["x","value"]
    for key in required:
        if mapping.get(key) not in frame.columns:raise ValueError("Map a column for "+key)
    for col in mapping.values():
        if col and col not in frame.columns:raise ValueError("Mapped column does not exist: "+str(col))
    unit=label(raw.get("value_unit"),"measured value unit",80)
    xunit=label(raw.get("x_unit"),"independent-variable unit",80)
    original_xunit=xunit
    if conversion:xunit="days"
    fixed=KINDS[kind]
    if kind!="property" and (unit!=fixed["value_unit"] or xunit!=fixed["x_unit"]):
        raise ValueError("Use "+fixed["x_unit"]+" for x and "+fixed["value_unit"]+" for values; convert explicitly before import")
    recipe=label(raw.get("recipe_id"),"recipe_id",100)
    condition=mapping.get("condition")
    if condition and frame[condition].dropna().astype(str).nunique()>1 and not raw.get("condition_value"):
        raise ValueError("Choose one assay condition before importing a multi-condition file")
    included=[];excluded=[]
    for idx,row in frame.iterrows():
        reason=None
        if mapping.get("recipe") and str(row[mapping["recipe"]])!=str(raw.get("recipe_value") or recipe):
            reason="different recipe"
        if condition and raw.get("condition_value") and str(row[condition])!=str(raw["condition_value"]):
            reason="different assay condition"
        qc=str(row.get(mapping.get("qc",""),"accepted")).lower().strip()
        if qc in ("exclude","excluded","fail","rejected","false","0"):reason="explicit QC exclusion"
        if reason:
            excluded.append({"row":int(idx)+2,"reason":reason});continue
        try:
            value=number(row[mapping["value"]],"measured value",-1e12,1e12)
            if kind in ("rainfastness","suspension") and not 0<=value<=1:raise ValueError("fraction outside 0 to 1")
            if kind in ("solubility","rheology","milling","packaging") and value<0:raise ValueError("negative physical measurement")
            if kind=="mixture_response" and not 0<=value<=100:raise ValueError("response outside 0 to 100")
            item={"value":value,"source_row":int(idx)+2,"recipe_id":recipe,
                "batch_id":str(row.get(mapping.get("batch",""),"unspecified")),
                "replicate_id":str(row.get(mapping.get("replicate",""),"unspecified")),
                "condition_id":str(row[condition]) if condition else "single_assay"}
            if kind=="mixture_response":
                item.update(dose_a=number(row[mapping["dose_a"]],"dose A",0,1e9),dose_b=number(row[mapping["dose_b"]],"dose B",0,1e9))
            else:
                item["x"]=number(row[mapping["x"]],"independent variable",-273.14 if kind=="solubility" else 0,1e12)*(conversion["factor_to_days"] if conversion else 1)
            included.append(item)
        except (ValueError,TypeError):
            excluded.append({"row":int(idx)+2,"reason":"missing, nonfinite or out-of-range measurement"})
    if not included:raise ValueError("No valid observations remain")
    return {"kind":kind,"recipe_id":recipe,"active_name":raw.get("active_name"),"active_b_name":raw.get("active_b_name"),
        "observations":included,"excluded":excluded,"source":source,"mapping":mapping,"x_unit":xunit,"original_value_unit":unit,
        "instrument":label(raw.get("instrument"),"instrument / method",300),"context":raw.get("context",{}),
        "source_kind":origin,"evidence":data_provenance.evidence(raw),"time_conversion":conversion,"original_x_unit":original_xunit,
        "warnings":[] if mapping.get("batch") else ["Independent batch IDs were not supplied; replication is unknown"]}
def identify(item):
    item.setdefault("dataset_id","d-"+digest({k:item.get(k) for k in ("kind","recipe_id","active_name","active_b_name","mapping","context","source_kind","time_conversion","x_unit","original_value_unit","original_time_unit")}|{"sha":item.get("source",{}).get("sha256") or digest(item.get("observations",[]))}))
    item.setdefault("review",{"status":"unreviewed","notes":"","excluded_source_rows":[]})
    return item
def observations(dataset):
    if dataset.get("review",{}).get("status")=="rejected":raise ValueError("Rejected datasets cannot be fitted")
    excluded=set(dataset.get("review",{}).get("excluded_source_rows",[]))
    return [r for r in dataset["observations"] if r["source_row"] not in excluded]
def fit(dataset,options=None):
    control.check()
    options=options or {}
    if not isinstance(options,dict) or set(options)-{"model","reference_temperature_c"}:raise ValueError("Unsupported fit options")
    rows=observations(dataset)
    kind=dataset["kind"]
    if kind=="release":
        fitted=kinetics.fit_curves(rows)
        params=deepcopy(fitted["models"][0]["scenario"])
        model="kinetics"
        native=fitted
        x=[r["time_days"] for r in rows];y=[r["fraction"] for r in rows]
        predicted=kinetics.simulate(dict(params,horizon_days=max(max(x),.001)))
        series=[{"name":"Observed measurements","x":x,"y":y,"x_label":"Time (days)","y_label":"Released fraction","scatter":True},
            {"name":"Fitted release","x":predicted["times_days"],"y":predicted["release_fraction"],"x_label":"Time (days)","y_label":"Released fraction"}]
    elif kind=="stability":
        native=stability.fit_stability(rows)
        params={k:native[k] for k in ("reference_rate_per_day","reference_temperature_c","activation_energy_kj_mol")}
        model="stability"
        series=[]
        for temp in native["temperatures_c"]:
            points=[r for r in native["observations"] if r["temperature_c"]==temp]
            xx=[r["time_days"] for r in points]
            yy=[r["retained_fraction"] for r in points]
            grid=np.linspace(0,max(xx),100)
            rate=stability.rate_at(params["reference_rate_per_day"],params["activation_energy_kj_mol"],params["reference_temperature_c"],temp)
            series.extend([{"name":str(temp)+" C observations","x":xx,"y":yy,"x_label":"Time (days)","y_label":"Retained fraction","scatter":True},
                {"name":str(temp)+" C fitted","x":grid.tolist(),"y":np.exp(-rate*grid).tolist(),"x_label":"Time (days)","y_label":"Retained fraction"}])
    elif kind=="dose_response":
        native=dosage.fit_response({"observations":rows,"dose_unit":dataset.get("dose_unit"),"context":dataset.get("context",{})})
        x=[r["dose"] for r in rows]
        params={"ec50":native["ec50"],"slope":native["slope"],"baseline_pct":native["baseline_pct"]}
        model=None
        series=[{"name":"Measured response","x":[r["dose"] for r in rows],"y":[r["response_pct"] for r in rows],
            "x_label":dataset.get("dose_unit"),"y_label":"Response (%)","scatter":True},
            {"name":"Fitted Hill response","x":native["doses"],"y":native["predicted_response_pct"],"x_label":dataset.get("dose_unit"),"y_label":"Response (%)"}]
    else:
        if kind=="mixture_response":
            return mixture_comparison(dataset,rows,options)
        x=np.array([r["x"] for r in rows]);y=np.array([r["value"] for r in rows])
        if len(rows)<5 or len(set(x))<4:raise ValueError("Provide at least five observations spanning four distinct x values")
        grid=np.linspace(min(x),max(x),120)
        native={}
        if kind=="rheology":
            if np.any(x<=0):raise ValueError("Rheology fits require strictly positive shear rates")
            fitted=least_squares(lambda p:p[0]+p[1]*x**p[2]-y,[max(0,min(y)*.5),max(.001,np.median(y/x)),.7],
                bounds=([0,1e-9,.05],[max(1,max(y)*10),1e6,3]),max_nfev=2000)
            params=dict(zip(("yield_stress_pa","consistency_pa_sn","flow_index"),map(float,fitted.x)))
            predict=lambda xx:fitted.x[0]+fitted.x[1]*xx**fitted.x[2]
            model="rheology"
        elif kind=="solubility":
            if np.any(y<=0) or np.any(x<=-273.15):raise ValueError("Solubility fits require positive concentration and physical temperature")
            ref=number(options.get("reference_temperature_c",25),"reference temperature",-50,100)
            b=1/(ref+273.15)-1/(x+273.15)
            slope,intercept=np.polyfit(b,np.log(y),1)
            params={"intrinsic_solubility_mg_l":float(np.exp(intercept)),"dissolution_enthalpy_kj_mol":float(slope*8.314462618/1000),
                "reference_temperature_c":ref,"ionization":"neutral","cosolvent_fraction":0,"cosolvency_log10":0}
            predict=lambda xx:np.exp(intercept+slope*(1/(ref+273.15)-1/(xx+273.15)))
            model="solubility"
        elif kind=="rainfastness":
            if 0 not in x or np.any(y<=0) or np.any(y>1):raise ValueError("Wash-off fits need a zero-rain observation and positive retained fractions")
            base=float(np.mean(y[x==0]))
            if abs(base-1)>.05:raise ValueError("Normalize retained fraction against the zero-rain observation before fitting")
            rate=float(-np.dot(x,np.log(y))/np.dot(x,x))
            if rate<0:raise ValueError("Data do not identify a nonnegative wash-off rate")
            params={"labile_washoff_per_mm":rate,"maximum_bound_fraction":0}
            predict=lambda xx:np.exp(-rate*xx)
            model="rainfastness"
        elif kind=="milling":
            if 0 not in x:raise ValueError("Milling fits require a zero-energy particle-size observation")
            initial=float(np.mean(y[x==0]))
            if initial<=0 or np.any(y<=0):raise ValueError("Particle sizes must be positive")
            fitted=least_squares(lambda p:p[0]+(initial-p[0])*np.exp(-p[1]*x)-y,
                [max(.001,min(y)*.5),1/max(max(x),.001)],bounds=([0,0],[max(.001,min(y)),1e6]))
            params={"initial_size_um":initial,"limiting_size_um":max(.001,float(fitted.x[0])),"milling_rate_per_kwh_kg":float(fitted.x[1])}
            predict=lambda xx:fitted.x[0]+(initial-fitted.x[0])*np.exp(-fitted.x[1]*xx)
            model="manufacturing"
        else:
            if options.get("model","linear")!="linear":raise ValueError("This property supports a descriptive linear fit")
            slope,intercept=np.polyfit(x,y,1)
            params={"slope":float(slope),"intercept":float(intercept)}
            predict=lambda xx:slope*xx+intercept
            model=None
        residual=y-predict(x)
        native={"rmse":float(np.sqrt(np.mean(residual**2))),"residuals":residual.tolist(),"x_range":[float(min(x)),float(max(x))]}
        series=[{"name":"Observed measurements","x":x.tolist(),"y":y.tolist(),"x_label":KINDS[kind]["x_label"]+" ("+dataset["x_unit"]+")",
            "y_label":dataset["original_value_unit"],"scatter":True},
            {"name":"Fitted relation","x":grid.tolist(),"y":predict(grid).tolist(),"x_label":KINDS[kind]["x_label"]+" ("+dataset["x_unit"]+")","y_label":dataset["original_value_unit"]}]
    batches={r.get("batch_id") for r in rows}-{None,"","unspecified"}
    warnings=["Descriptive fit; independent validation is required. No calibrated confidence interval is claimed."]
    if len(batches)<2:warnings.append("Fewer than two identified independent batches; between-batch uncertainty is unknown.")
    if dataset.get("review",{}).get("status")!="reviewed":warnings.append("Dataset review is incomplete.")
    control.check()
    origin=data_provenance.source_kind(dataset)
    for item in series:
        if item.get("scatter"):item["name"]=origin.capitalize()+" observations"
    native.update(source_kind=origin,evidence=data_provenance.evidence(dataset,fitted=True),prediction_gate=data_provenance.gate(dataset))
    return clean({"dataset_id":dataset["dataset_id"],"dataset_digest":digest(dataset),"source_sha256":dataset["source"]["sha256"],
        "recipe_id":dataset["recipe_id"],"active_name":dataset["active_name"],"kind":kind,"simulation_key":model,
        "parameters":params,"native":native,"series":series,"n_rows":len(rows),"n_independent_batches":len(batches),
        **data_provenance.fit_metadata(dataset),"warnings":warnings+[data_provenance.gate(dataset)["reason"]],"options":options,
        "calibration_domain":{"x_min":min(x) if kind not in ("stability",) else None,"x_max":max(x) if kind not in ("stability",) else None}})
def mixture_comparison(dataset,rows,options):
    from .simulation_models import run
    a=np.array([r["dose_a"] for r in rows]);b=np.array([r["dose_b"] for r in rows]);y=np.array([r["value"]/100 for r in rows])
    zero=(a==0)&(b==0)
    if not zero.any() or float(y[zero].mean())>.02:
        raise ValueError("Include a near-zero untreated control; normalize baseline response before this zero-baseline reference analysis")
    parameters={}
    for suffix,dose,mask in (("a",a,b==0),("b",b,a==0)):
        x=dose[mask];v=y[mask]
        positive=x>0
        if len(set(x[positive]))<4:
            raise ValueError("Include at least four positive single-active dose levels for each active plus untreated controls")
        fit=least_squares(lambda p:expit(p[1]*(np.log(np.maximum(x,1e-300))-p[0]))-v,
            [float(np.median(np.log(x[positive]))),1],bounds=([float(np.log(x[positive]).min()-10),.05],[float(np.log(x[positive]).max()+10),10]))
        parameters["ec50_"+suffix]=float(np.exp(fit.x[0]));parameters["hill_"+suffix]=float(fit.x[1])
    parameters.update(reference_model="bliss",dose_unit=dataset["x_unit"],doses_a=sorted(set(a.tolist())),doses_b=sorted(set(b.tolist())))
    predicted=run("mixture_response",parameters)
    expected={(r["dose_a"],r["dose_b"]):r["reference_response_pct"] for r in predicted["rows"]}
    comparisons=[{**r,"reference_response_pct":expected[(r["dose_a"],r["dose_b"])],
        "observed_minus_reference_pct":r["value"]-expected[(r["dose_a"],r["dose_b"])]} for r in rows]
    batches={r.get("batch_id") for r in rows}-{None,"","unspecified"}
    return clean({"dataset_id":dataset["dataset_id"],"dataset_digest":digest(dataset),"source_sha256":dataset["source"]["sha256"],
        "recipe_id":dataset["recipe_id"],"active_name":dataset["active_name"],"active_b_name":dataset.get("active_b_name"),
        "kind":"mixture_response","simulation_key":"mixture_response","parameters":parameters,"series":predicted["series"],
        "native":{"comparison_rows":comparisons},"n_rows":len(rows),"n_independent_batches":len(batches),
        **data_provenance.fit_metadata(dataset),
        "warnings":["Observed-minus-reference differences do not establish significant synergy or antagonism.",
            "Independent validation and replication are required."],"options":options,
        "calibration_domain":{"dose_a_min":float(a.min()),"dose_a_max":float(a.max()),"dose_b_min":float(b.min()),"dose_b_max":float(b.max())}})

