"""Append-only project revisions in a local SQLite database."""
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .common import label, integer

class RevisionConflict(ValueError):
    pass

class Workspace:
    def __init__(self, path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS recipe_library (library_id TEXT PRIMARY KEY, created TEXT, document TEXT)")
            db.execute("CREATE TABLE IF NOT EXISTS revisions (project_id TEXT, revision INTEGER, name TEXT, created TEXT, document TEXT, PRIMARY KEY(project_id, revision))")
    def connect(self):
        return sqlite3.connect(self.path, timeout=10)
    def list(self):
        with self.connect() as db:
            rows=db.execute("SELECT r.project_id,r.revision,r.name,r.created FROM revisions r JOIN (SELECT project_id, MAX(revision) v FROM revisions GROUP BY project_id) x ON r.project_id=x.project_id AND r.revision=x.v ORDER BY r.created DESC").fetchall()
        return [dict(zip(("project_id","revision","name","updated"),r)) for r in rows]
    def load(self, project_id, revision=None):
        label(project_id,"project_id",80)
        with self.connect() as db:
            if revision is None:
                row=db.execute("SELECT revision,document,created FROM revisions WHERE project_id=? ORDER BY revision DESC LIMIT 1",(project_id,)).fetchone()
            else:
                revision=integer(revision,"revision",1,1000000)
                row=db.execute("SELECT revision,document,created FROM revisions WHERE project_id=? AND revision=?",(project_id,revision)).fetchone()
        if row is None:
            raise ValueError("Project revision not found")
        return {"project_id":project_id,"revision":row[0],"document":json.loads(row[1]),"updated":row[2]}
    def save(self,document,project_id=None,expected_revision=0):
        from contextlib import nullcontext
        from . import control
        token=control.current()
        with (token._lock if token else nullcontext()):
            control.check()
            return self._save(document,project_id,expected_revision)

    def _save(self, document, project_id=None, expected_revision=0):
        if not isinstance(document,dict):
            raise ValueError("Project document must be an object")
        name=label(document.get("brief",{}).get("name"),"project name")
        body=json.dumps(document,sort_keys=True,allow_nan=False)
        if len(body.encode())>7_500_000:
            raise ValueError("Project exceeds 7.5 MB; export raw data separately")
        project_id=str(uuid.uuid4()) if not project_id else label(project_id,"project_id",80)
        expected_revision=integer(expected_revision,"expected_revision",0,1000000)
        created=datetime.now(timezone.utc).isoformat()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            previous=db.execute("SELECT MAX(revision) FROM revisions WHERE project_id=?",(project_id,)).fetchone()[0] or 0
            if previous != expected_revision:
                raise RevisionConflict("Project changed since loading; reload before saving")
            revision=previous+1
            db.execute("INSERT INTO revisions VALUES(?,?,?,?,?)",(project_id,revision,name,created,body))
        return {"project_id":project_id,"revision":revision,"updated":created}

    def library_list(self):
        with self.connect() as db:
            rows=db.execute("SELECT document FROM recipe_library ORDER BY created DESC").fetchall()
        return [json.loads(row[0]) for row in rows]

    def commit_run(self,document,project_id,expected_revision,initial=None):
        """Rebase run outputs only; ordinary user saves keep strict revision checks."""
        if not project_id:
            return self.save(document,project_id,expected_revision)
        try:
            return self.save(document,project_id,expected_revision)
        except RevisionConflict:
            pass
        from .run_persistence import merge
        base=initial if initial is not None else self.load(project_id,expected_revision)["document"]
        for _ in range(4):
            latest=self.load(project_id)
            combined=merge(latest["document"],base,document)
            try:
                saved=self.save(combined,project_id,latest["revision"])
                return {**saved,"merged_concurrent_outputs":True}
            except RevisionConflict:
                continue
        raise RevisionConflict("Project kept changing while saving; completed outputs remain in run history")
    def library_save(self, entry):
        body=json.dumps(entry,sort_keys=True,allow_nan=False)
        if len(body)>500000:raise ValueError("Library entry exceeds 500 KB")
        with self.connect() as db:
            db.execute("INSERT OR IGNORE INTO recipe_library VALUES(?,?,?)",
                (entry["library_id"],datetime.now(timezone.utc).isoformat(),body))
        return entry
