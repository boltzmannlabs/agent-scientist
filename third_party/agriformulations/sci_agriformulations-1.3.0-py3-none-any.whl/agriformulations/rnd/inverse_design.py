"""Seeded, constrained Bayesian search over declared physical model parameters.

The GP learns a numerical simulator, never unmeasured chemistry. Shortlists
contain only directly evaluated feasible points. No surrogate output is treated
as a measured material property or a verified physical result.
"""
from copy import deepcopy

import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.stats import qmc

from . import control, simulation_catalog
from .common import integer, number


def _objects(value, name, maximum, minimum=1):
    if not isinstance(value, list) or not minimum <= len(value) <= maximum or any(not isinstance(v, dict) for v in value):
        raise ValueError(f"{name} requires {minimum} to {maximum} objects")
    return value


def design_space(p):
    """Validate bounded scalar variables and forbid nested searches."""
    key = p["base_model"]
    if key in {"inverse_design", "robustness", "sensitivity", "mixture_response"}:
        raise ValueError("Choose a single-active physical base model; nested searches are unsupported")
    model = simulation_catalog.spec(key)
    template = simulation_catalog.validate(key, p["base_inputs"])
    fields = {f["key"]: f for f in model["fields"] if f["type"] == "number"}
    variables = []
    for raw in _objects(p["variables"], "variables", 6):
        if set(raw) - {"parameter", "low", "high", "scale"}:
            raise ValueError("Unsupported variable fields")
        name = raw.get("parameter")
        if not isinstance(name, str) or name not in fields:
            raise ValueError("Search variables must be numeric base-model inputs")
        f = fields[name]
        lo = number(raw.get("low"), name + " lower bound", f["min"], f["max"])
        hi = number(raw.get("high"), name + " upper bound", f["min"], f["max"])
        scale = raw.get("scale", "linear")
        if hi <= lo or not isinstance(scale, str) or scale not in {"linear", "log"} or (scale == "log" and lo <= 0):
            raise ValueError("Variable bounds must increase; log bounds must be positive")
        variables.append(dict(parameter=name, low=lo, high=hi, scale=scale, unit=f.get("unit", "")))
    names = [v["parameter"] for v in variables]
    if len(set(names)) != len(names):
        raise ValueError("Search variables must be distinct")
    if key in {"geometry_release", "finite_bath", "swelling_release"} and {"diffusivity_m2_s", "length_um"} <= set(names):
        raise ValueError("D and length are confounded through D/L². Fix independently measured diffusivity or particle size before searching the other")
    return key, model, template, variables


def _kernel(a, b):
    # Fixed kernel, dimensionless coordinates: reproducible and dependency-light.
    distance = ((a[:, None, :] - b[None, :, :]) / .3) ** 2
    return np.exp(-.5 * distance.sum(axis=2))


def posterior(x, y, pool):
    """Return mean and GP interpolation SD in the original response units."""
    y = np.asarray(y, float)
    center = y.mean(axis=0)
    scale = np.maximum(y.std(axis=0), 1e-9)
    factor = cho_factor(_kernel(x, x) + np.eye(len(x)) * 1e-8, lower=True)
    cross = _kernel(x, pool)
    mean = center + cross.T @ cho_solve(factor, (y - center) / scale) * scale
    variance = np.maximum(1e-12, 1 - np.sum(cross * cho_solve(factor, cross), axis=0))
    sd = np.sqrt(variance)[:, None] * scale
    return mean, sd


def optimize(p, active_fraction=.1):
    from .simulation_models import run

    key, model, template, variables = design_space(p)
    budget = integer(p["evaluations"], "evaluations", 12, 96)
    seed = integer(p["seed"], "seed", 0, 2**32 - 1)
    objectives = deepcopy(_objects(p["objectives"], "objectives", 3))
    constraints = deepcopy(_objects(p["constraints"], "constraints", 8, 0))
    for objective in objectives:
        if set(objective) - {"metric", "goal", "target", "scale", "weight"}:
            raise ValueError("Unsupported objective fields")
        if not isinstance(objective.get("goal"), str) or objective["goal"] not in {"minimize", "maximize", "target"}:
            raise ValueError("Objective goal must be minimize, maximize or target")
        objective["scale"] = number(objective.get("scale", 1), "objective scale", 1e-20, 1e20)
        objective["weight"] = number(objective.get("weight", 1), "objective weight", 1e-6, 1e6)
        if objective["goal"] == "target":
            objective["target"] = number(objective.get("target"), "objective target", -1e20, 1e20)
    for constraint in constraints:
        if set(constraint) - {"metric", "minimum", "maximum"} or not ({"minimum", "maximum"} & set(constraint)):
            raise ValueError("Constraints need a metric and minimum and/or maximum")
        for bound in ("minimum", "maximum"):
            if bound in constraint:
                constraint[bound] = number(constraint[bound], "constraint " + bound, -1e20, 1e20)
        if constraint.get("minimum", -1e20) > constraint.get("maximum", 1e20):
            raise ValueError("Constraint minimum exceeds maximum")
    requested = list(dict.fromkeys(o.get("metric") for o in [*objectives, *constraints] if isinstance(o.get("metric"), str)))
    if any(not isinstance(o.get("metric"), str) or not o["metric"] for o in [*objectives, *constraints]):
        raise ValueError("Each objective and constraint requires a metric name")
    rng = np.random.default_rng(seed)
    dimension = len(variables)
    pool = qmc.LatinHypercube(dimension, seed=seed).random(512)
    initial_count = min(budget, max(8, 2 * dimension + 3))
    initial = np.vstack([np.full(dimension, .5), np.zeros(dimension), np.ones(dimension),
                         qmc.LatinHypercube(dimension, seed=(seed + 1) % 2**32).random(initial_count - 3)])
    tried, x, responses, scores, feasible, records = [], [], [], [], [], []
    valid_metrics = None
    best_history = []

    def inputs_at(point):
        values = deepcopy(template)
        for coordinate, variable in zip(point, variables):
            lo, hi = variable["low"], variable["high"]
            value = np.exp(np.log(lo) + coordinate * (np.log(hi) - np.log(lo))) if variable["scale"] == "log" else lo + coordinate * (hi - lo)
            values[variable["parameter"]] = float(np.clip(value, lo, hi))
        return values

    def objective_values(metrics):
        values = []
        for o in objectives:
            value = metrics[o["metric"]]
            if o["goal"] == "maximize": value = -value
            elif o["goal"] == "target": value = abs(value - o["target"])
            values.append(value / o["scale"])
        return values

    def passing(metrics):
        return all(c.get("minimum", -np.inf) <= metrics[c["metric"]] <= c.get("maximum", np.inf) for c in constraints)

    def surrogate_samples(means, sds):
        # Fit smooth physical responses, then transform their posterior draws.
        # Regressing absolute target error directly creates a cusp the smooth
        # kernel cannot interpolate reliably near the desired target.
        draws = means[:, None, :] + sds[:, None, :] * rng.normal(size=(1, 96, len(requested)))
        score = np.zeros(draws.shape[:2])
        total_weight = sum(o["weight"] for o in objectives)
        for o in objectives:
            values = draws[:, :, requested.index(o["metric"])]
            if o["goal"] == "maximize": values = -values
            elif o["goal"] == "target": values = np.abs(values - o["target"])
            score += values * o["weight"] / o["scale"] / total_weight
        ok = np.ones(draws.shape[:2], dtype=bool)
        for c in constraints:
            values = draws[:, :, requested.index(c["metric"])]
            ok &= (values >= c.get("minimum", -np.inf)) & (values <= c.get("maximum", np.inf))
        return score, ok

    for step in range(budget):
        control.check()
        if step < initial_count:
            point, phase = initial[step], "space filling"
        else:
            distance = np.min(np.linalg.norm(pool[:, None, :] - np.array(tried)[None, :, :], axis=2), axis=1)
            eligible = distance > 1e-6
            if len(x) >= 3:
                means, sds = posterior(np.array(x), np.array(responses), pool)
                sampled_scores, sampled_pass = surrogate_samples(means, sds)
                sigma = sampled_scores.std(axis=1)
                if any(feasible):
                    improvement = min(s for s, f in zip(scores, feasible) if f) - sampled_scores
                    acquisition = np.mean(np.maximum(improvement, 0) * sampled_pass, axis=1)
                else:
                    acquisition = sampled_pass.mean(axis=1) + .05 * sigma / max(float(sigma.max()), 1e-12)
                # Occasional max-distance exploration avoids collapse near a flat response.
                if step % 5 == 0 or np.max(acquisition[eligible]) < 1e-14:
                    acquisition = distance
                index = int(np.argmax(np.where(eligible, acquisition, -np.inf)))
                phase = "GP acquisition"
            else:
                index = int(np.argmax(np.where(eligible, distance, -np.inf)))
                phase = "domain exploration"
            point = pool[index]
        tried.append(point)
        inputs = inputs_at(point)
        record = dict(evaluation=step+1, phase=phase, inputs=inputs,
                      parameters={v["parameter"]: inputs[v["parameter"]] for v in variables})
        try:
            output = run(key, inputs, active_fraction)
        except ValueError as exc:
            record.update(status="model domain rejected", reason=str(exc), feasible=False)
        else:
            metrics = dict(output["metrics"])
            metrics.update({"input:" + v["parameter"]: inputs[v["parameter"]] for v in variables})
            if valid_metrics is None:
                valid_metrics = sorted(k for k, v in metrics.items() if v is None or (isinstance(v, (int, float)) and not isinstance(v, bool)))
                if set(requested) - set(valid_metrics):
                    raise ValueError("Choose finite scalar metrics from: " + ", ".join(valid_metrics))
            unavailable = [k for k in requested if isinstance(metrics.get(k), bool) or not isinstance(metrics.get(k), (float, int)) or not np.isfinite(metrics[k])]
            if unavailable:
                record.update(status="metric unavailable", reason="No finite output for: " + ", ".join(unavailable), metrics=metrics, feasible=False)
            else:
                objectives_at_point = objective_values(metrics)
                with np.errstate(over="ignore", invalid="ignore"):
                    weights=np.array([o["weight"] for o in objectives]);weights/=weights.sum()
                    score = float(np.dot(objectives_at_point,weights))
                if not np.isfinite(score) or not np.isfinite(objectives_at_point).all():
                    record.update(status="metric unavailable", reason="Scaled objectives exceed the finite numerical range; adjust their scales", metrics=metrics, feasible=False)
                else:
                    ok = passing(metrics)
                    record.update(status="directly evaluated", metrics=metrics, objective_values=objectives_at_point, score=score, feasible=ok)
                    x.append(point); responses.append([metrics[k] for k in requested]); scores.append(score); feasible.append(ok)
        records.append(record)
        best_history.append(min((r["score"] for r in records if r["feasible"]), default=None))
        token = control.current()
        if token and token.on_event:
            token.on_event({"kind":"tool_progress", "tool":"inverse_design",
                            "message":f"Physics design {step+1}/{budget}: {sum(feasible)} feasible candidates"})

    eligible_records = [r for r in records if r["feasible"]]
    for record in eligible_records:
        value = np.array(record["objective_values"])
        record["pareto"] = not any(np.all(np.array(other["objective_values"]) <= value) and np.any(np.array(other["objective_values"]) < value) for other in eligible_records)
    pareto = sorted([r for r in eligible_records if r["pareto"]], key=lambda r:r["score"])
    shortlist = deepcopy(pareto[:8])
    # Replay the numerical solver, not the GP, before publishing a candidate.
    for record in shortlist:
        control.check()
        verified = run(key, record["inputs"], active_fraction)["metrics"]
        if any(not np.isclose(verified[k], record["metrics"][k], rtol=1e-10, atol=1e-12) for k in verified if isinstance(verified[k], (int, float))):
            raise ValueError("Direct solver verification did not reproduce candidate metrics")
        record["verification"] = "direct base-model replay passed"

    next_experiments = []
    if shortlist:
        next_experiments.append(dict(purpose="Test the leading feasible physics hypothesis", inputs=shortlist[0]["inputs"],
                                     simulated_metrics=shortlist[0]["metrics"], evidence="unmeasured experimental target"))
    if len(x) >= 3:
        means, sds = posterior(np.array(x), np.array(responses), pool)
        sampled_scores, _ = surrogate_samples(means, sds)
        score_sd = sampled_scores.std(axis=1)
        distance = np.min(np.linalg.norm(pool[:, None, :] - np.array(tried)[None, :, :], axis=2), axis=1)
        i = int(np.argmax(np.where(distance > 1e-6, score_sd, -np.inf)))
        next_experiments.append(dict(purpose="Explore simulator interpolation uncertainty; not yet physics checked", inputs=inputs_at(pool[i]),
                                     surrogate_score_mean=float(sampled_scores[i].mean()), surrogate_score_sd=float(score_sd[i]),
                                     evidence="surrogate-only exploration point"))
    rows = [{"evaluation":r["evaluation"], "phase":r["phase"], "status":r["status"], "feasible":r["feasible"],
             "pareto":r.get("pareto", False), "score":r.get("score"), **r["parameters"],
             **{k:r.get("metrics", {}).get(k) for k in requested}, "reason":r.get("reason", "")} for r in records]
    history = [(i+1, value) for i, value in enumerate(best_history) if value is not None]
    series = [{"name":"Best feasible objective", "x":[v[0] for v in history], "y":[v[1] for v in history],
               "x_label":"Physics evaluations", "y_label":"Weighted scaled objective (lower is better)"}]
    if len(objectives) > 1 and eligible_records:
        series.append({"name":"Feasible tradeoffs", "x":[r["metrics"][objectives[0]["metric"]] for r in eligible_records],
                       "y":[r["metrics"][objectives[1]["metric"]] for r in eligible_records], "scatter":True,
                       "x_label":objectives[0]["metric"], "y_label":objectives[1]["metric"]})
        series.append({"name":"Pareto front", "x":[r["metrics"][objectives[0]["metric"]] for r in pareto],
                       "y":[r["metrics"][objectives[1]["metric"]] for r in pareto], "scatter":True,
                       "x_label":objectives[0]["metric"], "y_label":objectives[1]["metric"]})
    return dict(metrics={"feasible_candidates":len(eligible_records), "pareto_candidates":len(pareto),
                         "physics_evaluations":budget, "verification_evaluations":len(shortlist),
                         "rejected_candidates":sum(r["status"] != "directly evaluated" for r in records),
                         "unavailable_metric_candidates":sum(r["status"] == "metric unavailable" for r in records)},
                series=series, rows=rows, shortlist=shortlist, pareto_front=pareto, next_experiments=next_experiments,
                base_model=key, base_equation=model["equation"], base_limitations=deepcopy(model["limits"]),
                objectives=objectives, constraints=constraints, variables=variables,
                search_status="feasible candidates found" if shortlist else "no feasible candidate found within evaluation budget",
                method="Fixed-kernel Gaussian processes on simulator responses; 96-draw constrained Monte Carlo expected improvement; seeded Latin hypercube exploration",
                uncertainty_basis="GP interpolation uncertainty over simulator evaluations; not experimental confidence",
                best_inputs=shortlist[0]["inputs"] if shortlist else None,
                best_metrics=shortlist[0]["metrics"] if shortlist else None)
