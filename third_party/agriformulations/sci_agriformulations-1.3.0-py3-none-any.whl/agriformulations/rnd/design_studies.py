"""Specification-driven, reproducible comparisons of explicit physical scenarios."""
from copy import deepcopy
import math
import re

from . import control, simulation_catalog, simulation_service
from .common import digest, label, number
from .workspace import RevisionConflict


def objects(value, name, maximum):
    if not isinstance(value, list) or not 1 <= len(value) <= maximum or any(not isinstance(v, dict) for v in value):
        raise ValueError(f"{name} requires 1 to {maximum} objects")
    return value


def prepare(state, raw):
    if not isinstance(raw, dict) or set(raw) - {"name", "goal", "candidates", "scenarios", "criteria", "assumptions", "parent_study_id"}:
        raise ValueError("Unsupported design study fields")
    config = deepcopy(raw)
    config["name"] = label(raw.get("name"), "study name", 200)
    config["goal"] = label(raw.get("goal"), "design goal", 3000)
    notes = raw.get("assumptions", [])
    if not isinstance(notes, list) or len(notes) > 30:
        raise ValueError("Supply up to 30 study assumptions")
    config["assumptions"] = [label(v, "study assumption", 2000) for v in notes]
    if raw.get("parent_study_id"):
        if not any(s["study_id"] == raw["parent_study_id"] for s in state.get("design_studies", [])):
            raise ValueError("Parent study does not belong to this project")
    scenarios = deepcopy(objects(raw.get("scenarios"), "scenarios", 4))
    config["scenarios"] = scenarios
    by_id = {}
    for scenario in scenarios:
        if set(scenario) - {"id", "model", "inputs", "candidate_parameters"}:
            raise ValueError("Unsupported study scenario fields")
        scenario.setdefault("inputs", {})
        scenario.setdefault("candidate_parameters", [])
        sid = scenario.get("id")
        if not isinstance(sid, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,39}", sid) or sid in by_id:
            raise ValueError("Scenario IDs must be distinct short letters/numbers/underscore identifiers")
        if not isinstance(scenario.get("model"), str):
            raise ValueError("Choose a declared physical model")
        model = simulation_catalog.spec(scenario["model"])
        if model["key"] in {"inverse_design", "robustness", "sensitivity", "mixture_response"}:
            raise ValueError("Study scenarios require single-active physical models, not nested analyses")
        simulation_catalog.validate(model["key"], scenario.get("inputs", {}))
        varying = scenario.get("candidate_parameters", [])
        if not isinstance(varying, list) or any(not isinstance(v, str) for v in varying) or len(set(varying)) != len(varying):
            raise ValueError("candidate_parameters must be distinct field names")
        if set(varying) - set(model.get("candidate_parameters", [])):
            raise ValueError("Only declared material/property parameters may vary; keep test conditions shared")
        by_id[sid] = scenario
    candidates = objects(raw.get("candidates"), "candidates", 8)
    planned, identities, active_names = [], set(), set()
    for candidate in candidates:
        if set(candidate) - {"recipe_id", "active_name", "inputs", "fit_ids"}:
            raise ValueError("Unsupported study candidate fields")
        rid = label(candidate.get("recipe_id"), "candidate recipe ID", 200)
        active_name = label(candidate.get("active_name"), "candidate individual active", 200)
        recipe, active = simulation_service.recipe(state, rid, active_name)
        if recipe["recipe_id"] in identities:
            raise ValueError("Choose distinct recipe versions")
        identities.add(recipe["recipe_id"])
        active_names.add(active["name"])
        overrides, fits = candidate.get("inputs", {}), candidate.get("fit_ids", {})
        if not isinstance(overrides, dict) or not isinstance(fits, dict) or (set(overrides) | set(fits)) - set(by_id):
            raise ValueError("Candidate inputs and fits must reference declared scenario IDs")
        requests = []
        for sid, scenario in by_id.items():
            extra = overrides.get(sid, {})
            if not isinstance(extra, dict) or set(extra) - set(scenario.get("candidate_parameters", [])):
                raise ValueError("Candidate overrides must be explicitly declared candidate_parameters")
            request = {"model":scenario["model"], "recipe_id":recipe["recipe_id"], "active_name":active["name"],
                       "inputs":{**scenario.get("inputs", {}), **extra},
                       "assumptions":[*config["assumptions"], "Candidate property inputs are explicit scenarios unless supplied by an unchanged matching measured fit."]}
            if sid in fits:
                request["fit_id"] = label(fits[sid], "candidate fit ID", 200)
            _, _, values, _, provenance = simulation_service.prepare(state, request)
            requests.append({"id":sid, "request":request, "resolved_inputs":values, "input_provenance":provenance})
        planned.append({"recipe_id":recipe["recipe_id"], "recipe_name":recipe["name"], "active_name":active["name"],
                        "active_fraction":active["active_fraction"], "requests":requests})
    if len(active_names) != 1:
        raise ValueError("Compare the same individual active across candidate recipes")
    # Measured fits must obey the same shared test conditions as manual inputs.
    for index, scenario in enumerate(scenarios):
        baseline = planned[0]["requests"][index]["resolved_inputs"]
        for candidate in planned[1:]:
            changed = {k for k, v in candidate["requests"][index]["resolved_inputs"].items() if v != baseline[k]}
            if changed - set(scenario.get("candidate_parameters", [])):
                raise ValueError("Inputs differ outside declared candidate_parameters; use matching test conditions and fit references")
    criteria = deepcopy(objects(raw.get("criteria"), "criteria", 12))
    seen = set()
    for criterion in criteria:
        if set(criterion) - {"scenario", "metric", "minimum", "maximum", "goal", "target", "scale"}:
            raise ValueError("Unsupported study criterion fields")
        sid, metric = criterion.get("scenario"), criterion.get("metric")
        if not isinstance(sid, str) or sid not in by_id or not isinstance(metric, str):
            raise ValueError("Criteria require a declared scenario and output metric")
        if metric not in simulation_catalog.spec(by_id[sid]["model"])["output_metrics"]:
            raise ValueError("Choose a declared base-model output metric")
        if (sid, metric) in seen:
            raise ValueError("Combine bounds and objective for each distinct scenario/metric in one criterion")
        seen.add((sid, metric))
        for bound in ("minimum", "maximum", "target"):
            if bound in criterion:
                criterion[bound] = number(criterion[bound], bound, -1e20, 1e20)
        if criterion.get("minimum", -math.inf) > criterion.get("maximum", math.inf):
            raise ValueError("Criterion minimum exceeds maximum")
        goal = criterion.get("goal")
        if goal is not None and goal not in ("minimize", "maximize", "target"):
            raise ValueError("Objective goal must be minimize, maximize or target")
        if goal == "target" and "target" not in criterion:
            raise ValueError("A target objective requires a target value")
        if not goal and not ({"minimum", "maximum"} & set(criterion)):
            raise ValueError("Each criterion needs an objective or acceptance bound")
        criterion["scale"] = number(criterion.get("scale", 1), "objective scale", 1e-12, 1e12)
    covered = {c["scenario"] for c in criteria}
    if covered != set(by_id):
        raise ValueError("Every study scenario needs at least one output criterion")
    config["criteria"] = criteria
    return config, planned


def record(state, raw):
    config, planned = prepare(state, raw)
    version = control.engine_version()
    study_id = "study-" + digest({"config":config, "planned":planned, "engine":version})
    existing = next((s for s in state.get("design_studies", []) if s["study_id"] == study_id), None)
    if existing:
        control.checkpoint(state, "Reused completed design study")
        return existing
    has_bounds = any("minimum" in c or "maximum" in c for c in config["criteria"])
    objectives = [c for c in config["criteria"] if c.get("goal")]
    candidates, warnings = [], []
    total = sum(len(c["requests"]) for c in planned)
    completed = 0
    for candidate in planned:
        row = {k:v for k, v in candidate.items() if k != "requests"}
        cases = {}
        for item in candidate["requests"]:
            control.check()
            case = dict(scenario=item["id"], model=item["request"]["model"], inputs=item["resolved_inputs"],
                        input_provenance=item["input_provenance"], fit_id=item["request"].get("fit_id"))
            try:
                entry = simulation_service.record(state, item["request"])
                result = entry["result"]
                case.update(status="evaluated", scenario_id=entry["scenario_id"], metrics=result["metrics"],
                            input_provenance=entry["input_provenance"], evidence=result["evidence"],
                            recipe_linkage=result["recipe_linkage"], calibration=result.get("calibration"),
                            limitations=result["limitations"], equation=result["equation"],
                            metric_labels=result.get("metric_labels",{}),interpretation=result.get("interpretation"),prediction_gate=result.get("prediction_gate"),
                            source_kind=result.get("source_kind","unknown"),calibration_prediction_gate=result.get("calibration_prediction_gate"))
            except RevisionConflict:
                raise
            except (ValueError, ArithmeticError) as exc:
                case.update(status="model domain rejected", reason=str(exc), metrics={}, evidence="no numerical result")
            cases[item["id"]] = case
            completed += 1
            token = control.current()
            if token and token.on_event:
                token.on_event({"kind":"tool_progress", "tool":"run_design_study",
                                "message":f"{completed}/{total} study scenarios completed"})
        checks, losses = [], []
        for criterion in config["criteria"]:
            value = cases[criterion["scenario"]]["metrics"].get(criterion["metric"])
            available = not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)
            bounded = "minimum" in criterion or "maximum" in criterion
            check = {**criterion, "value":value if available else None,
                     "metric_label":cases[criterion["scenario"]].get("metric_labels",{}).get(criterion["metric"],criterion["metric"]),
                     "passed":(criterion.get("minimum", -math.inf) <= value <= criterion.get("maximum", math.inf)) if available and bounded else None,
                     "available":available}
            margins = ([value-criterion["minimum"]] if "minimum" in criterion else []) + ([criterion["maximum"]-value] if "maximum" in criterion else []) if available else []
            check["specification_margin"] = min(margins) if margins else None
            check["specification_violation"] = max(0., -min(margins)) if margins else None
            check["target_distance"] = abs(value-criterion["target"]) if available and criterion.get("goal")=="target" else None
            if not available:
                check["reason"] = cases[criterion["scenario"]].get("reason", "Metric is not a finite available scalar in this scenario")
            if criterion.get("goal") and available:
                loss = (-value if criterion["goal"] == "maximize" else abs(value - criterion["target"]) if criterion["goal"] == "target" else value) / criterion["scale"]
                if math.isfinite(loss):
                    losses.append(loss)
                else:
                    check.update(available=False, reason="Rescale the objective to keep its transformed value finite")
            checks.append(check)
        complete = all(c["status"] == "evaluated" for c in cases.values()) and all(c["available"] for c in checks)
        feasible = all(c["passed"] is not False for c in checks) if complete and has_bounds else None
        row.update(cases=cases, checks=checks, complete=complete, feasible=feasible, objective_values=losses,
                   status="incomplete" if not complete else "outside specifications" if feasible is False else "meets model specifications" if feasible is True else "evaluated without acceptance limits",
                   pareto=False)
        candidates.append(row)
    eligible = [c for c in candidates if c["complete"] and c["feasible"] is not False]
    if objectives:
        for candidate in eligible:
            a = candidate["objective_values"]
            candidate["pareto"] = not any(all(x <= y for x, y in zip(other["objective_values"], a)) and
                                          any(x < y for x, y in zip(other["objective_values"], a)) for other in eligible if other is not candidate)
    for scenario in config["scenarios"]:
        cases = [c["cases"][scenario["id"]] for c in candidates]
        if len(cases) > 1 and all(c["status"] == "evaluated" for c in cases):
            if all(c["metrics"] == cases[0]["metrics"] for c in cases[1:]) and all(not c["recipe_linkage"]["composition_used_by_model"] for c in cases):
                warnings.append(scenario["id"] + ": identical outputs under shared physical inputs; recipe composition does not distinguish these candidates in this model.")
    next_steps = []
    for candidate in candidates:
        for check in candidate["checks"]:
            if not check["available"] or check["passed"] is False:
                next_steps.append({"recipe_id":candidate["recipe_id"], "scenario":check["scenario"], "metric":check["metric"],
                                   "action":"resolve model domain" if not check["available"] else "inspect sensitivity and revise explicit property assumptions",
                                   "value":check["value"], "specification_margin":check["specification_margin"],
                                   "reason":check.get("reason", f"{check['metric']}={check['value']:.6g} is outside the declared bounds by {check['specification_violation']:.6g} in the metric's units." if check["available"] else "Metric unavailable")})
    if not next_steps:
        next_steps.append({"action":"compare Pareto tradeoffs and confirm influential physical inputs",
                           "reason":("Passing model specifications is conditional on the declared assumptions; focused measurements can check the selected hypothesis." if has_bounds else
                                     "No acceptance limits were declared. Pareto membership compares objectives; add limits to assess specification satisfaction.")})
    control.check()
    study = dict(study_id=study_id, name=config["name"], goal=config["goal"], request=config,
                 engine_version=version, engine_manifest=control.engine_manifest(), candidates=candidates, criteria=config["criteria"], warnings=warnings,
                 pareto_recipe_ids=[c["recipe_id"] for c in candidates if c["pareto"]], next_steps=next_steps,
                 summary={"candidates":len(candidates), "scenario_evaluations":completed,
                          "complete_candidates":sum(c["complete"] for c in candidates),
                          "meeting_specifications":sum(c["feasible"] is True for c in candidates),
                          "has_acceptance_limits":has_bounds, "pareto_candidates":sum(c["pareto"] for c in candidates)},
                 evidence="comparison of explicit model scenarios; not measured product performance",
                 limitations=["Material properties are supplied assumptions or matching measured fits; ingredients do not automatically determine model coefficients.",
                              "Models are evaluated independently. Outputs are not silently coupled or converted into a universal formulation score.",
                              "Pareto membership uses declared objectives only among complete candidates satisfying any declared bounds; ties remain visible.",
                              "Different candidate parameters are explicit material/property hypotheses. Test conditions stay shared within each scenario.",
                              "Diffusion sensitivity does not identify D and length separately; release alone identifies D/L²."])
    state.setdefault("design_studies", []).append(study)
    control.checkpoint(state, "Saved design study " + config["name"])
    return study
