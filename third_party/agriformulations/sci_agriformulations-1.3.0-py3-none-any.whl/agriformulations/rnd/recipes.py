"""Constrained recipe proposals; no invented composition-to-performance mapping."""
from copy import deepcopy
import numpy as np
from scipy.optimize import linprog
from .common import number, integer, label, digest

from .formulation_types import FORMATS, canonical

ROLES = {"active", "carrier", "matrix", "solvent", "surfactant", "dispersant", "binder", "filler", "coating", "stabilizer", "other"}

def default_brief():
    return {
        "name": "New formulation project", "format": "CR", "active_name": "Specify active / nutrient",
        "crop": "", "target": "", "application": "", "batch_g": 1000, "active_pct": 20,
        "count": 16, "seed": 2026, "cost_limit": None, "currency": "INR", "cost_assumptions": {},
        "process": [{"step": 1, "instruction": "Define preparation order and equipment before making a batch", "temperature_c": 25, "duration_min": None}],
        "ingredients": [
            {"name": "Technical active (replace with grade)", "role": "active", "min_pct": 20, "max_pct": 25, "purity_pct": 95, "cost_per_kg": None, "supplier": "", "lot": ""},
            {"name": "Matrix / carrier (select material)", "role": "matrix", "min_pct": 5, "max_pct": 20, "purity_pct": 100, "cost_per_kg": None, "supplier": "", "lot": ""},
            {"name": "Dispersant (select grade)", "role": "dispersant", "min_pct": 1, "max_pct": 4, "purity_pct": 100, "cost_per_kg": None, "supplier": "", "lot": ""},
            {"name": "Vehicle / balance (select material)", "role": "solvent", "min_pct": 45, "max_pct": 80, "purity_pct": 100, "cost_per_kg": None, "supplier": "", "lot": ""},
        ],
        "bounds_source": "User design assumptions; example bounds are not validated recipes",
        "specs": [],
    }

def suggest(brief):
    brief = deepcopy(brief)
    name = label(brief.get("name"), "project name")
    fmt = canonical(brief.get("format", "CR"))
    brief["format"] = fmt
    if fmt not in FORMATS:
        raise ValueError("Unknown formulation format")
    batch = number(brief.get("batch_g", 1000), "batch_g", 0.001, 1e9)
    count = integer(brief.get("count", 16), "count", 1, 100)
    seed = integer(brief.get("seed", 2026), "seed", 0, 2**32-1)
    rows = brief.get("ingredients", [])
    if not isinstance(rows, list) or not 2 <= len(rows) <= 20:
        raise ValueError("Provide 2 to 20 ingredients")
    names, lo, hi, purity, costs = [], [], [], [], []
    for row in rows:
        names.append(label(row.get("name"), "ingredient name"))
        if row.get("role") not in ROLES:
            raise ValueError("Unknown ingredient role; use one of: " + ", ".join(sorted(ROLES)))
        a = number(row.get("min_pct"), "min_pct", 0, 100) / 100
        b = number(row.get("max_pct"), "max_pct", 0, 100) / 100
        if a > b:
            raise ValueError("Ingredient minimum exceeds maximum")
        lo.append(a); hi.append(b)
        purity.append(number(row.get("purity_pct", 100), "purity_pct", 0.001, 100)/100)
        price = row.get("cost_per_kg")
        estimate = row.get("price_estimate")
        if price in (None, "") and isinstance(estimate, dict) and estimate.get("currency") == brief.get("currency", "INR"):
            price = estimate.get("base")
        costs.append(None if price in (None, "") else number(price, "cost_per_kg"))
    if len(set(names)) != len(names):
        raise ValueError("Ingredient names must be unique")
    active = [i for i, row in enumerate(rows) if row["role"] == "active"]
    if not active:
        raise ValueError("At least one active or nutrient ingredient is required")
    target = number(brief.get("active_pct"), "active_pct", .001, 100) / 100
    targets = {active[0]: target} if len(active)==1 else {
        i: number(rows[i].get("target_active_pct"), "individual target_active_pct", .001, 100)/100 for i in active}
    if abs(sum(targets.values())-target)>1e-8:
        raise ValueError("Individual active targets must sum to the total pure-active target")
    for ai, delivered in targets.items():
        technical = delivered / purity[ai]
        if not lo[ai]-1e-10 <= technical <= hi[ai]+1e-10:
            raise ValueError(f"Purity-corrected technical active {names[ai]} is {technical*100:.4g}%; adjust its ingredient bounds")
        lo[ai] = hi[ai] = technical
    lo, hi = np.array(lo), np.array(hi)
    if lo.sum() > 1+1e-10 or hi.sum() < 1-1e-10:
        raise ValueError("Ingredient bounds cannot sum to 100%")
    cost_limit = brief.get("cost_limit")
    cost_limit = None if cost_limit in (None, "") else number(cost_limit, "cost_limit")
    if cost_limit is not None and any(c is None for c in costs):
        raise ValueError("A cost ceiling requires prices for every ingredient")
    rng = np.random.default_rng(seed)
    vectors, seen = [], set()

    def retain(x):
        if abs(x.sum()-1) > 1e-8 or np.any(x < lo-1e-8) or np.any(x > hi+1e-8):
            return
        if cost_limit is not None and float(np.dot(costs, x)) > cost_limit+1e-8:
            return
        key = tuple(np.round(x, 8))
        if key not in seen:
            seen.add(key)
            vectors.append(x.copy())

    # Linear programs reach feasible boundary designs, including narrow cost-limited
    # regions that rejection sampling can easily miss. No material substitutions.
    varying = np.flatnonzero(hi-lo > 1e-10)
    objectives = [np.zeros(len(rows))]
    for i in varying:
        direction = np.zeros(len(rows)); direction[i] = 1
        objectives.extend([direction, -direction])
    for objective in objectives:
        solved = linprog(objective, A_eq=np.ones((1, len(rows))), b_eq=[1.],
                         A_ub=None if cost_limit is None else [costs],
                         b_ub=None if cost_limit is None else [cost_limit],
                         bounds=list(zip(lo, hi)), method="highs")
        if solved.success:
            retain(solved.x)
    if not vectors:
        raise ValueError("No candidate meets the bounds and cost ceiling")
    extremes = np.array(vectors)
    # Build a seeded pool first; selecting the first feasible samples clusters
    # proposals and wastes meaningful degrees of freedom.
    for trial in range(0 if len(extremes) == 1 else max(300, count*40)):
        x = lo.copy()
        remaining = 1.0
        order = np.arange(len(rows)) if trial == 0 else rng.permutation(len(rows))
        for position, i in enumerate(order):
            rest = order[position+1:]
            lower = max(lo[i], remaining - hi[rest].sum())
            upper = min(hi[i], remaining - lo[rest].sum())
            x[i] = (lower+upper)/2 if trial == 0 else rng.uniform(lower, max(lower, upper))
            remaining -= x[i]
        retain(x)
        if len(extremes) > 1:
            weights = rng.dirichlet(np.ones(len(extremes)))
            retain(weights @ extremes)
    pool = np.array(vectors)
    center = pool.mean(axis=0)
    first = int(np.argmin(np.abs(pool-center).sum(axis=1)))
    selected = [first]
    distances = np.abs(pool-pool[first]).sum(axis=1)*.5
    while len(selected) < min(count, len(pool)):
        distances[selected] = -1
        next_index = int(np.argmax(distances))
        selected.append(next_index)
        distances = np.minimum(distances, np.abs(pool-pool[next_index]).sum(axis=1)*.5)
    chosen = pool[selected]
    candidates = []
    for index, x in enumerate(chosen):
        cost = None if any(c is None and v > 0 for c,v in zip(costs,x)) else sum((c or 0)*v for c,v in zip(costs,x))
        composition = [dict(row, fraction=float(v), pct=float(v*100), grams=float(v*batch),grade_status="source declared; availability unverified" if row.get("grade_source") else "hypothetical or unverified grade") for row,v in zip(rows,x)]
        recipe_id = "R-"+digest({"ingredients": composition, "format": fmt, "process": brief.get("process", []), "process_parameters": brief.get("process_parameters", [])})
        candidates.append({
            "recipe_id": recipe_id, "name": f"{name} · {len(candidates)+1:02d}", "format": fmt,
            "ingredients": composition, "batch_g": batch, "active_fraction": target,
            "active_components": [{"name":names[i],"active_fraction":targets[i]} for i in active],
            "cost_per_kg": cost, "currency": brief.get("currency", "INR"),
            "process": brief.get("process", []), "process_parameters": brief.get("process_parameters", []), "status": "draft_for_experiment",
            "evidence": "constraint-generated hypothesis", "performance_status": "unmeasured",
            "compatibility": "not established; test selected materials together",
            "required_tests": FORMATS[fmt]["tests"], "bounds_source": brief.get("bounds_source", "user assumptions"),
            "library_reference": brief.get("library_reference"),
            "design_role": "central feasible composition" if index == 0 else "composition diversity candidate",
        })
    if not candidates:
        raise ValueError("No candidate meets the bounds and cost ceiling")
    # Raw-material cost remains the legacy sorting/ceiling basis. Finished costs
    # are separate scenarios and stay unavailable when assumptions are missing.
    if brief.get("currency", "INR") != "cost units":
        from .costing import estimate
        for candidate in candidates:
            candidate["cost_estimate"] = estimate(candidate, brief.get("cost_assumptions", {}))
    candidates.sort(key=lambda r: (r["cost_per_kg"] is None, r["cost_per_kg"] or 0, r["recipe_id"]))
    pairwise = [float(np.abs(a-b).sum()*.5*100) for i,a in enumerate(chosen) for b in chosen[i+1:]]
    actual_varying = [names[i] for i in range(len(rows)) if np.ptp(pool[:,i]) > 1e-8]
    shortfall = None if len(candidates) == count else (
        "The constraints fix a single composition; percentage variation cannot create additional recipes."
        if not actual_varying else "Only this many distinct feasible compositions were found in the bounded candidate pool; this is not proof that no others exist.")
    return {"recipes": candidates, "requested": count, "generated": len(candidates),
            "diversity": {"method": "seeded feasible pool with boundary extremes; greedy maximin total variation distance (half L1 mass fractions)",
                          "min_pairwise_distance_pct": min(pairwise) if pairwise else None,
                          "varying_ingredients": actual_varying, "candidate_pool_size": len(pool),
                          "shortfall_explanation": shortfall},
            "ranking_basis": "known ingredient cost, then stable identifier; performance has not been predicted",
            "warnings": ["Ingredient ranges and identities require experimental confirmation.",
                         "No validated recipe-to-kinetics or physical-stability model is available from the public catalog."],
            "brief": brief}


def scaffold(fmt):
    """Editable component-role scaffolds, never validated material recipes."""
    fmt=canonical(fmt)
    if fmt not in FORMATS:
        raise ValueError("Unknown formulation format")
    brief=default_brief()
    brief["format"]=fmt
    pairs={
        "SC":[("Dispersant / wetting agent","dispersant",1,5),("Rheology modifier","stabilizer",.1,2),("Water / vehicle","solvent",60,80)],
        "EC":[("Emulsifier package","surfactant",3,15),("Solvent blend","solvent",60,80)],
        "WG":[("Dispersant","dispersant",2,8),("Binder","binder",1,5),("Filler / carrier","filler",60,80)],
        "CR":[("Matrix / carrier","matrix",5,20),("Dispersant","dispersant",1,4),("Vehicle / balance","solvent",45,80)],
        "SL":[("Solubilizer / buffer","other",0,5),("Water / soluble vehicle","solvent",65,80)],
        "OD":[("Oil-compatible dispersant","dispersant",1,5),("Emulsifier package","surfactant",3,10),("Oil carrier","carrier",60,80)],
        "WP":[("Dispersant / wetter","dispersant",1,6),("Dry carrier","filler",65,80)],
        "SG":[("Soluble binder","binder",0,4),("Soluble carrier","carrier",65,80)],
        "SP":[("Soluble processing aid","other",0,4),("Soluble carrier","carrier",65,80)],
        "GR":[("Binder / coating","binder",1,5),("Granular carrier","carrier",65,80)],
        "EW":[("Oil phase","solvent",10,25),("Emulsifier package","surfactant",2,8),("Water phase","carrier",45,70)],
        "FERT":[("Carrier / filler","carrier",55,78),("Binder / coating","binder",1,8),("Balance material","other",1,20)],
    }[fmt]
    active=brief["ingredients"][0]
    if fmt=="FERT":
        active["name"]="Nutrient-bearing grade (specify assay basis)"
    brief["ingredients"]=[active]+[{"name":name+" (select grade)","role":role,"min_pct":lo,"max_pct":hi,
        "purity_pct":100,"cost_per_kg":None,"supplier":"","lot":""} for name,role,lo,hi in pairs]
    return brief["ingredients"]
