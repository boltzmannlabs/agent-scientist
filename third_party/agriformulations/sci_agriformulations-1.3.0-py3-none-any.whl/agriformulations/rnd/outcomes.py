"""Run deliverables derived from recorded tool execution, never from model claims."""
from copy import deepcopy
from datetime import datetime, timezone
from .common import digest

OUTPUT_TOOLS = {
    "complete_formulation_request": ("formulation_workflows", "Bounded formulation workflow", "evidence"),
    "run_formulation_workflow": ("formulation_workflows", "Computed formulation workflow", "evidence"),
    "run_design_study": ("design_studies", "Design study comparison", "design"),
    "search_literature": ("research_searches", "Literature search", "research"),
    "search_patent": ("research_searches", "Patent search", "research"),
    "search_patents": ("research_searches", "Patent search", "research"),
    "save_research_source": ("research_sources", "Saved research sources", "research"),
    "create_recipe_candidates": ("recipes", "Recipe candidates", "recipes"),
    "create_recipe_portfolio": ("recipes", "Recipe candidates", "recipes"),
    "calculate_formulation_cost": ("cost_estimates", "Formulation cost estimates", "recipe"),
    "suggest_recipes": ("recipes", "Recipe candidates", "recipes"),
    "simulate_kinetics": ("kinetics_result", "Release / kinetics scenario", "kinetics"),
    "simulate_stability": ("stability_result", "Stability scenario", "stability"),
    "calculate_dosage": ("dosage_result", "Exposure / dosage scenario", "dosage"),
    "plan_experiments": ("experiment_result", "Experiment matrix", "experiments"),
    "fit_measurements": (None, "Descriptive data fit", "results"),
    "fit_dataset": ("fit_runs", "Descriptive data fit", "data"),
    "run_simulation": ("analysis_runs", "Simulation results", "simulation"),
    "run_simulation_batch": ("analysis_runs", "Simulation results", "simulation"),
    "save_manual_recipe": ("recipes", "Recipe candidates", "recipes"),
    "learn_response_model": ("learning_result", "Measured-response model", "results"),
    "save_recipe_to_library": (None, "Recipe library entry", "library"),
}

def build_outcome(question, answer, trace, state, sources=(), warnings=(), web_requested=False):
    """Only successful tools with retained outputs count as generated deliverables."""
    outputs = []
    seen = set()
    expanded_trace=[]
    for item in trace:
        expanded_trace.append(item)
        if item.get("tool")=="develop_product" and not item.get("error") and item.get("evidence")!="tool input rejected":
            expanded_trace.extend(dict(item,tool=name) for name in
                ("create_recipe_candidates","simulate_kinetics","simulate_stability","calculate_dosage"))
    for item in expanded_trace:
        name = item.get("tool")
        if name not in OUTPUT_TOOLS or item.get("error") or item.get("evidence") == "tool input rejected":
            continue
        key, title, page = OUTPUT_TOOLS[name]
        if key and not state.get(key):
            continue
        if title in seen:
            continue
        seen.add(title)
        entry = {"title": title, "page": page, "tool": name}
        if key == "recipes":
            entry["count"] = len(state[key])
        outputs.append(entry)
    searched = any(t.get("tool") in ("OpenAI web_search","search_literature","search_patent","search_patents") for t in trace)
    return {
        "report_id": "report-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f"),
        "created": datetime.now(timezone.utc).isoformat(),
        "task": question, "answer": answer,
        "status": "outputs_created" if outputs else "assessment_only",
        "outputs": outputs, "sources": deepcopy(list(sources)),
        "web_requested": web_requested, "web_searched": searched,
        "warnings": deepcopy(list(warnings)),
        "notice": ("" if outputs else
            "Assessment only: this run produced no recipe candidates, numerical simulations, or experiment matrix. The report below is the outcome."),
    }

def project_reports(document):
    """Expose historical saved answers without modifying existing project revisions."""
    reports = deepcopy(document.get("research_reports", []))
    ids = {r.get("report_id") for r in reports}
    legacy = []
    for turn in document.get("conversation", []):
        if turn.get("intent") == "discussion" or not turn.get("answer"):
            continue
        report = turn.get("outcome")
        if report:
            if report.get("report_id") not in ids:
                legacy.append(deepcopy(report))
                ids.add(report.get("report_id"))
        elif not any(r.get("task") == turn.get("question") and r.get("answer") == turn.get("answer") for r in reports):
            item=build_outcome(turn.get("question", ""), turn["answer"],
                turn.get("trace", []), document, turn.get("sources", []), turn.get("warnings", []))
            item["report_id"]="legacy-"+digest({"task":item["task"],"answer":item["answer"]})
            item["created"]=turn.get("created")
            legacy.append(item)
    return legacy + reports
