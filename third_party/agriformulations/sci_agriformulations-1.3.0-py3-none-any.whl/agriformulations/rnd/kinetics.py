"""Release, reservoir degradation and available-active mass balance in days."""
import numpy as np
from scipy.optimize import least_squares
from ..release import release_fraction, fit_release
from ..design.zero_order import zero_order_fraction
from .common import number, integer

MODELS = ("fickian", "zero_order", "first_order", "weibull")

def parameters(raw):
    model = raw.get("model", "zero_order")
    if model not in MODELS:
        raise ValueError("Unknown kinetic model")
    plateau = number(raw.get("plateau", 1), "plateau", .000001, 1)
    lag = number(raw.get("lag_days", 0), "lag_days", 0, 1e5)
    p = {"plateau": plateau, "lag_days": lag}
    if model == "weibull":
        p["tau_days"] = number(raw.get("tau_days", 20), "tau_days", 1e-8, 1e8)
        p["beta"] = number(raw.get("beta", 1), "beta", .05, 10)
    else:
        p["rate_per_day"] = number(raw.get("rate_per_day", .03), "rate_per_day", 1e-10, 1000)
    return model, p

def fraction(times, model, p):
    times = np.maximum(np.asarray(times)-p["lag_days"], 0)
    plateau = p["plateau"]
    if model == "zero_order":
        return zero_order_fraction(times, p["rate_per_day"], plateau, 0)
    if model == "weibull":
        return plateau * release_fraction(times, "weibull", {"tau": p["tau_days"], "beta": p["beta"]})
    kind = "spherical_diffusion" if model == "fickian" else "first_order"
    key = "rate" if model == "fickian" else "k"
    return plateau * release_fraction(times, kind, {key: p["rate_per_day"]})

def _loss_rate(raw, key):
    half = raw.get(key)
    return 0.0 if half in (None, "") else np.log(2)/number(half, key, 1e-6, 1e9)

def simulate(raw):
    model, p = parameters(raw)
    horizon = number(raw.get("horizon_days", 60), "horizon_days", .001, 1e5)
    points = integer(raw.get("points", 241), "points", 50, 2000)
    claim_times = [number(c["day"], "spec day", 0, horizon) for c in raw.get("release_specs", [])]
    times = np.unique(np.r_[np.linspace(0, horizon, points), claim_times, min(p["lag_days"], horizon)])
    release = fraction(times, model, p)
    kr = _loss_rate(raw, "reservoir_half_life_days")
    ka = _loss_rate(raw, "available_half_life_days")
    remaining = np.zeros(len(times)); available = np.zeros(len(times)); released = np.zeros(len(times))
    remaining[0] = 1.
    # Exact interval solution for competing first-order release and reservoir loss.
    # The entered release curve defines the no-loss release hazard.
    for i in range(1,len(times)):
        dt = times[i]-times[i-1]
        probability = np.clip((release[i]-release[i-1])/max(1-release[i-1],1e-15),0,1-1e-15)
        hazard = -np.log1p(-probability)/dt if probability else 0.
        total = hazard+kr
        e0 = remaining[i-1]
        decay_total = np.exp(-total*dt)
        transfer = e0*(hazard/total)*(-np.expm1(-total*dt)) if total else 0.
        remaining[i] = e0*decay_total
        decay_available = np.exp(-ka*dt)
        gap = total-ka
        if hazard == 0:
            influx = 0.
        elif abs(gap) <= 1e-12*max(1.,total,ka):
            influx = hazard*e0*dt*decay_available
        else:
            influx = hazard*e0*(decay_available-decay_total)/gap
        available[i] = available[i-1]*decay_available+influx
        released[i] = released[i-1]+transfer
    degraded = np.clip(1-remaining-available,0,1)
    spec_results = []
    for spec in raw.get("release_specs", []):
        day = float(spec["day"])
        value = float(fraction([day],model,p)[0])
        low = number(spec.get("min_fraction",0), "min_fraction",0,1)
        high = number(spec.get("max_fraction",1), "max_fraction",0,1)
        if low > high:
            raise ValueError("Release spec minimum exceeds maximum")
        spec_results.append({"day":day,"fraction":value,"min_fraction":low,"max_fraction":high,
                             "verdict":"PASS" if low-1e-12 <= value <= high+1e-12 else "FAIL"})
    sensitivities=[]
    for factor in (.5,1.,2.):
        pp=dict(p)
        if model=="weibull": pp["tau_days"]/=factor
        else: pp["rate_per_day"]*=factor
        sensitivities.append({"factor":factor,"release_fraction":fraction(times,model,pp).tolist()})
    milestones={}
    from scipy.optimize import brentq
    for level in (.1,.5,.9):
        crossing = None
        if model == "zero_order" and level <= p["plateau"]:
            candidate = p["lag_days"] + level / (p["plateau"] * p["rate_per_day"])
            crossing = candidate if candidate <= horizon else None
        elif level < p["plateau"] and release[-1] >= level:
            crossing = float(brentq(lambda t: float(fraction([t],model,p)[0])-level,0,horizon))
        milestones[f"t{int(level*100)}_days"] = crossing
    return {"model":model,"parameters":p,"times_days":times.tolist(),"release_fraction":release.tolist(),
            "reservoir_fraction":remaining.tolist(),"available_fraction":available.tolist(),
            "degraded_fraction":degraded.tolist(),"cumulative_intact_released":released.tolist(),
            "mass_balance_error":float(np.max(np.abs(remaining+available+degraded-1))),
            "spec_results":spec_results,"milestones":milestones,"sensitivity":sensitivities,
            "evidence":"assumption-based simulation","parameter_source":raw.get("parameter_source","user scenario"),
            "assumptions":["The release curve defines the no-loss release hazard and is not a composition-to-release prediction.",
              "Release competes continuously with reservoir degradation; available-active loss is first order.",
              "Available active is a modeled compartment, not measured uptake or efficacy.",
              "Sensitivity factors are scenario envelopes, not confidence intervals."],
            "release_curve_basis":"intrinsic no-loss release; cumulative_intact_released includes reservoir degradation",
            "physical_stability":"not inferred from release kinetics"}

def fit_curves(observations):
    if not isinstance(observations,list) or not 5 <= len(observations) <= 5000:
        raise ValueError("Provide five to 5000 observations")
    times=np.array([number(r.get("time_days"),"time_days",0,1e5) for r in observations])
    y=np.array([number(r.get("fraction"),"fraction",0,1) for r in observations])
    unique=np.unique(times)
    if len(unique) > 500:
        raise ValueError("Use at most 500 distinct observation times per fit")
    if len({r.get("condition_id", "single") for r in observations}) > 1:
        raise ValueError("Fit one assay condition at a time")
    if len(unique)<5:
        raise ValueError("At least five distinct times are required")
    # Aggregate technical observations within each independent batch/time first.
    batches={str(r.get("batch_id","unspecified")) for r in observations}
    means=[]
    for t in unique:
        per_batch=[]
        for batch in batches:
            indices=[i for i,r in enumerate(observations) if str(r.get("batch_id","unspecified"))==batch and times[i]==t]
            if indices: per_batch.append(float(np.mean(y[indices])))
        means.append(float(np.mean(per_batch)))
    means=np.array(means)
    if np.ptp(means)<1e-8:
        raise ValueError("Constant observations cannot identify kinetics")
    cut=max(3,int(len(unique)*.7))
    cut=min(cut,len(unique)-1)
    results=[]
    for name in ("first_order","weibull","spherical_diffusion"):
        try:
            early=fit_release(unique[:cut],means[:cut],name)
            holdout=early.predict(unique[cut:])
            mae=float(np.mean(np.abs(holdout-means[cut:])))
            fitted=fit_release(unique,means,name)
            pred=fitted.predict(unique)
            result=fitted.to_dict()
            result.update({"holdout_mae":mae,"predicted":pred.tolist(),"residuals":(means-pred).tolist()})
            params=fitted.parameters
            if name=="weibull":
                scenario={"model":"weibull","tau_days":params["tau"],"beta":params["beta"]}
            else:
                scenario={"model":"fickian" if name=="spherical_diffusion" else name,
                          "rate_per_day":params.get("rate",params.get("k"))}
            result["scenario"] = dict(scenario,plateau=1,lag_days=0,
                horizon_days=float(unique[-1]),parameter_source="fit to imported release observations")
            results.append(result)
        except ValueError:
            continue
    # Membrane model is fitted with nonlinear least squares, without inferring a plateau
    # from an incomplete ramp as if it had been observed.
    if len(unique)>=7:
        scale=max(unique[-1],1e-6)
        def optimize(t,v):
            return least_squares(lambda x: zero_order_fraction(t,x[0]/scale,x[1],x[2]*scale)-v,
                [.8,.95,.01],bounds=([1e-7,.001,0],[100,1,1]),max_nfev=2000).x
        try:
            early=optimize(unique[:cut],means[:cut])
            pred_early=zero_order_fraction(unique[cut:],early[0]/scale,early[1],early[2]*scale)
            full=optimize(unique,means)
            pred=zero_order_fraction(unique,full[0]/scale,full[1],full[2]*scale)
            results.append({"model":"zero_order","holdout_mae":float(np.mean(np.abs(pred_early-means[cut:]))),
                "predicted":pred.tolist(),"residuals":(means-pred).tolist(),
                "parameters":{"k0_per_day":float(full[0]/scale),"plateau":float(full[1]),"lag_days":float(full[2]*scale)},
                "scenario":{"model":"zero_order","rate_per_day":float(full[0]/scale),"plateau":float(full[1]),
                   "lag_days":float(full[2]*scale),"horizon_days":float(unique[-1]),"parameter_source":"fit to imported release observations"},
                "identifiability":"Plateau and rate may be confounded unless the observation window spans depletion."})
        except ValueError:
            pass
    if not results:
        raise ValueError("No model could be fitted to these observations")
    results.sort(key=lambda r:(r["holdout_mae"],r["model"]))
    return {"models":results,"times_days":unique.tolist(),"observed_means":means.tolist(),
        "n_independent_batches":len(batches),"n_rows":len(observations),"selected":results[0]["model"],
        "evidence":"fitted experimental observations; batch labels supplied by user",
        "validation":"Chronological tail held out within this recipe; no new-chemistry validation",
        "uncertainty":"Residuals and between-batch variation are descriptive; no calibrated prediction interval",
        "observations":observations}
