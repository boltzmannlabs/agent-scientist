"""Explicit, auditable time conversion shared by preview and ingestion."""
import re
from .common import number

TIME_FACTORS = {"days": 1, "hours": 1 / 24, "minutes": 1 / 1440}
TIME_KINDS = {"release", "stability", "suspension", "packaging"}

def column_unit(column):
    text = str(column).lower()
    for unit, pattern in (("minutes", r"(?:^|[_\s(\[])min(?:ute)?s?(?:$|[_\s)\]])"),
                          ("hours", r"(?:^|[_\s(\[])h(?:ou)?rs?(?:$|[_\s)\]])|(?:^|[_\s])hours?(?:$|[_\s])"),
                          ("days", r"(?:^|[_\s(\[])days?(?:$|[_\s)\]])")):
        if re.search(pattern, text): return unit
    return None

def time_columns(columns):
    return [{"column": str(c), "unit": column_unit(c)} for c in columns
            if column_unit(c) and re.search(r"time|elapsed|duration|day|hour|minute", str(c), re.I)]

def describe(frame, raw):
    kind = raw.get("kind", "release")
    if kind not in TIME_KINDS: return None
    axis = "time" if kind in {"release", "stability"} else "x"
    candidates = time_columns(frame.columns)
    preferred = sorted(candidates, key=lambda c: (c["column"].lower().startswith("original_"), c["unit"] != "days", c["column"]))
    column = raw.get("mapping", {}).get(axis) or (preferred[0]["column"] if preferred else None)
    inferred = column_unit(column or "")
    unit = raw.get("time_unit") if axis == "time" else raw.get("x_unit")
    unit = unit or inferred or "days"
    if unit not in TIME_FACTORS: raise ValueError("Choose days, hours or minutes for the time axis")
    if inferred and unit != inferred:
        raise ValueError(f"Time column {column} declares {inferred}; selected unit is {unit}. Choose the matching unit or rename the column after an explicit conversion.")
    samples = []
    if column in frame.columns:
        for value in frame[column].head(5):
            try:
                v = number(value, "time", 0, 1e12)
                samples.append({"source": v, "days": v * TIME_FACTORS[unit]})
            except (ValueError, TypeError): pass
    return {"axis": axis, "column": column, "source_unit": unit, "normalized_unit": "days",
            "factor_to_days": TIME_FACTORS[unit], "samples": samples,
            "time_columns": candidates, "confirmation_required": len(candidates) > 1,
            "confirmed": raw.get("time_mapping_confirmed") is True}

def conversion(frame, raw):
    info = describe(frame, raw)
    if info and info["confirmation_required"] and not info["confirmed"]:
        raise ValueError("Multiple time columns are present. Confirm the selected column and unit in the conversion preview before importing.")
    return info
