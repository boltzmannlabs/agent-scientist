"""Readable scenario summaries, also projected onto immutable historical results."""
from .simulation_catalog import spec

PRIORITY={"suspension":["particle_sizes_um","viscosity_mpa_s","yield_stress_pa","horizon_days"],
    "dilution":["hardness_mg_l_caco3","dilution_factors","ph"],
    "manufacturing":["power_w","horizon_minutes","batch_kg"],
    "stability":["temperatures_c","horizon_days","reference_rate_per_day"]}

def describe(model,inputs,scenario_id,name=None):
    try:info=spec(model)
    except ValueError:return {}
    fields={f["key"]:f for f in info["fields"]}
    keys=PRIORITY.get(model,list(inputs))
    descriptions=[]
    for key in keys:
        if key not in inputs or key not in fields:continue
        value=inputs[key]
        if isinstance(value,dict) or value is None:continue
        if isinstance(value,list):
            if not value or any(isinstance(v,(list,dict)) for v in value):continue
            text=", ".join(f"{v:g}" if isinstance(v,(float,int)) else str(v) for v in value[:4])+("…" if len(value)>4 else "")
        else:text=f"{value:g}" if isinstance(value,(float,int)) else str(value)
        descriptions.append(fields[key]["label"]+"="+text+(" "+fields[key]["unit"] if fields[key].get("unit") else ""))
        if len(descriptions)==3:break
    summary="; ".join(descriptions)
    return {"scenario_id":scenario_id,"parameter_summary":summary,
        "scenario_label":(name or info["title"])+(" · "+summary if summary else "")+" · #"+str(scenario_id)[-8:]}
