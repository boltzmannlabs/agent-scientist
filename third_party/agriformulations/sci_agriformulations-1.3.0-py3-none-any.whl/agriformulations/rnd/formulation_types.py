"""Formulation classes describe physical forms, not validated product performance."""
SOURCE="https://www.apvma.gov.au/about/communication-and-decision-making/section-6a-guidelines/formulation-types"
CODE_SOURCE="https://www.cipac.org/images/Handbook-O/DD_App_D_293_294.pdf"

def entry(name,group,physical,water,advantage,caution,tests):
    return {"name":name,"group":group,"physical_form":physical,
            "requires_tank_mixing":water,"application_preparation":"Dilute or disperse in water as specified for the product" if water else "Direct dry application where the product label permits",
            "market_advantage":advantage,"design_caution":caution,"tests":tests,
            "sources":[SOURCE,CODE_SOURCE]}

FORMATS={
 "EC":entry("Emulsifiable concentrate","Liquid","Usually clear, solvent-based concentrate",True,
     "Solvent delivery can support rapid wetting and penetration for suitable actives.",
     "Penetration, knockdown, flammability, phytotoxicity and emulsion stability depend on the actual product.",
     ["active assay","concentrate homogeneity","emulsion stability","dilution compatibility","storage stability"]),
 "SC":entry("Suspension concentrate","Liquid","Opaque suspension, usually water-based",True,
     "A water-based route for poorly water-soluble solid actives; can reduce solvent loading.",
     "Water-based does not establish safety or non-flammability. Settling, caking and redispersion require assessment.",
     ["active assay","particle size","rheology","suspensibility","wet sieve","redispersibility","foam","storage stability"]),
 "SL":entry("Soluble concentrate","Liquid","Usually clear solution, often water-based",True,
     "A true-solution route can simplify dispersion when solubility is sufficient.",
     "Solubility, crystallization and chemical stability remain conditional on temperature, pH, impurities and dilution water.",
     ["active assay","solution homogeneity","solubility across temperature","dilution stability","storage stability"]),
 "OD":entry("Oil dispersion","Liquid","Opaque suspension of particles in an oil phase",True,
     "A low-water carrier can help protect suitable water-sensitive actives.",
     "Water sensitivity, oil compatibility, dispersion and dilution-emulsion stability must be demonstrated.",
     ["active assay","particle size","rheology","suspensibility","emulsion stability","storage stability"]),
 "WG":entry("Water-dispersible granule","Dry","Small granules that disperse in water",True,
     "Can reduce dust and shipping mass relative to comparable liquid products.",
     "Not necessarily dust-free or highly concentrated; granule strength, wetting and disintegration need verification.",
     ["active assay","wetting","dispersibility","wet sieve","moisture","attrition","storage stability"]),
 "WP":entry("Wettable powder","Dry","Fine powder dispersed as a suspension in water",True,
     "A potentially economical dry formulation route.",
     "Dust exposure, wetting, suspensibility and crop tolerance depend on the actual formulation.",
     ["active assay","wetting","suspensibility","wet sieve","dustiness","storage stability"]),
 "SG":entry("Water-soluble granule","Dry","Granules that dissolve to deliver active in solution",True,
     "Combines dry storage and handling with solution delivery where solubility permits.",
     "Active solubility and insoluble residue require assessment; excipients may remain insoluble.",
     ["active assay","dissolution","solution stability","insoluble residue","moisture","storage stability"]),
 "SP":entry("Water-soluble powder","Dry","Powder that dissolves to deliver active in solution",True,
     "A dry route for soluble actives with relatively simple dilution preparation.",
     "Dust, solubility, residue and chemical stability remain product-specific.",
     ["active assay","dissolution","insoluble residue","dustiness","storage stability"]),
 "GR":entry("Granule","Dry","Coarse ready-to-use granules",False,
     "Can support targeted soil or paddy placement without spray-tank dilution.",
     "Application route, dose uniformity, release and crop suitability require product-specific evidence and label directions.",
     ["active assay","size distribution","attrition","dustiness","loading uniformity","release","storage stability"]),
 "EW":entry("Emulsion, oil in water","Liquid","Oil droplets emulsified in an aqueous continuous phase",True,
     "Can reduce solvent loading compared with a comparable solvent concentrate.",
     "Concentrate and diluted emulsion stability require phase-specific measurements.",
     ["active assay","droplet size","emulsion stability","dilution compatibility","storage stability"]),
 "CR":entry("Controlled release","Other","Matrix, coated or encapsulated design; physical form varies",True,
     "Offers a route to investigate release timing.","Ingredient identity alone does not establish a release rate or efficacy.",
     ["active assay","loading","release kinetics","burst","mass recovery","storage stability"]),
 "FERT":entry("Fertilizer","Other","Nutrient formulation; physical form and application vary",False,
     "Supports nutrient-delivery design.","Define nutrient assay basis and actual application form; dilution requirements vary.",
     ["nutrient content","dissolution","pH","conductivity","moisture","caking","granule strength"]),
}
FORMATS["WG"]["aliases"]=["WDG"]
FORMATS["CR"]["requires_tank_mixing"]=None
FORMATS["FERT"]["requires_tank_mixing"]=None
for key in ("CR","FERT"):
    FORMATS[key]["sources"]=[]
    FORMATS[key]["classification_status"]="Internal design category, not a standard pesticide physical-form code"
    FORMATS[key]["application_preparation"]="Depends on the specified physical product and application route"

def canonical(code):
    return "WG" if code=="WDG" else code

def catalogue():
    return [{"code":code,**value} for code,value in FORMATS.items()]
