"""Local mixture-response learning, gated on recipe-held-out utility.

No pretrained chemistry predictor is claimed. Predictions are accepted only in
the convex hull of measured compositions with the same preparation process.
"""
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
from .common import number, digest

def learn(raw):
    recipes=raw.get("recipes",[])
    by_id={r["recipe_id"]:r for r in recipes}
    grouped=defaultdict(lambda:defaultdict(list))
    for row in raw.get("measurements",[]):
        rid=row.get("recipe_id")
        if rid not in by_id: raise ValueError("Response references an unknown recipe")
        grouped[rid][str(row.get("batch_id","unspecified"))].append(number(row.get("value"),"response",-1e12,1e12))
    if len(grouped)<8:
        raise ValueError("At least eight distinct measured recipes are needed; more batches do not substitute for recipes")
    ids=sorted(grouped)
    first=by_id[ids[0]]
    names=[i["name"] for i in first["ingredients"]]
    process=digest([first.get("process",[]),first.get("process_parameters",[])])
    for rid in ids:
        r=by_id[rid]
        if [i["name"] for i in r["ingredients"]]!=names or r["format"]!=first["format"] or digest([r.get("process",[]),r.get("process_parameters",[])])!=process:
            raise ValueError("Learning requires the same ingredient basis, format and preparation process")
    x=np.array([[i["fraction"] for i in by_id[rid]["ingredients"]] for rid in ids])
    y=np.array([np.mean([np.mean(v) for v in grouped[rid].values()]) for rid in ids])
    def fit_predict(train_x,train_y,test_x):
        mean=train_x.mean(axis=0); scale=train_x.std(axis=0)
        scale=np.where(scale>1e-8,scale,1)
        xx=np.c_[np.ones(len(train_x)),(train_x-mean)/scale]
        penalty=np.eye(xx.shape[1])*.1; penalty[0,0]=0
        coef=np.linalg.solve(xx.T@xx+penalty,xx.T@train_y)
        return np.c_[np.ones(len(test_x)),(test_x-mean)/scale]@coef
    held=[]; baseline=[]
    for i in range(len(x)):
        mask=np.arange(len(x))!=i
        held.append(float(fit_predict(x[mask],y[mask],x[i:i+1])[0]))
        baseline.append(float(y[mask].mean()))
    mae=float(np.mean(np.abs(y-held)))
    baseline_mae=float(np.mean(np.abs(y-baseline)))
    utility=bool(baseline_mae>1e-12 and mae<.9*baseline_mae)
    candidates=[]
    goal=raw.get("goal","minimize")
    if goal not in ("minimize","maximize"): raise ValueError("goal must be minimize or maximize")
    for r in recipes:
        if [i["name"] for i in r["ingredients"]]!=names or r["format"]!=first["format"] or digest([r.get("process",[]),r.get("process_parameters",[])])!=process:
            candidates.append({"recipe_id":r["recipe_id"],"status":"incompatible ingredient/process domain"}); continue
        v=np.array([i["fraction"] for i in r["ingredients"]])
        feasible=linprog(np.zeros(len(x)),A_eq=np.r_[x.T,np.ones((1,len(x)))],b_eq=np.r_[v,1],bounds=(0,None),method="highs")
        inside=bool(feasible.success)
        prediction=float(fit_predict(x,y,v[None,:])[0]) if utility and inside else None
        candidates.append({"recipe_id":r["recipe_id"],"prediction":prediction,
            "status":"eligible within measured mixture domain" if prediction is not None else
                ("outside measured composition convex hull" if not inside else "utility gate failed")})
    candidates.sort(key=lambda r:(r.get("prediction") is None,
        (r.get("prediction") or 0)*(1 if goal=="minimize" else -1),r["recipe_id"]))
    return {"response_name":raw.get("response_name","measured response"),"response_unit":raw.get("response_unit",""),
        "goal":goal,"n_measured_recipes":len(ids),"n_independent_batches":sum(len(v) for v in grouped.values()),
        "holdout_mae":mae,"baseline_mae":baseline_mae,"utility_pass":utility,
        "predictions":candidates,"validation":"Leave one complete recipe out; technical readings averaged within batch",
        "evidence":"local experimental mixture-response regression",
        "limitations":["Linear mixture response with fixed ridge regularization; nonlinear interactions may be missed.",
            "Held-out MAE is descriptive validation error, not a calibrated confidence interval.",
            "Only same ingredient identity, format, preparation process and measured composition hull are eligible.",
            "A utility pass supports experiment prioritization, not product approval."]}
