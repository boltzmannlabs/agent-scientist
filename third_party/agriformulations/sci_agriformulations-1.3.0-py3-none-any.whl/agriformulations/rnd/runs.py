"""Background investigations with per-run cancellation and durable partial outputs."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
import re
import sqlite3
import threading
import uuid

from .common import clean, label
from .gpt_agents import answer, SECRET_KEYS
from . import control

def now():
    return datetime.now(timezone.utc).isoformat()

def snapshot(value):
    if isinstance(value,dict):
        return {k:snapshot(v) for k,v in value.items() if str(k).lower() not in SECRET_KEYS-{"content_base64"}}
    if isinstance(value,list):
        return [snapshot(v) for v in value]
    return clean(value)

def local_request(raw):
    task=raw.get("_studio_manual") or raw.get("manual")
    return isinstance(task,dict) and task.get("operation")!="research_search"

class AgentRuns:
    def __init__(self,workspace,connection,runner=None,max_active=2,max_local_active=2):
        self.workspace=workspace
        self.connection=connection
        self.runner=runner or answer
        self.max_active=max_active
        self.max_local_active=max_local_active
        self._lock=threading.RLock()
        self._active=set()
        self._local_active=set()
        self._controls={}
        self.on_event=None
        self.on_checkpoint=None
        self.on_finished=None
        with workspace.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("""CREATE TABLE IF NOT EXISTS agent_runs (
                run_id TEXT PRIMARY KEY,input_hash TEXT,created TEXT,updated TEXT,
                question TEXT,focus TEXT,intent TEXT,project_name TEXT,project_id TEXT,
                saved_revision INTEGER,status TEXT,owner_pid INTEGER,
                events TEXT,result TEXT,error TEXT,initial_state TEXT)""")
            columns={row[1] for row in db.execute("PRAGMA table_info(agent_runs)")}
            for name,kind in (("initial_state","TEXT"),("working_state","TEXT"),
                    ("checkpoint_no","INTEGER DEFAULT 0"),("session_id","TEXT"),
                    ("cancel_requested","INTEGER DEFAULT 0")):
                if name not in columns:
                    db.execute("ALTER TABLE agent_runs ADD COLUMN "+name+" "+kind)

    @property
    def active(self):
        with self._lock:
            return bool(self._active)

    def has_capacity(self,local=False):
        with self._lock:
            return (len(self._local_active)<self.max_local_active if local else
                    len(self._active-self._local_active)<self.max_active)

    def _row(self,run_id,include_result=True):
        run_id=label(run_id,"run_id",80)
        fields="*" if include_result else """run_id,created,updated,question,focus,intent,project_name,
            project_id,saved_revision,status,owner_pid,events,error,session_id,checkpoint_no,cancel_requested,
            NULL AS result,NULL AS initial_state,NULL AS working_state"""
        with self.workspace.connect() as db:
            db.row_factory=sqlite3.Row
            row=db.execute("SELECT "+fields+" FROM agent_runs WHERE run_id=?",(run_id,)).fetchone()
        if row is None:
            raise ValueError("Agent investigation not found")
        return dict(row)

    def start(self,raw):
        if not isinstance(raw,dict) or not isinstance(raw.get("state",{}),dict):
            raise ValueError("Agent request and project state must be objects")
        question=label(raw.get("question"),"question",6000)
        intent=raw.get("intent","research")
        if intent not in ("research","execute","create_recipes","discussion","develop_product"):
            raise ValueError("Unknown agent request intent")
        identity=raw.get("project_identity",{})
        if not isinstance(identity,dict):
            raise ValueError("project_identity must be an object")
        run_id=raw.get("client_request_id") or uuid.uuid4().hex
        if not isinstance(run_id,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}",run_id):
            raise ValueError("Invalid investigation request ID")
        identity=snapshot(identity)
        payload=deepcopy(raw)
        payload["project_identity"]=identity
        payload["state"]=snapshot(payload.get("state",{}))
        payload.pop("client_request_id",None)
        input_hash=hashlib.sha256(json.dumps(clean(payload),sort_keys=True,allow_nan=False).encode()).hexdigest()
        with self._lock:
            with self.workspace.connect() as db:
                prior=db.execute("SELECT input_hash FROM agent_runs WHERE run_id=?",(run_id,)).fetchone()
            if prior:
                if prior[0]!=input_hash:
                    raise ValueError("This request ID belongs to a different investigation")
                return self.get(run_id,include_result=False)
            local=local_request(raw)
            if not self.has_capacity(local):
                raise ValueError("All "+("local calculation" if local else "research")+" workers are already running; wait for one to finish")
            if not raw.get("_studio_manual") and not self.connection.status()["configured"]:
                raise ValueError("The research agent connection is unavailable; check Agent settings")
            created=now()
            event={"seq":1,"at":created,"kind":"started","message":"Local calculation started" if local else "Investigation started","execution_lane":"local" if local else "research"}
            with self.workspace.connect() as db:
                db.execute("""INSERT INTO agent_runs
                    (run_id,input_hash,created,updated,question,focus,intent,project_name,project_id,
                     saved_revision,status,owner_pid,events,result,error,initial_state,session_id,checkpoint_no,cancel_requested)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (run_id,input_hash,created,created,question,str(raw.get("focus","research"))[:80],intent,
                     str(raw.get("state",{}).get("brief",{}).get("name","New project"))[:300],
                     identity.get("project_id"),None,"running",os.getpid(),json.dumps([event]),None,None,
                     json.dumps({"state":payload["state"],"identity":identity},allow_nan=False),
                     raw.get("_session_id"),0,0))
            self._active.add(run_id)
            if local:self._local_active.add(run_id)
            token=control.RunControl(
                checkpoint=lambda state,message:self.checkpoint(run_id,state,message),
                event=lambda event:self.event(run_id,event),resume_state=raw.get("_resume_state"))
            self._controls[run_id]=token
            threading.Thread(target=self._work,args=(run_id,payload),daemon=True,
                name="agri-agent-"+run_id[:12]).start()
        return self.get(run_id,include_result=False)

    def event(self,run_id,event):
        with self.workspace.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row=db.execute("SELECT events FROM agent_runs WHERE run_id=?",(run_id,)).fetchone()
            if not row:
                return
            events=json.loads(row[0])
            item=clean(dict(event,seq=(events[-1]["seq"]+1 if events else 1),at=now()))
            events.append(item)
            db.execute("UPDATE agent_runs SET events=?,updated=? WHERE run_id=?",
                (json.dumps(events[-256:]),item["at"],run_id))
        if self.on_event:
            self.on_event(run_id,item)

    def checkpoint(self,run_id,state,message):
        state=snapshot(state)
        with self.workspace.connect() as db:
            db.execute("UPDATE agent_runs SET working_state=?,checkpoint_no=checkpoint_no+1,updated=? WHERE run_id=?",
                (json.dumps(state,allow_nan=False),now(),run_id))
        self.event(run_id,{"kind":"checkpoint","message":message,
            "recipes":len(state.get("recipes",[])),"results":len(state.get("analysis_runs",[])),
            "target":state.get("product_development",{}).get("target_count")})
        if self.on_checkpoint:
            self.on_checkpoint(run_id,state)

    def cancel(self,run_id):
        with self._lock:
            row=self._row(run_id,include_result=False)
            if row["status"] not in ("running","stopping"):
                return self.get(run_id,include_result=False)
            token=self._controls.get(run_id)
            if token is None:
                raise ValueError("This investigation belongs to another server; reconnect to its server")
            with self.workspace.connect() as db:
                changed=db.execute("UPDATE agent_runs SET status=?,cancel_requested=1,updated=? WHERE run_id=? AND status IN (?,?)",
                    ("stopping",now(),run_id,"running","stopping")).rowcount
            if not changed:
                return self.get(run_id,include_result=False)
            self.event(run_id,{"kind":"stopping","message":"Stopping work; completed results are retained"})
            token.cancel()
        return self.get(run_id,include_result=False)

    def cancel_all(self):
        with self._lock:
            ids=list(self._active)
        return [self.cancel(run_id) for run_id in ids]

    def _work(self,run_id,raw):
        token=self._controls[run_id]
        result=None
        def progress(event):
            try:
                self.event(run_id,event)
            except (OSError,sqlite3.Error):
                pass
        try:
            with control.scope(token):
                if raw.get("_studio_manual"):
                    from .studio_actions import run as run_manual
                    result=run_manual(raw,self.connection,self.workspace,on_event=progress)
                else:
                    result=self.runner(raw,self.connection,self.workspace,on_event=progress)
                with self._lock:
                    token.check()
                    saved=result.get("project_saved",{})
                    status=("completed_unsaved" if result.get("persistence_error") else
                        "completed_with_warnings" if result.get("warnings") else "completed")
                    progress({"kind":"finished","message":"Investigation finished","status":status,
                        "saved_revision":saved.get("revision")})
                    with self.workspace.connect() as db:
                        db.execute("""UPDATE agent_runs SET status=?,result=?,updated=?,
                            project_id=COALESCE(?,project_id),saved_revision=? WHERE run_id=?""",
                            (status,json.dumps(clean(result),allow_nan=False),now(),
                             saved.get("project_id"),saved.get("revision"),run_id))
        except control.RunCancelled:
            with self._lock:
                progress({"kind":"cancelled","message":"Stopped by you; completed step results are saved"})
                with self.workspace.connect() as db:
                    db.execute("UPDATE agent_runs SET status=?,error=?,updated=?,result=COALESCE(?,result) WHERE run_id=?",
                        ("cancelled","Stopped at user request",now(),
                         json.dumps(clean(result),allow_nan=False) if result else None,run_id))
        except Exception as exc:
            logging.getLogger(__name__).exception("Investigation %s failed",run_id)
            error=str(exc) if isinstance(exc,ValueError) else "The investigation failed unexpectedly; inspect server diagnostics."
            try:
                progress({"kind":"failed","message":error})
                with self.workspace.connect() as db:
                    db.execute("UPDATE agent_runs SET status=?,error=?,updated=? WHERE run_id=?",
                        ("failed",error[:2000],now(),run_id))
            except (OSError,sqlite3.Error):
                pass
        finally:
            with self._lock:
                self._active.discard(run_id)
                self._local_active.discard(run_id)
                self._controls.pop(run_id,None)
            if self.on_finished:
                try:
                    self.on_finished(run_id)
                except Exception:
                    logging.getLogger(__name__).exception("Session recovery failed for %s",run_id)
                    self.event(run_id,{"kind":"recovery_available","message":"Saved results remain available in run recovery"})

    def get(self,run_id,include_result=True):
        row=self._row(run_id,include_result)
        if row["status"] in ("running","stopping") and row["owner_pid"]!=os.getpid():
            try:
                os.kill(row["owner_pid"],0)
            except ProcessLookupError:
                with self.workspace.connect() as db:
                    db.execute("UPDATE agent_runs SET status=?,error=?,updated=? WHERE run_id=? AND status IN (?,?)",
                        ("interrupted","The server stopped before this investigation completed. Completed checkpoints are recoverable.",
                         now(),run_id,"running","stopping"))
                row=self._row(run_id,include_result)
            except PermissionError:
                pass
        fields=("run_id","created","updated","question","focus","intent","project_name","project_id",
            "saved_revision","status","error","session_id","checkpoint_no","cancel_requested")
        result={key:row.get(key) for key in fields}
        result["events"]=json.loads(row["events"])
        events=result["events"]
        result["execution_lane"]=events[0].get("execution_lane","research") if events else "research"
        end=datetime.now(timezone.utc) if row["status"] in ("running","stopping") else datetime.fromisoformat(row["updated"])
        result["elapsed_seconds"]=max(0,int((end-datetime.fromisoformat(row["created"])).total_seconds()))
        meaningful=next((e for e in reversed(events) if e["kind"] in {"checkpoint","tool_completed","model_completed","finished"} and e.get("meaningful_progress",True)),events[0] if events else {"at":row["created"]})
        result["last_progress_at"]=meaningful["at"]
        result["idle_seconds"]=max(0,int((end-datetime.fromisoformat(meaningful["at"])).total_seconds()))
        if result["execution_lane"]=="research":
            from .gpt_agents import INVESTIGATION_TIMEOUT_SECONDS
            result["budget_seconds"]=INVESTIGATION_TIMEOUT_SECONDS
        if include_result and row.get("result"):
            result["result"]=json.loads(row["result"])
        if include_result and row.get("working_state"):
            result["working_state"]=json.loads(row["working_state"])
        if include_result and row["status"] not in ("running","stopping") and row.get("initial_state"):
            initial=json.loads(row["initial_state"])
            result["initial_state"]=initial.get("state",initial)
            result["initial_identity"]=initial.get("identity",{})
        return result

    def list(self,project_id=None,include_discussions=False):
        conditions=[];values=[]
        if project_id:
            conditions.append("project_id=?");values.append(project_id)
        if not include_discussions:
            conditions.append("intent!=?");values.append("discussion")
        where=" WHERE "+" AND ".join(conditions) if conditions else ""
        with self.workspace.connect() as db:
            rows=db.execute("SELECT run_id FROM agent_runs"+where+" ORDER BY created DESC LIMIT 50",values).fetchall()
        return [self.get(row[0],include_result=False) for row in rows]

