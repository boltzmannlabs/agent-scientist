"""Save a factual partial synthesis without inventing scientific conclusions."""
from .common import digest

def build(state,question,trace):
    workflow=next((w for w in reversed(state.get("formulation_workflows",[])) if w.get("task")==question),None)
    if workflow and any(t.get("tool") in {"run_formulation_workflow","complete_formulation_request"} for t in trace):
        return {"report_id":workflow["workflow_id"],"task":"Computed workflow · "+workflow["name"],
            "answer":workflow["answer"],"status":workflow["status"],"evidence":workflow["evidence"],"sources":[],"outputs":[]}
    tools=[t["tool"] for t in trace if t.get("evidence")!="tool input rejected" and not t.get("error")]
    recipes=state.get("recipes",[])
    scenarios=state.get("analysis_runs",[])
    searches=state.get("research_searches",[])
    lines=["Checkpoint synthesis · incomplete scientific assessment."]
    if recipes:
        lines.append(str(len(recipes))+" recipe drafts are retained; mass-balance validation does not establish compatibility or product performance.")
        lines.extend("- "+r["name"] for r in recipes[-6:])
    if scenarios:
        lines.append(str(len(scenarios))+" numerical scenarios are saved with their exact inputs. Their physical assumptions remain conditional.")
        lines.extend("- "+str(r.get("title",r["kind"]))+" · "+str(r.get("scenario_id","")) for r in scenarios[-4:])
    if searches:
        lines.append(str(len(searches))+" searches are saved. Retrieved titles/snippets/abstracts are discovery evidence; no full-text or claim review is implied.")
        for search in searches[-2:]:
            lines.extend("- ["+r["title"].replace("[","(").replace("]",")")+"]("+r["url"]+") · discovery evidence" for r in search.get("results",[])[:2])
    lines.append("Still unresolved: final scientific comparison and any requested outputs not yet recorded. Ingredient-specific stability, emulsion behavior and efficacy require applicable validated evidence.")
    content="\n\n".join(lines)
    return {"report_id":"partial-"+digest({"task":question,"content":content,"tools":tools}),
        "task":"In progress · "+question[:140],"answer":content,"status":"partial",
        "evidence":"Recorded tool outputs; scientific synthesis incomplete","sources":[],
        "outputs":[],"completed_tools":list(dict.fromkeys(tools))}
