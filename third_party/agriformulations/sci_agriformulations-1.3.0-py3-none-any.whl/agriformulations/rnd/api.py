"""Explicit workbench tool dispatch and reproducible report/export bundles."""
import base64
import csv
import io
import json
import zipfile
from html import escape
from . import recipes, kinetics, stability, dosage, experiments, importing, agent, learning, recipe_library, gpt_agents
from .common import clean

DEFAULTS={
 "kinetics_input":{"model":"zero_order","rate_per_day":.03,"plateau":.9,"lag_days":2,"horizon_days":60,
    "reservoir_half_life_days":None,"available_half_life_days":None,"parameter_source":"user scenario",
    "release_specs":[{"day":5,"min_fraction":0,"max_fraction":.2},{"day":35,"min_fraction":.8,"max_fraction":1}]},
 "stability_input":{"reference_rate_per_day":.001,"reference_temperature_c":25,"activation_energy_kj_mol":50,
    "temperatures_c":[25,40,54],"horizon_days":180,"minimum_retained_fraction":.9,
    "physical":{"particle_diameter_um":5,"viscosity_mpa_s":100,"density_difference_kg_m3":500,"container_height_cm":10}},
 "dosage_input":{"evaluation_day":35,"target_available_g_ha":50,"storage_retained_fraction":1,"deposition_fraction":.8,
    "maximum_product_kg_ha":None,"product_density_kg_l":None,"spray_volume_l_ha":200},
 "experiment_input":{"n_recipes":6,"independent_batches":3,"technical_replicates":2,"seed":2026,
    "sampling_days":[0,1,3,5,10,20,35,60],"process_factors":{},"reference_name":"Define laboratory reference"}
}

def bootstrap():
    return dict(DEFAULTS,brief=recipes.default_brief(),formats=recipes.FORMATS,format_scaffolds={k:recipes.scaffold(k) for k in recipes.FORMATS},agent_examples=gpt_agents.EXAMPLES)

def _chart(title, times, series):
    import math
    if not times or not series:
        return ""
    values=[float(v) for _,ys in series for v in ys]
    if not all(math.isfinite(v) for v in values):
        return ""
    xmax=max(times) or 1
    ymax=max(values) or 1
    colors=["#328565","#cc733d","#447dc0","#a16a9f"]
    paths=[]
    for i,(name,ys) in enumerate(series):
        if len(ys)!=len(times):
            continue
        points=" ".join(f"{55+float(t)/xmax*650:.2f},{245-float(y)/ymax*210:.2f}" for t,y in zip(times,ys))
        paths.append(f'<polyline points="{points}" fill="none" stroke="{colors[i%4]}" stroke-width="2"/>')
    legend=" · ".join(escape(name) for name,_ in series)
    return f'<h3>{escape(title)}</h3><svg viewBox="0 0 740 285" role="img" aria-label="{escape(title)}"><line x1="55" y1="245" x2="705" y2="245" stroke="#999"/><text x="55" y="265">0</text><text x="650" y="265">{xmax:.4g}</text><text x="8" y="35">{ymax:.4g}</text>{"".join(paths)}</svg><p>{legend}</p>'

def export(raw):
    document=raw.get("document",{})
    if not isinstance(document,dict): raise ValueError("document must be an object")
    body=json.dumps(clean(document),indent=2,allow_nan=False)
    if len(body)>7_500_000: raise ValueError("Export exceeds 7.5 MB")
    from .outcomes import project_reports
    outcomes=project_reports(document)
    title=document.get("brief",{}).get("name","Formulation project")
    parts=["<!doctype html><meta charset='utf-8'><title>Formulation R&D report</title>",
        "<style>body{font:15px system-ui;max-width:1000px;margin:40px auto}pre{white-space:pre-wrap}table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:6px}</style>",
        "<h1>"+escape(title)+"</h1>",
        "<p>Recipe drafts and scenario calculations require experimental confirmation. Imported measurements retain their source hashes and batch identifiers.</p>"]
    if outcomes:
        parts.append("<h2>Run outcomes</h2>")
        for outcome in reversed(outcomes):
            parts.append("<h3>"+escape(outcome["task"])+"</h3>")
            parts.append("<p>"+escape(outcome.get("notice",""))+"</p>")
            parts.append("<pre>"+escape(outcome["answer"])+"</pre>")
    for key in ("brief","recipe_result","kinetics_result","stability_result","dosage_result","dose_response_result","learning_result","experiment_result"):
        if key in document:
            value=document[key]
            # Reports summarize metadata; full curves are preserved in project.json.
            if isinstance(value,dict):
                value={k:v for k,v in value.items() if k not in ("observations","recipes","runs","times_days","sensitivity","curves","temperature_profile","doses","predicted_response_pct","release_fraction","available_fraction","reservoir_fraction","degraded_fraction","cumulative_intact_released")}
            parts.append("<h2>"+escape(key.replace("_"," "))+"</h2><pre>"+escape(json.dumps(clean(value),indent=2))+"</pre>")
    k=document.get("kinetics_result",{})
    if k:
        parts.append(_chart("Release fraction vs time (days)",k["times_days"],[("Release",k["release_fraction"])]))
        parts.append(_chart("Initial active mass balance vs time (days)",k["times_days"],[(name,k[key]) for name,key in
            [("Reservoir","reservoir_fraction"),("Available","available_fraction"),("Degraded","degraded_fraction")]]))
    storage=document.get("stability_result",{})
    if storage:
        parts.append(_chart("Chemical retention vs storage time (days)",storage["times_days"],
            [(str(c["temperature_c"])+" C",c["retained_fraction"]) for c in storage["curves"]]))
    dose=document.get("dose_response_result",{})
    if dose:
        parts.append(_chart("Dose response ("+dose["dose_unit"]+")",dose["doses"],[("Fitted response %",dose["predicted_response_pct"])]))
    if document.get("analysis_runs"):
        parts.append("<h2>Analysis history</h2><p>"+str(len(document["analysis_runs"]))+" model runs retained in project.json with recipe, active, inputs and outputs.</p>")
    report="\n".join(parts)
    target=io.BytesIO()
    def csv_text(rows):
        if not rows: return ""
        columns=list(dict.fromkeys(k for r in rows for k in r))
        def safe(value):
            if isinstance(value,(dict,list)):
                value=json.dumps(value)
            if isinstance(value,str) and value[:1] in ("=","+","-","@"):
                value="'"+value
            return value
        stream=io.StringIO(); w=csv.writer(stream); w.writerow([safe(c) for c in columns])
        for row in rows:
            w.writerow([safe(row.get(k)) for k in columns])
        return stream.getvalue()
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("project.json",body); z.writestr("report.html",report)
        z.writestr("research_outcomes.json",json.dumps(outcomes,indent=2,allow_nan=False))
        for index,outcome in enumerate(outcomes,1):
            z.writestr(f"research_outcomes/{index:03d}.md","# Research outcome\n\n"+outcome["task"]+"\n\n"+outcome.get("notice","")+"\n\n"+outcome["answer"])

        z.writestr("recipes.csv",csv_text([{"recipe_id":r["recipe_id"],"name":r["name"],"active_fraction":r["active_fraction"],"cost_per_kg":r.get("cost_per_kg"),**{i["name"]+" (%)":i["pct"] for i in r["ingredients"]}} for r in document.get("recipes",[])]))
        costs=document.get("cost_estimates",[])
        z.writestr("formulation_costs.csv",csv_text([{
            "cost_id":c["cost_id"],"recipe_id":c["recipe_id"],"recipe_name":c["recipe_name"],
            "currency":c["result"]["currency"], **{k:c["result"].get(k) for k in
            ("material_cost_per_input_kg","final_cost_per_saleable_kg","final_batch_cost","cost_per_pack")},
            "missing_ingredients":"; ".join(c["result"]["missing_ingredients"]),
            "missing_assumptions":"; ".join(c["result"]["missing_assumptions"])} for c in costs]))
        for index,cost in enumerate(costs,1):
            z.writestr(f"cost_estimates/{index:03d}.json",json.dumps(cost,indent=2,allow_nan=False))
        z.writestr("run_sheet.csv",csv_text(document.get("experiment_result",{}).get("runs",[])))
        for index,study in enumerate(document.get("design_studies",[]),1):
            z.writestr(f"design_studies/{index:03d}.json",json.dumps(study,indent=2,allow_nan=False))
            z.writestr(f"design_studies/{index:03d}_comparison.csv",csv_text([
                {"recipe_id":c["recipe_id"],"recipe_name":c["recipe_name"],"active_name":c["active_name"],
                 "status":c["status"],"pareto":c["pareto"],**{v["scenario"]+":"+v["metric"]:v["value"] for v in c["checks"]},
                 **{v["scenario"]+":"+v["metric"]+":margin":v.get("specification_margin") for v in c["checks"]}}
                for c in study["candidates"]]))
        manifest=[]
        for index,item in enumerate(document.get("imports",[]),1):
            source=item.get("source",{})
            name=f"raw/{index:03d}"+(".xlsx" if source.get("filename","").lower().endswith(".xlsx") else ".csv")
            if source.get("content_base64"):
                z.writestr(name,base64.b64decode(source["content_base64"],validate=True))
            z.writestr(f"observations/{index:03d}.csv",csv_text(item.get("observations",[])))
            manifest.append({"archive_path":name,"original_filename":source.get("filename"),"sha256":source.get("sha256"),
                             "recipe_id":item.get("recipe_id"),"instrument":item.get("instrument"),"excluded":item.get("excluded",[])})
        z.writestr("source_manifest.json",json.dumps(manifest,indent=2))
    return {"filename":"formulation_project.zip","archive_base64":base64.b64encode(target.getvalue()).decode(),
            "report_html":report}

def dispatch(action, raw, workspace, connection=None):
    if not isinstance(raw,dict): raise ValueError("Request body must be an object")
    handlers={
        "recipes":recipes.suggest,"kinetics":kinetics.simulate,"fit-release":kinetics.fit_curves,
        "stability":stability.simulate,"fit-stability":stability.fit_stability,
        "dosage":dosage.scenario,"fit-dose-response":dosage.fit_response,
        "experiments":experiments.plan,"preview-import":importing.preview,"import":importing.ingest,
        "ask-offline":agent.answer,"learn":learning.learn,"export":export,
    }
    if action=="ask":
        if connection is None:raise ValueError("GPT connection is not initialized")
        return clean(gpt_agents.answer(raw,connection,workspace))
    if action=="agent-configure":
        if connection is None:raise ValueError("GPT connection is not initialized")
        return connection.configure(raw)
    if action=="agent-test":
        if connection is None:raise ValueError("GPT connection is not initialized")
        return connection.test()
    if action=="library-search":
        return {"entries":recipe_library.entries(workspace,raw.get("query",""),raw.get("format",""),raw.get("origin",""))}
    if action=="library-apply":
        return recipe_library.apply(raw.get("library_id"),raw.get("brief"),workspace)
    if action=="library-save":
        return recipe_library.save(raw,workspace)
    if action=="save":
        return workspace.save(raw.get("document"),raw.get("project_id"),raw.get("expected_revision",0))
    if action=="load":
        return workspace.load(raw.get("project_id"),raw.get("revision"))
    if action not in handlers: raise ValueError("Unknown workbench action")
    value=raw.get("observations",[]) if action in ("fit-release","fit-stability") else raw
    return clean(handlers[action](value))
