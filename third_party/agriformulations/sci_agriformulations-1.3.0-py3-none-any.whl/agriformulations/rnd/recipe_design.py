"""Validate model-authored recipe designs before they enter the workbench."""
import json
from copy import deepcopy
from . import recipes, recipe_library
from .common import label, integer
from .gpt_connection import MODEL


def create(raw, workspace, query=""):
    try:
        supplied = json.loads(raw.get("brief_json", ""))
    except (TypeError, json.JSONDecodeError):
        raise ValueError("brief_json must encode a complete formulation brief") from None
    if not isinstance(supplied, dict):
        raise ValueError("brief_json must encode an object")
    required = {"name", "format", "active_name", "active_pct", "batch_g", "count", "ingredients", "process"}
    missing = required - supplied.keys()
    if missing:
        raise ValueError("New recipe design is missing: " + ", ".join(sorted(missing)))
    allowed = set(recipes.default_brief()) | {"process_parameters", "objective"}
    if set(supplied) - allowed:
        raise ValueError("Unsupported brief fields: " + ", ".join(sorted(set(supplied) - allowed)))
    assumptions = raw.get("assumptions")
    if not isinstance(assumptions, list) or not 1 <= len(assumptions) <= 30:
        raise ValueError("List the explicit design assumptions and evidence gaps")
    assumptions = [label(a, "design assumption", 2000) for a in assumptions]
    rationale = label(raw.get("rationale"), "design rationale", 6000)
    active_name=label(supplied["active_name"], "active identity").lower()
    if any(token in active_name for token in ("specify active", "choose active", "replace with", "select identity")):
        raise ValueError("The user must supply an active or nutrient identity before recipe creation")
    rows = supplied["ingredients"]
    if not isinstance(rows, list):
        raise ValueError("Recipe ingredients must be a list")
    for row in rows:
        if not isinstance(row, dict) or not {"name", "role", "min_pct", "max_pct", "purity_pct"} <= row.keys():
            raise ValueError("Every proposed ingredient needs identity, role, bounds and explicit purity/assay")
        name = label(row["name"], "ingredient identity").lower()
        if any(x in name for x in ("replace with", "select material", "specify active", "vehicle / balance", "choose active")):
            raise ValueError("Choose concrete chemical/material identities instead of copying editor placeholders")
    process = supplied["process"]
    if not isinstance(process, list) or not process:
        raise ValueError("Include proposed laboratory preparation steps")
    for step in process:
        if not isinstance(step, dict):
            raise ValueError("Preparation steps must contain an instruction")
        label(step.get("instruction"), "preparation instruction", 4000)
    source_ids = raw.get("source_library_ids", [])
    if not isinstance(source_ids, list) or len(source_ids) > 10:
        raise ValueError("Use up to ten actual library source IDs")
    sources = []
    for library_id in source_ids:
        entry = recipe_library.get(library_id, workspace)
        sources.append({"library_id": entry["library_id"], "source": entry["source"],
                        "validation_status": entry["validation_status"]})
    # Start independently of old editor composition, target, preparation and calibration.
    brief = dict(recipes.default_brief(), **deepcopy(supplied))
    brief["bounds_source"] = "Agent-proposed design assumptions: " + "; ".join(assumptions)
    if sources:
        brief["library_reference"] = sources[0]
    result = recipes.suggest(brief)
    result.update(agent_rationale=rationale, design_assumptions=assumptions,
        design_query=query, design_sources=sources, design_model=MODEL,
        evidence="Agent-designed, constraint-checked research draft; performance unmeasured")
    for recipe in result["recipes"]:
        recipe.update(agent_rationale=rationale, design_assumptions=assumptions,
            design_query=query, design_sources=sources, design_model=MODEL)
    return result


def portfolio(raw, workspace, query=""):
    """Independently validate material families before returning any drafts.

    Families remain hypotheses. Distinct ingredients do not establish chemical
    compatibility or equal performance, and no workspace mutation occurs here.
    """
    try:
        designs = json.loads(raw.get("designs_json", ""))
    except (TypeError, json.JSONDecodeError):
        raise ValueError("designs_json must encode a list of formulation families") from None
    if not isinstance(designs, list) or not 2 <= len(designs) <= 6:
        raise ValueError("Provide 2 to 6 independent formulation families")
    for design in designs:
        if not isinstance(design, dict) or not isinstance(design.get("brief"), dict):
            raise ValueError("Each family requires a complete brief object")
    if sum(integer(design["brief"].get("count"), "count", 1, 100) for design in designs) > 24:
        raise ValueError("A portfolio may request at most 24 combined recipes; reduce the count in each family")
    names, results, signatures = set(), [], set()
    reference = None
    for design in designs:
        if not isinstance(design, dict) or not isinstance(design.get("brief"), dict):
            raise ValueError("Each family requires a complete brief object")
        family = label(design.get("family"), "design family", 200)
        if family.casefold() in names:
            raise ValueError("Design family names must be unique")
        names.add(family.casefold())
        result = create({"brief_json": json.dumps(design["brief"]),
                         "rationale": design.get("rationale"),
                         "assumptions": design.get("assumptions"),
                         "source_library_ids": design.get("source_library_ids", [])}, workspace, query)
        brief = result["brief"]
        active_rows = [row for row in brief["ingredients"] if row["role"] == "active"]
        targets = tuple(sorted((row["name"].strip().casefold(),
                                float(brief["active_pct"] if len(active_rows) == 1 else row["target_active_pct"]))
                               for row in active_rows))
        identity = (brief["active_name"].strip().casefold(), targets, float(brief["batch_g"]), brief["currency"])
        if reference is None:
            reference = identity
        elif identity != reference:
            raise ValueError("Portfolio families must share the active identity, individual pure-active targets, batch size and currency")
        signature = (brief["format"], frozenset(row["name"].strip().casefold()
                     for row in brief["ingredients"] if row["role"] != "active" and float(row["max_pct"]) > 0))
        if signature in signatures:
            raise ValueError("Each family must change an excipient identity or formulation format; percentage variation alone is not a different family")
        signatures.add(signature)
        results.append((family, result))
    combined, families = [], []
    for family, result in results:
        for recipe in result["recipes"]:
            recipe["design_family"] = family
            recipe["name"] = family + " · " + recipe["name"]
            combined.append(recipe)
        families.append({"family": family, "format": result["brief"]["format"],
                         "requested": result["requested"], "generated": result["generated"],
                         "rationale": result["agent_rationale"], "assumptions": result["design_assumptions"],
                         "sources": result["design_sources"], "recipe_ids": [r["recipe_id"] for r in result["recipes"]],
                         "brief": result["brief"], "diversity": result["diversity"]})
    combined.sort(key=lambda recipe: (recipe["cost_per_kg"] is None, recipe["cost_per_kg"] or 0, recipe["recipe_id"]))
    return {"recipes": combined, "families": families, "brief": results[0][1]["brief"],
            "requested": sum(result["requested"] for _, result in results), "generated": len(combined),
            "diversity": {"method": "independent material or format families, each with maximin composition selection",
                          "family_count": len(families), "recipe_count": len(combined),
                          "shortfall_explanation": [dict(family=f["family"], explanation=f["diversity"]["shortfall_explanation"])
                                                    for f in families if f["generated"] < f["requested"]]},
            "ranking_basis": "known ingredient cost, then stable identifier; performance has not been predicted",
            "warnings": list(dict.fromkeys(warning for _, result in results for warning in result["warnings"])) +
                        ["Material families are independent research hypotheses; compatibility and comparative performance are unestablished."],
            "design_query": query, "design_model": MODEL,
            "evidence": "Agent-designed, constraint-checked family portfolio; performance unmeasured"}
