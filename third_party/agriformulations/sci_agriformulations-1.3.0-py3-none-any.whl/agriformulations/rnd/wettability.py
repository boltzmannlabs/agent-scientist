"""Analytical wettability screens; predictions require formulation-specific calibration."""
import math
import numpy as np

def predict(p):
    gamma=p['surface_tension_mn_m']*1e-3
    gamma_sv=p['solid_vapor_tension_mn_m']*1e-3
    gamma_sl=p['solid_liquid_tension_mn_m']*1e-3
    young=(gamma_sv-gamma_sl)/gamma
    if not -1 <= young <= 1:
        raise ValueError('Young equation inputs imply complete wetting/nonwetting; adjust tensions or model a precursor film explicitly')
    theta=math.acos(young)
    r=p['pore_radius_um']*1e-6
    laplace=2*gamma*math.cos(theta)/r
    theta0=math.radians(p['dynamic_initial_angle_deg']); thetae=theta
    mu=p['viscosity_mpa_s']*1e-3; U=p['contact_line_speed_mm_s']*1e-3
    # Cox-Voinov small-angle closure; reject regime outside its declared range.
    capillary=mu*U/gamma
    if capillary>0.05: raise ValueError('Dynamic-angle capillary number exceeds supported limit 0.05')
    theta_d=min(math.pi,max(0,(theta0**3+9*capillary*math.log(p['macro_micro_ratio']))**(1/3)))
    surf=p['surfactant_mol_l']; c=p['langmuir_k_l_mol']*surf
    coverage=c/(1+c) if surf else 0.0
    gamma_eq=max(1e-6,gamma*(1-p['max_surface_tension_reduction_fraction']*coverage))
    # Washburn: L^2 = r gamma cos(theta) t / (2 mu); non-wetting => no spontaneous penetration.
    cos_theta=max(0,math.cos(theta)); length=p['penetration_distance_mm']*1e-3
    t=2*mu*length**2/(r*gamma_eq*cos_theta) if cos_theta>1e-12 else math.inf
    # Wenzel roughness for chemically homogeneous rough substrate; clamp outside physical range.
    wenzel=min(180,max(0,math.degrees(math.acos(max(-1,min(1,p['roughness_ratio']*young))))))
    spread=math.pi*(p['droplet_diameter_mm']*0.5)**2*(1-math.cos(theta))
    runoff=max(0,min(1,(wenzel-90)/90 + max(0,p['porosity_fraction']-coverage)*0.2))
    return {'metrics':{'equilibrium_contact_angle_deg':math.degrees(theta),'dynamic_contact_angle_deg':math.degrees(theta_d),
      'young_laplace_pressure_pa':laplace,'washburn_penetration_time_s':t,'washburn_penetration_distance_mm':length,
      'langmuir_surface_coverage_fraction':coverage,'equilibrium_interfacial_tension_mn_m':gamma_eq*1000,
      'wenzel_apparent_contact_angle_deg':wenzel,'droplet_footprint_area_mm2':spread,'contact_line_velocity_mm_s':p['contact_line_speed_mm_s'],'runoff_risk_index':runoff,
      'adhesion_work_mn_m':gamma*(1+math.cos(theta))*1000},
      'series':[{'name':'Washburn penetration','x':[0,t if math.isfinite(t) else 0],'y':[0,length*1000],'x_label':'Time (s)','y_label':'Penetration (µm)'}] if math.isfinite(t) else [],
      'uncertainty':{'status':'not quantified; no parameter distributions or calibration supplied'},
      'evidence':'uncalibrated analytical model prediction','limits':['Ideal smooth-surface Young equilibrium; Wenzel roughness approximation assumes homogeneous chemistry.','Langmuir adsorption is equilibrium and uses an explicit effective adsorption constant; no mixture adsorption competition.','Cox–Voinov dynamic angle is restricted to capillary number <=0.05.','Washburn assumes cylindrical pores, Newtonian liquid and negligible gravity/inertia. Adhesion and runoff are screening indices, not measured outcomes.']}
