"""Deterministic one-at-a-time sweeps of explicit physical assumptions."""
from copy import deepcopy
import math

import numpy as np

from . import control, simulation_catalog
from .common import integer, number


def analyze(p, active_fraction=.1):
    from .simulation_models import run

    key = p["base_model"]
    if key in {"sensitivity", "robustness", "inverse_design", "mixture_response"}:
        raise ValueError("Choose a single-active physical model; nested analyses are unsupported")
    model = simulation_catalog.spec(key)
    template = simulation_catalog.validate(key, p["base_inputs"])
    fields = {f["key"]: f for f in model["fields"] if f["type"] == "number"}
    count = integer(p["points"], "points", 3, 15)
    parameters = p["parameters"]
    if not 1 <= len(parameters) <= 6 or any(not isinstance(v, dict) for v in parameters):
        raise ValueError("Choose 1 to 6 parameter objects")
    variables = []
    for raw in parameters:
        if set(raw) - {"parameter", "low", "high", "scale"}:
            raise ValueError("Unsupported sensitivity parameter fields")
        name = raw.get("parameter")
        if not isinstance(name, str) or name not in fields:
            raise ValueError("Sensitivity parameters must be declared scalar numeric inputs")
        field = fields[name]
        lo = number(raw.get("low"), name + " lower bound", field["min"], field["max"])
        hi = number(raw.get("high"), name + " upper bound", field["min"], field["max"])
        scale = raw.get("scale", "linear")
        if hi <= lo or scale not in ("linear", "log") or (scale == "log" and lo <= 0):
            raise ValueError("Bounds must increase; log bounds must be positive")
        baseline = template[name]
        if baseline is None or not lo <= baseline <= hi:
            raise ValueError("Supply a numeric baseline inside the bounds for " + name)
        variables.append(dict(parameter=name, label=field["label"], unit=field.get("unit", ""),
                              low=lo, high=hi, scale=scale, baseline=baseline))
    if len({v["parameter"] for v in variables}) != len(variables):
        raise ValueError("Sensitivity parameters must be distinct")

    metric = p["metric"]

    def metric_value(output):
        value = output["metrics"].get(metric)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError("Choose an available finite scalar output metric")
        return float(value)

    # A failed baseline invalidates the analysis; failed sweep points stay visible.
    control.check()
    baseline_output = run(key, template, active_fraction)
    baseline_value = metric_value(baseline_output)
    evaluations = [dict(evaluation=1, parameter="baseline", input_value=None,
                        inputs=deepcopy(template), value=baseline_value, status="evaluated", reason="")]
    ranking, series = [], []

    def progress():
        token = control.current()
        if token and token.on_event:
            token.on_event({"kind":"tool_progress", "tool":"sensitivity",
                            "message":str(len(evaluations)) + " sensitivity physics evaluations completed"})

    progress()
    for variable in variables:
        name, lo, hi = variable["parameter"], variable["low"], variable["high"]
        grid = np.geomspace(lo, hi, count) if variable["scale"] == "log" else np.linspace(lo, hi, count)
        grid[0], grid[-1] = lo, hi
        values = sorted(set([*map(float, grid), variable["baseline"]]))
        points = []
        for value in values:
            control.check()
            if value == variable["baseline"]:
                points.append((value, baseline_value))
                continue
            inputs = dict(template, **{name:value})
            row = dict(evaluation=len(evaluations) + 1, parameter=name, input_value=value,
                       inputs=inputs, value=None, status="evaluated", reason="")
            try:
                row["value"] = metric_value(run(key, inputs, active_fraction))
            except (ValueError, ArithmeticError) as exc:
                row.update(status="model domain rejected", reason=str(exc))
            evaluations.append(row)
            points.append((value, row["value"]))
            progress()
        successful = [y for _, y in points if y is not None]
        complete = len(successful) == len(points)
        ranking.append({**variable, "rank":None, "complete":complete,
                        "low_output":points[0][1], "high_output":points[-1][1],
                        "sampled_output_span":max(successful) - min(successful),
                        "max_absolute_change":max(abs(y - baseline_value) for y in successful),
                        "rejected_points":len(points) - len(successful)})
        # Separate segments keep charts from interpolating across domain failures.
        segments = [[]]
        for value, output in points:
            if output is None:
                if segments[-1]:
                    segments.append([])
                continue
            coordinate = ((math.log(value) - math.log(lo)) / (math.log(hi) - math.log(lo))
                          if variable["scale"] == "log" else (value - lo) / (hi - lo))
            segments[-1].append((coordinate, output - baseline_value))
        for segment in segments:
            if segment:
                series.append(dict(name=variable["label"] + " (" + variable["scale"] + " range)",
                                   x=[x for x, _ in segment], y=[y for _, y in segment],
                                   x_label="Position in declared parameter range (0–1)",
                                   y_label="Change in " + metric + " from baseline"))

    control.check()
    ranking.sort(key=lambda row:(not row["complete"], -row["max_absolute_change"]))
    complete_rows = [row for row in ranking if row["complete"]]
    for rank, row in enumerate(complete_rows, 1):
        row["rank"] = rank
    next_measurements = [dict(parameter=row["parameter"], unit=row["unit"],
                              assumed_baseline=row["baseline"], assumed_range=[row["low"], row["high"]],
                              max_absolute_output_change=row["max_absolute_change"],
                              purpose="Check or calibrate " + row["label"] + " for this recipe and scenario to narrow its assumed range.",
                              evidence="sensitivity-based measurement suggestion; no measurement performed")
                         for row in complete_rows if row["max_absolute_change"] > 0][:3]
    notes = ["Ranks depend on the declared ranges and the fixed baseline; compare effects in the selected metric's units.",
             "One-at-a-time sweeps exclude interactions and correlated changes. Sampled ranges are not guaranteed extrema, variance contributions or confidence intervals.",
             "Parameters with rejected sweep points remain unranked; narrowing a range can change the ranking.",
             "Measurement suggestions prioritize numerical sensitivity only; they do not establish identifiability, measurement feasibility or expected information gain."]
    if key in {"geometry_release", "finite_bath", "swelling_release"}:
        notes.append("Release alone identifies D/L²; sensitivity to diffusivity and size does not identify them separately. Fix one using independent evidence before calibration.")
    return dict(metrics={"baseline_value":baseline_value, "physics_evaluations":len(evaluations),
                         "rejected_evaluations":sum(row["status"] != "evaluated" for row in evaluations),
                         "ranked_parameters":len(complete_rows)},
                series=series, rows=[{k:v for k, v in row.items() if k != "inputs"} for row in evaluations],
                evaluations=evaluations, ranking=ranking, base_model=key, base_inputs=template,
                metric=metric, baseline_value=baseline_value, base_equation=baseline_output["equation"],
                base_limitations=baseline_output["limitations"], next_measurements=next_measurements,
                analysis_notes=notes)
