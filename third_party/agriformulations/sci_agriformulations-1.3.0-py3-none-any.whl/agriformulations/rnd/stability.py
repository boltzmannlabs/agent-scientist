"""Chemical retention scenarios and a separate, idealized settling screen."""
import numpy as np
from .common import number

R = 8.314462618  # J/mol/K

def rate_at(kref, ea, reference_c, temperature_c):
    return kref*np.exp(ea*1000/R*(1/(reference_c+273.15)-1/(temperature_c+273.15)))

def fit_stability(rows):
    if not isinstance(rows,list) or len(rows)<6:
        raise ValueError("Provide at least six chemical-assay observations")
    groups={}
    for row in rows:
        temp=number(row.get("temperature_c"),"temperature_c",-50,100)
        day=number(row.get("time_days"),"time_days",0,1e5)
        assay=number(row.get("assay_pct"),"assay_pct",1e-8,200)
        batch=str(row.get("batch_id","unspecified"))
        groups.setdefault((temp,batch),[]).append((day,assay))
    slopes={}
    normalized=[]
    for (temp,batch),values in groups.items():
        baseline=[v for t,v in values if t==0]
        if not baseline:
            raise ValueError("Each temperature/batch needs a day-zero assay")
        if len(set(t for t,_ in values))<3:
            raise ValueError("Each temperature/batch needs three distinct assay times")
        base=float(np.mean(baseline))
        ts=np.array([t for t,_ in values])
        ys=np.log(np.array([v/base for _,v in values]))
        slope=float(-np.dot(ts,ys)/np.dot(ts,ts))
        if slope<=0:
            raise ValueError("Assay data do not identify a positive first-order degradation rate")
        slopes.setdefault(temp,[]).append(slope)
        normalized.extend({"temperature_c":temp,"batch_id":batch,"time_days":t,"retained_fraction":v/base} for t,v in values)
    temps=sorted(slopes)
    if len(temps)<2:
        raise ValueError("At least two temperatures are needed for an Arrhenius fit")
    rates=np.array([np.mean(slopes[t]) for t in temps])
    x=1/(np.array(temps)+273.15)
    slope,intercept=np.polyfit(x,np.log(rates),1)
    ea=float(-slope*R/1000)
    if ea<0:
        raise ValueError("Apparent activation energy is negative; inspect the assay data and mechanism")
    ref=temps[0]
    return {"reference_temperature_c":ref,"reference_rate_per_day":float(np.exp(intercept+slope/(ref+273.15))),
        "activation_energy_kj_mol":ea,"calibrated_temperature_range_c":[min(temps),max(temps)],
        "temperatures_c":temps,"rates_per_day":rates.tolist(),
        "residual_rms_log":float(np.sqrt(np.mean((np.log(rates)-(intercept+slope*x))**2))),
        "weakly_identified":len(temps)<3,"observations":normalized,
        "evidence":"fitted chemical-assay data","model":"first-order degradation plus Arrhenius temperature dependence",
        "limitations":"Temperature interpolation only by default. Physical stability and packaging effects are unmodeled."}

def simulate(raw):
    calibration=raw.get("calibration")
    source=calibration or raw
    kref=number(source.get("reference_rate_per_day",.001),"reference_rate_per_day",0,100)
    ea=number(source.get("activation_energy_kj_mol",50),"activation_energy_kj_mol",0,300)
    ref=number(source.get("reference_temperature_c",25),"reference_temperature_c",-50,100)
    horizon=number(raw.get("horizon_days",180),"horizon_days",.001,1e5)
    threshold=number(raw.get("minimum_retained_fraction",.9),"minimum_retained_fraction",.001,1)
    temperatures=raw.get("temperatures_c",[25,40,54])
    if not isinstance(temperatures,list) or not 1<=len(temperatures)<=12:
        raise ValueError("Provide 1 to 12 temperatures")
    temperatures=[number(t,"temperature_c",-50,100) for t in temperatures]
    calibrated=source.get("calibrated_temperature_range_c")
    if calibrated:
        lo,hi=map(float,calibrated)
        if any(t<lo or t>hi for t in temperatures) and raw.get("allow_extrapolation") is not True:
            raise ValueError("Temperature outside assay calibration range; enable an explicit extrapolation scenario")
    times=np.linspace(0,horizon,241)
    curves=[]
    for temp in temperatures:
        rate=float(rate_at(kref,ea,ref,temp))
        crossing=None if rate==0 else float(-np.log(threshold)/rate)
        curves.append({"temperature_c":temp,"rate_per_day":rate,
            "retained_fraction":np.exp(-rate*times).tolist(),"threshold_crossing_days":crossing,
            "retained_at_horizon":float(np.exp(-rate*horizon))})
    profile=raw.get("temperature_profile",[])
    profile_result=None
    if profile:
        elapsed=[0.]; retention=[1.]; hazard=0.
        for segment in profile:
            duration=number(segment.get("days"),"profile days",.001,1e5)
            temp=number(segment.get("temperature_c"),"profile temperature",-50,100)
            if calibrated and not lo<=temp<=hi and raw.get("allow_extrapolation") is not True:
                raise ValueError("Temperature profile exceeds assay calibration range")
            rate=float(rate_at(kref,ea,ref,temp))
            tt=np.linspace(0,duration,21)[1:]
            elapsed.extend((elapsed[-1]+tt).tolist())
            retention.extend(np.exp(-hazard-rate*tt).tolist())
            hazard+=rate*duration
        profile_result={"times_days":elapsed,"retained_fraction":retention}
    physical=None
    if raw.get("physical"):
        p=raw["physical"]
        diameter=number(p.get("particle_diameter_um"),"particle_diameter_um",.001,1e5)*1e-6
        viscosity=number(p.get("viscosity_mpa_s"),"viscosity_mpa_s",.001,1e9)*.001
        density=number(p.get("density_difference_kg_m3"),"density_difference_kg_m3",-1e5,1e5)
        height=number(p.get("container_height_cm",10),"container_height_cm",.001,1e4)*.01
        velocity=density*9.80665*diameter**2/(18*viscosity)
        physical={"velocity_m_per_day":float(velocity*86400),"direction":"settling" if density>=0 else "creaming",
            "ideal_travel_days":None if velocity==0 else float(height/abs(velocity)/86400),
            "evidence":"idealized Stokes screen",
            "limitations":"Dilute isolated rigid spheres in a Newtonian fluid; no flocculation, yield stress, crystal growth or emulsion coalescence. Not a physical shelf-life prediction."}
    return {"times_days":times.tolist(),"curves":curves,"temperature_profile":profile_result,
        "minimum_retained_fraction":threshold,"physical_screen":physical,
        "evidence":"fitted-assay scenario" if calibration else "assumption-based simulation",
        "parameters":{"reference_rate_per_day":kref,"reference_temperature_c":ref,"activation_energy_kj_mol":ea},
        "extrapolation":bool(calibrated and (any(t<lo or t>hi for t in temperatures) or any(not lo<=float(p["temperature_c"])<=hi for p in profile))),
        "limitations":["Chemical retention alone does not establish shelf life.",
            "Constant mechanism, first-order degradation, fixed packaging and humidity assumptions.",
            "Release activation energy is not chemical-degradation activation energy."]}
