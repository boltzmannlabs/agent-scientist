"""Run-scoped cancellation, durable checkpoints and bounded numerical memoization."""
from collections import OrderedDict
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import threading

import numpy as np
import scipy

class RunCancelled(Exception):
    pass

class RunControl:
    def __init__(self, checkpoint=None, event=None, resume_state=None):
        self.cancelled = threading.Event()
        self.on_checkpoint = checkpoint
        self.on_event = event
        self.resume_state = resume_state or {}
        self._callbacks = []
        self._lock = threading.RLock()

    def check(self):
        if self.cancelled.is_set():
            raise RunCancelled("Stopped at user request")

    def cancel(self):
        with self._lock:
            self.cancelled.set()
            callbacks = list(self._callbacks)
        for callback in callbacks:
            try:
                callback()
            except (OSError, ProcessLookupError):
                pass

    @contextmanager
    def interrupt_with(self, callback):
        with self._lock:
            self.check()
            self._callbacks.append(callback)
        try:
            yield
        finally:
            with self._lock:
                if callback in self._callbacks:
                    self._callbacks.remove(callback)

_local = threading.local()

@contextmanager
def scope(value):
    previous = getattr(_local, "control", None)
    _local.control = value
    try:
        yield value
    finally:
        _local.control = previous

def current():
    return getattr(_local, "control", None)

def check():
    value = current()
    if value:
        value.check()

def checkpoint(state, message="Step results saved"):
    value = current()
    if value and value.on_checkpoint:
        value.on_checkpoint(state, message)
    check()

SCIENTIFIC_SOURCES = (
    "rnd/importing.py", "rnd/import_units.py", "rnd/data_provenance.py", "rnd/bounded_formulation.py",
    "rnd/control.py", "rnd/common.py", "rnd/kinetics.py", "rnd/stability.py", "rnd/dosage.py",
    "rnd/product_development.py", "rnd/simulation_catalog.py", "rnd/simulation_models.py",
    "rnd/simulation_service.py", "rnd/data_tools.py", "rnd/inverse_design.py", "rnd/sensitivity.py",
    "rnd/design_studies.py", "rnd/recipes.py", "rnd/recipe_design.py", "rnd/recipe_inputs.py",
    "rnd/recipe_library.py", "rnd/formulation_types.py", "rnd/formulation_workflow.py", "rnd/costing.py", "rnd/cost_service.py", "release.py", "metrics.py", "design/zero_order.py",
    "physics/geometry.py", "physics/swelling.py", "physics/batched.py",
)


def engine_manifest():
    """Identify numerical code, lower-level solvers and the executing runtime."""
    root = Path(__file__).resolve().parents[1]
    sources = {name:hashlib.sha256((root / name).read_bytes()).hexdigest() for name in SCIENTIFIC_SOURCES}
    manifest = {"sources_sha256":sources,
                "runtime":{"python":platform.python_version(), "numpy":np.__version__, "scipy":scipy.__version__}}
    fingerprint = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()[:16]
    return {"fingerprint":fingerprint, **manifest}


def engine_version():
    return engine_manifest()["fingerprint"]

_cache = OrderedDict()
_cache_lock = threading.RLock()

def compute(kind, inputs, function):
    check()
    key = hashlib.sha256(json.dumps({"kind":kind,"inputs":inputs,"engine":engine_version()},
        sort_keys=True, allow_nan=False).encode()).hexdigest()
    with _cache_lock:
        found = _cache.get(key)
        if found is not None:
            _cache.move_to_end(key)
    if found is not None:
        value = current()
        if value and value.on_event:
            value.on_event({"kind":"cache_hit","message":"Reused identical "+kind+" calculation","tool":kind})
        return deepcopy(found)
    result = function(inputs)
    with _cache_lock:
        _cache[key] = deepcopy(result)
        _cache.move_to_end(key)
        while len(_cache) > 128:
            _cache.popitem(last=False)
    return result

