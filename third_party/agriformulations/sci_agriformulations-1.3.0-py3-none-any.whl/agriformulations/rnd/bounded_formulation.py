"""Small structured authoring action with deterministic purity and balance math.

The agent supplies chemical hypotheses; this module never invents chemicals,
compatibility, or recipe-dependent physical parameters to recover a timed-out run.
"""
from copy import deepcopy
import json
from . import recipe_inputs, formulation_workflow, control
from .common import label, number, integer

def record(state, config, workspace, question=""):
    if not isinstance(config, dict): raise ValueError("Supply a structured formulation request")
    required={"name","format","batch_g","actives","hypotheses","scenarios","literature_query","assumptions"}
    if set(config)!=required: raise ValueError("Formulation request fields: "+", ".join(sorted(required)))
    prior=next((w for w in state.get("formulation_workflows",[]) if w.get("authoring_request")==config and w.get("task")==question and w.get("engine_version")==control.engine_version()),None)
    if prior:return dict(deepcopy(prior),generated_recipes=0,reused=True)
    actives=config["actives"];hypotheses=config["hypotheses"]
    if not isinstance(actives,list) or not 1<=len(actives)<=6:raise ValueError("Supply 1 to 6 individual active targets")
    if not isinstance(hypotheses,list) or not 2<=len(hypotheses)<=6:raise ValueError("Supply 2 to 6 distinct recipe hypotheses")
    if not isinstance(config["assumptions"],list) or not config["assumptions"]:raise ValueError("Record explicit design assumptions")
    assumptions=[label(a,"assumption",2000) for a in config["assumptions"]]
    active_rows=[]
    for active in actives:
        if set(active)!={"name","target_pct","purity_pct"}:raise ValueError("Each active needs name, target_pct and purity_pct")
        purity=number(active["purity_pct"],"technical assay",.001,100)
        active_rows.append({"name":label(active["name"],"active identity"),"role":"active",
                            "pct":number(active["target_pct"],"pure-active target",.000001,100)*100/purity,"purity_pct":purity})
    if len({a["name"].casefold() for a in active_rows})!=len(active_rows):raise ValueError("Active identities must be distinct")
    targets=[];signatures=set();planned=deepcopy(state)
    for hypothesis in hypotheses:
        if set(hypothesis)!={"name","ingredients","balance","process","rationale"}:raise ValueError("Each hypothesis needs name, ingredients, balance, process and rationale")
        rows=deepcopy(active_rows)
        for ingredient in hypothesis["ingredients"]:
            if set(ingredient)!={"name","role","pct"} or ingredient["role"]=="active":raise ValueError("Excipient rows need name, nonactive role and supplied pct")
            rows.append({**ingredient,"purity_pct":100})
        balance=hypothesis["balance"]
        if set(balance)!={"name","role"} or balance["role"]=="active":raise ValueError("Supply a nonactive balance ingredient name and role")
        headroom=100-sum(number(i["pct"],"supplied percentage",0,100) for i in rows)
        if headroom < -1e-8:raise ValueError("Technical actives and excipients exceed 100%; repair the hypothesis without changing fixed active targets")
        rows.append({**balance,"pct":max(0,headroom),"purity_pct":100})
        signature=frozenset(i["name"].casefold() for i in rows if i["role"]!="active" and i["pct"]>0)
        if signature in signatures:raise ValueError("Hypotheses must differ in an excipient identity, not only percentages")
        signatures.add(signature)
        generated=recipe_inputs.create({"name":label(hypothesis["name"],"hypothesis name",200),"format":config["format"],
            "batch_g":config["batch_g"],"mode":"fixed","ingredients":rows,"process":"\n".join(hypothesis["process"])})
        created=generated["recipes"][0]
        if not targets:
            planned["brief"]={**generated["brief"],"name":state.get("brief",{}).get("name") or config["name"]}
        created.update(input_origin="agent",agent_rationale=label(hypothesis["rationale"],"rationale",6000),
                       design_assumptions=assumptions,design_query=question,
                       evidence="Agent-authored research hypothesis; mass balanced, performance unmeasured")
        targets.append(created)
    by_id={r["recipe_id"]:r for r in planned.get("recipes",[])}
    additions=[r for r in targets if r["recipe_id"] not in by_id]
    planned.setdefault("recipes",[]).extend(additions)
    scenarios=[]
    for scenario in config["scenarios"]:
        if set(scenario)!={"name","model","active_name","inputs_json"}:raise ValueError("Scenarios need name, model, individual active_name and inputs_json")
        try:inputs=json.loads(scenario["inputs_json"]) if isinstance(scenario["inputs_json"],str) else scenario["inputs_json"]
        except ValueError:raise ValueError("inputs_json must encode a valid model input object") from None
        scenarios.append({"name":scenario["name"],"model":scenario["model"],"active_name":scenario["active_name"],
                          "inputs":inputs,"assumptions":assumptions})
    request={"name":config["name"],"goal":question[:3000] or config["name"],"recipe_ids":[r["recipe_id"] for r in targets],"scenarios":scenarios}
    if config["literature_query"].strip():request["research"]={"kind":"literature","query":config["literature_query"],"limit":3}
    result=formulation_workflow.record(planned,{"workflow_json":json.dumps(request)},workspace,question)
    result["generated_recipes"]=len(additions)
    result["authoring_request"]=deepcopy(config)
    result["delivery"]={"requested_recipes":len(hypotheses),"saved_recipes":len(targets),
                        "requested_cases":len(hypotheses)*len(scenarios),"saved_cases":result["summary"]["evaluated"]}
    result["answer"]="Requested / saved: "+str(len(hypotheses))+" / "+str(len(targets))+" recipes; "+str(result["delivery"]["requested_cases"])+" / "+str(result["delivery"]["saved_cases"])+" physical cases.\n\n"+result["answer"]
    state.update(planned)
    control.checkpoint(state,"Bounded formulation request and computed comparison saved")
    return result
