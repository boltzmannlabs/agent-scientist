"""Versioned costing scenarios; price research never changes recipe composition."""
from copy import deepcopy

from . import control, costing
from .common import digest, label


def record(state, raw):
    if not isinstance(raw, dict) or set(raw)-{"recipe_id", "prices", "assumptions", "notes"}:
        raise ValueError("Unsupported formulation costing fields")
    rid = label(raw.get("recipe_id"), "recipe ID", 200)
    original = next((r for r in state.get("recipes", []) if r["recipe_id"] == rid), None)
    if original is None:
        raise ValueError("Choose a recipe belonging to this project")
    prices, assumptions = raw.get("prices", {}), raw.get("assumptions", {})
    if not isinstance(prices, dict) or not isinstance(assumptions, dict):
        raise ValueError("Prices and cost assumptions must be objects")
    names = {i["name"] for i in original["ingredients"]}
    if set(prices)-names:
        raise ValueError("Price identities must exactly match ingredients in this recipe")
    snapshot = deepcopy(original)
    currency = assumptions.get("currency", original.get("currency", "INR"))
    if currency == "cost units":
        currency = "INR"
    for item in snapshot["ingredients"]:
        supplied = prices.get(item["name"])
        if supplied is not None:
            if not isinstance(supplied, dict) or set(supplied)-{"cost_per_kg", "price_estimate"}:
                raise ValueError("Each ingredient price needs cost_per_kg or price_estimate")
            item.pop("cost_per_kg", None)
            item.pop("price_estimate", None)
            item.update(deepcopy(supplied))
        elif item.get("cost_per_kg") is not None and original.get("currency") != currency:
            raise ValueError("Re-enter existing ingredient prices in the selected currency; no currency conversion is assumed")
    snapshot["currency"] = currency
    resolved = {**assumptions, "currency": currency}
    result = costing.estimate(snapshot, resolved)
    notes = raw.get("notes", [])
    if not isinstance(notes, list) or len(notes) > 30:
        raise ValueError("Supply up to 30 cost assumption notes")
    notes = [label(n, "cost note", 2000) for n in notes]
    manifest = control.engine_manifest()
    entry = {"recipe_id": rid, "recipe_name": original["name"], "result": result,
             "inputs": {"recipe": snapshot, "assumptions": result["assumptions"], "notes": notes},
             "evidence": "Indicative cost scenario; not a supplier quotation or selling price",
             "engine_version": manifest["fingerprint"], "engine_manifest": manifest}
    entry["cost_id"] = "cost-" + digest(entry)
    previous = next((c for c in state.get("cost_estimates", []) if c["cost_id"] == entry["cost_id"]), None)
    if previous:
        return previous
    state.setdefault("cost_estimates", []).append(entry)
    control.checkpoint(state, "Saved formulation cost scenario")
    return entry
