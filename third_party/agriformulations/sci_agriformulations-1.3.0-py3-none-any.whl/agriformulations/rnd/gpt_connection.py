"""Server-only GPT-6.1 Sol connection through the Responses API."""
import json
import os
import ssl
import threading
import urllib.request
import urllib.error
from pathlib import Path
from urllib.parse import urlsplit
from .common import label
from . import control

MODEL = "gpt-6.1-sol"

class AgentConnectionError(ValueError):
    pass

class GPTConnection:
    def __init__(self, transport=None):
        self._lock=threading.RLock()
        self._key=os.environ.get("OPENAI_API_KEY","")
        self._base=os.environ.get("OPENAI_BASE_URL","https://api.openai.com/v1").rstrip("/")
        self._reasoning="high"
        self._verified=False
        self._transport=transport
    def status(self):
        with self._lock:
            return {"provider":"OpenAI Responses","model":MODEL,"configured":bool(self._key),
                "verified":self._verified,"reasoning":self._reasoning,"endpoint_host":urlsplit(self._base).hostname,"base_url":self._base,
                "key_storage":"server process memory / environment; never project files"}
    def configure(self,raw):
        if raw.get("model",MODEL)!=MODEL:
            raise ValueError("This workspace is pinned to gpt-6.1-sol by user instruction")
        base=raw.get("base_url",self._base).rstrip("/")
        parsed=urlsplit(base)
        if parsed.scheme!="https" or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Use an HTTPS Responses API base URL without embedded credentials")
        reasoning=raw.get("reasoning",self._reasoning)
        if reasoning not in ("low","medium","high","xhigh"):
            raise ValueError("Unknown reasoning effort")
        key=raw.get("api_key","")
        if not isinstance(key,str):raise ValueError("API key must be text")
        with self._lock:
            if raw.get("clear_key") is True:self._key=""
            elif key.strip():self._key=key.strip()
            self._base=base
            self._reasoning=reasoning
            self._verified=False
        return self.status()
    def _post(self,payload,timeout):
        token=control.current()
        if token is None:
            return self._request(payload,timeout)
        # A stopped run releases its worker immediately, even while TLS is connecting.
        # The in-flight HTTP request is discarded and closed as soon as it returns.
        done=threading.Event()
        result=[]
        def request():
            try:
                with control.scope(token):
                    token.check()
                    result.append((True,self._request(payload,timeout)))
            except BaseException as exc:
                result.append((False,exc))
            finally:
                done.set()
        threading.Thread(target=request,daemon=True,name="studio-model-http").start()
        while not done.wait(.1):
            token.check()
        token.check()
        ok,value=result[0]
        if not ok:
            raise value
        return value

    def _request(self,payload,timeout):
        with self._lock:
            key,base=self._key,self._base
        if not key:
            raise AgentConnectionError("Connect OpenAI in Agent connection settings to run GPT-6.1 Sol. Offline tools remain available.")
        if self._transport:
            return self._transport(payload)
        headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"}
        request=urllib.request.Request(base+"/responses",data=json.dumps(payload,allow_nan=False).encode(),headers=headers)
        # Use the operating system trust store when available, keeping verification enabled.
        cafile=os.environ.get("SSL_CERT_FILE")
        if not cafile and Path("/etc/ssl/certs/ca-certificates.crt").exists():
            cafile="/etc/ssl/certs/ca-certificates.crt"
        context=ssl.create_default_context(cafile=cafile)
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,*args,**kwargs):return None
        opener=urllib.request.build_opener(urllib.request.HTTPSHandler(context=context),NoRedirect())
        try:
            with opener.open(request,timeout=timeout) as response:
                control.check()
                data=response.read(8_000_001)
                control.check()
                if len(data)>8_000_000:raise AgentConnectionError("Model response exceeded the 8 MB limit")
                return json.loads(data)
        except urllib.error.HTTPError as exc:
            message={401:"OpenAI rejected the API key",403:"This connection cannot access the requested model",
                404:"GPT-6.1 Sol or the Responses endpoint is unavailable on this connection",
                429:"The OpenAI connection reached a quota or rate limit"}.get(exc.code,"The OpenAI request failed")
            raise AgentConnectionError(f"{message} (HTTP {exc.code}); no alternative model was used") from None
        except (urllib.error.URLError,TimeoutError,OSError):
            raise AgentConnectionError("Could not reach the OpenAI Responses endpoint with a verified TLS connection; check connectivity and certificate configuration") from None
    def respond(self,inputs,instructions,tools=None,timeout=60,max_output_tokens=6000):
        with self._lock:effort=self._reasoning
        payload={"model":MODEL,"input":inputs,"instructions":instructions,"store":False,
            "include":["reasoning.encrypted_content"],"reasoning":{"effort":effort},"max_output_tokens":max_output_tokens}
        if tools:
            payload.update(tools=tools,parallel_tool_calls=False)
        data=self._post(payload,timeout)
        actual=data.get("model","")
        if actual!=MODEL and not actual.startswith(MODEL+"-"):
            raise AgentConnectionError("Provider returned a different model; the call was stopped without substitution")
        if data.get("error"):
            raise AgentConnectionError("OpenAI returned a model error; no result was applied")
        with self._lock:self._verified=True
        return data
    def test(self):
        data=self.respond([{"role":"user","content":"Reply READY only."}],
            "You are a connection check. Reply READY only.",max_output_tokens=2048)
        text=extract_text(data)
        if not text:raise AgentConnectionError("The model returned no text; connection is not verified for conversation")
        return dict(self.status(),test_response=text[:100])

def extract_text(data):
    parts=[]
    for item in data.get("output",[]):
        if item.get("type")=="message":
            for block in item.get("content",[]):
                if block.get("type")=="output_text":parts.append(block.get("text",""))
                elif block.get("type")=="refusal":parts.append(block.get("refusal",""))
    return "\n".join(parts).strip()
