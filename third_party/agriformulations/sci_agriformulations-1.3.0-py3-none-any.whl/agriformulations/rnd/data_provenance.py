"""Declared observation origin, kept separate from review and model validation."""

KINDS = {"synthetic", "experimental", "literature", "unknown"}

def source_kind(item):
    value = item.get("source_kind", "unknown")
    if not isinstance(value,str) or value not in KINDS:
        raise ValueError("source_kind must be synthetic, experimental, literature or unknown")
    return value

def evidence(item, fitted=False):
    kind = source_kind(item)
    if fitted:
        return {"synthetic": "descriptive fit to synthetic data; no empirical validation",
                "experimental": "descriptive fit to declared experimental observations; validation unestablished",
                "literature": "descriptive fit to literature observations; applicability unverified",
                "unknown": "descriptive fit to observations of unspecified origin"}[kind]
    return {"synthetic": "user-declared synthetic observations; not experimental measurements",
            "experimental": "user-declared experimental observations; provenance and QC require review",
            "literature": "user-declared literature observations; source and applicability require review",
            "unknown": "imported observations; source kind unspecified"}[kind]

def gate(item):
    kind = source_kind(item)
    return {"source_kind": kind, "empirical_validation_established": False,
            "product_performance_prediction": "unavailable",
            "reason": "Synthetic data cannot establish empirical validation." if kind == "synthetic" else
                "Observation origin and descriptive fitting do not establish independent validation or a composition-to-performance mapping."}

def fit_metadata(dataset):
    return {"source_kind": source_kind(dataset), "evidence": evidence(dataset, fitted=True),
            "prediction_gate": gate(dataset)}
