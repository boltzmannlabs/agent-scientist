"""Space-filling mixture/process experiment plans and format-specific test queues."""
from itertools import product
import numpy as np
from .common import number, integer
from .recipes import FORMATS

def plan(raw):
    recipes=raw.get("recipes",[])
    if not isinstance(recipes,list) or not 1<=len(recipes)<=100:
        raise ValueError("Generate or select 1 to 100 recipes first")
    n=integer(raw.get("n_recipes",min(6,len(recipes))),"n_recipes",1,len(recipes))
    replicates=integer(raw.get("independent_batches",3),"independent_batches",1,10)
    technical=integer(raw.get("technical_replicates",2),"technical_replicates",1,10)
    seed=integer(raw.get("seed",2026),"seed",0,2**32-1)
    ids=[r["recipe_id"] for r in recipes]
    if len(set(ids))!=len(ids):
        raise ValueError("Recipe identifiers must be unique")
    names=[i["name"] for i in recipes[0]["ingredients"]]
    for recipe in recipes:
        if [i["name"] for i in recipe["ingredients"]]!=names:
            raise ValueError("Mixture design requires a shared ingredient basis")
    matrix=np.array([[number(i["fraction"],"ingredient fraction",0,1) for i in r["ingredients"]] for r in recipes])
    if not np.allclose(matrix.sum(axis=1),1,atol=1e-8):
        raise ValueError("Recipes must sum to 100%")
    span=np.ptp(matrix,axis=0)
    scaled=matrix/np.where(span>1e-10,span,1)
    center=scaled.mean(axis=0)
    selected=[int(np.argmin(np.linalg.norm(scaled-center,axis=1)))]
    while len(selected)<n:
        distances=np.min(np.linalg.norm(scaled[:,None,:]-scaled[selected][None,:,:],axis=2),axis=1)
        distances[selected]=-1
        selected.append(int(np.argmax(distances)))
    factors=raw.get("process_factors",{})
    if not isinstance(factors,dict) or len(factors)>3:
        raise ValueError("Provide at most three process factors")
    for name,levels in factors.items():
        if not isinstance(levels,list) or not 1<=len(levels)<=4:
            raise ValueError("Each process factor needs 1 to 4 explicit levels")
        if any(isinstance(v,(dict,list)) for v in levels):
            raise ValueError("Process levels must be scalar values")
    combinations=list(product(*factors.values())) if factors else [()]
    if len(combinations)*n*replicates>500:
        raise ValueError("Experiment exceeds 500 independent batches; reduce factors or replicates")
    days=raw.get("sampling_days",[0,1,3,5,10,20,35,60])
    days=sorted(set(number(t,"sampling day",0,1e5) for t in days))
    if not 3<=len(days)<=50:
        raise ValueError("Choose 3 to 50 sampling days")
    rng=np.random.default_rng(seed)
    runs=[]
    for i in selected:
        recipe=recipes[i]
        for levels in combinations:
            for rep in range(1,replicates+1):
                runs.append({"recipe_id":recipe["recipe_id"],"recipe_name":recipe["name"],
                    "batch_id":f"B-{len(runs)+1:04d}","independent_batch":rep,
                    "technical_replicates":technical,"process_settings":dict(zip(factors,levels)),
                    "batch_g":recipe["batch_g"],"ingredients":recipe["ingredients"],
                    "preparation_steps":recipe.get("process",[]),"role":"candidate"})
    # Explicit reference batches remain separate from the mixture-design recipe identifiers.
    if raw.get("reference_name"):
        for rep in range(1,replicates+1):
            runs.append({"recipe_id":"REFERENCE","recipe_name":str(raw["reference_name"]),
                "batch_id":f"REF-{rep:03d}","independent_batch":rep,"technical_replicates":technical,
                "process_settings":{},"role":"reference","ingredients":[],"batch_g":None})
    rng.shuffle(runs)
    for i,run in enumerate(runs,1): run["run_order"]=i
    tests=sorted(set(test for i in selected for test in FORMATS[recipes[i]["format"]]["tests"]))
    schedule=[{"test":test,"status":"planned","method":"assign validated laboratory method","acceptance":"define product-specific limits"} for test in tests]
    return {"runs":runs,"selected_recipe_ids":[ids[i] for i in selected],"sampling_days":days,
        "test_queue":schedule,"seed":seed,"n_independent_batches":len(runs),
        "n_technical_readings_per_time":len(runs)*technical,
        "design":"Greedy maximin mixture screening crossed with explicit process levels; seeded randomized order",
        "limitations":["Screening design, not a claim of D-optimality or model-identification sufficiency.",
            "Technical readings do not increase the number of independent batches.",
            "Add an untreated control and suitable comparator to efficacy studies; a reference formulation alone is not an untreated control.",
            "Record deviations, actual process settings and raw assay files against batch identifiers."]}
