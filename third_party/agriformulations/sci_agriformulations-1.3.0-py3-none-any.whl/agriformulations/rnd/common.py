"""Shared validation and deterministic serialization for the R&D workbench."""
import hashlib
import json
import math

def number(value, name, low=0.0, high=1e12):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number")
    try:
        value = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a number") from exc
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} must lie in [{low}, {high}]")
    return value

def integer(value, name, low=1, high=1000):
    value = number(value, name, low, high)
    if value != int(value):
        raise ValueError(f"{name} must be an integer")
    return int(value)

def label(value, name="name", limit=200):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"{name} is required (maximum {limit} characters)")
    return value.strip()

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()[:16]

def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if hasattr(value, "item"):
        return clean(value.item())
    if isinstance(value, float):
        return float(value) if math.isfinite(value) else None
    return value
