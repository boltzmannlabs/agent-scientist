"""Multi-geometry, heterogeneous, finite-bath and swelling physics (v4)."""

from .geometry import GEOMETRY_DIMENSIONS, analytic_release_fraction, fv_operator
from .batched import batched_release
from .finite_bath import finite_bath_release
from .swelling import swelling_release
from .identifiability import profile_grid, unidentifiable_pairs
from .verification import verify_finite_bath, verify_geometry, verify_heterogeneous, verify_swelling
from .features import physics_features

__all__ = [
    "GEOMETRY_DIMENSIONS",
    "analytic_release_fraction",
    "fv_operator",
    "batched_release",
    "finite_bath_release",
    "swelling_release",
    "profile_grid",
    "unidentifiable_pairs",
    "verify_geometry",
    "verify_finite_bath",
    "verify_heterogeneous",
    "verify_swelling",
    "physics_features",
]
