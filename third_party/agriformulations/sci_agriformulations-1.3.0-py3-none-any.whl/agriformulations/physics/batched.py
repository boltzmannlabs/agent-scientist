"""Batched GPU/CPU driver for the multi-geometry FV solvers (v4).

Generalizes the v2 sphere stepper to any geometry (and heterogeneous
diffusivity profiles): states advance in dimensionless tau with explicit
Euler in float64 on torch, recording the released fraction at each scenario's
own tau targets.  Scenario grids are synthetic sensitivity calculations, not
experimental data.
"""

from __future__ import annotations

import time

import numpy as np

from .geometry import GEOMETRY_DIMENSIONS, fv_operator


def _resolve_device(device: str):
    import torch

    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("explicit device='cuda' requested but CUDA is unavailable")
    resolved = "cuda" if device in ("auto", "cuda") and torch.cuda.is_available() else "cpu"
    return torch, resolved


def batched_release(
    rates,
    times,
    *,
    geometry: str = "sphere",
    shells: int = 40,
    device: str = "auto",
    dt_safety: float = 0.5,
    diffusivity_profile=None,
):
    """Released fraction ``F(rate_i * time_j)`` per scenario for one geometry.

    Returns ``(fractions, metadata)``; ``fractions[i, j]`` is the released
    fraction after physical time ``times[j]`` at dimensionless rate
    ``rates[i]`` (= D/L^2 per time unit).
    """
    if geometry not in GEOMETRY_DIMENSIONS:
        raise ValueError(f"geometry must be one of {sorted(GEOMETRY_DIMENSIONS)}")
    torch, resolved = _resolve_device(device)
    started = time.perf_counter()
    rates = np.asarray(rates, dtype=float)
    times = np.asarray(times, dtype=float)
    tau_matrix = np.outer(rates, times)
    tau_targets, inverse = np.unique(tau_matrix.ravel(), return_inverse=True)
    index_of = inverse.reshape(tau_matrix.shape)
    max_tau = tau_matrix.max(axis=1)

    operator, volumes = fv_operator(shells, geometry, diffusivity_profile)
    from .geometry import boundary_leak

    boundary_conductance = boundary_leak(shells, geometry, diffusivity_profile)

    operator_t = torch.tensor(operator, dtype=torch.float64, device=resolved)
    weights = torch.tensor(volumes / volumes.sum(), dtype=torch.float64, device=resolved)
    eigenvalues = np.linalg.eigvals(operator)
    eigen_scale = float(np.max(np.abs(eigenvalues.real)))
    dt = float(dt_safety / eigen_scale)

    batch = len(rates)
    max_tau_t = torch.tensor(max_tau, dtype=torch.float64, device=resolved)
    state = torch.ones((batch, shells), dtype=torch.float64, device=resolved)
    flux_released = torch.zeros(batch, dtype=torch.float64, device=resolved)
    recorded = torch.full((batch, len(tau_targets)), float("nan"), dtype=torch.float64, device=resolved)

    steps_done = 0
    next_target = 0
    tau_now = 0.0
    while next_target < len(tau_targets):
        while next_target < len(tau_targets) and tau_now + 1e-12 >= tau_targets[next_target]:
            reached = max_tau_t >= tau_targets[next_target] - 1e-12
            recorded[reached, next_target] = flux_released[reached]
            next_target += 1
        if next_target >= len(tau_targets):
            break
        advance = min(dt, float(tau_targets[next_target] - tau_now))
        sink = state[:, -1]
        state = state + advance * (state @ operator_t.T)
        flux_released = flux_released + advance * boundary_conductance * sink
        tau_now += advance
        steps_done += 1

    released_inventory = 1.0 - (state * weights).sum(dim=1)
    mass_balance_error = float(torch.max(torch.abs(released_inventory - flux_released)).item())
    gathered = recorded.cpu().numpy()
    fractions = np.take_along_axis(gathered, index_of, axis=1)
    metadata = {
        "solver": f"explicit euler conservative FV ({geometry}), float64",
        "device": resolved,
        "geometry": geometry,
        "shells": shells,
        "batch_scenarios": int(batch),
        "n_tau_targets": int(len(tau_targets)),
        "dt": dt,
        "dt_safety": dt_safety,
        "steps": steps_done,
        "max_tau": float(tau_targets[-1]),
        "mass_balance_error": mass_balance_error,
        "wall_s": round(time.perf_counter() - started, 4),
        "dtype": "float64",
    }
    return fractions, metadata
