"""Finite-bath release: a well-stirred compartment instead of a perfect sink (v4).

The domain is coupled to a bath of relative volume ``bath_ratio = V_bath /
V_domain`` through the outer face, with equal partition coefficients.  The
augmented state ``(c_cells, b_tilde)`` with ``b_tilde`` the bath mass in
domain-volume units conserves ``sum(w c) + b_tilde = 1`` exactly, so released
fraction = ``b_tilde(tau)``.  Verification anchors: the bath plateau must
approach ``K/(1+K)`` with ``K = bath_ratio``; a large ratio must approach the
perfect-sink solution; total mass must balance to roundoff.
"""

from __future__ import annotations

import time

import numpy as np

from .geometry import GEOMETRY_DIMENSIONS, boundary_leak, cell_geometry, fv_operator


def _resolve_device(device: str):
    import torch

    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("explicit device='cuda' requested but CUDA is unavailable")
    resolved = "cuda" if device in ("auto", "cuda") and torch.cuda.is_available() else "cpu"
    return torch, resolved


def finite_bath_release(
    tau_targets,
    *,
    bath_ratio: float,
    geometry: str = "sphere",
    shells: int = 40,
    device: str = "auto",
    dt_safety: float = 0.5,
) -> tuple[np.ndarray, dict]:
    """Released-to-bath fraction at each dimensionless time for one scenario.

    Returns ``(fractions, metadata)`` with ``fractions[k]`` the bath mass
    fraction at ``tau_targets[k]``.
    """
    if geometry not in GEOMETRY_DIMENSIONS:
        raise ValueError(f"geometry must be one of {sorted(GEOMETRY_DIMENSIONS)}")
    if not bath_ratio > 0:
        raise ValueError("bath_ratio must be positive")
    torch, resolved = _resolve_device(device)
    started = time.perf_counter()
    tau = np.unique(np.asarray(tau_targets, dtype=float))

    operator, volumes = fv_operator(shells, geometry)
    boundary_conductance = boundary_leak(shells, geometry)

    # Augmented linear system.  The operator's last row already carries the
    # sink leak -conduct*c; finite bath replaces the sink with coupling to a
    # well-stirred compartment: -conduct*(c - b) with b = b_tilde/bath_ratio
    # (b_tilde is bath mass in domain-volume units, so F = b_tilde).
    n = shells
    augmented = np.zeros((n + 1, n + 1))
    augmented[:n, :n] = operator
    h = 1.0 / shells
    edges, face_area, _ = cell_geometry(shells, geometry)
    leak_conduct = face_area[n] / (h / 2.0)
    augmented[n - 1, n] = (leak_conduct / volumes[n - 1]) / bath_ratio
    augmented[n, n - 1] = leak_conduct / volumes.sum()
    augmented[n, n] = -(leak_conduct / volumes.sum()) / bath_ratio

    eigen_scale = float(np.max(np.abs(np.linalg.eigvals(augmented).real)))
    dt = float(dt_safety / eigen_scale)
    state = np.zeros(n + 1)
    state[:n] = 1.0

    state_t = torch.tensor(state, dtype=torch.float64, device=resolved).unsqueeze(0)
    operator_t = torch.tensor(augmented, dtype=torch.float64, device=resolved)
    weights = torch.tensor(volumes / volumes.sum(), dtype=torch.float64, device=resolved)
    out = torch.zeros(len(tau), dtype=torch.float64, device=resolved)

    steps_done = 0
    next_target = 0
    tau_now = 0.0
    while next_target < len(tau):
        while next_target < len(tau) and tau_now + 1e-12 >= tau[next_target]:
            out[next_target] = state_t[0, n]
            next_target += 1
        if next_target >= len(tau):
            break
        advance = min(dt, float(tau[next_target] - tau_now))
        state_t = state_t + advance * (state_t @ operator_t.T)
        tau_now += advance
        steps_done += 1

    fractions = out.cpu().numpy()
    inventory = float((state_t[0, :n] * weights).sum().item())
    bath = float(state_t[0, n].item())
    metadata = {
        "solver": f"finite-bath coupled FV ({geometry}, ratio={bath_ratio}), float64",
        "device": resolved,
        "geometry": geometry,
        "shells": shells,
        "bath_ratio": bath_ratio,
        "dt": dt,
        "steps": steps_done,
        "equilibrium_plateau_expected": bath_ratio / (1.0 + bath_ratio),
        "released_at_last_tau": float(fractions[-1]),
        "mass_balance_error": abs(1.0 - inventory - bath),
        "wall_s": round(time.perf_counter() - started, 4),
        "dtype": "float64",
    }
    return fractions, metadata
