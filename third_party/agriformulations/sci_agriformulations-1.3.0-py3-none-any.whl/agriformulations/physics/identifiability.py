"""Identifiability analysis by batched profile likelihood (v4).

Which parameter combinations can release data actually recover?  Synthetic
observations from a known model are fitted over a grid of parameter pairs
using the GPU-batched verified forward kernel; the profile likelihood along
one parameter marginalizes the other.  A parameter is flagged unidentifiable
alone when the profiled chi-square never rises above the 95% threshold on
both sides of its minimum - the classic D-versus-R ridge, since the forward
model depends on D/R^2 only.  The resulting table restricts what v6 inversion
may claim to recover.
"""

from __future__ import annotations

import numpy as np

from ..accelerated import batch_sphere_predictions

CHI2_THRESHOLD_1DOF_95 = 3.841


def profile_grid(
    *,
    times,
    true_rate: float,
    noise: float,
    pair: tuple[str, str],
    grid: int = 41,
    seed: int = 271828,
    device: str = "auto",
) -> dict:
    """chi-square surface over one parameter pair for synthetic data.

    Pairs: ``("D", "R")`` tests the joint diffusivity/radius ridge (forward
    model depends on D/R^2 only); ``("rate", "loading")`` tests the
    identifiable pair of the released-fraction model.
    """
    rng = np.random.default_rng(seed)
    times = np.asarray(times, dtype=float)
    forward = batch_sphere_predictions(np.array([true_rate]), times, device=device)[0][0]
    if pair == ("D", "R"):
        observed = forward + noise * rng.normal(size=times.size)
        # Matched grids: the D axis spans the R axis squared so the exact
        # compensation ridge D ~ R^2 stays inside the grid on both axes; a
        # narrower D grid would fake R-identifiability at its boundary.
        r_axis = np.geomspace(1.0 / 10.0, 10.0, grid)
        d_axis = np.geomspace(1.0 / 100.0, 100.0, grid)
        dd, rr = np.meshgrid(d_axis, r_axis, indexing="ij")
        rates = (dd / rr**2).ravel()
        predicted = batch_sphere_predictions(rates, times, device=device)[0]
        chi2 = (((predicted - observed) / noise) ** 2).sum(axis=1).reshape(grid, grid)
        profiles = {"D": chi2.min(axis=1), "R": chi2.min(axis=0)}
        axes = {"D": d_axis, "R": r_axis}
    elif pair == ("rate", "loading"):
        loading_true = 0.9
        observed = loading_true * forward + noise * rng.normal(size=times.size)
        rate_axis = np.geomspace(true_rate / 10.0, true_rate * 10.0, grid)
        load_axis = np.linspace(0.5, 1.3, grid)
        fraction_curves = batch_sphere_predictions(rate_axis, times, device=device)[0]
        residuals = (fraction_curves[None, :, :] * load_axis[:, None, None] - observed[None, None, :]) / noise
        chi2 = (residuals**2).sum(axis=2).T  # (rate, loading)
        profiles = {"rate": chi2.min(axis=1), "loading": chi2.min(axis=0)}
        axes = {"rate": rate_axis, "loading": load_axis}
    else:
        raise ValueError(f"unsupported pair {pair}")
    return {"pair": pair, "chi2": chi2, "profiles": profiles, "axes": axes,
            "chi2_min": float(chi2.min()), "noise": noise}


def _axis_unidentifiable(profile: np.ndarray) -> bool:
    """Flat profile: the chi-square never rises 3.84 above the global minimum
    on both sides of the minimum (a one-sided wall is still informative)."""
    rising = profile - float(profile.min()) > CHI2_THRESHOLD_1DOF_95
    if not rising.any():
        return True
    best_index = int(np.argmin(profile))
    return not (rising[:best_index].any() and rising[best_index + 1 :].any())


def unidentifiable_pairs(profile_records: list[dict]) -> list[dict]:
    """Summarize profile records into the identifiability table."""
    rows = []
    for record in profile_records:
        a, b = record["pair"]
        for name in (a, b):
            rows.append(
                {
                    "pair": f"{a}|{b}",
                    "parameter": name,
                    "unidentifiable_alone": bool(_axis_unidentifiable(record["profiles"][name])),
                    "profile_range_chi2": float(
                        record["profiles"][name].max() - record["profiles"][name].min()
                    ),
                    "chi2_min": record["chi2_min"],
                }
            )
    return rows
