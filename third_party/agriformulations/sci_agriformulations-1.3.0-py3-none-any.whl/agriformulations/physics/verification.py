"""Per-geometry numerical gates for the v4 physics package.

Same gate structure and thresholds as v2: mass balance <= 1e-6, mesh
convergence monotone across 20/40/80 shells, time-step convergence below the
mesh error, torch CPU/CUDA float64 agreement (abs 1e-8, rel 1e-6), analytic
agreement, and the finite-bath anchors (plateau K/(1+K), sink limit).
"""

from __future__ import annotations

import numpy as np

from .batched import batched_release
from .finite_bath import finite_bath_release
from .geometry import analytic_release_fraction

TAU_GRID = [0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 3.0]


def verify_geometry(geometry: str, device: str = "auto") -> dict:
    tau = np.array(TAU_GRID)
    analytic = analytic_release_fraction(tau, geometry)
    mesh_errors = {}
    metadata = {}
    for shells in (20, 40, 80):
        grid, meta = batched_release(np.array([1.0]), tau, geometry=geometry, shells=shells, device=device)
        mesh_errors[shells] = float(np.max(np.abs(grid[0] - analytic)))
        metadata[shells] = meta
    coarse, _ = batched_release(np.array([1.0]), tau, geometry=geometry, shells=80, device=device, dt_safety=0.5)
    fine, _ = batched_release(np.array([1.0]), tau, geometry=geometry, shells=80, device=device, dt_safety=0.25)
    dt_change = float(np.max(np.abs(coarse[0] - fine[0])))
    record = {
        "geometry": geometry,
        "mesh_errors_vs_analytic": mesh_errors,
        "time_step_convergence": {
            "max_fraction_change_dt_safety_0p5_to_0p25": dt_change,
            "below_mesh_error": bool(dt_change < mesh_errors[80]),
        },
        "gates": {
            "mesh_convergence": bool(mesh_errors[20] > mesh_errors[40] > mesh_errors[80]),
            "mass_balance": bool(all(m["mass_balance_error"] <= 1e-6 for m in metadata.values())),
            "analytic_agreement_80": bool(mesh_errors[80] <= 5e-3),
        },
        "shells80_metadata": metadata[80],
    }
    try:
        cpu_grid, _ = batched_release(np.array([1.0, 0.5]), tau, geometry=geometry, shells=40, device="cpu")
        cuda_grid, _ = batched_release(np.array([1.0, 0.5]), tau, geometry=geometry, shells=40, device="cuda")
        abs_dev = float(np.max(np.abs(cpu_grid - cuda_grid)))
        rel_dev = float(np.max(np.abs(cpu_grid - cuda_grid) / np.maximum(np.abs(cpu_grid), 1e-12)))
        record["cpu_cuda_agreement"] = {
            "max_abs": abs_dev, "max_rel": rel_dev,
            "within_tolerance": bool(abs_dev <= 1e-8 and rel_dev <= 1e-6),
        }
        record["gates"]["cpu_cuda_float64"] = record["cpu_cuda_agreement"]["within_tolerance"]
    except RuntimeError:
        record["cpu_cuda_agreement"] = {"note": "CUDA unavailable; single-device execution"}
    return record


def verify_finite_bath(device: str = "auto") -> dict:
    tau = np.array([0.05, 0.25, 1.0, 3.0, 10.0, 30.0])
    records = {}
    for ratio in (1.0, 9.0, 1000.0):
        fractions, meta = finite_bath_release(tau, bath_ratio=ratio, shells=80, device=device)
        expected_plateau = ratio / (1.0 + ratio)
        records[ratio] = {
            "mass_balance_error": meta["mass_balance_error"],
            "plateau_error": abs(float(fractions[-1]) - expected_plateau),
        }
    sink, _ = batched_release(np.array([1.0]), tau, geometry="sphere", shells=80, device=device)
    large, _ = finite_bath_release(tau, bath_ratio=1000.0, shells=80, device=device)
    sink_limit_diff = float(np.max(np.abs(large - sink[0])))
    return {
        "per_ratio": {str(k): v for k, v in records.items()},
        "sink_limit_max_abs_diff_ratio_1000": sink_limit_diff,
        "gates": {
            "mass_balance": bool(all(v["mass_balance_error"] <= 1e-6 for v in records.values())),
            "plateau": bool(all(v["plateau_error"] <= 1e-3 for v in records.values())),
            "sink_limit": bool(sink_limit_diff <= 5e-3),
        },
    }


def verify_heterogeneous(device: str = "auto") -> dict:
    """A coated matrix (outer cells 10x less permeable) must release slower
    than uniform, and mass must still balance."""
    shells = 40
    profile = np.ones(shells)
    profile[int(shells * 0.75) :] = 0.1
    tau = np.array([0.1, 0.5, 1.0, 2.0])
    coated, meta_coated = batched_release(
        np.array([1.0]), tau, geometry="sphere", shells=shells, device=device,
        diffusivity_profile=profile,
    )
    uniform, meta_uniform = batched_release(
        np.array([1.0]), tau, geometry="sphere", shells=shells, device=device
    )
    slower = bool(np.all(coated[0] <= uniform[0] + 1e-12))
    return {
        "coated_end_fraction": float(coated[0][-1]),
        "uniform_end_fraction": float(uniform[0][-1]),
        "gates": {
            "coating_slows_release": slower,
            "mass_balance": bool(
                meta_coated["mass_balance_error"] <= 1e-6 and meta_uniform["mass_balance_error"] <= 1e-6
            ),
        },
    }


def verify_swelling(device: str = "auto") -> dict:
    from .swelling import swelling_release

    times = np.array([1.0, 5.0, 20.0, 50.0])
    fixed, meta_fixed = swelling_release(
        times, rate=0.05, swelling_rate=0.0, swelling_exponent=1.0, device=device
    )
    swollen, meta_swan = swelling_release(
        times, rate=0.05, swelling_rate=0.05, swelling_exponent=0.5, device=device
    )
    reference, _ = batched_release(np.array([0.05]), times, geometry="sphere", shells=40, device=device)
    return {
        "ks0_matches_fixed_solver_max_abs": float(np.max(np.abs(fixed - reference[0]))),
        "swollen_slower": bool(swollen[-1] < fixed[-1]),
        "monotone": bool(np.all(np.diff(swollen) >= -1e-12)),
        "mass_balance": bool(meta_fixed["mass_balance_error"] <= 1e-6),
        "gates": {
            "ks0_reduction": bool(np.max(np.abs(fixed - reference[0])) <= 1e-12),
            "swelling_slows_release": bool(swollen[-1] < fixed[-1]),
        },
    }
