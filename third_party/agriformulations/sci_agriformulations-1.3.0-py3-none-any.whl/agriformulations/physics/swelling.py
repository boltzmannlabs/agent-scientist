"""Swelling-dependent release: growing characteristic length (v4).

R(t) = R0 (1 + k_s t^m) with constant D in the material frame.  We use the
standard quasi-static reduction: the dimensionless time becomes an integral
of the instantaneous rate, tau(t) = (D/R0^2) * integral_0^t dt'/(1+k_s t'^m)^2,
and the released fraction is the fixed-geometry solution evaluated at
tau(t).  The advection term from boundary motion is neglected - a registered
approximation, not an exact moving-boundary solve.  Verification: k_s = 0
reduces exactly to the fixed-geometry solver; monotonicity in time; the
swollen release is slower than the unswollen one at equal physical time.
"""

from __future__ import annotations

import numpy as np
from scipy.integrate import quad

from .batched import batched_release
from .geometry import GEOMETRY_DIMENSIONS


def effective_tau(
    times,
    *,
    rate: float,
    swelling_rate: float,
    swelling_exponent: float,
    integration_points: int = 2001,
) -> np.ndarray:
    """Integrate the quasi-static clock with error-controlled quadrature.

    Natural swelling time and log-time resolve the rapid initial change even
    over long requested horizons. ``integration_points`` is retained for API
    compatibility; accuracy is no longer determined by a uniform grid.
    """
    times = np.atleast_1d(np.asarray(times, dtype=float))
    if times.ndim != 1 or not np.isfinite(times).all() or np.any(times < 0):
        raise ValueError("times must be finite, nonnegative and one-dimensional")
    if not all(np.isfinite(v) for v in (rate, swelling_rate, swelling_exponent)) or rate < 0 or swelling_rate < 0 or swelling_exponent <= 0:
        raise ValueError("rate and swelling_rate must be finite and nonnegative; exponent must be positive")
    if rate == 0 or swelling_rate == 0:
        return rate * times
    if swelling_exponent == 1:
        return rate * times / (1 + swelling_rate * times)

    log_scale = -np.log(swelling_rate) / swelling_exponent
    first, first_error = quad(lambda x: 1 / (1 + x**swelling_exponent)**2,
                              0, 1, epsabs=1e-12, epsrel=1e-11, limit=200)
    if first_error > 1e-9 * max(first, 1e-12):
        raise ValueError("Swelling integral did not meet its accuracy tolerance")
    lookup = {}
    for t in np.unique(times):
        if t == 0:
            lookup[t] = 0.
            continue
        log_x = np.log(t) - log_scale
        if log_x <= 0:
            q = np.exp(swelling_exponent * log_x)
            value, error = quad(lambda u: 1 / (1 + q * u**swelling_exponent)**2,
                                0, 1, epsabs=1e-12, epsrel=1e-11, limit=200)
            integral = t * value
        else:
            tail, error = quad(lambda s: np.exp(s - 2 * np.logaddexp(0, swelling_exponent * s)),
                               0, log_x, epsabs=1e-12, epsrel=1e-11, limit=200)
            value = first + tail
            integral = np.exp(log_scale) * value
        if error > 1e-9 * max(value, 1e-12) or not np.isfinite(integral):
            raise ValueError("Swelling integral did not meet its accuracy tolerance")
        lookup[t] = rate * integral
    return np.array([lookup[t] for t in times])


def swelling_release(
    times,
    *,
    rate: float,
    swelling_rate: float,
    swelling_exponent: float,
    geometry: str = "sphere",
    shells: int = 40,
    device: str = "auto",
) -> tuple[np.ndarray, dict]:
    """Released fraction under quasi-static swelling; see module docstring."""
    if geometry not in GEOMETRY_DIMENSIONS:
        raise ValueError(f"geometry must be one of {sorted(GEOMETRY_DIMENSIONS)}")
    tau = effective_tau(
        times,
        rate=rate,
        swelling_rate=swelling_rate,
        swelling_exponent=swelling_exponent,
    )
    fractions, meta = batched_release(
        np.array([1.0]), tau, geometry=geometry, shells=shells, device=device
    )
    meta.update(
        {
            "model": "quasi-static swelling (advection term neglected)",
            "rate": rate,
            "swelling_rate": swelling_rate,
            "swelling_exponent": swelling_exponent,
            "effective_tau": tau.tolist(),
        }
    )
    return fractions[0], meta
