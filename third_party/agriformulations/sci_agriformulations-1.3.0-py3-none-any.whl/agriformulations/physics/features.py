"""Physics features for the surrogate layer (v4 -> v5).

Per release curve: the calibrated dimensionless rate D/L^2 (jointly
identified, never a measured molecular diffusivity), the geometry tag from
the catalog ontology, a finite-bath correction factor when the assay protocol
declares one, and fit quality.  These covariates feed the v5 surrogates.
"""

from __future__ import annotations

import pandas as pd

from ..release import fit_release

UNIT_FAMILY_SCALE = {"percent": 100.0, "mass_per_mass": 1000.0, "fraction": 1.0}


def _scale_for(unit: str) -> tuple[float, str]:
    from ..units import family

    unit_family = family(unit)
    if unit_family == "percent":
        return 100.0, "percent scale"
    if unit_family == "mass_per_mass":
        return 1000.0, "declared 1000 mg/g mass bound, not a measured loading"
    return 1.0, "fraction scale"


def physics_features(catalog) -> pd.DataFrame:
    """One row per catalog curve with calibrated physics covariates."""
    rows = []
    for key, entry in sorted(catalog.studies.items()):
        observations = entry["observations"]
        if "included_primary" in observations.columns:
            observations = observations[observations["included_primary"].astype(bool)]
        if "qc_status" in observations.columns:
            observations = observations[observations["qc_status"] == "accepted"]
        if "in_target" in observations.columns:
            observations = observations[observations["in_target"].astype(bool)]
        formulations = {f.formulation_id: f for f in catalog.formulations if f.study_id == entry["meta"].get("study_id")}
        protocols = entry["meta"].get("protocols") or [{}]
        protocol = protocols[0]
        for curve_id, curve in observations.groupby("curve_id", sort=True):
            unit = curve["unit"].iloc[0] if "unit" in curve.columns else "%"
            scale, note = _scale_for(str(unit))
            geometry = "sphere"
            formulation = formulations.get(str(curve["formulation_id"].iloc[0]))
            if formulation is not None:
                geometry = formulation.geometry
            try:
                fit = fit_release(
                    curve["time"].astype(float).to_numpy(),
                    curve["value"].astype(float).to_numpy() / scale,
                    "spherical_diffusion",
                )
                rate = float(fit.parameters["rate"])
                r2 = fit.metrics.get("r2")
            except Exception:
                rate, r2 = float("nan"), float("nan")
            bath_ratio = protocol.get("bath_to_sample_ratio")
            finite_bath_factor = (
                bath_ratio / (1.0 + bath_ratio) if bath_ratio else None
            )
            rows.append(
                {
                    "study_key": key,
                    "study_id": entry["meta"].get("study_id", key),
                    "curve_id": curve_id,
                    "formulation_id": str(curve["formulation_id"].iloc[0]),
                    "condition_id": str(curve["condition_id"].iloc[0]),
                    "unit": unit,
                    "n_points": int(len(curve)),
                    "end_time_native": float(curve["time"].astype(float).max()),
                    "calibrated_rate_per_time": rate,
                    "calibrated_r2": r2,
                    "geometry_tag": geometry,
                    "assay_type": protocol.get("assay_type"),
                    "sink_condition": protocol.get("sink_condition"),
                    "finite_bath_factor": finite_bath_factor,
                    "scale_note": note,
                }
            )
    return pd.DataFrame(rows)
