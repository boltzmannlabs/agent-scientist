"""Multi-geometry release physics: analytic series and FV operators (v4).

One construction generalizes slab (d=0), cylinder (d=1) and sphere (d=2):
face areas scale as r^d and cell volumes as the integral of r^d, giving a
conservative radial/slab operator with a perfect-sink outer boundary and zero
flux at the center/symmetry plane.  All operators live in dimensionless time
tau = D t / L^2 and are advanced by the same batched explicit stepper as the
v2 sphere solver; verification gates live in ``verification.py``.
"""

from __future__ import annotations

import math

import numpy as np

GEOMETRY_DIMENSIONS = {"slab": 0, "cylinder": 1, "sphere": 2}

# Bessel J0 zeros for the cylinder eigenvalue series.
J0_ZEROS = np.array(
    [2.4048255577, 5.5200781103, 8.6537279129, 11.7915344391, 14.9309177085,
     18.0710639679, 21.2116366299, 24.3524715308, 27.4934791320, 30.6346064684]
)


def analytic_release_fraction(tau, geometry: str, modes: int = 200) -> np.ndarray:
    """Eigenmode-series released fraction F(tau) for a uniform slab/cylinder/
    sphere under perfect-sink boundary conditions."""
    tau = np.asarray(tau, dtype=float)
    if tau.ndim > 1 or not np.isfinite(tau).all() or np.any(tau < 0):
        raise ValueError("tau must be a finite, nonnegative scalar or one-dimensional array")
    if isinstance(modes, bool) or not isinstance(modes, (int, np.integer)) or modes < 1:
        raise ValueError("modes must be a positive integer")
    scalar = tau.ndim == 0
    flat = np.atleast_1d(tau)
    if geometry not in GEOMETRY_DIMENSIONS:
        raise ValueError(f"geometry must be one of {sorted(GEOMETRY_DIMENSIONS)}")
    if not flat.size:
        return flat.copy()
    if geometry == "sphere":
        from agriformulations.release import release_fraction

        return release_fraction(tau, "spherical_diffusion", {"rate": 1.0})
    values = np.empty_like(flat)
    # At short times a fixed eigenmode cutoff falsely reports its omitted
    # initial inventory as release. Heat-content expansions avoid subtraction
    # of nearly equal numbers and have the correct zero-diffusion limit.
    early = flat < (0.01 if geometry == "slab" else 1e-5)
    t = flat[early]
    values[early] = 2 * np.sqrt(t / np.pi) if geometry == "slab" else (
        4 * np.sqrt(t / np.pi) - t - t**1.5 / (3 * np.sqrt(np.pi)) - t**2 / 8
    )
    if not np.any(~early):
        return float(values[0]) if scalar else values
    t = flat[~early]
    # The slowest requested time sets a conservative omitted-tail cutoff.
    # User modes is a minimum, never permission to publish a truncated burst.
    count = max(modes, int(np.ceil(np.sqrt(40 / t.min()) / np.pi)) + 2)
    if geometry == "slab":
        # F = 1 - (8/pi^2) sum_{n odd} exp(-n^2 pi^2 tau / 4) / n^2
        n = np.arange(1, 2 * count + 1, 2, dtype=float)
        coefficients = 8.0 / (np.pi**2 * n**2)
        retained = np.exp(-np.outer(t, (n * np.pi / 2.0) ** 2)) * coefficients
    else:
        from scipy.special import jn_zeros

        alphas = jn_zeros(0, count)
        retained = np.exp(-np.outer(t, alphas**2)) * (4.0 / alphas**2)
    values[~early] = np.clip(1 - retained.sum(axis=1), 0, 1)
    return float(values[0]) if scalar else values


def cell_geometry(shells: int, geometry: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Edges, face-area weights (r^d) and cell volumes (∫ r^d dr) on N uniform
    cells over [0, 1]; the r=0 face of slab/cylinder/sphere carries zero area
    except the slab, whose symmetry face has unit area but zero flux by
    construction (no neighbour)."""
    dimension = GEOMETRY_DIMENSIONS[geometry]
    edges = np.arange(shells + 1, dtype=float) / shells
    centers = (np.arange(shells, dtype=float) + 0.5) / shells
    face_area = edges**dimension if dimension > 0 else np.ones_like(edges)
    volumes = (edges[1:] ** (dimension + 1) - edges[:-1] ** (dimension + 1)) / (dimension + 1)
    return edges, face_area, volumes


def fv_operator(shells: int, geometry: str, diffusivity_profile=None):
    """Conservative FV operator and volumes for one geometry, optionally with
    a piecewise-constant relative diffusivity per cell (heterogeneous media
    use harmonic-mean face conductances).  Returns ``(operator, volumes)``
    as float64 numpy arrays; the last cell leaks to the sink over a half
    cell, the first cell has no inward flux."""
    edges, face_area, volumes = cell_geometry(shells, geometry)
    h = 1.0 / shells
    n = shells
    d_rel = np.ones(n) if diffusivity_profile is None else np.asarray(diffusivity_profile, float)
    if d_rel.shape != (n,) or np.any(d_rel <= 0):
        raise ValueError("diffusivity_profile must be positive with one value per cell")

    def face_diffusivity(i: int) -> float:
        # harmonic mean across the face between cells i-1 and i
        a, b = d_rel[i - 1], d_rel[i]
        return 2.0 * a * b / (a + b)

    lower = np.zeros(n)
    upper = np.zeros(n)
    diag = np.zeros(n)
    for i in range(n):
        conduct_in = face_area[i] * (face_diffusivity(i) if i > 0 else 1.0) / h if i > 0 else 0.0
        if i < n - 1:
            conduct_out = face_area[i + 1] * face_diffusivity(i + 1) / h
            upper[i] = conduct_out / volumes[i]
        else:
            conduct_out = face_area[n] * d_rel[i] / (h / 2.0)  # sink face, half cell
        diag[i] = -(conduct_in + conduct_out) / volumes[i]
        if i > 0:
            lower[i] = conduct_in / volumes[i]
    operator = np.diag(lower[1:], -1) + np.diag(diag) + np.diag(upper[:-1], 1)
    return operator, volumes


def boundary_leak(shells: int, geometry: str, diffusivity_profile=None) -> float:
    """Sink-face leak conductance in inventory-fraction units (conductance
    divided by total cell volume), matching the operator's boundary row."""
    edges, face_area, volumes = cell_geometry(shells, geometry)
    h = 1.0 / shells
    d_rel = np.ones(shells) if diffusivity_profile is None else np.asarray(diffusivity_profile, float)
    conduct = face_area[shells] * d_rel[-1] / (h / 2.0)
    return float(conduct / volumes.sum())
