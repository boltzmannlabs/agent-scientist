"""Explicit unit handling at the schema boundary (v3).

A tiny conversion table — deliberately not a units library.  Its job is to
make the classic pooling bug (hours into days, percent into mg/g) impossible
to commit silently where curves from different studies meet.
"""

from __future__ import annotations

TIME_TO_HOURS = {
    "s": 1.0 / 3600.0,
    "min": 1.0 / 60.0,
    "h": 1.0,
    "d": 24.0,
    "day": 24.0,
}

FRACTION_LIKE = {"1", "fraction"}
PERCENT_LIKE = {"%", "percent", "percentage_points", "pp"}
MASS_PER_MASS = {"mg/g"}


class UnitMismatchError(ValueError):
    """Raised when incompatible units are asked to convert into each other."""


def convert_time(value: float, from_unit: str, to_unit: str = "h") -> float:
    if from_unit not in TIME_TO_HOURS:
        raise UnitMismatchError(f"unknown time unit {from_unit!r}; known: {sorted(TIME_TO_HOURS)}")
    if to_unit not in TIME_TO_HOURS:
        raise UnitMismatchError(f"unknown time unit {to_unit!r}")
    return float(value) * TIME_TO_HOURS[from_unit] / TIME_TO_HOURS[to_unit]


def assert_compatible_targets(unit_a: str, unit_b: str) -> None:
    """Percent release and mg/g desorption measure different things; pooling
    them is forbidden by protocol and must fail loudly."""
    families = []
    for unit in (unit_a, unit_b):
        if unit in PERCENT_LIKE:
            families.append("percent")
        elif unit in MASS_PER_MASS:
            families.append("mass_per_mass")
        elif unit in FRACTION_LIKE:
            families.append("fraction")
        else:
            families.append(f"other:{unit}")
    if families[0] != families[1]:
        raise UnitMismatchError(
            f"targets in {unit_a!r} and {unit_b!r} belong to different families "
            f"({families[0]} vs {families[1]}); pooling is forbidden"
        )


def family(unit: str) -> str:
    if unit in PERCENT_LIKE:
        return "percent"
    if unit in MASS_PER_MASS:
        return "mass_per_mass"
    if unit in FRACTION_LIKE:
        return "fraction"
    return f"other:{unit}"
