"""Locate bundled reference data in source trees and installed distributions."""
from pathlib import Path


def resource_root():
    source = Path(__file__).resolve().parents[2]
    if (source / "data").is_dir() and (source / "scripts").is_dir():
        return source
    import agri_tool
    return Path(agri_tool.__file__).parent / "_engine"
