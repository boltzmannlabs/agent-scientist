"""Metrics on fractional release; errors have units of fraction."""
import numpy as np


def regression_metrics(observed, predicted, n_parameters: int = 0) -> dict[str, float]:
    y, p = np.asarray(observed, dtype=float), np.asarray(predicted, dtype=float)
    if y.ndim != 1 or y.shape != p.shape or y.size == 0:
        raise ValueError("Expected equal, nonempty one-dimensional arrays")
    if not np.all(np.isfinite(y)) or not np.all(np.isfinite(p)):
        raise ValueError("Metrics require finite values")
    if not isinstance(n_parameters, int) or n_parameters < 0:
        raise ValueError("Parameter count must be a nonnegative integer")
    residual = y - p
    sse = float(residual @ residual)
    tss = float(np.sum((y - y.mean()) ** 2))
    n = len(y)
    aic = n * np.log(max(sse / n, np.finfo(float).tiny)) + 2 * n_parameters
    return {
        "rmse": float(np.sqrt(sse / n)),
        "mae": float(np.mean(np.abs(residual))),
        "r2": float(1 - sse / tss) if tss > 0 else float("nan"),
        "sse": sse,
        "aic": float(aic),
        "aicc": float(aic + 2 * n_parameters * (n_parameters + 1) / (n - n_parameters - 1))
        if n > n_parameters + 1 else float("nan"),
    }
