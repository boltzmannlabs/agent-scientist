"""Loading and validation of the pinned v9 stereochemistry registries.

Three frozen JSON files under data/v9/stereo/: ingredient descriptors
(validated to exist in the catalog, keyed study/formulation/ingredient),
component descriptors (must cover exactly the v8 component set) and
analogue regimes (must cover exactly the five v8 analogue study keys).
Every entry needs descriptor, note, source_url and retrieved_utc;
``unspecified`` is a legitimate, counted descriptor - never imputed.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from ..ontology import STEREO_FORMS

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()
DATA_V9 = REPO_ROOT / "data" / "v9" / "stereo"


def _validate_entry(entry: dict, where: str, descriptor_key: str = "stereo") -> None:
    if entry.get(descriptor_key) not in STEREO_FORMS:
        raise ValueError(f"{where}: {descriptor_key} must be one of {sorted(STEREO_FORMS)}")
    if not entry.get("note"):
        raise ValueError(f"{where}: a note is required (class-level judgments must say so)")
    if not entry.get("source_url") or not entry.get("retrieved_utc"):
        raise ValueError(f"{where}: source_url and retrieved_utc are required provenance")


def validate_ingredients(payload: dict, catalog) -> None:
    studies = payload.get("ingredients", {})
    if not studies:
        raise ValueError("stereo ingredients registry is empty")
    misses = []
    for study_key, formulations in sorted(studies.items()):
        if study_key not in catalog.studies:
            raise ValueError(f"stereo registry references unknown study {study_key!r}")
        meta = catalog.studies[study_key]["meta"]
        study_id = meta.get("study_id", study_key)
        known_forms = {f.formulation_id for f in catalog.formulations if f.study_id == study_id}
        for formulation_id, ingredients in sorted(formulations.items()):
            if formulation_id not in known_forms:
                raise ValueError(f"{study_key}: stereo registry references unknown formulation {formulation_id!r}")
            names = {
                i.name
                for f in catalog.formulations
                if f.study_id == study_id and f.formulation_id == formulation_id
                for i in f.ingredients
            }
            for name, entry in sorted(ingredients.items()):
                if name not in names:
                    misses.append(f"{study_key}/{formulation_id}/{name}")
                _validate_entry(entry, f"{study_key}/{formulation_id}/{name}")
    if misses:
        raise ValueError(f"stereo registry references unknown ingredients: {misses}")


def validate_components(payload: dict, component_names: set[str]) -> None:
    entries = payload.get("components", {})
    if set(entries) != component_names:
        missing = sorted(component_names - set(entries))
        extra = sorted(set(entries) - component_names)
        raise ValueError(f"stereo components registry must cover the v8 set exactly; missing={missing} extra={extra}")
    for name, entry in sorted(entries.items()):
        _validate_entry(entry, f"component/{name}")


def validate_analogues(payload: dict, analogue_keys: set[str]) -> None:
    entries = payload.get("analogues", {})
    if set(entries) != analogue_keys:
        raise ValueError(
            f"stereo analogues registry must cover the v8 analogue keys exactly; "
            f"missing={sorted(analogue_keys - set(entries))} extra={sorted(set(entries) - analogue_keys)}"
        )
    for key, entry in sorted(entries.items()):
        _validate_entry(entry, f"analogue/{key}", descriptor_key="active_stereo")
        if entry.get("carrier_stereo") and entry["carrier_stereo"] not in STEREO_FORMS:
            raise ValueError(f"analogue/{key}: carrier_stereo must be a stereo descriptor")


@dataclass(frozen=True)
class StereoRegistries:
    ingredients: dict
    components: dict
    analogues: dict

    def ingredient_stereo(self, study_key: str, formulation_id: str, ingredient_name: str) -> str:
        return (
            self.ingredients["ingredients"]
            .get(study_key, {})
            .get(formulation_id, {})
            .get(ingredient_name, {})
            .get("stereo", "unspecified")
        )

    def component_stereo(self, name: str) -> str:
        return self.components["components"].get(name, {}).get("stereo", "unspecified")

    def analogue_regime(self, study_key: str) -> str:
        return self.analogues["analogues"].get(study_key, {}).get("active_stereo", "unspecified")


def load_stereo_registries(catalog, component_names: set[str], analogue_keys: set[str]) -> StereoRegistries:
    """Load and validate every data/v9/stereo registry; raise on any violation."""

    def read(name: str) -> dict:
        with open(DATA_V9 / name) as handle:
            return json.load(handle)

    ingredients = read("ingredients.json")
    components = read("components.json")
    analogues = read("analogues.json")
    validate_ingredients(ingredients, catalog)
    validate_components(components, component_names)
    validate_analogues(analogues, analogue_keys)
    return StereoRegistries(ingredients=ingredients, components=components, analogues=analogues)


def stereo_coverage(catalog, registries: StereoRegistries):
    """Per-study ingredient stereo completeness (described vs unspecified)."""
    rows = []
    for study_key, entry in sorted(catalog.studies.items()):
        study_id = entry["meta"].get("study_id", study_key)
        described = unspecified = 0
        for formulation in (f for f in catalog.formulations if f.study_id == study_id):
            for ingredient in formulation.ingredients:
                descriptor = registries.ingredient_stereo(study_key, formulation.formulation_id, ingredient.name)
                if descriptor == "unspecified":
                    unspecified += 1
                else:
                    described += 1
        total = described + unspecified
        rows.append(
            {
                "study": study_key,
                "n_ingredients": total,
                "described": described,
                "unspecified": unspecified,
                "described_share": round(described / total, 3) if total else 0.0,
            }
        )
    return rows
