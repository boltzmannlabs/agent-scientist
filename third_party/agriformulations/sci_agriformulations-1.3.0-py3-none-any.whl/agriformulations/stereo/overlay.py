"""Additive stereo overlay on the v8 campaign concepts (v9).

Never edits frozen v8 exports: reads reports/v8/v8_concepts.csv, joins
the stereo registries and writes a companion frame - per-concept stereo
regimes, regime distance to the chosen analogue, overlay widening,
mismatch flags and the chiral-carrier flag the registered assumption
requires.  MIX/ROBUST concepts carry regimes and flags without a regime
distance (no kinetics claim).
"""

from __future__ import annotations

import pandas as pd

from .regimes import regime_widen, stereo_regime, worst_regime
from .registry import StereoRegistries

CHIRAL_CARRIER_FORMS = frozenset(
    {"enantiopure", "single_stereoisomer", "diastereomeric_mixture", "multi_stereocenter_natural"}
)
ASSUMPTION_NOTE = (
    "stereo-blind Fickian kernel (achiral media); chiral carriers may release "
    "enantioselectively - not modeled, liftable only with stereo-resolved assays"
)

OVERLAY_COLUMNS = [
    "concept_id", "direction", "role", "format", "carrier", "partner",
    "active_regimes", "analogue", "analogue_regime", "regime", "stereo_widen_factor",
    "region_low_per_day", "region_high_per_day",
    "overlay_region_low_per_day", "overlay_region_high_per_day",
    "stereo_regime_mismatch", "chiral_carrier", "assumption",
]


def build_overlay(v8_concepts: pd.DataFrame, stereo: StereoRegistries, *, primary_active: str = "sulfoxaflor") -> pd.DataFrame:
    rows = []
    for _, row in v8_concepts.iterrows():
        regimes = {primary_active: stereo.component_stereo(primary_active)}
        if isinstance(row.get("partner"), str):
            regimes[row["partner"]] = stereo.component_stereo(row["partner"])
        active_regimes = "; ".join(f"{name}:{form}" for name, form in sorted(regimes.items()))
        analogue = row.get("analogue")
        has_analogue = isinstance(analogue, str) and analogue == analogue and analogue != ""
        analogue_regime = stereo.analogue_regime(analogue) if has_analogue else None
        if has_analogue:
            regime = worst_regime([stereo_regime(form, analogue_regime) for form in regimes.values()])
        else:
            regime = "not_applicable"
        widen = regime_widen(regime) if regime != "not_applicable" else 1.0
        low, high = row.get("region_low_per_day"), row.get("region_high_per_day")
        has_region = pd.notna(low) and pd.notna(high) and low > 0
        carrier = row.get("carrier")
        carrier_is_chiral = isinstance(carrier, str) and stereo.component_stereo(carrier) in CHIRAL_CARRIER_FORMS
        rows.append(
            {
                "concept_id": row["concept_id"],
                "direction": row["direction"],
                "role": row["role"],
                "format": row["format"],
                "carrier": carrier if isinstance(carrier, str) else None,
                "partner": row["partner"] if isinstance(row["partner"], str) else None,
                "active_regimes": active_regimes,
                "analogue": analogue if has_analogue else None,
                "analogue_regime": analogue_regime,
                "regime": regime,
                "stereo_widen_factor": widen,
                "region_low_per_day": float(low) if has_region else None,
                "region_high_per_day": float(high) if has_region else None,
                "overlay_region_low_per_day": float(low) / widen if has_region else None,
                "overlay_region_high_per_day": float(high) * widen if has_region else None,
                "stereo_regime_mismatch": bool(regime in ("related", "cross_class", "unspecified")),
                "chiral_carrier": bool(carrier_is_chiral),
                "assumption": ASSUMPTION_NOTE if carrier_is_chiral else "stereo-blind Fickian kernel (achiral media)",
            }
        )
    frame = pd.DataFrame(rows)[OVERLAY_COLUMNS]
    return frame.sort_values("concept_id", kind="mergesort").reset_index(drop=True)
