"""Stereo regime distance between a concept's actives and an analogue (v9).

Three honest levels plus unknown: match (same descriptor, or both pure
single-isomer forms), related (achiral/racemic against the single-isomer
family - racemate vs enantiopure can differ in solubility and crystal
form), cross_class (a multi-stereocenter natural product or complex
mixture on either side against a non-identical other), unspecified
(either side unknown).  Declared analyst-judgment widening factors ride
on the levels; they widen OVERLAY regions only, never frozen v8 exports.
"""

from __future__ import annotations

SINGLE_ISOMER_FORMS = frozenset({"enantiopure", "single_stereoisomer"})
SIMPLE_FORMS = frozenset({"achiral", "racemic"}) | SINGLE_ISOMER_FORMS
MIXTURE_FORMS = frozenset({"multi_stereocenter_natural", "complex_mixture"})

REGIME_ORDER = {"match": 0, "unspecified": 1, "related": 2, "cross_class": 3}
WIDENING = {"match": 1.00, "unspecified": 1.15, "related": 1.15, "cross_class": 1.30}


def stereo_regime(a: str, b: str) -> str:
    if a == b:
        return "match"
    if "unspecified" in (a, b):
        return "unspecified"
    if a in SINGLE_ISOMER_FORMS and b in SINGLE_ISOMER_FORMS:
        return "match"
    if a in MIXTURE_FORMS or b in MIXTURE_FORMS:
        return "cross_class"
    if a in SIMPLE_FORMS and b in SIMPLE_FORMS:
        return "related"
    return "cross_class"


def regime_widen(regime: str) -> float:
    return WIDENING.get(regime, 1.0)


def worst_regime(regimes: list[str]) -> str:
    """Most conservative regime by severity order (empty -> unspecified)."""
    if not regimes:
        return "unspecified"
    return max(regimes, key=lambda r: REGIME_ORDER.get(r, 1))
