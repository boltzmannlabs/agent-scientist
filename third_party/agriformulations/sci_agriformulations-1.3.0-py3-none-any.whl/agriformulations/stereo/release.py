"""Stereo-resolved release: per-enantiomer rates and their identifiability (v9).

Total release of a two-enantiomer active is w*F(k_R) + (1-w)*F(k_S)
through the same verified analytic kernel, w the loading share.  Two
automated demonstrations on declared synthetic data: the recovery gate
(stereo-RESOLVED curves recover both rates within the v6-style 1.25x
tolerance in >= 90% of trials) and the degeneracy demonstration (the
TOTAL curve alone admits multiple (w', k_R', k_S') triples within a
0.02-fraction tolerance, so only the loading-weighted effective rate -
what v1-v8 calibrate from total-a.i. data - is recoverable).  Verdicts
are exported as computed; the demo never fabricates certainty.
"""

from __future__ import annotations

import numpy as np

from ..accelerated import batch_sphere_predictions
from ..release import fit_release

RECOVERY_RATE_RATIO = 1.25
RECOVERY_MIN_SHARE = 0.9
RECOVERY_TRIALS = 12
DEGENERACY_TOLERANCE = 0.02
DEGENERACY_LOADINGS = (0.3, 0.5, 0.7)
DEGENERACY_GRID = 25
DEGENERACY_SPAN = 30.0  # grid spans true_rate / span .. true_rate * span


def simulate_resolved(times, k_r: float, k_s: float, *, w: float = 0.5, noise: float = 0.0, seed: int = 0):
    """Stereo-resolved observations as fractions of the TOTAL loading."""
    rng = np.random.default_rng(seed)
    times = np.asarray(times, dtype=float)
    fractions, _ = batch_sphere_predictions(np.array([k_r, k_s]), times)
    obs_r = w * fractions[0] + (noise * rng.normal(size=times.size) if noise else 0.0)
    obs_s = (1.0 - w) * fractions[1] + (noise * rng.normal(size=times.size) if noise else 0.0)
    return obs_r, obs_s


def fit_resolved(times, obs_r, obs_s, *, w: float = 0.5) -> dict:
    """Per-enantiomer rates from resolved curves: normalize each series by
    its loading share, then calibrate the verified kernel per species.
    Boundary overshoot from observation noise is clipped into [0, 1]."""
    times = np.asarray(times, dtype=float)
    norm_r = np.clip(np.asarray(obs_r, dtype=float) / w, 0.0, 1.0)
    norm_s = np.clip(np.asarray(obs_s, dtype=float) / (1.0 - w), 0.0, 1.0)
    fit_r = fit_release(times, norm_r, "spherical_diffusion")
    fit_s = fit_release(times, norm_s, "spherical_diffusion")
    return {
        "k_r": float(fit_r.parameters["rate"]),
        "k_s": float(fit_s.parameters["rate"]),
        "r2_r": fit_r.metrics.get("r2"),
        "r2_s": fit_s.metrics.get("r2"),
    }


def total_curve(times, k_r: float, k_s: float, *, w: float = 0.5) -> np.ndarray:
    fractions, _ = batch_sphere_predictions(np.array([k_r, k_s]), np.asarray(times, dtype=float))
    return w * fractions[0] + (1.0 - w) * fractions[1]


def recovery_gate(*, trials: int = RECOVERY_TRIALS, seed: int = 0) -> dict:
    """v6-style synthetic recovery on resolved curves (>= 90% of trials)."""
    times = np.array([0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0])
    log_tolerance = np.log10(RECOVERY_RATE_RATIO)
    recovered = 0
    for trial in range(trials):
        k_r = float(np.geomspace(1e-2, 1e-1, trials)[trial])
        k_s = k_r / 8.0
        w = 0.5
        obs_r, obs_s = simulate_resolved(times, k_r, k_s, w=w, noise=0.003, seed=seed + trial)
        fit = fit_resolved(times, obs_r, obs_s, w=w)
        hit = (
            abs(np.log10(fit["k_r"] / k_r)) <= log_tolerance
            and abs(np.log10(fit["k_s"] / k_s)) <= log_tolerance
        )
        recovered += int(hit)
    share = recovered / trials
    return {
        "pass": share >= RECOVERY_MIN_SHARE,
        "recovered": recovered,
        "trials": trials,
        "min_share": RECOVERY_MIN_SHARE,
        "rate_ratio_tolerance": RECOVERY_RATE_RATIO,
        "label": "synthetic demonstration; resolved curves assumed",
    }


def _passing_triples(times, observed, k_r: float, k_s: float, tolerance: float):
    passing = []
    for w_prime in DEGENERACY_LOADINGS:
        grid_r = np.geomspace(k_r / DEGENERACY_SPAN, k_r * DEGENERACY_SPAN, DEGENERACY_GRID)
        grid_s = np.geomspace(k_s / DEGENERACY_SPAN, k_s * DEGENERACY_SPAN, DEGENERACY_GRID)
        fractions_r, _ = batch_sphere_predictions(grid_r, times)
        fractions_s, _ = batch_sphere_predictions(grid_s, times)
        for i in range(len(grid_r)):
            for j in range(len(grid_s)):
                model = w_prime * fractions_r[i] + (1.0 - w_prime) * fractions_s[j]
                if float(np.max(np.abs(model - observed))) <= tolerance:
                    passing.append({"w": w_prime, "k_r": float(grid_r[i]), "k_s": float(grid_s[j])})
    return passing


def degeneracy_demo(times=None, *, k_r: float = 0.05, k_s: float = 0.006, w: float = 0.5,
                    strict_tolerance: float = 0.02, campaign_tolerance: float = 0.05) -> dict:
    """From the TOTAL curve alone: count (w', k_R', k_S') triples that
    reproduce it, at a strict tolerance and at the campaign's own
    feasibility tolerance (0.05 fraction, the same number v8 uses), and
    calibrate the single-species effective rate the total data DO support.

    Two separate statements export: (1) VALUE degeneracy - empirical, from
    the grids; the verdict is read at the campaign tolerance because that
    is the tolerance the campaign itself calls feasible.  (2) ASSIGNMENT
    degeneracy - exact and grid-free: (w, k_R, k_S) and (1-w, k_S, k_R)
    produce IDENTICAL total curves, so total-a.i. data can never say which
    enantiomer carries which rate, whatever the grids show."""
    times = np.array([0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0]) if times is None else np.asarray(times, dtype=float)
    observed = total_curve(times, k_r, k_s, w=w)
    strict = _passing_triples(times, observed, k_r, k_s, strict_tolerance)
    campaign = _passing_triples(times, observed, k_r, k_s, campaign_tolerance)
    effective = fit_release(times, observed, "spherical_diffusion")

    def block(passing, tolerance):
        return {
            "tolerance": tolerance,
            "n_passing_triples": len(passing),
            "distinct_loadings": len({p["w"] for p in passing}),
        }

    campaign_block = block(campaign, campaign_tolerance)
    verdict = (
        "jointly_unidentifiable"
        if campaign_block["distinct_loadings"] >= 2 and campaign_block["n_passing_triples"] >= 3
        else "values_identifiable_assignment_always_degenerate"
    )
    return {
        "verdict": verdict,
        "verdict_tolerance": campaign_tolerance,
        "strict": {**block(strict, strict_tolerance),
                   "passing_triples_sample": sorted(strict, key=lambda p: (p["w"], p["k_r"]))[:12]},
        "campaign": {**campaign_block,
                     "passing_triples_sample": sorted(campaign, key=lambda p: (p["w"], p["k_r"]))[:12]},
        "true": {"w": w, "k_r": k_r, "k_s": k_s},
        "effective_rate": float(effective.parameters["rate"]),
        "effective_r2": effective.metrics.get("r2"),
        "swap_symmetry": (
            "exact: (w, k_R, k_S) and (1-w, k_S, k_R) produce identical total curves; "
            "enantiomer assignment is never recoverable from total-release data"
        ),
        "statement": (
            "total-release data recover only the loading-weighted effective rate; "
            "per-enantiomer rates and their assignment require stereo-resolved assays"
        ),
        "label": "synthetic demonstration",
    }
