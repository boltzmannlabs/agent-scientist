"""Stereochemistry layer (v9).

Makes the framework's stance on chirality explicit: stereo descriptors on
every ingredient and component, chiral-resolution flags on assay
protocols, the stereo-blind-physics assumption registered, a
synthetic-gated multi-species capability with its identifiability
statement, and an additive stereo overlay on the v8 campaign.  The layer
never rewrites frozen v8 exports and never claims enantiomer-specific
kinetics from total-a.i. data.
"""

from .overlay import build_overlay
from .regimes import REGIME_ORDER, WIDENING, regime_widen, stereo_regime, worst_regime
from .registry import (
    StereoRegistries,
    load_stereo_registries,
    validate_analogues,
    validate_components,
    validate_ingredients,
)
from .release import (
    degeneracy_demo,
    fit_resolved,
    recovery_gate,
    simulate_resolved,
    total_curve,
)

__all__ = [
    "REGIME_ORDER",
    "StereoRegistries",
    "WIDENING",
    "build_overlay",
    "degeneracy_demo",
    "fit_resolved",
    "load_stereo_registries",
    "recovery_gate",
    "regime_widen",
    "simulate_resolved",
    "stereo_regime",
    "total_curve",
    "validate_analogues",
    "validate_components",
    "validate_ingredients",
    "worst_regime",
]
