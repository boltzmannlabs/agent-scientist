"""Formulation ontology for the hybrid catalog (v3).

Extends the evidence schema with structured formulation records: ingredients
with roles and measured properties, process parameters, geometry, and a
``data_source`` separation between literature and internal data.  Missing
ontology fields stay ``None`` and surface in the catalog coverage matrix;
they are never imputed.  Internal evidence requires an instrument/method and
an internal study identifier, and must never present a public URL.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .evidence import EvidenceKind, Measurement, Provenance

INGREDIENT_ROLES = frozenset(
    {
        "active",
        "matrix",
        "crosslinker",
        "filler",
        "surfactant",
        "coating",
        "plasticizer",
        "solvent",
        "dispersant",
        "control",
        "other",
    }
)

GEOMETRIES = frozenset({"sphere", "slab", "cylinder", "fiber", "granule", "film"})

DATA_SOURCES = frozenset({"literature", "internal"})

STEREO_FORMS = frozenset(
    {
        "achiral",
        "racemic",
        "enantiopure",
        "single_stereoisomer",
        "diastereomeric_mixture",
        "multi_stereocenter_natural",
        "complex_mixture",
        "unspecified",
    }
)


def internal_provenance(internal_study_id: str, instrument: str, notes: str = "") -> Provenance:
    """Provenance for in-house measurements: method is mandatory, public URLs
    are forbidden, and the internal study identifier travels in the notes."""
    if not internal_study_id.strip():
        raise ValueError("internal evidence requires an internal_study_id")
    if not instrument.strip():
        raise ValueError("internal evidence requires the instrument/method")
    return Provenance(
        kind=EvidenceKind.INTERNAL_MEASURED,
        method=instrument,
        notes=f"internal_study_id={internal_study_id}; confidentiality=internal"
        + (f"; {notes}" if notes else ""),
    )


@dataclass(frozen=True)
class IngredientSpec:
    name: str
    role: str
    cas: str | None = None
    mass_fraction: Measurement | None = None
    particle_d50: Measurement | None = None
    loading: Measurement | None = None
    crosslink_density: Measurement | None = None
    stereo: str = "unspecified"

    def __post_init__(self):
        if not self.name.strip():
            raise ValueError("Ingredient name is required")
        if self.role not in INGREDIENT_ROLES:
            raise ValueError(f"role {self.role!r} not in the registry {sorted(INGREDIENT_ROLES)}")
        stereo = (self.stereo or "unspecified").strip() or "unspecified"
        object.__setattr__(self, "stereo", stereo)
        if stereo not in STEREO_FORMS:
            raise ValueError(f"stereo {stereo!r} not in the registry {sorted(STEREO_FORMS)}")
        for label, measurement, unit in (
            ("mass_fraction", self.mass_fraction, "1"),
            ("particle_d50", self.particle_d50, "m"),
            ("loading", self.loading, None),
            ("crosslink_density", self.crosslink_density, "mol/m^3"),
        ):
            if measurement is None:
                continue
            if measurement.unit == "1" and not 0.0 <= measurement.value <= 1.0:
                raise ValueError(f"{label} as a fraction must lie in [0, 1]")
            if unit and measurement.unit != unit:
                raise ValueError(f"{label} must carry unit {unit!r}, got {measurement.unit!r}")
        if self.loading is not None and self.loading.unit not in ("1", "mg/g"):
            raise ValueError("loading must be '1' (fraction) or 'mg/g'")


@dataclass(frozen=True)
class ProcessParameter:
    step: str
    parameter: str
    value: Measurement | None = None
    note: str = ""

    def __post_init__(self):
        if not self.step.strip() or not self.parameter.strip():
            raise ValueError("Process parameter needs a step and a name")
        if self.value is None and not self.note.strip():
            raise ValueError("A process parameter without a measured value needs a descriptive note")


@dataclass(frozen=True)
class FormulationRecord:
    formulation_id: str
    study_id: str
    geometry: str
    characteristic_length: Measurement | None = None
    ingredients: tuple[IngredientSpec, ...] = ()
    process: tuple[ProcessParameter, ...] = ()
    data_source: str = "literature"
    notes: str = ""

    def __post_init__(self):
        object.__setattr__(self, "ingredients", tuple(self.ingredients))
        object.__setattr__(self, "process", tuple(self.process))
        if not self.formulation_id.strip() or not self.study_id.strip():
            raise ValueError("Formulation and study IDs are required")
        if self.geometry not in GEOMETRIES:
            raise ValueError(f"geometry {self.geometry!r} not in {sorted(GEOMETRIES)}")
        if self.data_source not in DATA_SOURCES:
            raise ValueError(f"data_source must be one of {sorted(DATA_SOURCES)}")
        if self.characteristic_length is not None and self.characteristic_length.unit != "m":
            raise ValueError("characteristic_length must carry unit 'm'")
        if self.data_source == "internal":
            for ingredient in self.ingredients:
                for measurement in (
                    ingredient.mass_fraction,
                    ingredient.particle_d50,
                    ingredient.loading,
                    ingredient.crosslink_density,
                ):
                    if measurement is not None and measurement.provenance.kind not in (
                        EvidenceKind.INTERNAL_MEASURED,
                        EvidenceKind.DERIVED,
                    ):
                        raise ValueError(
                            "internal formulations need internal_measured or derived provenance, "
                            f"got {measurement.provenance.kind}"
                        )

    def validate(self) -> list[str]:
        """Soft gaps as warnings; hard errors already raised in __post_init__."""
        warnings: list[str] = []
        if not self.ingredients:
            warnings.append(f"{self.formulation_id}: no ingredients recorded")
        roles = {i.role for i in self.ingredients}
        if "active" not in roles and self.data_source == "literature":
            warnings.append(f"{self.formulation_id}: no active ingredient role recorded")
        if not any(i.mass_fraction is not None for i in self.ingredients):
            warnings.append(f"{self.formulation_id}: no measured mass fractions (ratios only)")
        if self.characteristic_length is None and self.geometry in ("sphere", "cylinder", "fiber"):
            warnings.append(f"{self.formulation_id}: geometry {self.geometry} without characteristic length")
        return warnings

    def to_dict(self) -> dict[str, Any]:
        return {
            "formulation_id": self.formulation_id,
            "study_id": self.study_id,
            "geometry": self.geometry,
            "characteristic_length": self.characteristic_length.to_dict() if self.characteristic_length else None,
            "ingredients": [
                {
                    "name": i.name,
                    "role": i.role,
                    "cas": i.cas,
                    "mass_fraction": i.mass_fraction.to_dict() if i.mass_fraction else None,
                    "particle_d50": i.particle_d50.to_dict() if i.particle_d50 else None,
                    "loading": i.loading.to_dict() if i.loading else None,
                    "crosslink_density": i.crosslink_density.to_dict() if i.crosslink_density else None,
                    "stereo": i.stereo,
                }
                for i in self.ingredients
            ],
            "process": [
                {"step": p.step, "parameter": p.parameter, "value": p.value.to_dict() if p.value else None, "note": p.note} for p in self.process
            ],
            "data_source": self.data_source,
            "notes": self.notes,
        }


def formulation_from_dict(record: dict[str, Any]) -> FormulationRecord:
    def measurement(entry):
        if entry is None:
            return None
        return Measurement(
            id=entry["id"],
            name=entry["name"],
            value=float(entry["value"]),
            unit=entry["unit"],
            provenance=Provenance(**entry["provenance"]),
            uncertainty=entry.get("uncertainty"),
        )

    ingredients = tuple(
        IngredientSpec(
            name=i["name"],
            role=i["role"],
            cas=i.get("cas"),
            mass_fraction=measurement(i.get("mass_fraction")),
            particle_d50=measurement(i.get("particle_d50")),
            loading=measurement(i.get("loading")),
            crosslink_density=measurement(i.get("crosslink_density")),
            stereo=i.get("stereo", "unspecified"),
        )
        for i in record.get("ingredients", [])
    )
    process = tuple(
        ProcessParameter(
            step=p["step"],
            parameter=p["parameter"],
            value=measurement(p.get("value")),
            note=p.get("note", ""),
        )
        for p in record.get("process", [])
    )
    return FormulationRecord(
        formulation_id=record["formulation_id"],
        study_id=record["study_id"],
        geometry=record["geometry"],
        characteristic_length=measurement(record.get("characteristic_length")),
        ingredients=ingredients,
        process=process,
        data_source=record.get("data_source", "literature"),
        notes=record.get("notes", ""),
    )
