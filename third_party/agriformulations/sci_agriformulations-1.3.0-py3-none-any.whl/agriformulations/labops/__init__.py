"""Lab operations layer (v7): batch verdicts, Arrhenius, bridge, matching, dossiers."""

from .specs import ProductSpec, drift_control, forecast_endpoint, spec_verdict
from .arrhenius import fit_arrhenius, rate_at_temperature, synthetic_recovery
from .composition import CompositionBridge, composition_features, synthetic_demo
from .protocol_match import match_protocols
from .dossier import export_dossier

__all__ = [
    "ProductSpec",
    "forecast_endpoint",
    "spec_verdict",
    "drift_control",
    "fit_arrhenius",
    "rate_at_temperature",
    "synthetic_recovery",
    "CompositionBridge",
    "composition_features",
    "synthetic_demo",
    "match_protocols",
    "export_dossier",
]
