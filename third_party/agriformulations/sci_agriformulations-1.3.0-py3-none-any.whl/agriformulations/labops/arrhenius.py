"""Arrhenius temperature-dependence fitting for release rates (v7 labops).

Per formulation: fit ln(rate) = ln(A) - Ea/(R T) by least squares on
per-curve calibrated effective rates (the v4 physics-feature logic).  Two
temperatures make Ea and the pre-exponential jointly weakly identified -
those fits carry a "weakly_identified" flag; three or more do not.
Predictions are offered only INSIDE the fitted temperature range; silent
extrapolation is refused.  A synthetic recovery test (known Ea) gates the
module before catalog output is used.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..release import fit_release

R_GAS = 8.31446261815324e-3  # kJ mol^-1 K^-1


def _calibrated_rate(times: np.ndarray, values: np.ndarray, scale: float) -> float:
    fit = fit_release(times, np.clip(values / scale, 0.0, 1.0), "spherical_diffusion")
    return float(fit.parameters["rate"])


def fit_arrhenius(
    curve_rows: pd.DataFrame, *, replicates: pd.DataFrame | None = None,
    bootstrap: int = 200, seed: int = 271828,
) -> dict:
    """Fit Ea for one formulation.

    ``curve_rows``: rows of the formulation's release curves with a
    ``temperature_c`` column; ``replicates`` (optional) enables a
    whole-trajectory bootstrap interval for Ea.
    """
    needed = curve_rows[["temperature_c"]].dropna()
    temperatures = sorted(needed["temperature_c"].astype(float).unique())
    if len(temperatures) < 2:
        return {"status": "insufficient_temperatures", "n_temperatures": len(temperatures)}
    unit = str(curve_rows["unit"].iloc[0])
    scale = 100.0 if unit in ("%", "percent") else 1000.0 if unit == "mg/g" else 1.0

    rates = []
    for temperature in temperatures:
        block = curve_rows[curve_rows["temperature_c"].astype(float) == temperature]
        curve_ids = block["curve_id"].unique()
        if len(curve_ids) != 1:
            return {"status": "ambiguous_curves_per_temperature",
                    "n_temperatures": len(temperatures)}
        curve = block[block["curve_id"] == curve_ids[0]]
        rates.append(
            _calibrated_rate(
                curve["time"].astype(float).to_numpy(),
                curve["value"].astype(float).to_numpy(),
                scale,
            )
        )
    kelvin = np.asarray(temperatures, dtype=float) + 273.15
    log_rates = np.log(np.asarray(rates))
    inverse_t = 1.0 / kelvin
    slope, intercept = np.polyfit(inverse_t, log_rates, 1)
    ea_kj_mol = float(-slope * R_GAS)
    prediction = intercept + slope * inverse_t
    residuals = log_rates - prediction
    record = {
        "status": "ok",
        "n_temperatures": len(temperatures),
        "temperatures_c": temperatures,
        "rates_per_time": rates,
        "ea_kj_mol": ea_kj_mol,
        "ln_a": float(intercept),
        "weakly_identified": len(temperatures) < 3,
        "residual_rms_log": float(np.sqrt(np.mean(residuals**2))) if len(residuals) else 0.0,
        "ea_ci_kj_mol": None,
    }

    if replicates is not None and bootstrap > 0 and not replicates.empty:
        rng = np.random.default_rng(seed)
        replicates = replicates.copy()
        if "curve_id" not in replicates.columns:
            # some replicate frames key curves by formulation|condition
            replicates["curve_id"] = (
                replicates["formulation_id"].astype(str) + "|" + replicates["condition_id"].astype(str)
            )
            curve_rows = curve_rows.copy()
            if "curve_id" not in curve_rows.columns:
                curve_rows["curve_id"] = (
                    curve_rows["formulation_id"].astype(str) + "|" + curve_rows["condition_id"].astype(str)
                )
        curve_temperature = dict(zip(curve_rows["curve_id"], curve_rows["temperature_c"]))
        trajectories = {
            curve_id: group
            for curve_id, group in replicates.groupby("curve_id")
            if curve_id in curve_temperature
        }
        draws = []
        for _ in range(bootstrap):
            boot_rows = []
            for curve_id, group in trajectories.items():
                resampled = group.sample(frac=1.0, replace=True, random_state=rng.integers(1 << 31))
                by_time = resampled.groupby("time")["value"].mean()
                for time_value, value in by_time.items():
                    boot_rows.append(
                        {"curve_id": curve_id, "time": float(time_value), "value": float(value),
                         "temperature_c": curve_temperature[curve_id], "unit": unit}
                    )
            if not boot_rows:
                continue
            boot_frame = pd.DataFrame(boot_rows)
            try:
                boot_rates = []
                for temperature in temperatures:
                    block = boot_frame[boot_frame["temperature_c"].astype(float) == temperature]
                    boot_rates.append(
                        _calibrated_rate(
                            block["time"].astype(float).to_numpy(),
                            block["value"].astype(float).to_numpy(), scale,
                        )
                    )
                b_slope, _ = np.polyfit(inverse_t, np.log(np.asarray(boot_rates)), 1)
                draws.append(-b_slope * R_GAS)
            except Exception:
                continue
        if len(draws) >= 20:
            record["ea_ci_kj_mol"] = [
                float(np.quantile(draws, 0.05)), float(np.quantile(draws, 0.95))
            ]
            record["bootstrap_draws"] = len(draws)
    return record


def rate_at_temperature(fit: dict, temperature_c: float) -> float:
    """Predicted effective rate at a temperature INSIDE the fitted range;
    refuses extrapolation."""
    if fit.get("status") != "ok":
        raise ValueError("no Arrhenius fit available")
    lo, hi = min(fit["temperatures_c"]), max(fit["temperatures_c"])
    if not (lo - 1e-9 <= temperature_c <= hi + 1e-9):
        raise ValueError(
            f"refusing Arrhenius extrapolation: {temperature_c} C outside fitted range [{lo}, {hi}] C"
        )
    kelvin = temperature_c + 273.15
    return float(np.exp(fit["ln_a"] - fit["ea_kj_mol"] / (R_GAS * kelvin)))


def synthetic_recovery(*, ea_true: float = 60.0, seed: int = 7) -> dict:
    """Gate: recover a known Ea from synthetic multi-temperature data
    generated by the same spherical model the calibration uses."""
    from ..release import release_fraction

    rng = np.random.default_rng(seed)
    temperatures = np.array([25.0, 35.0, 45.0])
    kelvin = temperatures + 273.15
    # anchor the pre-exponential so the warmest curve is well resolved
    # (rate ~ 0.03 per hour at the top temperature)
    ln_a = np.log(0.03) + ea_true / (R_GAS * kelvin.max())
    rows = []
    for temperature, k in zip(temperatures, kelvin):
        rate = float(np.exp(ln_a - ea_true / (R_GAS * k)))
        times = np.array([2.0, 6.0, 12.0, 24.0, 48.0])
        values = np.array(
            [release_fraction(float(t), "spherical_diffusion", {"rate": rate}) for t in times]
        )
        values = values + 0.003 * rng.normal(size=times.size)
        rows.extend(
            {"curve_id": f"T{int(temperature)}", "time": t, "value": max(v, 0.0) * 100.0,
             "temperature_c": temperature, "unit": "%"}
            for t, v in zip(times, values)
        )
    fit = fit_arrhenius(pd.DataFrame(rows))
    return {"fit": fit, "ea_true": ea_true,
            "recovered": fit.get("ea_kj_mol"),
            "pass": bool(abs(fit.get("ea_kj_mol", 1e9) - ea_true) <= 0.1 * ea_true)}
