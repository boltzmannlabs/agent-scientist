"""Product specifications and batch-verdict logic (v7 labops).

A spec declares the release window a product must hit; the verdict workflow
forecasts the batch endpoint from its own early times (v2 forecast-track
candidates with inner-split selection), compares against the window, and
computes drift z-scores against reference batches.  Verdicts are PASS, FAIL,
BORDERLINE (inside one tolerance of a limit) or INSUFFICIENT_EVIDENCE.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from ..benchmark_v2.candidates import CandidateFailure, fit_candidate
from ..benchmark_v2.splits import inner_split, outer_split, unique_times
from ..release import fit_release

VERDICTS = ("PASS", "FAIL", "BORDERLINE", "INSUFFICIENT_EVIDENCE")


@dataclass(frozen=True)
class ProductSpec:
    product_id: str
    endpoint_time: float
    time_unit: str
    unit: str
    window: tuple[float, float]
    tolerance: float
    reference_batches: tuple[str, ...] = ()
    min_forecast_times: int = 5

    def __post_init__(self):
        if not self.product_id.strip():
            raise ValueError("spec needs a product_id")
        if not self.window[0] < self.window[1]:
            raise ValueError("spec window must be (lower, upper) with lower < upper")
        if self.tolerance < 0:
            raise ValueError("tolerance must be nonnegative")
        if self.endpoint_time <= 0:
            raise ValueError("endpoint_time must be positive")

    @classmethod
    def from_json(cls, path) -> "ProductSpec":
        record = json.loads(Path(path).read_text())
        return cls(
            product_id=record["product_id"],
            endpoint_time=float(record["endpoint_time"]),
            time_unit=record.get("time_unit", "h"),
            unit=record["unit"],
            window=(float(record["window"][0]), float(record["window"][1])),
            tolerance=float(record["tolerance"]),
            reference_batches=tuple(record.get("reference_batches", [])),
            min_forecast_times=int(record.get("min_forecast_times", 5)),
        )


def forecast_endpoint(batch: pd.DataFrame, spec: ProductSpec) -> dict:
    """Inner-split-selected candidate forecast of the endpoint from early times."""
    times = unique_times(batch)
    if len(times) < spec.min_forecast_times:
        return {
            "status": "insufficient",
            "reason": f"{len(times)} unique times < {spec.min_forecast_times} required",
            "forecast": None,
            "candidate": None,
        }
    train, test = outer_split(batch)
    inner_train, inner_val = inner_split(train)
    val_times = unique_times(inner_val)
    scores: dict[str, tuple[float, object]] = {}
    for name in ("persistence", "linear_trend", "first_order_plateau"):
        try:
            fit = fit_candidate(inner_train, name)
            predicted = fit.predict(val_times)
            observed = np.array(
                [float(inner_val.loc[inner_val["time"] == t, "value"].mean()) for t in val_times]
            )
            scores[name] = (float(np.mean(np.abs(predicted - observed))), fit)
        except CandidateFailure:
            continue
    if not scores:
        return {"status": "insufficient", "reason": "no candidate could fit",
                "forecast": None, "candidate": None}
    best_name = min(scores, key=lambda n: (scores[n][0], n == "weibull_plateau", n))
    final = fit_candidate(train, best_name)
    forecast = float(final.predict([spec.endpoint_time])[0])
    return {"status": "ok", "forecast": forecast, "candidate": best_name,
            "train_cutoff": max(unique_times(train))}


def spec_verdict(forecast: float | None, observed_now: float | None, spec: ProductSpec) -> dict:
    """PASS/FAIL/BORDERLINE against the window; observed values can override a
    borderline forecast when the endpoint is already measured."""
    lower, upper = spec.window
    value = observed_now if observed_now is not None else forecast
    if value is None:
        return {"verdict": "INSUFFICIENT_EVIDENCE", "value": None}
    if lower <= value <= upper:
        borderline = (value - lower) <= spec.tolerance or (upper - value) <= spec.tolerance
        return {"verdict": "BORDERLINE" if borderline else "PASS", "value": value}
    return {"verdict": "FAIL", "value": value}


def drift_control(
    batch: pd.DataFrame, reference_frames: dict[str, pd.DataFrame], unit: str
) -> dict:
    """Effective-rate and endpoint z-scores against reference batches."""
    scale = 100.0 if unit in ("%", "percent") else 1000.0 if unit == "mg/g" else 1.0
    times = batch["time"].astype(float).to_numpy()
    values = batch["value"].astype(float).to_numpy() / scale
    try:
        fit = fit_release(times, np.clip(values, 0.0, 1.0), "spherical_diffusion")
        rate = float(fit.parameters["rate"])
    except Exception:
        rate = float("nan")
    endpoint = float(values[-1]) * scale
    ref_rates, ref_endpoints = [], []
    for frame in reference_frames.values():
        ref_times = frame["time"].astype(float).to_numpy()
        ref_values = frame["value"].astype(float).to_numpy() / scale
        try:
            ref_fit = fit_release(ref_times, np.clip(ref_values, 0.0, 1.0), "spherical_diffusion")
            ref_rates.append(float(ref_fit.parameters["rate"]))
        except Exception:
            pass
        ref_endpoints.append(float(ref_values[-1]) * scale)
    def zscore(value, references):
        references = np.asarray([r for r in references if np.isfinite(r)], dtype=float)
        if references.size < 2 or not np.isfinite(value):
            return None
        spread = references.std(ddof=1)
        return float((value - references.mean()) / spread) if spread > 0 else None
    rate_z = zscore(
        np.log10(rate) if np.isfinite(rate) else np.nan,
        np.log10(ref_rates) if ref_rates else [],
    )
    endpoint_z = zscore(endpoint, ref_endpoints)
    z_values = [abs(z) for z in (rate_z, endpoint_z) if z is not None]
    return {
        "batch_effective_rate": rate,
        "batch_endpoint": endpoint,
        "reference_rate_mean": float(np.mean(ref_rates)) if ref_rates else None,
        "rate_zscore": rate_z,
        "endpoint_zscore": endpoint_z,
        "control_limit_sigma": 3.0,
        "in_control": bool(z_values) and all(z < 3.0 for z in z_values),
    }
