"""Assay-protocol matching service (v7 labops).

Which studies' calibrations, intervals and verdicts may transfer to a new
assay?  protocol_distance (protocol_registry) plus declared thresholds:
< 0.3 transfers, 0.3-0.6 marginal, > 0.6 or incompatible target families do
not.  Thresholds are analyst judgments registered here.
"""

from __future__ import annotations

import pandas as pd

from ..protocol_registry import AssayProtocol, protocol_distance
from ..units import family

TRANSFER_THRESHOLD = 0.3
MARGINAL_THRESHOLD = 0.6


def match_protocols(query: AssayProtocol, catalog_protocols: dict[str, AssayProtocol]) -> pd.DataFrame:
    rows = []
    for study_key, protocol in sorted(catalog_protocols.items()):
        if family(query.unit) != family(protocol.unit):
            rows.append(
                {"study_key": study_key, "distance": 1.0, "transfer": "no",
                 "reason": f"incompatible target families ({query.unit} vs {protocol.unit})"}
            )
            continue
        distance = protocol_distance(query, protocol)
        transfer = "yes" if distance < TRANSFER_THRESHOLD else (
            "marginal" if distance <= MARGINAL_THRESHOLD else "no"
        )
        reason = (
            "close protocol; calibrations may transfer"
            if transfer == "yes"
            else "partial mismatch; treat intervals as indicative"
            if transfer == "marginal"
            else "protocol too different; recalibrate before use"
        )
        rows.append({"study_key": study_key, "distance": distance, "transfer": transfer, "reason": reason})
    return pd.DataFrame(rows).sort_values("distance")
