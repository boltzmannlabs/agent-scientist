"""Audit-dossier export (v7 labops).

One zip bundling everything an auditor asks for: the provenance chain (source
files, hashes, locators), the claims audit with verdicts, execution
manifests, gate records, the agent-log hash-chain verification result, and
the standing not-comparable register.  Nothing is regenerated or summarized
beyond what the reports already state - the dossier points, it does not retell.
"""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()
NOT_COMPARABLE = (
    "crop yield; weed-control or pest-mortality efficacy; toxicity; environmental fate "
    "beyond aqueous release; field performance; synthesis chemistry; MD/DFT"
)


def export_dossier(out_path, *, phase: str = "v3", studies: list[str] | None = None) -> Path:
    """Assemble the dossier for the catalog claims audit plus phase records."""
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    included: list[str] = []

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as bundle:
        def add(name: str, path: Path):
            if path.exists():
                bundle.write(path, arcname=name)
                included.append(name)

        # Provenance chain: raw sources recorded per study
        index = []
        for study_dir in sorted((REPO_ROOT / "data/v2").glob("*")) + sorted((REPO_ROOT / "data/v3").glob("*")):
            study_json = study_dir / "study.json"
            if not study_json.exists():
                continue
            meta = json.loads(study_json.read_text())
            if studies and meta.get("study_id") not in studies and study_dir.name not in studies:
                continue
            for name, entry in (meta.get("source_files") or {}).items():
                source = REPO_ROOT / entry["path"]
                add(f"sources/{study_dir.name}/{source.name}", source)
                index.append(
                    {
                        "study": meta.get("study_id"),
                        "file": str(entry["path"]),
                        "sha256": entry["sha256"],
                        "declared_in": f"{study_dir.name}/study.json",
                    }
                )
            add(f"studies/{study_dir.name}/study.json", study_json)
            for artifact in ("observations.csv", "claims.csv", "release_replicates.csv"):
                add(f"studies/{study_dir.name}/{artifact}", study_dir / artifact)
        bundle.writestr("provenance_index.json", json.dumps(index, indent=1))

        # Claims audit + phase records
        add("audit/v3_claims_audit.csv", REPO_ROOT / "reports/v3/v3_claims_audit.csv")
        add("audit/v5_claims_audit_drafts.csv", REPO_ROOT / "reports/v5/v5_claims_audit_drafts.csv")
        for phase_dir in ("v2", "v3", "v4", "v5", "v6"):
            add(f"manifests/{phase_dir}_execution_manifest.json", REPO_ROOT / f"reports/{phase_dir}/execution_manifest.json")
            add(f"gates/{phase_dir}_gate.json", REPO_ROOT / f"reports/{phase_dir}/{phase_dir}_gate.json")

        # Agent activity + chain verification
        add("agents/agent_log.jsonl", REPO_ROOT / "proposals/agent_log.jsonl")
        try:
            from ..agents import verify_log_chain

            chain_ok = verify_log_chain()
        except Exception:
            chain_ok = False
        bundle.writestr(
            "verification.json",
            json.dumps(
                {
                    "agent_log_chain_intact": bool(chain_ok),
                    "not_comparable_register": NOT_COMPARABLE,
                    "dossier_created_utc": __import__("datetime").datetime.now(
                        __import__("datetime").timezone.utc
                    ).strftime("%Y-%m-%dT%H:%M:%SZ"),
                },
                indent=1,
            ),
        )
        add("risk_register.md", REPO_ROOT / "docs/risk_register.md")

    return out_path
