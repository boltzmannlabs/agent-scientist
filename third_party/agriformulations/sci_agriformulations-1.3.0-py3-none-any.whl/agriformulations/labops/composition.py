"""Composition-bridge surrogate: ingredient fractions -> physics parameters (v7).

A GP over role-aggregated ingredient fractions predicting log10 effective
rate and endpoint fraction, with HARD domain refusal outside the observed
composition ranges (the v5 registry pattern) and the standing prohibition on
training over published fit parameters - never fit metadata as if measured.

Catalog reality (2026-10-20): no formulation yet has both measured fractions
and release curves (Perera has fractions without curves; curve-bearing
studies carry fractions as None).  The module therefore ships as verified
machinery, demonstrated on declared synthetic data, and every caller must
pass ``overlap_report`` so the zero-overlap fact stays visible.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, WhiteKernel
from sklearn.preprocessing import StandardScaler

from ..catalog import Catalog

TARGETS = ("log10_rate", "endpoint_fraction")
MIN_TRAINING_ROWS = 8


def composition_features(catalog: Catalog) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Role-aggregated fractions per formulation + physics targets where both
    exist; also returns the overlap report showing how many do not."""
    from ..physics.features import physics_features

    physics = physics_features(catalog)
    fractions: dict[str, dict[str, float]] = {}
    for formulation in catalog.formulations:
        row = {"formulation_id": formulation.formulation_id, "study_id": formulation.study_id}
        for role in ("active", "matrix", "crosslinker", "filler"):
            values = [
                i.mass_fraction.value
                for i in formulation.ingredients
                if i.role == role and i.mass_fraction is not None
            ]
            row[f"fraction_{role}"] = float(np.sum(values)) if values else np.nan
        fractions[formulation.formulation_id] = row
    frame = pd.DataFrame(fractions.values())
    merged = frame.merge(
        physics[["formulation_id", "study_key", "calibrated_rate_per_time", "calibrated_r2", "unit"]],
        on="formulation_id", how="left",
    )
    merged["log10_rate"] = np.log10(merged["calibrated_rate_per_time"].clip(lower=1e-12))
    curve_bearing = merged["calibrated_rate_per_time"].notna()
    with_fractions = merged[[c for c in merged.columns if c.startswith("fraction_")]].notna().any(axis=1)
    overlap = merged[curve_bearing & with_fractions]
    report = {
        "formulations_total": int(len(merged)),
        "with_measured_fractions": int(with_fractions.sum()),
        "with_calibrated_curves": int(curve_bearing.sum()),
        "with_both": int(len(overlap)),
        "bridge_trainable": bool(len(overlap) >= MIN_TRAINING_ROWS),
    }
    return merged, report


class CompositionBridge:
    """GP bridge with hard domain refusal; refuses to fit on fit-metadata."""

    def __init__(self):
        self.model: dict[str, GaussianProcessRegressor] = {}
        self.scaler = StandardScaler()
        self.domain: dict[str, tuple[float, float]] = {}
        self.feature_columns: list[str] = []
        self.fitted = False

    def fit(self, frame: pd.DataFrame) -> "CompositionBridge":
        self.feature_columns = [c for c in frame.columns if c.startswith("fraction_")]
        if len(frame) < MIN_TRAINING_ROWS:
            raise ValueError(
                f"composition bridge needs >= {MIN_TRAINING_ROWS} formulations with both "
                "fractions and curves; got "
                f"{len(frame)} (catalog overlap limitation, exported honestly)"
            )
        x = frame[self.feature_columns].to_numpy(dtype=float)
        if np.isnan(x).any():
            raise ValueError("composition features must be complete for the bridge pilot")
        x_scaled = self.scaler.fit_transform(x)
        for column in self.feature_columns:
            values = frame[column].astype(float)
            self.domain[column] = (float(values.min()), float(values.max()))
        for target in TARGETS:
            kernel = Matern(nu=1.5, length_scale=1.0, length_scale_bounds="fixed") + WhiteKernel(
                noise_level=0.05, noise_level_bounds="fixed"
            )
            model = GaussianProcessRegressor(
                kernel=kernel, normalize_y=True, random_state=271828
            )
            model.fit(x_scaled, frame[target].astype(float).to_numpy())
            self.model[target] = model
        self.fitted = True
        return self

    def check_domain(self, candidate: dict[str, float]) -> tuple[bool, list[str]]:
        violations = []
        for column, (lo, hi) in self.domain.items():
            value = candidate.get(column)
            if value is None or value != value:
                violations.append(f"{column} missing")
                continue
            if not (lo - 1e-9 <= value <= hi + 1e-9):
                violations.append(f"{column}={value:.3g} outside observed [{lo:.3g}, {hi:.3g}]")
        return (not violations), violations

    def predict(self, candidate: dict[str, float]) -> dict:
        if not self.fitted:
            raise RuntimeError("CompositionBridge.predict before fit")
        ok, violations = self.check_domain(candidate)
        if not ok:
            raise PermissionError("outside composition domain: " + "; ".join(violations))
        x = np.array([[candidate[c] for c in self.feature_columns]], dtype=float)
        x_scaled = self.scaler.transform(x)
        return {target: float(self.model[target].predict(x_scaled)[0]) for target in TARGETS}


def synthetic_demo(seed: int = 271828) -> dict:
    """Verified machinery demonstration on declared synthetic data: rate
    follows a log-linear composition law; recovery and domain refusal are
    checked.  Synthetic rows are labelled and never mixed into the catalog."""
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(24):
        active = rng.uniform(0.1, 0.6)
        matrix = rng.uniform(0.2, 0.7)
        log_rate = -2.0 + 1.5 * active - 1.0 * matrix + rng.normal(0, 0.05)
        rows.append(
            {
                "fraction_active": round(active, 4),
                "fraction_matrix": round(matrix, 4),
                "log10_rate": log_rate,
                "endpoint_fraction": 0.55 + 0.3 * active + rng.normal(0, 0.02),
            }
        )
    frame = pd.DataFrame(rows)
    bridge = CompositionBridge().fit(frame)
    interior = {"fraction_active": float(frame.fraction_active.mean()),
                "fraction_matrix": float(frame.fraction_matrix.mean())}
    prediction = bridge.predict(interior)
    # recovery on the training law
    expected = -2.0 + 1.5 * interior["fraction_active"] - 1.0 * interior["fraction_matrix"]
    recovered = abs(prediction["log10_rate"] - expected) <= 0.15
    try:
        bridge.predict({"fraction_active": 0.95, "fraction_matrix": 0.9})
        refused = False
    except PermissionError:
        refused = True
    return {"recovery_pass": bool(recovered), "domain_refusal_pass": refused,
            "prediction": prediction, "n_synthetic_rows": len(frame),
            "note": "synthetic demonstration only; catalog has zero fraction+curve overlap"}
