"""Assay protocol registry: assay differences stay first-class metadata (v3).

Two release curves measured under different dialysis ratios, temperatures or
sink conditions are not interchangeable, and the framework must say so
structurally.  ``protocol_distance`` is a coarse shift diagnostic consumed by
the v5 surrogate layer; it is a warning light, never a pooling justification.
"""

from __future__ import annotations

from dataclasses import dataclass

ASSAY_TYPES = frozenset(
    {
        "dialysis_release",
        "immersion_release",
        "flow_through",
        "column_leach",
        "soil_incubation",
        "other",
    }
)

SINK_CONDITIONS = frozenset({"assumed_perfect_sink", "finite_bath", "unknown"})

CHIRAL_RESOLUTION = frozenset({"yes", "no", "unspecified"})


@dataclass(frozen=True)
class AssayProtocol:
    protocol_id: str
    assay_type: str
    target: str
    unit: str
    time_unit: str
    medium: str | None = None
    temperature_c: float | None = None
    ph: float | None = None
    sink_condition: str = "unknown"
    bath_to_sample_ratio: float | None = None
    sampling_scheme: str | None = None
    chiral_resolution: str = "unspecified"

    def __post_init__(self):
        if not self.protocol_id.strip():
            raise ValueError("protocol_id is required")
        if self.assay_type not in ASSAY_TYPES:
            raise ValueError(f"assay_type {self.assay_type!r} not in {sorted(ASSAY_TYPES)}")
        if self.sink_condition not in SINK_CONDITIONS:
            raise ValueError(f"sink_condition must be one of {sorted(SINK_CONDITIONS)}")
        resolution = (self.chiral_resolution or "unspecified").strip() or "unspecified"
        object.__setattr__(self, "chiral_resolution", resolution)
        if resolution not in CHIRAL_RESOLUTION:
            raise ValueError(f"chiral_resolution must be one of {sorted(CHIRAL_RESOLUTION)}")
        if not self.target.strip() or not self.unit.strip() or not self.time_unit.strip():
            raise ValueError("target, unit and time_unit are required")
        if self.bath_to_sample_ratio is not None and not self.bath_to_sample_ratio > 0:
            raise ValueError("bath_to_sample_ratio must be positive")
        if self.sink_condition == "finite_bath" and self.bath_to_sample_ratio is None:
            raise ValueError("finite_bath protocols must declare bath_to_sample_ratio")

    def to_dict(self) -> dict:
        return {
            "protocol_id": self.protocol_id,
            "assay_type": self.assay_type,
            "target": self.target,
            "unit": self.unit,
            "time_unit": self.time_unit,
            "medium": self.medium,
            "temperature_c": self.temperature_c,
            "ph": self.ph,
            "sink_condition": self.sink_condition,
            "bath_to_sample_ratio": self.bath_to_sample_ratio,
            "sampling_scheme": self.sampling_scheme,
            "chiral_resolution": self.chiral_resolution,
        }


def protocol_from_dict(record: dict) -> AssayProtocol:
    return AssayProtocol(
        protocol_id=record["protocol_id"],
        assay_type=record["assay_type"],
        target=record["target"],
        unit=record["unit"],
        time_unit=record["time_unit"],
        medium=record.get("medium"),
        temperature_c=record.get("temperature_c"),
        ph=record.get("ph"),
        sink_condition=record.get("sink_condition", "unknown"),
        bath_to_sample_ratio=record.get("bath_to_sample_ratio"),
        sampling_scheme=record.get("sampling_scheme"),
        chiral_resolution=record.get("chiral_resolution", "unspecified"),
    )


def protocol_distance(a: AssayProtocol, b: AssayProtocol) -> float:
    """Coarse dissimilarity in [0, 1]: incompatible targets score 1 outright;
    otherwise mismatches accumulate weighted penalties.  Diagnostic only."""
    if (a.target, a.unit, a.time_unit) != (b.target, b.unit, b.time_unit):
        return 1.0
    penalties = 0.30 if a.assay_type != b.assay_type else 0.0
    if a.medium != b.medium:
        penalties += 0.15
    if a.temperature_c is not None and b.temperature_c is not None:
        penalties += min(abs(a.temperature_c - b.temperature_c) / 40.0, 0.20)
    else:
        penalties += 0.05  # unknown vs known is a small, real difference
    if a.ph is not None and b.ph is not None:
        penalties += min(abs(a.ph - b.ph) / 4.0, 0.20)
    else:
        penalties += 0.05
    if a.sink_condition != b.sink_condition:
        penalties += 0.10
    return round(min(penalties, 1.0), 4)
