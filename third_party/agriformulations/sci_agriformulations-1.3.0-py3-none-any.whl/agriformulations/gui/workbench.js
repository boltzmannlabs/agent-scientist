"use strict";
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt=v=>v===null||v===undefined?"—":typeof v==="number"?(Math.abs(v)>0&&Math.abs(v)<.001?v.toExponential(2):v.toLocaleString(undefined,{maximumFractionDigits:4})):String(v);
let state={}, identity={}, upload=null, compareIds=new Set(), loading=false, activeTab="project";
const schemas={
 brief:[["name","Project name","text"],["active_name","Active / nutrient identity","text"],["crop","Crop / system","text"],["target","Pest / nutrient objective","text"],["application","Application context","text"],["format","Formulation type",["CR","SC","EC","WG","FERT"]]],
 recipe:[["batch_g","Batch size (g)"],["active_pct","Pure active (% w/w)"],["count","Candidate count"],["seed","Random seed"],["cost_limit","Cost ceiling per kg (optional)"],["currency","Currency / cost units","text"]],
 kinetics:[["model","Release mechanism",["zero_order","fickian","first_order","weibull"]],["rate_per_day","Effective release rate (/day)"],["plateau","Plateau fraction (0–1)"],["lag_days","Induction lag (days)"],["tau_days","Weibull time scale (days)"],["beta","Weibull shape"],["horizon_days","Simulation horizon (days)"],["reservoir_half_life_days","Reservoir degradation half-life (days, optional)"],["available_half_life_days","Available-active half-life (days, optional)"]],
 stability:[["reference_rate_per_day","Chemical loss rate at reference (/day)"],["reference_temperature_c","Reference temperature (°C)"],["activation_energy_kj_mol","Chemical degradation Ea (kJ/mol)"],["horizon_days","Storage horizon (days)"],["minimum_retained_fraction","Minimum retained active (0–1)"]],
 physical:[["particle_diameter_um","Particle diameter (µm)"],["viscosity_mpa_s","Dynamic viscosity (mPa·s)"],["density_difference_kg_m3","Particle minus vehicle density (kg/m³)"],["container_height_cm","Container height (cm)"]],
 dosage:[["evaluation_day","Target evaluation day"],["target_available_g_ha","Target available active (g/ha)"],["storage_retained_fraction","Storage retained fraction (0–1)"],["deposition_fraction","Deposited fraction (0–1)"],["maximum_product_kg_ha","Product ceiling (kg/ha, optional)"],["product_density_kg_l","Product density (kg/L, optional)"],["spray_volume_l_ha","Spray volume (L/ha, optional)"]],
 experiment:[["n_recipes","Number of recipes to test"],["independent_batches","Independent batches per setting"],["technical_replicates","Technical readings per sample"],["seed","Randomization seed"],["reference_name","Reference / comparator","text"]],
 import:[["instrument","Instrument / validated method","text"],["time_unit","Time units",["days","hours","minutes"]],["value_unit","Value units",["percent","fraction"]],["dose_unit","Dose units",["g_ai_ha","mg_l"]],["crop_or_system","Dose-response crop / system","text"],["target","Dose-response target","text"],["assay","Dose-response assay","text"],["target_response_pct","Target biological response (%)"],["recipe_value","Recipe label in file (optional)","text"],["condition_value","Assay condition to import (optional)","text"]]
};
function fields(id,prefix,schema,values){
 $(id).innerHTML=schema.map(([key,label,type])=>{
  const eid=prefix+"_"+key, value=values[key]??"";
  return '<label for="'+eid+'">'+esc(label)+(Array.isArray(type)?'<select id="'+eid+'">'+type.map(x=>'<option value="'+esc(x)+'"'+(x===value?" selected":"")+'>'+esc(x)+'</option>').join("")+'</select>':'<input id="'+eid+'" type="'+(type==="text"?"text":"number")+'"'+(type==="text"?"":' step="any"')+' value="'+esc(value)+'">')+'</label>';
 }).join("");
}
function read(prefix,schema){
 return Object.fromEntries(schema.map(([key,,type])=>{const v=$(prefix+"_"+key).value;return [key,type==="text"||Array.isArray(type)?v:(v===""?null:Number(v))];}));
}
function jsonInput(id,fallback){
 const s=$(id).value.trim(); if(!s)return fallback;
 try{return JSON.parse(s);}catch{throw new Error(id+" must contain valid JSON");}
}
function nums(s){if(!s.trim())return [];const values=s.split(",").map(x=>Number(x.trim()));if(values.some(x=>!Number.isFinite(x)))throw new Error("Enter comma-separated numbers without text.");return values;}
function showError(e){$("error").hidden=!e;$("error").textContent=e?e.message||String(e):"";}
async function request(action,body){
 const r=await fetch("/api/rnd/"+action,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
 const result=await r.json();if(!r.ok){const error=new Error(result.error||"Request failed");error.status=r.status;throw error;}return result;
}
async function task(label,fn){
 if(loading)return; loading=true;showError(null);$("busy").textContent=label+"…";
 document.querySelectorAll("button").forEach(b=>b.disabled=true);
 const inputs=Array.from(document.querySelectorAll("input,select,textarea")).map(element=>[element,element.disabled]);
 inputs.forEach(([element])=>element.disabled=true);
 try{await fn();}catch(e){showError(e);}
 finally{loading=false;$("busy").textContent="";document.querySelectorAll("button").forEach(b=>b.disabled=false);inputs.forEach(([element,disabled])=>element.disabled=disabled);renderAgentPlan();}
}
function tab(name){
 activeTab=name;renderRecipeContext();
 $("pageHeading").textContent=({project:"Product brief & projects",library:"Recipe library",recipes:"Suggest recipes",kinetics:"Release & kinetics",stability:"Stability",dosage:"Dose scenarios",experiments:"Plan experiments",results:"Results & learning",assistant:"Ask the research agents"})[name]||"Research workbench";
 document.querySelectorAll(".tab").forEach(n=>n.hidden=n.id!=="tab-"+name);
 document.querySelectorAll("nav button").forEach(n=>n.classList.toggle("active",n.dataset.tab===name));
}
function renderRecipeContext(){
 const needsRecipe=["kinetics","stability","dosage","experiments"].includes(activeTab);
 $("recipeContext").hidden=!needsRecipe;
 const available=(state.recipes||[]).length>0;
 $("recipeSelectionLabel").hidden=!available;
 $("modeledActiveLabel").hidden=!available||(selected()?.active_components||[]).length<2;
 $("openRecipeEditor").hidden=available;
 $("recipeContextHint").textContent=available?"":"Create or load a recipe before connecting these calculations to a formulation.";
}
function markDirty(){$("saveStatus").textContent="Unsaved changes"+(identity.revision?" · revision "+identity.revision:"");}
function capture(){
 const previousK=JSON.stringify(state.kinetics_input),previousS=JSON.stringify(state.stability_input),previousD=JSON.stringify(state.dosage_input),previousE=JSON.stringify(state.experiment_input);
 state.brief={...state.brief,...read("brief",schemas.brief),...read("recipe",schemas.recipe),
  objective:$("objective").value,bounds_source:$("boundsSource").value};
 state.brief.ingredients=Array.from($("ingredients").querySelectorAll("tbody tr")).map(row=>{
  const value={};row.querySelectorAll("[data-key]").forEach(el=>{value[el.dataset.key]=el.type==="number"?(el.value===""?null:Number(el.value)):el.value;});return value;
 });
 state.brief.process=$("processSteps").value.split("\n").filter(x=>x.trim()).map((instruction,i)=>({step:i+1,instruction}));
 state.brief.process_parameters=jsonInput("processParameters",[]);
 state.brief.specs=jsonInput("productSpecs",[]);
 state.kinetics_input={...state.kinetics_input,...read("kinetics",schemas.kinetics),
  parameter_source:$("parameterSource").value,release_specs:jsonInput("releaseSpecs",[])};
 state.stability_input={...state.stability_input,...read("stability",schemas.stability),physical:read("physical",schemas.physical),
  temperatures_c:nums($("stabilityTemperatures").value),temperature_profile:jsonInput("temperatureProfile",[]),
  allow_extrapolation:$("allowExtrapolation").checked};
 state.dosage_input={...state.dosage_input,...read("dosage",schemas.dosage)};
 state.experiment_input={...state.experiment_input,...read("experiment",schemas.experiment),
  sampling_days:nums($("samplingDays").value),process_factors:jsonInput("processFactors",{})};
 if(previousK!==JSON.stringify(state.kinetics_input)){delete state.kinetics_result;delete state.dosage_result;}
 if(previousS!==JSON.stringify(state.stability_input))delete state.stability_result;
 if(previousD!==JSON.stringify(state.dosage_input))delete state.dosage_result;
 if(previousE!==JSON.stringify(state.experiment_input))delete state.experiment_result;
 $("projectTitle").textContent=state.brief.name;
 return state;
}
function ingredientTable(){
 const roles=["active","carrier","matrix","solvent","surfactant","dispersant","binder","filler","coating","stabilizer","other"];
 const columns=[["name","Material / grade"],["role","Role"],["min_pct","Min %"],["max_pct","Max %"],["purity_pct","Purity %"],["target_active_pct","Individual active target %"],["cost_per_kg","Cost / kg"],["supplier","Supplier"],["lot","Lot"]];
 $("ingredients").innerHTML="<thead><tr>"+columns.map(([,n])=>"<th>"+n+"</th>").join("")+"<th></th></tr></thead><tbody>"+state.brief.ingredients.map((r,i)=>"<tr>"+columns.map(([k])=>"<td>"+(k==="role"?'<select data-key="role">'+roles.map(role=>'<option'+(role===r[k]?" selected":"")+'>'+role+"</option>").join("")+"</select>":'<input aria-label="'+esc(columns.find(c=>c[0]===k)[1])+'" data-key="'+k+'" type="'+(["name","supplier","lot"].includes(k)?"text":"number")+'" step="any" value="'+esc(r[k]??"")+'">')+"</td>").join("")+'<td><button class="secondary" data-remove="'+i+'" aria-label="Remove ingredient">×</button></td></tr>').join("")+"</tbody>";
 $("ingredients").querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{capture();state.brief.ingredients.splice(+b.dataset.remove,1);ingredientTable();markDirty();});
}
function fillForms(){
 fields("briefFields","brief",schemas.brief,state.brief);
 fields("recipeFields","recipe",schemas.recipe,state.brief);
 fields("kineticsFields","kinetics",schemas.kinetics,state.kinetics_input);
 fields("stabilityFields","stability",schemas.stability,state.stability_input);
 fields("physicalFields","physical",schemas.physical,state.stability_input.physical||{});
 fields("dosageFields","dosage",schemas.dosage,state.dosage_input);
 fields("experimentFields","experiment",schemas.experiment,state.experiment_input);
 fields("importFields","import",schemas.import,state.import_settings||{time_unit:"days",value_unit:"percent",dose_unit:"g_ai_ha",target_response_pct:80});
 $("objective").value=state.brief.objective||"";$("boundsSource").value=state.brief.bounds_source||"";
 $("processSteps").value=(state.brief.process||[]).map(p=>p.instruction||p.note||JSON.stringify(p)).join("\n");
 $("processParameters").value=JSON.stringify(state.brief.process_parameters||[],null,2);
 $("productSpecs").value=JSON.stringify(state.brief.specs||[],null,2);
 $("releaseSpecs").value=JSON.stringify(state.kinetics_input.release_specs||[],null,2);
 $("parameterSource").value=state.kinetics_input.parameter_source||"user scenario";
 $("stabilityTemperatures").value=state.stability_input.temperatures_c.join(", ");
 $("temperatureProfile").value=JSON.stringify(state.stability_input.temperature_profile||[],null,2);
 $("allowExtrapolation").checked=state.stability_input.allow_extrapolation===true;
 $("samplingDays").value=state.experiment_input.sampling_days.join(", ");
 $("processFactors").value=JSON.stringify(state.experiment_input.process_factors||{},null,2);
 $("responseData").value=JSON.stringify(state.response_measurements||[],null,2);
 ingredientTable();updateModelFields();
}
function updateModelFields(){
 const weibull=$("kinetics_model").value==="weibull";
 for(const k of ["tau_days","beta"])$("kinetics_"+k).closest("label").hidden=!weibull;
 $("kinetics_rate_per_day").closest("label").hidden=weibull;
}
function table(id,columns,rows,downloadName){
 const el=typeof id==="string"?$(id):id;
 if(!rows.length){el.innerHTML='<p class="muted">No results yet.</p>';return;}
 el.innerHTML='<div class="table-wrap"><table><thead><tr>'+columns.map(c=>"<th>"+esc(c)+"</th>").join("")+"</tr></thead><tbody>"+rows.map(r=>"<tr>"+columns.map(c=>"<td>"+esc(fmt(r[c]))+"</td>").join("")+"</tr>").join("")+"</tbody></table></div>";
 if(downloadName){const b=document.createElement("button");b.className="secondary download";b.textContent="Download CSV";b.onclick=()=>download(downloadName,csv(columns,rows),"text/csv");el.appendChild(b);}
}
function csv(columns,rows){
 const cell=v=>'"'+String(v??"").replace(/^([=+@-])/,"'$1").replace(/"/g,'""')+'"';
 return [columns.map(cell).join(","),...rows.map(r=>columns.map(c=>cell(r[c])).join(","))].join("\n");
}
function download(name,content,type){
 const blob=new Blob([content],{type:type||"application/octet-stream"}),url=URL.createObjectURL(blob),a=document.createElement("a");
 a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function metrics(id,items){
 $(id).innerHTML='<div class="metrics">'+items.map(([v,l])=>'<div class="metric"><b>'+esc(fmt(v))+"</b><span>"+esc(l)+"</span></div>").join("")+"</div>";
}
const colors=["#328565","#cc733d","#447dc0","#a16a9f","#aa8631","#617b89"];
function plot(id,x,series,xlabel,ylabel){
 const el=$(id);if(!x?.length){el.innerHTML='<p class="muted">Run an analysis to see the chart.</p>';return;}
 const W=780,H=300,p={l:70,r:20,t:20,b:50};
 const all=series.flatMap(s=>s.y).filter(Number.isFinite),minX=Math.min(...x),maxX=Math.max(...x);
 const minY=Math.min(0,...all),maxY=Math.max(1e-8,...all)*1.06;
 const X=t=>p.l+(t-minX)/(maxX-minX||1)*(W-p.l-p.r),Y=v=>H-p.b-(v-minY)/(maxY-minY||1)*(H-p.t-p.b);
 let svg='<svg role="img" aria-label="'+esc(ylabel+" against "+xlabel)+'" viewBox="0 0 '+W+" "+H+'"><title>'+esc(ylabel+" against "+xlabel)+"</title>";
 for(let i=0;i<=4;i++){const y=minY+(maxY-minY)*i/4;svg+='<line x1="'+p.l+'" y1="'+Y(y)+'" x2="'+(W-p.r)+'" y2="'+Y(y)+'" stroke="var(--line)"/><text x="'+(p.l-8)+'" y="'+(Y(y)+4)+'" text-anchor="end" fill="var(--muted)" font-size="11">'+esc(fmt(y))+"</text>";}
 for(let i=0;i<=5;i++){const v=minX+(maxX-minX)*i/5;svg+='<text x="'+X(v)+'" y="'+(H-p.b+20)+'" text-anchor="middle" fill="var(--muted)" font-size="11">'+esc(fmt(v))+"</text>";}
 series.forEach((s,j)=>{
  const color=colors[j%colors.length];
  if(!s.points)svg+='<path d="'+s.y.map((v,i)=>(i?"L":"M")+X(x[i]).toFixed(2)+","+Y(v).toFixed(2)).join(" ")+'" fill="none" stroke="'+color+'" stroke-width="2.5"'+(s.dash?' stroke-dasharray="6 4"':"")+"/>";
  const stride=Math.max(1,Math.floor(x.length/80));
  s.y.forEach((v,i)=>{if(s.points||i%stride===0)svg+='<circle cx="'+X(x[i])+'" cy="'+Y(v)+'" r="'+(s.points?4:3)+'" fill="'+color+'" opacity="'+(s.points?1:.35)+'"><title>'+esc(s.name+": "+fmt(v)+" at "+fmt(x[i])+" "+xlabel)+"</title></circle>";});
 });
 svg+='<text x="'+W/2+'" y="'+(H-5)+'" text-anchor="middle" fill="var(--muted)" font-size="12">'+esc(xlabel)+'</text><text transform="translate(17 '+H/2+') rotate(-90)" text-anchor="middle" fill="var(--muted)" font-size="12">'+esc(ylabel)+"</text></svg>";
 el.innerHTML=svg+'<div class="legend">'+series.map((s,i)=>'<span style="--series:'+colors[i%colors.length]+'">'+esc(s.name)+"</span>").join("")+"</div>";
 const details=document.createElement("details");details.innerHTML="<summary>Data table & download</summary>";
 const target=document.createElement("div");details.appendChild(target);el.appendChild(details);
 table(target,[xlabel,...series.map(s=>s.name)],x.map((t,i)=>Object.fromEntries([[xlabel,t],...series.map(s=>[s.name,s.y[i]])])),id+".csv");
}
function selected(){return (state.recipes||[]).find(r=>r.recipe_id===state.selected_recipe_id);}
function renderRecipes(){
 const recipes=state.recipes||[];
 $("activeRecipe").innerHTML='<option value="">Choose a recipe</option>'+recipes.map(r=>'<option value="'+esc(r.recipe_id)+'"'+(r.recipe_id===state.selected_recipe_id?" selected":"")+'>'+esc(r.name)+" · "+esc(r.recipe_id)+"</option>").join("");
 if(state.recipe_result)metrics("recipeSummary",[[recipes.length,"feasible recipe drafts"],[state.brief.active_pct,"% pure active target"],["Unmeasured","performance status"]]);
 $("recipeTable").innerHTML=recipes.length?'<table><thead><tr><th>Compare</th><th>Candidate</th><th>Pure active</th><th>Cost / kg</th><th>Status</th><th></th></tr></thead><tbody>'+recipes.map(r=>'<tr><td><input type="checkbox" aria-label="Compare '+esc(r.name)+'" data-compare="'+r.recipe_id+'"'+(compareIds.has(r.recipe_id)?" checked":"")+'></td><td>'+esc(r.name)+'<small>'+esc(r.recipe_id)+'</small></td><td>'+fmt(r.active_fraction*100)+'%</td><td>'+esc(fmt(r.cost_per_kg))+'</td><td>Draft · unmeasured</td><td><button data-select="'+r.recipe_id+'">Select</button></td></tr>').join("")+"</tbody></table>":'<p class="muted">Add ingredients and generate candidates.</p>';
 $("recipeTable").querySelectorAll("[data-select]").forEach(b=>b.onclick=()=>chooseRecipe(b.dataset.select));
 $("recipeTable").querySelectorAll("[data-compare]").forEach(b=>b.onchange=()=>{b.checked?compareIds.add(b.dataset.compare):compareIds.delete(b.dataset.compare);renderCompare();});
 const r=selected();
 const components=r?.active_components||[];
 if(!components.some(c=>c.name===state.selected_active_name))state.selected_active_name=components[0]?.name||"";
 $("modeledActive").innerHTML=components.map(c=>'<option value="'+esc(c.name)+'"'+(c.name===state.selected_active_name?" selected":"")+'>'+esc(c.name)+'</option>').join("");
 if(r){table("weighout",["Material","Role","Mass %","Weigh-out g","Supplier","Lot"],r.ingredients.map(i=>({"Material":i.name,"Role":i.role,"Mass %":i.pct,"Weigh-out g":i.grams,"Supplier":i.supplier,"Lot":i.lot})),"weighout.csv");}
 else $("weighout").textContent="Select a candidate.";
 renderCompare();renderRecipeContext();
}
function renderRecipeDesign(){
 const design=state.recipe_result;
 $("recipeDesignAssumptions").innerHTML=(design?.design_assumptions||[]).length
  ?'<h3>Design assumptions to verify</h3><ul>'+design.design_assumptions.map(a=>'<li>'+esc(a)+'</li>').join("")+'</ul><p>'+esc(design.agent_rationale||"")+'</p>':"";
}
function createRecipesWithAgents(){return task("Agents designing recipes",async()=>{
 capture();const query=$("recipeDesignQuery").value.trim();
 if(!query)throw new Error("Describe the formulation you want to create.");
 $("recipeDesignStatus").textContent="Designing ingredients and recipe candidates from your request…";
 try{
  const result=await agentTurn(query,"recipes","gpt","create_recipes");
  $("recipeDesignStatus").textContent=result.recipe_creation?.status==="created"
   ?result.recipe_creation.recipe_ids.length+" recipe candidates created. "+(result.project_saved?"Saved as project revision "+result.project_saved.revision+".":"Review the save warning below.")
   :"No recipe candidates were created. Review the agent’s response below.";
 }catch(error){$("recipeDesignStatus").textContent="Recipe creation did not complete. Your existing recipes have been retained.";throw error;}
});}
function recordAnalysis(kind,result,inputs){
 const entry={kind,recipe_id:state.selected_recipe_id||null,active_name:state.selected_active_name||null,
   inputs:structuredClone(inputs),result:structuredClone(result)};
 (state.analysis_runs??=[]).push(entry);
 // Full inputs/results remain available for candidate comparisons and project export.
}
function lastAnalysis(recipeId,kind,activeName=null){
 return (state.analysis_runs||[]).filter(r=>r.recipe_id===recipeId&&r.kind===kind&&(activeName===null||r.active_name===activeName)).at(-1);
}

function restoreRecipeAnalyses(){
 for(const kind of ["kinetics","stability","dosage"]){
  delete state[kind+"_result"];
  const entry=lastAnalysis(state.selected_recipe_id,kind,state.selected_active_name);
  if(entry){state[kind+"_input"]=structuredClone(entry.inputs);state[kind+"_result"]=structuredClone(entry.result);}
 }
}
function candidateAnalysisRows(kind){
 return (state.recipes||[]).flatMap(recipe=>(recipe.active_components||[]).map(active=>{
  const entry=lastAnalysis(recipe.recipe_id,kind,active.name);
  const row={"Recipe":recipe.name,"Active":active.name,"Status":entry?"Scenario calculated":"Not simulated"};
  if(!entry)return row;
  const r=entry.result,p=entry.inputs;
  row["Assumptions"]=(entry.assumptions||r.scenario_assumptions||[]).join(" ");
  if(kind==="kinetics")Object.assign(row,{"Model":r.model,"Release at horizon":r.release_fraction.at(-1),"Horizon days":r.times_days.at(-1),"t50 days":r.milestones.t50_days,"Parameter source":r.parameter_source});
  if(kind==="stability")Object.assign(row,{"Storage days":p.horizon_days,"Chemical retention":r.curves.map(c=>c.temperature_c+" C: "+fmt(c.retained_at_horizon)).join("; "),"Evidence":r.evidence});
  if(kind==="dosage")Object.assign(row,{"Product kg/ha (scenario)":r.product_kg_ha,"Target active g/ha":r.target_available_g_ha,"Evaluation day":r.evaluation_day,"Storage retention":p.storage_retained_fraction,"Active fraction":p.active_fraction??active.active_fraction});
  return row;
 }));
}
function renderCandidateAnalyses(){
 for(const kind of ["kinetics","stability","dosage"]){
  const rows=candidateAnalysisRows(kind),columns=[...new Set(rows.flatMap(r=>Object.keys(r)))];
  table(kind+"Candidates",columns,rows,kind+"_candidate_scenarios.csv");
 }
 const product=state.product_development;
 $("productDevelopmentStatus").textContent=product
  ?product.candidate_count+" recipe drafts · "+product.active_count+" actives · "+product.analysis_count+" saved scenario results. Select a recipe and active to inspect the curves."
  :"Create a new product project from this brief or the latest assessment, with recipe candidates and all three scenario types.";
}
function developProductWithAgents(){return task("Developing new product",async()=>{
 capture();
 const details=$("productDevelopmentQuery").value.trim();
 const q=details||"Start a new product project around the active ingredients and crop/target in the latest saved assessment or current brief. Create three distinct recipe candidates for a 1000 g laboratory batch. Run kinetics, stability and storage-adjusted dose scenarios for every recipe and every individual active, using reasonable explicit R&D assumptions where measurements are missing. Save all results to the new project and show them in Recipes, Kinetics, Stability and Dose scenarios. Preserve the source assessment project. Dose targets are hypothetical comparison benchmarks, not field recommendations.";
 await agentTurn(q,"project","gpt","develop_product");
 tab("recipes");
});}

function renderCompare(){
 const rows=(state.recipes||[]).filter(r=>compareIds.has(r.recipe_id)).flatMap(r=>(r.active_components||[]).map(active=>{
 const imports=(state.imports||[]).filter(i=>i.recipe_id===r.recipe_id);
 const k=lastAnalysis(r.recipe_id,"kinetics",active.name),st=lastAnalysis(r.recipe_id,"stability",active.name),d=lastAnalysis(r.recipe_id,"dosage",active.name);
 return {"Release scenario":k?fmt(k.result.release_fraction.at(-1))+" at "+fmt(k.result.times_days.at(-1))+" d ("+k.active_name+")":"unmodeled",
 "Chemical retention":st?st.result.curves.map(c=>c.temperature_c+"C: "+fmt(c.retained_at_horizon)).join("; ")+" at "+st.inputs.horizon_days+" d":"unmodeled",
 "Dose scenario kg/ha":d?d.result.product_kg_ha:null,"Dose target":d?d.inputs.target_available_g_ha+" g/ha at day "+d.inputs.evaluation_day:"—",
 "Recipe":r.name,"Active":active.name,"Cost / kg":r.cost_per_kg,"Active %":active.active_fraction*100,
 "Imported datasets":imports.length,"Compatibility":r.compatibility,
 ...Object.fromEntries(r.ingredients.map(i=>[i.name+" %",i.pct]))};
 }));
 const columns=[...new Set(rows.flatMap(r=>Object.keys(r)))];table("compare",columns,rows,"candidate_comparison.csv");
}
function renderKinetics(){
 const r=state.kinetics_result;
 if(!r){$("kineticsSummary").textContent="Run the current settings to see results.";for(const id of ["releaseChart","massChart","sensitivityChart"])plot(id,[],[],"","");return;}
 metrics("kineticsSummary",[[r.milestones.t10_days,"t10 days"],[r.milestones.t50_days,"t50 days"],[r.milestones.t90_days,"t90 days"]]);
 $("kineticsSummary").innerHTML+='<p class="muted">'+esc(r.evidence+" · "+r.parameter_source)+'</p>'+r.spec_results.map(c=>'<p class="'+(c.verdict==="PASS"?"status-good":"status-bad")+'">'+(c.verdict==="PASS"?"✓ ":"✕ ")+"Day "+c.day+": "+fmt(c.fraction)+" · "+c.verdict+"</p>").join("");
 plot("releaseChart",r.times_days,[{name:"Cumulative release",y:r.release_fraction}],"Time (days)","Released fraction");
 plot("massChart",r.times_days,[{name:"Reservoir",y:r.reservoir_fraction},{name:"Available",y:r.available_fraction},{name:"Degraded",y:r.degraded_fraction}],"Time (days)","Fraction of initial active");
 plot("sensitivityChart",r.times_days,r.sensitivity.map(s=>({name:s.factor+"× release rate",y:s.release_fraction,dash:s.factor!==1})),"Time (days)","Released fraction");
}
function renderStability(){
 const r=state.stability_result;
 for(const key of ["reference_rate_per_day","reference_temperature_c","activation_energy_kj_mol"])
  $("stability_"+key).disabled=Boolean(state.stability_input.calibration);
 $("stabilityFitStatus").textContent=state.stability_input.calibration?"Fitted chemical assay selected"+(state.stability_input.calibration.weakly_identified?" · only two temperatures; weakly identified":""):"User-specified degradation assumptions.";
 if(!r){plot("stabilityChart",[],[],"","");$("stabilitySummary").textContent="Run current stability settings.";$("physicalSummary").textContent="";$("profileChart").textContent="";$("storageTemperature").innerHTML="";return;}
 plot("stabilityChart",r.times_days,r.curves.map(c=>({name:c.temperature_c+" °C",y:c.retained_fraction})),"Storage time (days)","Retained active fraction");
 table("stabilitySummary",["Temperature °C","Retained at horizon","Modeled threshold crossing (days)"],r.curves.map(c=>({"Temperature °C":c.temperature_c,"Retained at horizon":c.retained_at_horizon,"Modeled threshold crossing (days)":c.threshold_crossing_days})),"chemical_stability.csv");
 $("storageTemperature").innerHTML=r.curves.map((c,i)=>'<option value="'+i+'">'+c.temperature_c+" °C</option>").join("");
 const p=r.physical_screen;
 $("physicalSummary").innerHTML=p?'<p><b>'+esc(p.direction)+"</b>: "+fmt(p.velocity_m_per_day)+" m/day</p><p>Ideal container travel: "+fmt(p.ideal_travel_days)+" days</p>":"";
 if(r.temperature_profile)plot("profileChart",r.temperature_profile.times_days,[{name:"Temperature-history retention",y:r.temperature_profile.retained_fraction}],"Time (days)","Retained fraction");
 else $("profileChart").textContent="Add temperature segments to simulate a temperature history.";
}
function renderDosage(){
 const r=state.dosage_result;
 if(r){metrics("dosageSummary",[[r.product_kg_ha,"kg product / ha"],[r.product_l_ha,"L product / ha"],[r.tank_product_g_l,"g product / L spray"]]);
 $("dosageSummary").innerHTML+='<p>'+esc(r.equation)+'</p><p class="note">'+esc(r.limitations[0])+'</p>'+(r.within_user_ceiling===false?'<p class="status-bad">✕ Exceeds the supplied product ceiling.</p>':"");
 plot("dosageChart",r.deposition_sensitivity.map(s=>s.deposition_fraction),[{name:"Required product",y:r.deposition_sensitivity.map(s=>s.product_kg_ha)}],"Deposited fraction","Product (kg/ha)");
 }else {$("dosageSummary").textContent="Select a recipe and calculate the scenario.";$("dosageChart").textContent="";}
 const d=state.dose_response_result;
 if(!d){$("doseResponseChart").textContent="";$("doseResponseSummary").textContent="";}
 if(d){plot("doseResponseChart",d.doses,[{name:"Fitted response",y:d.predicted_response_pct}],"Dose ("+d.dose_unit+")","Biological response (%)");
 $("doseResponseSummary").innerHTML='<p>'+esc(d.within_tested_range?"Interpolated target dose: "+fmt(d.estimated_dose)+" "+d.dose_unit:"Target lies outside supported observations; no interpolated dose returned.")+'</p><p class="note">'+esc(d.limitations)+"</p>";}
}
function renderExperiments(){
 const r=state.experiment_result;
 if(!r){$("runSheet").textContent="Build a plan after generating recipes.";$("experimentSummary").textContent="";$("testQueue").textContent="";return;}
 metrics("experimentSummary",[[r.selected_recipe_ids.length,"recipes selected"],[r.n_independent_batches,"independent batches"],[r.n_technical_readings_per_time,"readings per time"]]);
 table("runSheet",["Order","Batch","Recipe","Role","Process settings","Technical readings"],r.runs.map(b=>({"Order":b.run_order,"Batch":b.batch_id,"Recipe":b.recipe_name,"Role":b.role,"Process settings":JSON.stringify(b.process_settings),"Technical readings":b.technical_replicates})),"experiment_run_sheet.csv");
 $("testQueue").innerHTML='<div class="table-wrap"><table><thead><tr><th>Test</th><th>Status</th><th>Method</th><th>Acceptance limits & units</th><th>Schedule / owner</th></tr></thead><tbody>'+r.test_queue.map((t,i)=>'<tr><td>'+esc(t.test)+'</td><td><select aria-label="Test status" data-testindex="'+i+'" data-testfield="status">'+["planned","running","complete","failed","needs review"].map(v=>'<option'+(v===t.status?" selected":"")+'>'+v+'</option>').join("")+'</select></td>'+["method","acceptance","schedule"].map(k=>'<td><input aria-label="'+esc(k)+'" data-testindex="'+i+'" data-testfield="'+k+'" value="'+esc(t[k]||"")+'"></td>').join("")+'</tr>').join("")+'</tbody></table></div>';
 $("testQueue").querySelectorAll("[data-testindex]").forEach(el=>el.onchange=()=>{state.experiment_result.test_queue[+el.dataset.testindex][el.dataset.testfield]=el.value;markDirty();});
 const downloadTests=document.createElement("button");downloadTests.className="secondary download";downloadTests.textContent="Download test queue CSV";downloadTests.onclick=()=>download("test_queue.csv",csv(["test","status","method","acceptance","schedule"],state.experiment_result.test_queue),"text/csv");$("testQueue").appendChild(downloadTests);
}
function renderImports(){
 $("importList").innerHTML=(state.imports||[]).map((item,i)=>'<div class="note"><b>'+esc(item.source.filename)+'</b><br>'+esc(item.kind)+" · "+item.observations.length+" included, "+item.excluded.length+" excluded<br>"+esc(item.recipe_id)+'<br><button data-fit="'+i+'" class="secondary">Fit this dataset</button></div>').join("")||'<p class="muted">No measurements imported.</p>';
 $("importList").querySelectorAll("[data-fit]").forEach(b=>b.onclick=()=>fitImport(+b.dataset.fit));
 const r=state.release_fit;
 if(!r){$("fitSummary").textContent="";$("fitChart").textContent="";}
 if(r){table("fitSummary",["Model","Tail holdout MAE"],r.models.map(m=>({"Model":m.model,"Tail holdout MAE":m.holdout_mae})));
 plot("fitChart",r.times_days,[{name:"Observed batch means",y:r.observed_means,points:true},...r.models.map(m=>({name:m.model,y:m.predicted}))],"Time (days)","Release fraction");
 const b=document.createElement("button");b.textContent="Use selected model parameters";b.onclick=()=>{if(r.recipe_id!==state.selected_recipe_id||r.active_name!==state.selected_active_name)throw new Error("Select the recipe associated with this fit first");state.kinetics_input={...state.kinetics_input,...r.models[0].scenario};delete state.kinetics_result;fillForms();renderAll();tab("kinetics");markDirty();};$("fitSummary").appendChild(b);}
 if(state.learning_result){const r=state.learning_result;$("learningSummary").innerHTML='<p class="'+(r.utility_pass?"status-good":"status-warn")+'">'+(r.utility_pass?"✓ Utility gate passed":"△ Utility gate failed")+" · recipe-held-out MAE "+fmt(r.holdout_mae)+" vs baseline "+fmt(r.baseline_mae)+"</p>";const box=document.createElement("div");$("learningSummary").appendChild(box);table(box,["recipe_id","prediction","status"],r.predictions,"learned_candidate_ranking.csv");}
}

function reportMarkdown(value){
 const inline=text=>esc(text).replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>').replace(/\*\*([^*]+)\*\*/g,"<strong>$1</strong>");
 const lines=String(value||"").split("\n");let html="",i=0;
 const cells=line=>line.trim().replace(/^\||\|$/g,"").split("|").map(c=>c.trim());
 while(i<lines.length){
  const line=lines[i].trim();if(!line){i++;continue;}
  if(line.includes("|")&&i+1<lines.length&&/^\|?\s*:?-{3,}/.test(lines[i+1].trim())){
   const headers=cells(line);i+=2;let rows="";
   while(i<lines.length&&lines[i].includes("|")&&lines[i].trim()){rows+="<tr>"+cells(lines[i++]).map(c=>"<td>"+inline(c)+"</td>").join("")+"</tr>";}
   html+='<div class="table-wrap"><table><thead><tr>'+headers.map(c=>"<th>"+inline(c)+"</th>").join("")+"</tr></thead><tbody>"+rows+"</tbody></table></div>";continue;
  }
  if(/^#{1,6}\s/.test(line)){html+="<h3>"+inline(line.replace(/^#{1,6}\s+/,""))+"</h3>";i++;continue;}
  if(/^([-*]|\d+\.)\s/.test(line)){
   const ordered=/^\d+\./.test(line),tag=ordered?"ol":"ul";let items="";
   while(i<lines.length&&(ordered?/^\d+\.\s/:/^[-*]\s/).test(lines[i].trim()))items+="<li>"+inline(lines[i++].trim().replace(/^([-*]|\d+\.)\s+/,""))+"</li>";
   html+="<"+tag+">"+items+"</"+tag+">";continue;
  }
  const paragraph=[];while(i<lines.length&&lines[i].trim()){paragraph.push(inline(lines[i++]));if(i<lines.length&&(/^([-*]|\d+\.)\s|^#{1,6}\s/.test(lines[i].trim())||(lines[i].includes("|")&&/^\|?\s*:?-{3,}/.test(lines[i+1]?.trim()||""))))break;}
  html+="<p>"+paragraph.join("<br>")+"</p>";
 }
 return html;
}
const reportTools={
 create_recipe_candidates:["Recipe candidates","recipes"],suggest_recipes:["Recipe candidates","recipes"],
 simulate_kinetics:["Release / kinetics scenario","kinetics"],simulate_stability:["Stability scenario","stability"],
 calculate_dosage:["Exposure / dosage scenario","dosage"],plan_experiments:["Experiment matrix","experiments"],
 fit_measurements:["Measured-data fit","results"],learn_response_model:["Measured-response model","results"],
 develop_product:["Product recipes and all scenarios","recipes"],save_recipe_to_library:["Recipe library entry","library"]
};
function projectReports(){
 // Older saved projects already contain their report in the conversation.
 const turns=(state.conversation||[]).filter(t=>t.intent!=="discussion"&&t.answer);
 const stored=state.research_reports||[],tasks=new Set(stored.map(r=>r.task));
 return [...turns.filter(t=>!tasks.has(t.question)).map((t,i)=>{
  if(t.outcome)return {...t.outcome,saved_revision:t.project_saved?.revision};
  const seen=new Set(),outputs=[];
  for(const item of t.trace||[]){
   const descriptor=reportTools[item.tool];if(!descriptor||item.error||item.evidence==="tool input rejected"||seen.has(descriptor[0]))continue;
   seen.add(descriptor[0]);outputs.push({title:descriptor[0],page:descriptor[1],tool:item.tool});
  }
  return {report_id:"legacy-"+i,task:t.question,answer:t.answer,outputs,status:outputs.length?"outputs_created":"assessment_only",
   sources:t.sources||[],warnings:t.warnings||[],web_searched:(t.trace||[]).some(item=>item.tool==="OpenAI web_search"),
   notice:outputs.length?"":"Assessment only: this run produced no recipe candidates, numerical simulations, or experiment matrix. The report below is the outcome."};
 }),...stored];
}
function renderResearchOutcomes(){
 const reports=projectReports(),latest=reports.at(-1);
 $("projectOutcome").hidden=!latest;
 if(latest)$("projectOutcomeSummary").textContent=(latest.status==="outputs_created"?latest.outputs.length+" types of tool output produced. ":"Assessment only; no recipe or simulation outputs. ")+latest.task;
 $("researchOutcomes").innerHTML=reports.length?reports.slice().reverse().map((report,index)=>{
  const links=(report.outputs||[]).map(o=>'<button class="secondary" data-outcome-page="'+esc(o.page)+'">'+esc(o.title)+(o.count?" ("+esc(o.count)+")":"")+"</button>").join("");
  const sources=(report.sources||[]).filter(s=>/^https?:\/\//.test(s.url||"")).map(s=>'<li><a href="'+esc(s.url)+'" target="_blank" rel="noopener noreferrer">'+esc(s.title||s.url)+"</a></li>").join("");
  const content='<p><b>Task:</b> '+esc(report.task)+'</p>'+(report.notice?'<p class="note">'+esc(report.notice)+"</p>":"")+
   '<div class="actions">'+links+'</div><p class="muted">'+(report.web_searched?"Web research performed · "+(report.sources||[]).length+" source links recorded.":"No web sources retrieved in this run; external evidence remains unverified.")+'</p>'+
   (report.warnings||[]).map(w=>'<p class="note">'+esc(w)+"</p>").join("")+
   '<div class="research-report">'+reportMarkdown(report.answer)+'</div>'+(sources?'<h3>Sources</h3><ul>'+sources+"</ul>":"");
  return '<section class="research-outcome">'+(index?'<details><summary>Earlier outcome · '+esc(report.task.slice(0,120))+"</summary>"+content+"</details>":'<div class="actions"><span class="badge">'+(report.status==="outputs_created"?"Tool outputs produced":"Assessment only")+'</span><button class="secondary" data-download-outcome="'+esc(report.report_id)+'">Download report</button></div>'+content)+"</section>";
 }).join(""):'<p class="muted">No agent run outcome yet. Discuss your goal in Research chat, finalize the plan, then run it.</p>';
 $("researchOutcomes").querySelectorAll("[data-outcome-page]").forEach(b=>b.onclick=()=>tab(b.dataset.outcomePage));
 $("researchOutcomes").querySelectorAll("[data-download-outcome]").forEach(b=>b.onclick=()=>{
  const report=reports.find(r=>r.report_id===b.dataset.downloadOutcome);
  if(report)download("research-outcome.md","# Research outcome\n\n"+report.task+"\n\n"+(report.notice||"")+"\n\n"+report.answer,"text/markdown");
 });
}

function renderAll(){renderCandidateAnalyses();renderResearchOutcomes();renderRecipes();renderRecipeDesign();renderKinetics();renderStability();renderDosage();renderExperiments();renderImports();renderAgentReviews();renderAgentPlan();$("evidenceBadge").textContent=state.kinetics_input.parameter_source?.startsWith("fit")?"Release parameters fitted to imported measurements; projections retain model assumptions.":"Release parameters are user assumptions; fit measurements to calibrate this model.";$("projectTitle").textContent=state.brief.name;}
function chooseRecipe(id){
 capture();if(state.selected_recipe_id!==id){
 state.selected_recipe_id=id;
 for(const key of ["kinetics_result","stability_result","dosage_result","dose_response_result","release_fit"])delete state[key];
 delete state.stability_input.calibration;state.kinetics_input.parameter_source="transferred parameter scenario; selected recipe changed, performance unvalidated";
 const components=selected()?.active_components||[];
 if(!components.some(c=>c.name===state.selected_active_name))state.selected_active_name=components[0]?.name||"";
 restoreRecipeAnalyses();
 }fillForms();renderAll();markDirty();
}
async function refreshProjects(){
 const r=await fetch("/api/rnd/projects");const rows=await r.json();
 $("savedProjects").innerHTML='<option value="">Select a saved project</option>'+rows.map(p=>'<option value="'+esc(p.project_id)+'">'+esc(p.name)+" · r"+p.revision+"</option>").join("");
}
async function save(){
 capture();const result=await request("save",{document:state,...identity,expected_revision:identity.revision||0});
 identity={project_id:result.project_id,revision:result.revision};$("saveStatus").textContent="Saved · revision "+result.revision;
 $("projectDetails").textContent="Last save: "+result.updated;rememberChatProject();await refreshProjects();
}
function generate(){return task("Generating recipes",async()=>{
 capture();const result=await request("recipes",state.brief);state.recipe_result=result;state.recipes=result.recipes;
 state.selected_recipe_id=result.recipes[0].recipe_id;$("experiment_n_recipes").value=Math.min(+$("experiment_n_recipes").value,result.recipes.length);compareIds=new Set(result.recipes.slice(0,3).map(r=>r.recipe_id));
 for(const key of ["kinetics_result","stability_result","dosage_result","experiment_result","release_fit","dose_response_result"])delete state[key];
 delete state.stability_input.calibration;renderAll();markDirty();await maybeAgentReview("recipes");
});}
function runKinetics(){return task("Simulating kinetics",async()=>{capture();state.kinetics_result=await request("kinetics",state.kinetics_input);state.kinetics_result.recipe_id=state.selected_recipe_id||null;recordAnalysis("kinetics",state.kinetics_result,state.kinetics_input);renderAll();markDirty();await maybeAgentReview("kinetics");});}
function runStability(){return task("Simulating stability",async()=>{capture();state.stability_result=await request("stability",state.stability_input);state.stability_result.recipe_id=state.selected_recipe_id||null;recordAnalysis("stability",state.stability_result,state.stability_input);renderAll();markDirty();await maybeAgentReview("stability");});}
function runDosage(){return task("Calculating dose scenario",async()=>{capture();const recipe=selected();if(!recipe)throw new Error("Generate and select a recipe first.");
 state.dosage_result=await request("dosage",{...state.dosage_input,active_fraction:(recipe.active_components||[]).find(c=>c.name===state.selected_active_name)?.active_fraction||recipe.active_fraction,kinetics:state.kinetics_input,context:{recipe_id:recipe.recipe_id,active_name:state.selected_active_name,crop:state.brief.crop,target:state.brief.target}});
 recordAnalysis("dosage",state.dosage_result,state.dosage_input);renderAll();markDirty();await maybeAgentReview("dosage");
});}
function runExperiments(){return task("Planning experiments",async()=>{capture();state.experiment_result=await request("experiments",{...state.experiment_input,recipes:state.recipes||[]});renderAll();markDirty();await maybeAgentReview("experiments");});}
function bytesBase64(buffer){let s="";new Uint8Array(buffer).forEach(b=>s+=String.fromCharCode(b));return btoa(s);}
async function prepareUpload(){
 const file=$("dataFile").files[0];if(!file)return;
 if(file.size>4000000)throw new Error("Upload files up to 4 MB.");
 upload={filename:file.name,content_base64:bytesBase64(await file.arrayBuffer())};
 const preview=await request("preview-import",upload);
 table("importPreview",preview.columns,preview.preview);
 const mapping=[["recipe","Recipe identifier (optional)"],["condition","Assay condition (optional)"],["time","Time"],["value","Measured value"],["temperature","Temperature °C"],["dose","Dose"],["batch","Independent batch ID"],["replicate","Technical replicate ID"],["qc","QC flag"]];
 const guess={recipe:/^recipe_id$|^formulation_id$/i,condition:/^condition_id$|^condition$/i,time:/time|day|hour/i,value:/fraction|release|assay|response|value/i,temperature:/temperature|temp/i,dose:/dose/i,batch:/batch/i,replicate:/replicate/i,qc:/qc|status/i};
 $("mappingFields").innerHTML=mapping.map(([key,label])=>'<label>'+label+'<select id="map_'+key+'"><option value="">Not mapped</option>'+preview.columns.map(c=>'<option value="'+esc(c)+'"'+(guess[key].test(c)?" selected":"")+'>'+esc(c)+"</option>").join("")+"</select></label>").join("");
}
function importData(){return task("Importing observations",async()=>{
 capture();if(!upload)throw new Error("Choose a measurement file first.");if(!selected())throw new Error("Select the recipe associated with these measurements.");
 const settings=read("import",schemas.import);state.import_settings=settings;
 const mapping=Object.fromEntries(["recipe","condition","time","value","temperature","dose","batch","replicate","qc"].map(k=>[k,$("map_"+k).value]));
 const result=await request("import",{...upload,...settings,mapping,kind:$("importKind").value,recipe_id:state.selected_recipe_id,active_name:state.selected_active_name,
 context:{recipe_id:state.selected_recipe_id,active_name:state.selected_active_name,crop_or_system:settings.crop_or_system,target:settings.target,assay:settings.assay}});
 (state.imports??=[]).push(result);$("importSummary").textContent=result.observations.length+" rows imported; "+result.excluded.length+" excluded. "+result.warnings.join(" ");
 renderAll();markDirty();
});}
function fitImport(index){return task("Fitting experimental data",async()=>{
 capture();const item=state.imports[index];
 if(item.kind==="release"){state.release_fit=await request("fit-release",{observations:item.observations});state.release_fit.recipe_id=item.recipe_id;state.release_fit.active_name=item.active_name;state.release_fit.source_sha256=item.source.sha256;}
 if(item.kind==="stability"){
  if(item.recipe_id!==state.selected_recipe_id||item.active_name!==state.selected_active_name)throw new Error("Select this dataset's recipe before applying its chemical stability fit.");
  const fit=await request("fit-stability",{observations:item.observations});fit.source_sha256=item.source.sha256;fit.recipe_id=item.recipe_id;fit.active_name=item.active_name;state.stability_input.calibration=fit;
  Object.assign(state.stability_input,{reference_rate_per_day:fit.reference_rate_per_day,reference_temperature_c:fit.reference_temperature_c,activation_energy_kj_mol:fit.activation_energy_kj_mol,temperatures_c:fit.temperatures_c});delete state.stability_result;
  fillForms();tab("stability");
 }
 if(item.kind==="dose_response"){state.dose_response_result=await request("fit-dose-response",{observations:item.observations,dose_unit:item.dose_unit,context:item.context,target_response_pct:state.import_settings?.target_response_pct||80});tab("dosage");}
 renderAll();markDirty();await maybeAgentReview("results");
});}
function renderConversation(){
 const turns=(state.conversation||[]).filter(turn=>!turn.focus||turn.focus==="research");
 $("conversation").innerHTML=turns.length?turns.map(item=>{
  const details=(item.trace||[]).length?'<details class="chat-details"><summary>Details</summary><ol>'+(item.trace||[]).map(t=>'<li><b>'+esc(t.agent)+'</b> · '+esc(t.tool)+'<p>'+esc(t.evidence)+'</p>'+(t.error?'<p>'+esc(t.error)+'</p>':"")+(t.inputs?'<details><summary>Inputs</summary><pre>'+esc(JSON.stringify(t.inputs,null,2))+'</pre></details>':"")+'</li>').join("")+'</ol></details>':"";
  const sources=(item.sources||[]).map(source=>/^https?:\/\//.test(source.url)?'<a href="'+esc(source.url)+'" target="_blank" rel="noopener noreferrer">'+esc(source.title)+'</a>':"").join(" · ");
  const recipes=item.recipe_creation?.status==="created"&&item.recipe_creation.recipe_ids.every(id=>(state.recipes||[]).some(r=>r.recipe_id===id))?'<button class="secondary" data-open-created="recipes">View '+item.recipe_creation.recipe_ids.length+' recipes</button>':"";
  return '<div class="chat-message user-message"><small>You</small><div>'+esc(item.question)+'</div></div><div class="chat-message agent-message"><small>Agent</small><div>'+esc(item.answer)+'</div>'+recipes+(item.intent!=="discussion"?'<button class="secondary" data-view-outcome="results">View outcome</button>':"")+(item.project_saved?'<small>Saved · revision '+esc(item.project_saved.revision)+'</small>':"")+(sources?'<details class="chat-sources"><summary>Sources</summary><p>'+sources+'</p></details>':"")+(item.warnings||[]).map(w=>'<p class="note">'+esc(w)+'</p>').join("")+details+'</div>';
 }).join(""):'<p class="chat-empty">Describe your formulation goal. We’ll refine the plan together.</p>';
 $("conversation").querySelectorAll("[data-open-created]").forEach(b=>b.onclick=()=>tab("recipes"));
 $("conversation").querySelectorAll("[data-view-outcome]").forEach(b=>b.onclick=()=>tab("results"));
 $("conversation").scrollTop=$("conversation").scrollHeight;
 renderAgentPlan();
}
function renderAgentPlan(){
 const plan=state.agent_plan;
 $("chatRunPlan").hidden=!plan||plan.status==="executed";
 if(!plan){$("executeAgentTask").disabled=true;return;}
 if($("runPlanText").dataset.planId!==plan.plan_id){
  $("runPlanText").value=plan.task||"";$("runPlanText").dataset.planId=plan.plan_id;
 }
 const unsent=$("question").value.trim();
 const ready=plan.status==="draft"&&!(plan.open_questions||[]).length&&$("runPlanText").value.trim()&&!unsent;
 $("executeAgentTask").disabled=loading||!ready;
 $("runPlanSummary").textContent=plan.summary||"";
 $("runPlanNotes").innerHTML=(plan.open_questions||[]).length?'<p>Still to decide:</p><ul>'+plan.open_questions.map(q=>'<li>'+esc(q)+'</li>').join("")+'</ul>':(plan.status==="needs_review"?'<p>Send a message to update this plan before running it.</p>':unsent?'<p>Send your message first, or clear it to run the displayed plan.</p>':"");
 $("runPlanAssumptions").innerHTML=(plan.assumptions||[]).length?'<details><summary>Assumptions</summary><ul>'+plan.assumptions.map(a=>'<li>'+esc(a)+'</li>').join("")+'</ul></details>':"";
}
function finalizeChatPlan(){return task("Running finalized plan",async()=>{
 capture();const plan=state.agent_plan,taskText=$("runPlanText").value.trim();
 if(!plan||plan.status!=="draft"||(plan.open_questions||[]).length||!taskText||$("question").value.trim())throw new Error("Finish discussing the open questions before running this plan.");
 const finalized={task:taskText,plan_id:plan.plan_id,discussion_run_id:plan.discussion_run_id||""};
 await agentTurn(taskText,"research","gpt","execute",{finalized_plan:finalized});
 tab("results");rememberChatProject();
});}

// GPT connections and recipe library are application services; credentials never enter state.
let connectionStatus={configured:false,verified:false,model:"gpt-6.1-sol"},libraryCache=[];
function renderProviderSettings(){
 const api=$("agentProvider").value==="openai";
 $("apiKeyLabel").hidden=!api;$("apiBaseLabel").hidden=!api;
}
async function refreshAgentStatus(){
 const response=await fetch("/api/rnd/agent-status");
 if(!response.ok)throw new Error("Could not read agent status.");
 connectionStatus=await response.json();
 const codex=connectionStatus.provider_type==="codex";
 $("agentConnectionBadge").textContent=connectionStatus.configured
  ?(codex?"Codex connected":"API connected"):"Agent settings";
 $("agentConnectionStatus").textContent=(codex
  ?(connectionStatus.configured?"Using the current Codex sign-in. No API key is needed.":"Codex is disabled, unavailable or signed out. Run codex login on this machine if needed.")
  :(connectionStatus.configured?"OpenAI API configured. The key stays in server memory.":"Enter an OpenAI API key or select the current Codex sign-in."))+
  " GPT-6.1 Sol"+(connectionStatus.verified?" · connection tested.":".");
 $("agentProvider").value=codex?"codex":"openai";
 $("agentReasoning").value=connectionStatus.reasoning||"high";
 if(connectionStatus.base_url)$("agentBaseUrl").value=connectionStatus.base_url;
 renderProviderSettings();
}
async function connectAgents(){
 await task("Testing research agents",async()=>{
  try{
   await request("agent-configure",{provider:$("agentProvider").value,model:"gpt-6.1-sol",
    api_key:$("agentApiKey").value,base_url:$("agentBaseUrl").value,reasoning:$("agentReasoning").value});
   await request("agent-test",{});
  }finally{$("agentApiKey").value="";await refreshAgentStatus();}
 });
}
async function refreshLibrary(){
 const result=await request("library-search",{query:$("libraryQuery").value,format:$("libraryFormat").value,origin:$("libraryOrigin").value});
 libraryCache=result.entries;renderLibrary();
}
function renderLibrary(){
 $("librarySummary").textContent=libraryCache.length+" records. Published records preserve missing quantities; starting drafts are explicitly unvalidated.";
 $("libraryEntries").innerHTML=libraryCache.map(r=>'<article class="library-card"><span class="badge">'+esc(r.format)+'</span><span class="badge">'+esc(r.origin)+'</span><h3>'+esc(r.name)+'</h3><p>'+esc(r.active)+'</p><p>'+esc(r.validation_status)+' · '+esc(r.composition_status)+'</p><div class="actions"><button data-libinspect="'+esc(r.library_id)+'" class="secondary">Inspect</button><button data-libload="'+esc(r.library_id)+'">Use in editor</button></div></article>').join("");
 $("libraryEntries").querySelectorAll("[data-libinspect]").forEach(b=>b.onclick=()=>inspectLibrary(b.dataset.libinspect));
 $("libraryEntries").querySelectorAll("[data-libload]").forEach(b=>b.onclick=()=>loadLibrary(b.dataset.libload));
}
function inspectLibrary(id){
 const entry=libraryCache.find(r=>r.library_id===id);if(!entry)return;
 $("libraryDetail").innerHTML='<h3>'+esc(entry.name)+'</h3><p>'+esc(entry.notes||"")+'</p><p class="note">'+esc(entry.validation_status)+" · "+esc(entry.composition_status)+'</p>';
 const box=document.createElement("div");$("libraryDetail").appendChild(box);
 table(box,["Ingredient","Role","Declared mass %","Bounds %","Purity %"],
 entry.ingredients.map(i=>({"Ingredient":i.name,"Role":i.role,
  "Declared mass %":i.mass_fraction===null||i.mass_fraction===undefined?null:i.mass_fraction*100,
  "Bounds %":i.min_pct===undefined?"unspecified":fmt(i.min_pct)+"–"+fmt(i.max_pct),
  "Purity %":i.purity_pct})));
 const source=document.createElement("p");
 source.textContent="Source: "+JSON.stringify(entry.source);$("libraryDetail").appendChild(source);
 if(/^https?:\/\//.test(entry.source?.url||"")){
  const link=document.createElement("a");link.href=entry.source.url;link.target="_blank";link.rel="noopener noreferrer";link.textContent="Open original source";$("libraryDetail").appendChild(link);
 }
 const b=document.createElement("button");b.textContent="Use this record in recipe editor";b.onclick=()=>loadLibrary(id);$("libraryDetail").appendChild(b);
}
function clearRecipeOutputs(){
 for(const key of ["recipes","recipe_result","kinetics_result","stability_result","dosage_result","experiment_result","release_fit","dose_response_result","learning_result"])delete state[key];
 state.selected_recipe_id=null;state.selected_active_name=null;state.agent_reviews={};
 if(state.stability_input)delete state.stability_input.calibration;
}
function loadLibrary(id){return task("Loading library recipe",async()=>{
 capture();const result=await request("library-apply",{library_id:id,brief:state.brief});
 clearRecipeOutputs();state.brief=result.brief;state.library_selection=result.entry;
 fillForms();renderAll();tab("recipes");markDirty();
 $("recipeSummary").innerHTML='<p class="note">'+esc(result.warnings.join(" "))+'</p>';
});}
function saveToLibrary(){return task("Saving recipe to library",async()=>{
 capture();const recipe=selected();if(!recipe)throw new Error("Select a generated recipe first.");
 const entry=await request("library-save",{recipe,name:$("librarySaveName").value.trim()||recipe.name,notes:$("librarySaveNotes").value});
 await refreshLibrary();inspectLibrary(entry.library_id);markDirty();
});}
async function applyAgentResult(result,q,focus){
 if(result.updates.invalidate_recipe_results){
  for(const key of ["kinetics_result","stability_result","dosage_result","experiment_result","release_fit","dose_response_result"])delete state[key];
  delete state.stability_input.calibration;
 }
 delete result.updates.invalidate_recipe_results;
 for(const key of result.deleted_keys||[])delete state[key];
 Object.assign(state,result.updates);
 if(result.intent==="discussion"&&state.agent_plan&&result.investigation_id)
  state.agent_plan.discussion_run_id=result.investigation_id;
 if(result.updates.recipe_result){
  state.recipes=result.updates.recipe_result.recipes;
  compareIds=new Set(state.recipes.slice(0,3).map(r=>r.recipe_id));
 }
 if(!result.updates.analysis_runs){
  for(const kind of ["kinetics","stability","dosage"]){
   if(result.updates[kind+"_result"])recordAnalysis(kind,result.updates[kind+"_result"],state[kind+"_input"]);
  }
 }
 const turn={question:q,answer:result.answer,trace:result.trace||[],warnings:result.warnings||[],
  sources:result.sources||[],model:result.model,mode:result.mode,model_calls:result.model_calls||[],focus,
  recipe_creation:result.recipe_creation,project_saved:result.project_saved,intent:result.intent,outcome:result.outcome};
 (state.conversation??=[]).push(turn);state.conversation=state.conversation.slice(-30);
 if(focus&&["project","library","recipes","kinetics","stability","dosage","experiments","results"].includes(focus)){
  (state.agent_reviews??={})[focus]=turn;
 }
 fillForms();renderAll();renderConversation();renderAgentReviews();markDirty();
}
async function agentTurn(q,focus="research",mode="gpt",intent="discussion",extra={}){
 const action=mode==="offline"?"ask-offline":"ask";
 const body={question:q,state,focus,intent,project_identity:identity,web_research:$("agentWebResearch").checked,...extra};
 const result=mode==="offline"?await request(action,body):await executeAgentRun(body);
 await applyAgentResult(result,q,focus);
 if(result.library_changed)await refreshLibrary();
 if(result.project_saved){
  identity={project_id:result.project_saved.project_id,revision:result.project_saved.revision};
  $("saveStatus").textContent="Agent saved · revision "+identity.revision;
  $("projectDetails").textContent="Last agent save: "+result.project_saved.updated;
  await refreshProjects();
 }
 if(result.project_saved)rememberChatProject();
 else if(result.investigation_id)storeChatResume({run_id:result.investigation_id,tab:activeTab});
 if(result.persistence_error)showError(new Error(result.persistence_error));
 return result;
}
function ask(question,focus="research",mode="gpt",intent="discussion"){return task(mode==="gpt"?(intent==="discussion"?"Agent replying":"GPT-6.1 Sol investigating"):"Running offline command tools",async()=>{
 capture();const q=question||$("question").value.trim();if(!q)return;
 if(intent==="discussion"&&state.agent_plan&&state.agent_plan.status!=="executed"){state.agent_plan.status="needs_review";renderAgentPlan();}
 await agentTurn(q,focus,mode,intent);$("question").value="";
});}
async function maybeAgentReview(focus){
 if(!$("autoAgentReview").checked)return;
 if(!connectionStatus.configured){
  $("agentReview-"+focus).textContent="GPT review pending: connect GPT-6.1 Sol under Product brief & projects.";
  return;
 }
 $("busy").textContent="GPT-6.1 Sol reviewing "+focus+"…";
 try{await agentTurn($("agentQuestion-"+focus).value,focus);}
 catch(error){
  // Preserve the completed scientific calculation if the model connection fails.
  $("agentReview-"+focus).textContent="Scientific result retained. GPT review failed: "+error.message;
  showError(error);
 }
}
function renderAgentReviews(){
 for(const focus of ["project","library","recipes","kinetics","stability","dosage","experiments","results"]){
  const review=state.agent_reviews?.[focus];
  $("agentReview-"+focus).textContent=review?(review.model||review.mode)+"\n\n"+review.answer:"";
 }
}
async function init(){
 const response=await fetch("/api/rnd/bootstrap");if(!response.ok)throw new Error("Could not load workbench defaults.");
 const defaults=await response.json();state={...defaults,recipes:[],imports:[],conversation:[]};delete state.formats;delete state.agent_examples;
 fillForms();renderAll();renderConversation();await refreshProjects();await refreshAgentStatus();await refreshLibrary();await refreshRunHistory();
 $("connectAgents").onclick=connectAgents;
 $("refreshRunHistory").onclick=()=>task("Loading agent history",refreshRunHistory);
 $("runHistoryScope").onchange=()=>task("Filtering agent history",refreshRunHistory);
 $("recoverAgentRun").onclick=()=>recoverAgentRun();
 $("recipeDesignForm").onsubmit=e=>{e.preventDefault();createRecipesWithAgents();};
 $("executeAgentTask").onclick=finalizeChatPlan;
 $("developProduct").onclick=developProductWithAgents;
 $("viewProjectOutcome").onclick=()=>tab("results");
 $("runPlanText").oninput=renderAgentPlan;
 $("question").oninput=renderAgentPlan;
 $("agentProvider").onchange=renderProviderSettings;
 $("agentConnectionBadge").onclick=()=>{tab("project");$("agentConnectionCard").scrollIntoView?.({behavior:"smooth"});};
 $("openRecipeEditor").onclick=()=>tab("recipes");
 $("addUserRecipe").onclick=()=>tab("recipes");
 $("addAgentRecipes").onclick=()=>ask("Develop recipe drafts for the current product brief and add them to my recipe library. Search the library first; consult a formulation specialist to challenge the proposed ingredients and bounds. Generate constraint-checked drafts, then save up to three distinct candidates with save_recipe_to_library. Label them agent-generated and unvalidated, include concise rationale and evidence gaps. Ask for essential missing chemical identities rather than inventing them.","library","gpt","execute");
 $("disconnectAgents").onclick=()=>task("Disconnecting agents",async()=>{await request("agent-configure",{clear_key:true});await refreshAgentStatus();});
 $("refreshLibrary").onclick=()=>task("Searching recipe library",refreshLibrary);
 for(const id of ["libraryQuery","libraryFormat","libraryOrigin"])$(id).onchange=()=>task("Searching recipe library",refreshLibrary);
 $("saveLibraryRecipe").onclick=saveToLibrary;
 document.querySelectorAll("[data-agent-focus]").forEach(b=>b.onclick=()=>ask($("agentQuestion-"+b.dataset.agentFocus).value,b.dataset.agentFocus));
 $("askOffline").onclick=()=>ask(undefined,"research","offline");
 document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>tab(b.dataset.tab));
 $("theme").onclick=()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==="dark"?"light":"dark";};
 $("activeRecipe").onchange=()=>chooseRecipe($("activeRecipe").value);
 $("generate").onclick=generate;$("runKinetics").onclick=runKinetics;$("runStability").onclick=runStability;$("runDosage").onclick=runDosage;$("runExperiments").onclick=runExperiments;
 $("modeledActive").onchange=()=>{state.selected_active_name=$("modeledActive").value;delete state.kinetics_result;delete state.dosage_result;delete state.stability_result;delete state.stability_input.calibration;delete state.release_fit;delete state.dose_response_result;state.kinetics_input.parameter_source="user scenario for selected active";restoreRecipeAnalyses();fillForms();renderAll();markDirty();};
 $("useScaffold").onclick=()=>{capture();state.brief.ingredients=structuredClone(defaults.format_scaffolds[state.brief.format]);ingredientTable();markDirty();};
 $("addIngredient").onclick=()=>{capture();state.brief.ingredients.push({name:"New material",role:"other",min_pct:0,max_pct:5,purity_pct:100,cost_per_kg:null,supplier:"",lot:""});ingredientTable();markDirty();};
 $("saveTop").onclick=()=>task("Saving project",save);
 $("loadProject").onclick=()=>task("Loading project",async()=>{const id=$("savedProjects").value;if(!id)throw new Error("Select a saved project.");const r=await request("load",{project_id:id});state=r.document;identity={project_id:r.project_id,revision:r.revision};fillForms();renderAll();renderConversation();$("saveStatus").textContent="Loaded · revision "+r.revision;rememberChatProject();});
 $("newProject").onclick=()=>{if(!window.confirm("Start a new project? Save your current work first."))return;state=structuredClone({...defaults,recipes:[],imports:[],conversation:[]});identity={};storeChatResume(null);fillForms();renderAll();renderConversation();markDirty();};
 $("exportProject").onclick=()=>task("Exporting report",async()=>{capture();const result=await request("export",{document:state});const binary=atob(result.archive_base64);download(result.filename,Uint8Array.from(binary,c=>c.charCodeAt(0)));download("project.json",JSON.stringify(state,null,2),"application/json");});
 $("restoreProject").onchange=()=>task("Restoring project",async()=>{const file=$("restoreProject").files[0];if(!file)return;if(file.size>7500000)throw new Error("Project JSON exceeds 7.5 MB.");const data=JSON.parse(await file.text());if(!data.brief||!data.kinetics_input||!data.stability_input||!data.experiment_input)throw new Error("This is not a workbench project document.");state=data;identity={};storeChatResume(null);fillForms();renderAll();renderConversation();markDirty();});
 $("dataFile").onchange=()=>task("Previewing file",prepareUpload);$("importData").onclick=importData;
 $("clearStabilityFit").onclick=()=>{delete state.stability_input.calibration;delete state.stability_result;renderStability();markDirty();};
 $("useStorageRetention").onclick=()=>{const r=state.stability_result;if(!r){showError(new Error("Run the selected recipe's stability scenario first."));return;}const c=r.curves[+$("storageTemperature").value];$("dosage_storage_retained_fraction").value=c.retained_at_horizon;capture();markDirty();};
 $("learn").onclick=()=>task("Validating response model",async()=>{capture();state.response_measurements=jsonInput("responseData",[]);state.learning_result=await request("learn",{recipes:state.recipes,measurements:state.response_measurements,response_name:$("responseName").value,response_unit:$("responseUnit").value,goal:$("responseGoal").value});renderImports();markDirty();});
 $("askForm").onsubmit=e=>{e.preventDefault();ask();};
 $("question").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey&&!e.isComposing){e.preventDefault();ask();}});
 $("agentExamples").innerHTML=defaults.agent_examples.map((q,i)=>'<button class="secondary" data-example="'+i+'">'+esc(q)+"</button>").join("");
 $("agentExamples").querySelectorAll("[data-example]").forEach(b=>b.onclick=()=>{$("question").value=defaults.agent_examples[+b.dataset.example];$("question").focus?.();});
 document.addEventListener("change",e=>{if(e.target.matches("input,select,textarea")&&!["activeRecipe","savedProjects","dataFile","restoreProject"].includes(e.target.id)){markDirty();if(e.target.id==="kinetics_model")updateModelFields();
 if(e.target.closest("#tab-kinetics")||e.target.closest("#tab-stability")||e.target.closest("#tab-dosage")||e.target.closest("#tab-experiments")){
  try{capture();renderKinetics();renderStability();renderDosage();renderExperiments();}catch(err){showError(err);}
 }}});
 if(storedRun())await recoverAgentRun(storedRun());
 else await restoreLastChat();
}
// Investigations run independently of the page; only a run ID is stored in browser storage.
let currentAgentRun=null, runHistory=[];
const runStorageKey="agriformulations.activeAgentRun";
function storedRun(){try{return (globalThis.sessionStorage||globalThis.localStorage)?.getItem(runStorageKey)||null;}catch{return null;}}
function rememberRun(id){currentAgentRun=id;try{(globalThis.sessionStorage||globalThis.localStorage)?.setItem(runStorageKey,id);}catch{}}
function forgetRun(id){if(currentAgentRun===id)currentAgentRun=null;try{if(storedRun()===id)(globalThis.sessionStorage||globalThis.localStorage)?.removeItem(runStorageKey);}catch{}}
function runLabel(status){return ({running:"Running",completed:"Completed",completed_with_warnings:"Completed with warnings",completed_unsaved:"Completed · save failed",failed:"Failed",interrupted:"Interrupted"})[status]||status;}
async function getRun(id){
 const response=await fetch("/api/rnd/agent-run?run_id="+encodeURIComponent(id));
 const data=await response.json();
 if(!response.ok){const error=new Error(data.error||"Could not read investigation");error.status=response.status;throw error;}
 return data;
}
function renderRunProgress(run){
 if(run.intent==="discussion"){
  $("agentRunPanel").hidden=true;$("chatThinking").hidden=false;
  $("busy").textContent="Agent is replying…";return;
 }
 $("agentRunPanel").hidden=false;
 $("agentRunTitle").textContent=run.question.length>240?run.question.slice(0,240)+"…":run.question;
 $("agentRunStatus").textContent=runLabel(run.status);
 const seconds=Math.max(0,Math.floor((Date.now()-Date.parse(run.created))/1000));
 $("agentRunElapsed").textContent=seconds+"s elapsed";
 $("agentRunEvents").innerHTML=(run.events||[]).slice(-8).map(e=>'<li class="'+(e.kind==="tool_failed"||e.kind==="save_failed"?"status-warn":"")+'">'+esc(e.message)+(e.revision?' · revision '+esc(e.revision):"")+'</li>').join("");
 $("busy").textContent=run.events?.at(-1)?.message||"Agents investigating…";
}
async function waitForRun(id){
 while(true){
  const run=await getRun(id);renderRunProgress(run);
  if(run.status!=="running")return run;
  await new Promise(resolve=>setTimeout(resolve,750));
 }
}
async function executeAgentRun(body){
 if(currentAgentRun)throw new Error("An investigation is already active. Recover it from Agent investigations before starting another.");
 const id=globalThis.crypto?.randomUUID?.()||"run-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2);
 rememberRun(id);
 try{
  await request("agent-start",{...body,client_request_id:id});
 }catch(error){
  if(error.status)forgetRun(id);
  throw error;
 }
 let run;try{run=await waitForRun(id);}finally{$("chatThinking").hidden=true;}
 forgetRun(id);
 $("agentRunPanel").hidden=true;
 await refreshRunHistory();
 if(!run.result)throw new Error(run.error||"The investigation ended without a result.");
 return {...run.result,investigation_id:run.run_id};
}
async function refreshRunHistory(){
 const scoped=$("runHistoryScope").value==="project"&&identity.project_id;
 const response=await fetch("/api/rnd/agent-runs"+(scoped?"?project_id="+encodeURIComponent(identity.project_id):""));
 if(!response.ok)throw new Error("Could not load agent investigations");
 runHistory=(await response.json()).runs;
 $("runHistorySummary").textContent=runHistory.length?runHistory.length+" recent investigations":"No agent investigations yet.";
 $("runHistoryEntries").innerHTML=runHistory.map(run=>'<article class="run-history-entry"><div class="actions"><span class="badge">'+esc(runLabel(run.status))+'</span><b>'+esc(run.project_name)+'</b>'+(run.saved_revision?'<span>Revision '+esc(run.saved_revision)+'</span>':"")+'</div><p>'+esc(run.question.length>300?run.question.slice(0,300)+"…":run.question)+'</p><small>'+esc(run.created)+'</small><details><summary>Tool progress</summary><ol>'+run.events.map(e=>'<li>'+esc(e.message)+'</li>').join("")+'</ol></details><div class="actions">'+(run.status==="running"?'<button data-recover-run="'+esc(run.run_id)+'" class="secondary">Track this investigation</button>':'<button data-open-run="'+esc(run.run_id)+'" class="secondary">'+(run.saved_revision?"Open saved results":"Open working draft")+'</button>'+(run.project_id?'<button data-follow-run="'+esc(run.run_id)+'" class="secondary">Follow up from latest</button>':""))+'</div></article>').join("");
 $("runHistoryEntries").querySelectorAll("[data-open-run]").forEach(b=>b.onclick=()=>openAgentRun(b.dataset.openRun));
 $("runHistoryEntries").querySelectorAll("[data-follow-run]").forEach(b=>b.onclick=()=>followAgentProject(b.dataset.followRun));
 $("runHistoryEntries").querySelectorAll("[data-recover-run]").forEach(b=>b.onclick=()=>recoverAgentRun(b.dataset.recoverRun));
 $("recoverAgentRun").hidden=!storedRun()&&!currentAgentRun;
}
async function restoreRun(run){
 if(run.result?.project_saved){
  const meta=run.result.project_saved;
  const loaded=await request("load",{project_id:meta.project_id,revision:meta.revision});
  state=loaded.document;identity={project_id:loaded.project_id,revision:loaded.revision};
  fillForms();renderAll();renderConversation();
  $("saveStatus").textContent="Loaded agent results · revision "+loaded.revision;
  $("projectDetails").textContent="Saved investigation: "+run.question;
 }else if(run.initial_state){
  state=run.initial_state;identity=run.initial_identity||{};
  fillForms();renderAll();renderConversation();
  if(run.result)await applyAgentResult({...run.result,investigation_id:run.run_id},run.question,run.focus);
  $("saveStatus").textContent=run.intent==="discussion"?"Chat draft restored":"Recovered working draft · save required";
 }else{throw new Error("No saved project or working draft is available for this investigation.");}
 await refreshProjects();await refreshLibrary();
 if(run.result?.persistence_error)showError(new Error(run.result.persistence_error));
 if(run.error)showError(new Error(run.error));
 if(run.result?.project_saved)rememberChatProject();
 else storeChatResume({run_id:run.run_id,tab:activeTab});
}
function openAgentRun(id){return task("Opening investigation",async()=>{
 const run=await getRun(id);await restoreRun(run);tab(run.intent==="discussion"?"assistant":"results");
 if(!$("question").value.trim())$("question").value="Using these results, investigate the next important uncertainty and save any new results.";
});}
function followAgentProject(id){return task("Opening project for follow-up",async()=>{
 const run=await getRun(id);
 if(!run.project_id){await restoreRun(run);}
 else{
  const loaded=await request("load",{project_id:run.project_id});
  state=loaded.document;identity={project_id:loaded.project_id,revision:loaded.revision};
  fillForms();renderAll();renderConversation();
  $("saveStatus").textContent="Loaded latest · revision "+loaded.revision;rememberChatProject();
 }
 tab("assistant");
 $("question").value="Using this project's current results, investigate the next important uncertainty and save any new results.";
});}
function recoverAgentRun(id){return task("Recovering investigation",async()=>{
 id=id||currentAgentRun||storedRun();
 if(!id)return;
 rememberRun(id);
 try{
  const run=await waitForRun(id);forgetRun(id);$("chatThinking").hidden=true;
  $("agentRunPanel").hidden=true;
  await restoreRun(run);await refreshRunHistory();
 }catch(error){
  if(error.status===400)forgetRun(id);
  throw error;
 }
});}

// Resume the conversation from a server-side snapshot; browser storage holds IDs only.
const chatResumeKey="agriformulations.chatResume";
function storeChatResume(value){try{const storage=globalThis.sessionStorage||globalThis.localStorage;if(value)storage?.setItem(chatResumeKey,JSON.stringify(value));else storage?.removeItem(chatResumeKey);}catch{}}
function rememberChatProject(){storeChatResume(identity.project_id?{project_id:identity.project_id,tab:activeTab}:null);}
async function restoreLastChat(){
 let value;try{value=JSON.parse((globalThis.sessionStorage||globalThis.localStorage)?.getItem(chatResumeKey)||"null");}catch{return;}
 if(globalThis.location?.search){
  const params=new URL(globalThis.location.href).searchParams;
  if(params.get("project"))value={project_id:params.get("project"),tab:params.get("tab")||"results"};
 }
 if(!value)return;
 try{
  if(value.project_id){
   const loaded=await request("load",{project_id:value.project_id});
   state=loaded.document;identity={project_id:loaded.project_id,revision:loaded.revision};
   fillForms();renderAll();renderConversation();$("saveStatus").textContent="Loaded · revision "+loaded.revision;
  }else if(value.run_id){await restoreRun(await getRun(value.run_id));}
  if(value.tab&&["project","library","recipes","kinetics","stability","dosage","experiments","results","assistant"].includes(value.tab))tab(value.tab);
 }catch(error){storeChatResume(null);throw error;}
}

init().catch(showError);
