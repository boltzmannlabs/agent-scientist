"""Local GUI for the formulation framework and GPT research workbench.

A view over the deterministic engines: the page parameterizes the
verified kernels and renders the frozen phase exports; it never invents
numbers and makes no efficacy, patentability or field claim.
"""

from .compute import (
    campaign_data,
    claim_scans,
    claim_state,
    degeneracy_data,
    simulate,
)
from .server import make_server

__all__ = [
    "campaign_data",
    "claim_scans",
    "claim_state",
    "degeneracy_data",
    "make_server",
    "simulate",
]
