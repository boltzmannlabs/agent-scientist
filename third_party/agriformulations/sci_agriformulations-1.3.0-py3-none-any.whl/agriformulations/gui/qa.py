"""Deterministic question router for the GUI ask console (v12).

No model, no external call: a regex/token parser maps free-text questions
onto the compute layer (claim scans, campaign exports, stereo registries,
the v9 identifiability export, proposal gates).  Every answer carries its
route name and the engine that produced it; unrouted questions get the
capability list with examples - the console never fabricates an answer,
and the standing not-comparable register applies to every reply.
"""

from __future__ import annotations

import json
import re

from .compute import REPO_ROOT, campaign_data, claim_scans, degeneracy_data

GATE_FILES = {
    "v6": REPO_ROOT / "reports/v6/v6_gate.json",
    "v8": REPO_ROOT / "reports/v8/v8_gate.json",
    "v10": REPO_ROOT / "reports/v10/v10_gate.json",
}
COMPONENT_FILES = (
    REPO_ROOT / "data/v9/stereo/components.json",
    REPO_ROOT / "data/v10/components.json",
    REPO_ROOT / "data/v9/stereo/ingredients.json",
)

CAP_WORDS = ("<=", "≤", "<", "at most", "less than", "under", "up to")
FLOOR_WORDS = (">=", "≥", ">", "at least", "more than", "over")
EXAMPLES = [
    "is a claim of <=20% at 5 days and >=80% at 35 days feasible?",
    "what is the Fickian ceiling for that claim?",
    "which concepts are blocked in v10?",
    "top 5 concepts by priority in v10",
    "what is the transfer region for CR__CR_granule__attapulgite_clay__none__racemic",
    "compare CR__CR_granule__attapulgite_clay__none__racemic vs MIX__SC__none__tebuconazole__enantioenriched",
    "which concepts use chitosan?",
    "how many enantioenriched concepts are in the v10 shortlist?",
    "is sulfoxaflor chiral?",
    "can total-release curves identify enantiomer rates?",
    "what proposals are pending?",
]


def _normalize(question: str) -> str:
    return re.sub(r"\s+", " ", question.strip().lower().rstrip("?"))


def _phase_of(question: str, default: str = "v10") -> str:
    if "sulfoxaflor" in question or re.search(r"\bv8\b", question):
        return "v8"
    if any(word in question for word in ("benzovindiflupyr", "bzf")) or re.search(r"\bv10\b", question):
        return "v10"
    return default


def _claim_from_question(question: str) -> dict:
    caps, floors = [], []
    for match in re.finditer(r"([\d.]+)\s*%[^0-9%]{0,24}([\d.]+)\s*(?:d\b|days?\b)", question):
        pct, day = float(match.group(1)) / 100.0, float(match.group(2))
        prefix = question[max(0, match.start() - 14):match.start()]
        if any(word in prefix for word in FLOOR_WORDS):
            floors.append((pct, day))
        else:
            caps.append((pct, day))
    if not floors and len(caps) > 1:  # order-based fallback: first cap, second floor
        caps, floors = caps[:1], caps[1:]
    if (caps or floors) and not (caps and floors):
        raise ValueError("Supply both an early cap and a late floor in explicit percent/day units")
    if re.search(r"\d", question) and not caps and not floors:
        raise ValueError("Use explicit percentages and days")
    cap, t1 = caps[0] if caps else (0.20, 5.0)
    floor, t2 = floors[0] if floors else (0.80, 35.0)
    return {"t1": t1, "cap": cap, "t2": t2, "floor": floor}


def _load_components() -> dict:
    registry = {}
    for path in COMPONENT_FILES:
        try:
            payload = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        block = payload.get("components", payload.get("ingredients", {}))
        if isinstance(block, list):  # v10 shape: list of records carrying "name"
            named = {record.get("name", ""): record for record in block if isinstance(record, dict)}
        elif isinstance(block, dict) and all(isinstance(v, dict) and "stereo" in v for v in block.values()):
            named = block  # v9 components shape: name -> entry
        else:
            continue  # nested structures (ingredients by study/formulation) have no direct entries
        for name, entry in named.items():
            descriptor = entry.get("stereo")
            if descriptor and name not in registry:
                registry[name] = {"stereo": descriptor, "note": entry.get("note", "")}
    return registry


def _match_concept(question: str, phase: str):
    data = campaign_data(phase)
    identifiers = [row["concept_id"] for row in data["concepts"]]
    contained = [cid for cid in identifiers if cid.lower() in question]
    if contained:
        return max(contained, key=len), data
    question_tokens = set(re.findall(r"[a-z0-9]+", question))
    best, best_score = None, 0.0
    for cid in identifiers:
        tokens = set(re.findall(r"[a-z0-9]+", cid))
        score = len(tokens & question_tokens) / len(tokens) if tokens else 0.0
        if score > best_score or (score == best_score and best and cid < best):
            best, best_score = cid, score
    if best_score >= 0.75:
        return best, data
    return None, data


def _row_for(data: dict, concept_id: str) -> dict:
    return next(row for row in data["concepts"] if row["concept_id"] == concept_id)


def _concept_table(row: dict) -> dict:
    columns = [c for c in ("concept_id", "direction", "format", "carrier", "partner", "enrichment",
                           "flag", "nearest_art", "S_nearest", "novelty", "india", "compatibility",
                           "feasibility", "priority", "analogue", "w", "stereo_regime",
                           "region_low_per_day", "region_high_per_day") if c in row and row[c] != ""]
    return {"columns": columns, "rows": [{c: row.get(c) for c in columns}]}


def _fmt(value, digits=3):
    if value is None or value == "":
        return "n/a"
    if isinstance(value, float):
        if value != 0 and (abs(value) < 1e-3 or abs(value) >= 1e4):
            return f"{value:.2e}"
        return f"{value:.{digits}f}"
    return str(value)


def _help_route() -> dict:
    return {
        "route": "help",
        "answer": "I did not recognize that question, so here is what I can answer (click an example):",
        "chips": [],
        "chart": None,
        "table": None,
        "examples": EXAMPLES,
        "engine": "deterministic router; no answer is fabricated",
    }


def _claim_route(question: str) -> dict | None:
    if not any(word in question for word in ("feasib", "claim", "ceiling", "achiev")):
        return None
    claim = _claim_from_question(question)
    result = claim_scans(claim)
    fickian, zero = result["fickian"], result["zero_order"]
    if "ceiling" in question and "feasib" not in question:
        answer = (
            f"For a cap of {claim['cap']:.0%} at day {claim['t1']:.0f} and a floor of "
            f"{claim['floor']:.0%} at day {claim['t2']:.0f}, the Fickian family ceiling at t2 is "
            f"{fickian['ceiling_t2']:.3f} (best rate {_fmt(fickian['best_rate_per_day'])} /day; "
            f"analytic ratio bound sqrt(t2/t1) = {fickian['ratio_bound_sqrt']:.3f})."
        )
    else:
        answer = (
            f"Claim: <= {claim['cap']:.0%} at day {claim['t1']:.0f} and >= {claim['floor']:.0%} at day "
            f"{claim['t2']:.0f}. Fickian family: {fickian['verdict']} "
            f"({fickian['n_feasible']} feasible candidates; ceiling {fickian['ceiling_t2']:.3f}). "
            f"Zero-order membrane: {zero['verdict']} - "
            f"see the explicit feasible example specs (a zero-lag interval exists only when corner.nonempty is true)."
        )
    return {
        "route": "claim_feasibility",
        "answer": answer,
        "chips": [
            {"kind": "good" if fickian["verdict"] == "feasible" else "crit", "text": f"Fickian: {fickian['verdict']}"},
            {"kind": "good" if zero["verdict"] == "feasible" else "crit", "text": f"zero-order: {zero['verdict']}"},
        ],
        "chart": {
            "type": "line",
            "cfg": {
                "xs": fickian["series"]["rate"], "logX": True,
                "xLabel": "Fickian rate D/L2 (/day, log)", "yLabel": "best achievable fraction at t2",
                "series": [{"label": "achievable t2", "color": "var(--series-1)", "values": fickian["series"]["achieved_t2"]}],
                "guides": [{"y": claim["floor"], "label": "claim floor", "color": "var(--good)"}],
            },
        },
        "table": {"columns": ["k0_per_day", "lag_days", "plateau", "release_t1", "release_t2"], "rows": zero["examples"]},
        "engine": "v11 claim scans (fickian_claim_scan / zero_order_claim_scan)",
    }


def _identifiability_route(question: str) -> dict | None:
    if not any(word in question for word in ("identif", "degener", "enantiomer rate", "total release", "total curve", "resolved curve")):
        return None
    data = degeneracy_data()
    return {
        "route": "identifiability",
        "answer": (
            f"{data['statement'].capitalize()}. Grid verdict: {data['verdict'].replace('_', ' ')} "
            f"({data['n_passing_triples_campaign_tolerance']} passing (w', kR', kS') triples at the 0.05 "
            f"tolerance, {data['n_passing_triples_strict']} at strict 0.02). The total data support only the "
            f"effective rate {_fmt(data['effective_rate_per_hour'], 4)} /h."
        ),
        "chips": [{"kind": "warn", "text": data["verdict"].replace("_", " ")},
                  {"kind": "good", "text": "resolved curves identify both rates (v9 gate 12/12)"}],
        "chart": {
            "type": "line",
            "cfg": {
                "xs": data["observed"]["times"], "xLabel": "time (hours)", "yLabel": "released fraction (total)",
                "series": [{"label": "observed total", "color": "var(--series-1)", "values": data["observed"]["values"]}]
                + [{"label": f"degenerate {i + 1}", "color": f"var(--ord-{i + 2})", "values": a["values"], "dash": True}
                   for i, a in enumerate(data["alternatives"])],
            },
        },
        "table": None,
        "engine": "v9 degeneracy demo (stereo.release.degeneracy_demo)",
    }


def _pending_route(question: str) -> dict | None:
    if not any(word in question for word in ("pending", "proposal", "awaiting", "review status", "what is pending")):
        return None
    rows = []
    for phase, path in GATE_FILES.items():
        try:
            gate = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        rows.append({
            "phase": phase,
            "proposal_id": gate.get("proposal_id"),
            "proposal_pending": gate.get("proposal_pending"),
            "recommendation_rendered": gate.get("recommendation_rendered"),
        })
    pending = [row for row in rows if row["proposal_pending"]]
    answer = (
        f"{len(pending)} proposal(s) await human review: "
        + "; ".join(f"{row['phase']} {row['proposal_id']}" for row in pending)
        + ". Agents never self-approve; approve via scripts.review --decide."
        if pending else "No pending proposals found in the gate records."
    )
    return {
        "route": "pending_proposals",
        "answer": answer,
        "chips": [{"kind": "warn", "text": f"{len(pending)} pending"}] if pending else [],
        "chart": None,
        "table": {"columns": ["phase", "proposal_id", "proposal_pending", "recommendation_rendered"], "rows": rows},
        "engine": "phase gate records (reports/*/v*_gate.json), read-only",
    }


def _compare_route(question: str) -> dict | None:
    if " vs " not in question and " versus " not in question:
        return None
    parts = re.split(r"\s+vs\s+|\s+versus\s+", question, maxsplit=1)
    phase = _phase_of(question)
    left, data = _match_concept(parts[0], phase)
    right, _ = _match_concept(parts[1], phase or "v8")
    if not left or not right:
        return None
    left_row, right_row = _row_for(data, left), _row_for(data, right)
    delta = (left_row.get("priority") or 0) - (right_row.get("priority") or 0)
    answer = (
        f"{left}: {left_row['flag']}, priority {_fmt(left_row.get('priority'))}. "
        f"{right}: {right_row['flag']}, priority {_fmt(right_row.get('priority'))}. "
        f"Priority difference {delta:+.3f} in favor of {left if delta >= 0 else right}."
    )
    merged = {**right_row, **left_row}
    columns = [c for c in ("concept_id", "flag", "novelty", "india", "compatibility", "feasibility", "priority") if c in merged]
    return {
        "route": "concept_compare",
        "answer": answer,
        "chips": [{"kind": "good" if left_row["flag"] == "clear" else ("warn" if left_row["flag"] == "adjacent" else "crit"), "text": left[:40]},
                  {"kind": "good" if right_row["flag"] == "clear" else ("warn" if right_row["flag"] == "adjacent" else "crit"), "text": right[:40]}],
        "chart": None,
        "table": {"columns": columns, "rows": [{c: left_row.get(c) for c in columns}, {c: right_row.get(c) for c in columns}]},
        "engine": f"frozen {data['phase']} concept export",
    }


def _top_route(question: str) -> dict | None:
    match = re.search(r"\b(?:top|best|rank)\w*\s*(\d+)?", question)
    if not match:
        return None
    metric = next((m for m in ("priority", "novelty", "india", "compatibility") if m in question), "priority")
    phase = _phase_of(question)
    data = campaign_data(phase)
    n = min(int(match.group(1) or 5), 15)
    rows = sorted((r for r in data["concepts"] if isinstance(r.get(metric), (int, float))), key=lambda r: r[metric], reverse=True)[:n]
    answer = f"Top {len(rows)} {data['phase']} concepts by {metric}: " + ", ".join(r["concept_id"] for r in rows[:3]) + (", ..." if len(rows) > 3 else "")
    return {
        "route": "top_ranking",
        "answer": answer,
        "chips": [],
        "chart": {
            "type": "bar",
            "cfg": {
                "xLabel": metric,
                "rows": [{"label": r["concept_id"], "value": r[metric],
                          "tip": f"{r['concept_id']}: {metric} {_fmt(r[metric])} (flag {r['flag']})"} for r in rows],
            },
        },
        "table": {"columns": ["concept_id", "flag", metric], "rows": [{ "concept_id": r["concept_id"], "flag": r["flag"], metric: r[metric]} for r in rows]},
        "engine": f"frozen {phase} concept export",
    }


def _flag_route(question: str) -> dict | None:
    flag = next((f for f in ("blocked", "adjacent", "clear") if f in question), None)
    if not flag or not any(word in question for word in ("which", "how many", "list", "show")):
        return None
    phase = _phase_of(question)
    data = campaign_data(phase)
    shortlist_only = "shortlist" in question
    source = data["shortlist"] if shortlist_only else data["concepts"]
    rows = [r for r in source if r["flag"] == flag]
    where = "shortlist" if shortlist_only else "concept set"
    listed = ": " + ", ".join(r["concept_id"] for r in rows[:4]) + (", ..." if len(rows) > 4 else "") if rows else ""
    answer = f"{len(rows)} {flag} concept(s) in the {phase} {where}{listed}."
    return {
        "route": "flag_listing",
        "answer": answer,
        "chips": [{"kind": "good" if flag == "clear" else ("warn" if flag == "adjacent" else "crit"), "text": f"{len(rows)} {flag}"}],
        "chart": None,
        "table": {"columns": ["concept_id", "direction", "flag", "nearest_art", "S_nearest", "priority"], "rows": rows},
        "engine": f"frozen {phase} concept export",
    }


def _concept_route(question: str) -> dict | None:
    phase = _phase_of(question)
    concept_id, data = _match_concept(question, phase)
    if not concept_id or not any(word in question for word in ("what", "region", "transfer", "tell", "about", "lookup", "feasib", "prior", "detail", "describe")):
        return None
    row = _row_for(data, concept_id)
    bits = [f"Concept {concept_id}: prior-art {row['flag']} (nearest {row.get('nearest_art', '')} at S={_fmt(row.get('S_nearest'))})",
            f"priority {_fmt(row.get('priority'))} from novelty {_fmt(row.get('novelty'))}, india {_fmt(row.get('india'))}, compatibility {_fmt(row.get('compatibility'))}"]
    if row.get("region_low_per_day"):
        bits.append(f"transferred region [{row['region_low_per_day']:.3g}, {row['region_high_per_day']:.3g}] /day from analogue {row.get('analogue')} (w={_fmt(row.get('w'))}"
                    + (f", stereo regime {row.get('stereo_regime')}" if row.get("stereo_regime") else "") + ")")
    chart = None
    if row.get("region_low_per_day"):
        chart = {"type": "interval", "cfg": {
            "xLabel": "transferred rate region (/day, log)",
            "rows": [{"label": concept_id, "low": row["region_low_per_day"], "high": row["region_high_per_day"],
                      "color": "var(--series-1)",
                      "tip": f"{concept_id}: [{row['region_low_per_day']:.3g}, {row['region_high_per_day']:.3g}] /day"}],
        }}
    return {
        "route": "concept_lookup",
        "answer": ". ".join(bits) + ".",
        "chips": [{"kind": "good" if row["flag"] == "clear" else ("warn" if row["flag"] == "adjacent" else "crit"), "text": row["flag"]}],
        "chart": chart,
        "table": _concept_table(row),
        "engine": f"frozen {data['phase']} concept export",
    }


def _filter_route(question: str) -> dict | None:
    if not any(word in question for word in ("use", "uses", "with ", "carrier", "how many")):
        return None
    phase = _phase_of(question)
    data = campaign_data(phase)
    if "enantioenriched" in question or "enriched" in question:
        rows = [r for r in data["concepts"] if r.get("enrichment") == "enantioenriched"]
        label = "enantioenriched"
    else:
        names = sorted({r.get("carrier") for r in data["concepts"] if r.get("carrier")} | {r.get("partner") for r in data["concepts"] if r.get("partner")}, key=len, reverse=True)
        name = next((n for n in names if n and n in question), None)
        if not name:
            return None
        rows = [r for r in data["concepts"] if r.get("carrier") == name or r.get("partner") == name]
        label = name
    shortlist_ids = {r["concept_id"] for r in data["shortlist"]}
    answer = f"{len(rows)} {phase} concept(s) involve {label}" + (
        f"; {sum(1 for r in rows if r['concept_id'] in shortlist_ids)} of them are shortlisted" if shortlist_ids else "") + "."
    return {
        "route": "concept_filter",
        "answer": answer,
        "chips": [{"kind": "good", "text": f"{len(rows)} concepts"}],
        "chart": None,
        "table": {"columns": ["concept_id", "direction", "flag", "priority"], "rows": rows},
        "engine": f"frozen {phase} concept export",
    }


def _stereo_route(question: str) -> dict | None:
    if not any(word in question for word in ("chiral", "stereo", "enantiomer", "racemic", "single stereoisomer")):
        return None
    registry = _load_components()
    name = next((n for n in sorted(registry, key=len, reverse=True) if n in question), None)
    if not name:
        return None
    entry = registry[name]
    kind = "good" if entry["stereo"] not in ("unspecified",) else "warn"
    return {
        "route": "stereo_descriptor",
        "answer": f"{name}: stereo descriptor '{entry['stereo']}'. {entry['note']}",
        "chips": [{"kind": kind, "text": entry["stereo"]}],
        "chart": None,
        "table": {"columns": ["component", "stereo"], "rows": [{"component": name, "stereo": entry["stereo"]}]},
        "engine": "pinned stereo registries (data/v9, data/v10)",
    }


ROUTES = (
    _identifiability_route,
    _pending_route,
    _claim_route,
    _compare_route,
    _top_route,
    _flag_route,
    _concept_route,
    _filter_route,
    _stereo_route,
)


def answer(question: str) -> dict:
    """Route a question deterministically; never raise, never fabricate."""
    normalized = _normalize(question)
    if len(normalized) < 3:
        return _help_route()
    if any(word in normalized for word in ("help", "what can you answer", "examples")):
        payload = _help_route()
        payload["answer"] = "Here is what I can answer (click an example):"
        return payload
    for route in ROUTES:
        try:
            payload = route(normalized)
        except Exception as exc:  # a broken route must not break the console
            payload = None
            _last_error = str(exc)  # noqa: F841 - surfaced nowhere by design
        if payload is not None:
            return payload
    return _help_route()
