"""Pure deterministic compute layer for the v12 GUI.

Every function is side-effect free and unit-tested: the server layer is
a thin parameter parser over these, and the page renders only what they
return.  Curves come from the verified kernels; scans from the v11
claim machinery; campaign rows from the frozen phase exports (read-only).
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from ..design.zero_order import (
    fickian_claim_scan,
    zero_order_claim_scan,
    zero_order_fraction,
)
from ..release import release_fraction
from ..stereo.release import total_curve

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()
CAMPAIGN_PHASES = ("v8", "v10")
DEGENERACY_EXPORT = REPO_ROOT / "reports/v9/v9_degeneracy_demo.json"
CHART_SERIES_POINTS = 140
ROUND_DIGITS = 6

PARAM_LIMITS = {
    "rate": (1e-9, 100.0),
    "k0": (1e-9, 100.0),
    "plateau": (1e-6, 1.0),
    "lag": (0.0, 1e4),
    "t_max": (1e-3, 1e5),
    "points": (50, 1000),
    "t1": (1e-3, 1e4),
    "t2": (1e-3, 1e4),
    "cap": (1e-6, 1.0),
    "floor": (1e-6, 1.0),
}
KERNELS = ("fickian", "zero_order")


def _checked(name: str, value, kind="float") -> float | int:
    low, high = PARAM_LIMITS[name]
    try:
        if kind == "int":
            parsed = int(value)
        else:
            parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a number") from exc
    if not np.isfinite(parsed) or not low <= parsed <= high:
        raise ValueError(f"{name} must lie in [{low}, {high}]")
    return parsed


def simulate(kernel: str, params: dict, t_max: float = 60.0, points: int = 200) -> dict:
    """Release curve in fraction units; times in days for both kernels
    (Fickian rate is D/L^2 per day, zero-order k0 per day)."""
    if kernel not in KERNELS:
        raise ValueError(f"kernel must be one of {KERNELS}")
    t_max = _checked("t_max", t_max)
    points = int(_checked("points", points, kind="int"))
    times = np.linspace(0.0, t_max, points)
    if kernel == "fickian":
        rate = _checked("rate", params.get("rate"))
        plateau = _checked("plateau", params.get("plateau", 1.0))
        values = plateau * np.asarray(
            release_fraction(times, "spherical_diffusion", {"rate": rate}), dtype=float
        )
        model = {"rate": rate, "plateau": plateau}
    else:
        k0 = _checked("k0", params.get("k0"))
        plateau = _checked("plateau", params.get("plateau", 1.0))
        lag = _checked("lag", params.get("lag", 0.0))
        values = zero_order_fraction(times, k0, plateau, lag)
        model = {"k0": k0, "plateau": plateau, "lag": lag}
    return {
        "kernel": kernel,
        "params": {key: round(value, ROUND_DIGITS) for key, value in model.items()},
        "times": [round(float(t), ROUND_DIGITS) for t in times],
        "values": [round(float(v), ROUND_DIGITS) for v in values],
        "unit": "released fraction (times in days)",
        "assumption": "verified kernel under stated model assumptions; no efficacy claim",
    }


def claim_state(kernel: str, params: dict, claim: dict) -> dict:
    """Evaluate a claim pair against the simulated parameters."""
    claim = _claim_checked(claim)
    simulate(kernel, params, t_max=max(claim["t2"], 1.0), points=50)
    times = np.array([claim["t1"], claim["t2"]])
    plateau = float(params.get("plateau", 1.0))
    if kernel == "fickian":
        values = plateau * release_fraction(times, "spherical_diffusion", {"rate": float(params["rate"])})
    else:
        values = zero_order_fraction(times, float(params["k0"]), plateau, float(params.get("lag", 0)))
    v_t1, v_t2 = map(float, values)
    pass_t1 = v_t1 <= claim["cap"]
    pass_t2 = v_t2 >= claim["floor"]
    return {
        "t1": claim["t1"], "cap": claim["cap"], "t2": claim["t2"], "floor": claim["floor"],
        "v_t1": round(v_t1, ROUND_DIGITS), "v_t2": round(v_t2, ROUND_DIGITS),
        "pass_t1": bool(pass_t1), "pass_t2": bool(pass_t2), "pass": bool(pass_t1 and pass_t2),
    }


def _claim_checked(raw: dict) -> dict:
    claim = {
        "t1": _checked("t1", raw.get("t1", 5.0)),
        "t2": _checked("t2", raw.get("t2", 35.0)),
        "cap": _checked("cap", raw.get("cap", 0.2)),
        "floor": _checked("floor", raw.get("floor", 0.8)),
    }
    if claim["t2"] <= claim["t1"]:
        raise ValueError("t2 must exceed t1")
    return claim


def claim_scans(raw: dict) -> dict:
    """Both kernel families against a user claim pair (v11 machinery)."""
    claim = _claim_checked(raw)
    fickian = fickian_claim_scan(claim["t1"], claim["t2"], claim["cap"], claim["floor"])
    scan = fickian["scan"]
    index = np.unique(np.linspace(0, len(scan["tau1"]) - 1, CHART_SERIES_POINTS).astype(int))
    rates = (scan["tau1"] / claim["t1"])[index]
    zero = zero_order_claim_scan(claim["t1"], claim["t2"], claim["cap"], claim["floor"])
    # An analytic witness covers lags/rates outside the legacy frozen scan.
    witness_k = claim["floor"] / (claim["t2"] - claim["t1"])
    witness = {"k0_per_day": witness_k, "lag_days": claim["t1"], "plateau": 1.0,
               "release_t1": 0.0, "release_t2": claim["floor"]}
    if not zero["n_feasible"]:
        zero["examples"] = [witness]
    return {
        "claim": claim,
        "fickian": {
            "n_feasible": fickian["n_feasible"],
            "ceiling_t2": round(fickian["ceiling_t2"], ROUND_DIGITS),
            "best_rate_per_day": round(fickian["best_rate_per_day"], 10),
            "ratio_bound_sqrt": round(fickian["ratio_bound_sqrt"], ROUND_DIGITS),
            "verdict": ("feasible" if fickian["n_feasible"] else
                "infeasible_for_the_family" if claim["cap"] * fickian["ratio_bound_sqrt"] < claim["floor"] else
                "no_feasible_candidate_in_grid"),
            "series": {
                "rate": [round(float(r), 10) for r in rates],
                "achieved_t2": [round(float(a), ROUND_DIGITS) for a in scan["achieved"][index]],
            },
        },
        "zero_order": {
            "n_feasible": zero["n_feasible"],
            "k0_feasible_min": zero["k0_feasible_min"] and round(zero["k0_feasible_min"], ROUND_DIGITS),
            "k0_feasible_max": zero["k0_feasible_max"] and round(zero["k0_feasible_max"], ROUND_DIGITS),
            "verdict": "feasible",
            "analytic_witness": witness,
            "search_status": "grid_has_candidates" if zero["n_feasible"] else "analytic_witness_outside_grid",
            "corner": zero["corner"],
            "examples": zero["examples"],
        },
        "note": "kernel feasibility under stated model assumptions; the standing not-comparable register applies",
    }


_CONCEPT_COLUMNS = [
    "concept_id", "direction", "format", "carrier", "partner", "enrichment", "flag",
    "blocked_by", "nearest_art", "S_nearest", "novelty", "india", "compatibility",
    "feasibility", "priority", "w", "analogue", "stereo_regime",
    "region_low_per_day", "region_high_per_day", "positive_control",
]


def campaign_data(phase: str) -> dict:
    """Frozen campaign exports, read-only, normalized across phases."""
    if phase not in CAMPAIGN_PHASES:
        raise ValueError(f"phase must be one of {CAMPAIGN_PHASES}")
    base = REPO_ROOT / "reports" / phase
    prefix = f"{phase}_"
    concepts = pd.read_csv(base / f"{prefix}concepts.csv")
    shortlist = pd.read_csv(base / f"{prefix}shortlist.csv")
    gates = json.loads((base / f"{phase}_gate.json").read_text())

    def records(frame: pd.DataFrame) -> list[dict]:
        available = [c for c in _CONCEPT_COLUMNS if c in frame.columns]
        cleaned = frame[available].copy()
        for column in available:
            if cleaned[column].dtype == object:
                cleaned[column] = cleaned[column].fillna("")
        rows = []
        for record in cleaned.to_dict(orient="records"):
            clean = {}
            for key, value in record.items():
                if isinstance(value, float) and not math.isfinite(value):
                    clean[key] = None  # strict JSON: browsers reject NaN tokens
                else:
                    clean[key] = round(value, ROUND_DIGITS) if isinstance(value, float) else value
            rows.append(clean)
        return rows

    return {
        "phase": phase,
        "columns": [c for c in _CONCEPT_COLUMNS if c in concepts.columns],
        "concepts": records(concepts),
        "shortlist": records(shortlist),
        "n_concepts": int(len(concepts)),
        "gates": {key: gates.get(key) for key in (
            "n_concepts", "positive_control_blocked", "shortlist_size", "proposal_pending",
            "recommendation_rendered", "coverage_disclaimer",
        )},
        "disclaimer": "prior-art coverage flags against pinned registries; no legal or efficacy claim",
    }


def degeneracy_data() -> dict:
    """The v9 identifiability demonstration, recomputed deterministically."""
    demo = json.loads(DEGENERACY_EXPORT.read_text())
    times = np.linspace(0.5, 64.0, 160)
    observed = total_curve(times, demo["true"]["k_r"], demo["true"]["k_s"], w=demo["true"]["w"])
    alternatives = []
    for triple in demo["campaign"]["passing_triples_sample"][:3]:
        curve = total_curve(times, triple["k_r"], triple["k_s"], w=triple["w"])
        alternatives.append({
            "label": f"w'={triple['w']:.1f}, k_R'={triple['k_r']:.4g}, k_S'={triple['k_s']:.4g} /h",
            "times": [round(float(t), ROUND_DIGITS) for t in times],
            "values": [round(float(v), ROUND_DIGITS) for v in curve],
        })
    return {
        "verdict": demo["verdict"],
        "n_passing_triples_campaign_tolerance": demo["campaign"]["n_passing_triples"],
        "n_passing_triples_strict": demo["strict"]["n_passing_triples"],
        "effective_rate_per_hour": round(demo["effective_rate"], ROUND_DIGITS),
        "true": demo["true"],
        "swap_symmetry": demo["swap_symmetry"],
        "statement": demo["statement"],
        "observed": {
            "times": [round(float(t), ROUND_DIGITS) for t in times],
            "values": [round(float(v), ROUND_DIGITS) for v in observed],
        },
        "alternatives": alternatives,
        "label": "synthetic demonstration (v9); per-enantiomer claims require stereo-resolved assays",
    }
