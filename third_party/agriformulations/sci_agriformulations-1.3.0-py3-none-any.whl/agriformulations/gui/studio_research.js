"use strict";
window.FormulationResearch=(()=>{
let u,sourceEdit=null;
const drafts=new Map(),choices=new Map(),savedOnly=new Map();
const el=id=>document.getElementById(id);
const esc=v=>u.esc(v);
const option=(v,t,selected)=>"<option value='"+esc(v)+"'"+(selected?" selected":"")+">"+esc(t)+"</option>";
const defaults=()=>({kind:"literature",query:"",focus_terms:"",year_from:"",year_to:"",country:"",cpc:"",sort:"relevance",limit:10});
const draft=()=>{if(!drafts.has(u.app.session))drafts.set(u.app.session,defaults());return drafts.get(u.app.session);};
const safe=fn=>async e=>{try{await fn(e);}catch(error){u.notify(error);}};
function link(url,title){return /^https:\/\//.test(url||"")?"<a href='"+esc(url)+"' target='_blank' rel='noopener noreferrer'>"+esc(title)+" ↗</a>":esc(title);}
function form(){
 const d=draft(),patent=d.kind==="patent";
 return "<form id='researchSearchForm' class='research-form'><div class='editor-fields'><label>Search collection<select id='researchKind' name='kind'>"+option("literature","Scientific literature",!patent)+option("patent","Patents",patent)+"</select></label><label>Order<select name='sort'>"+option("relevance","Relevance",d.sort==="relevance")+option("newest","Newest publications",d.sort==="newest")+"</select></label></div><label>Keywords or identifiers<input name='query' value='"+esc(d.query)+"' maxlength='500' required placeholder='e.g. coconut leaf blight fungicide'></label><label>Focus crop, active or target (optional)<input name='focus_terms' value='"+esc(d.focus_terms)+"' maxlength='605' placeholder='e.g. coconut; Cocos nucifera'><small>Separate aliases for the same focus with semicolons. Relevance order puts title matches first, then abstract matches. A match does not establish efficacy.</small></label><div class='editor-fields research-filters'><label>Publication year from<input name='year_from' type='number' min='1800' max='2100' value='"+esc(d.year_from)+"' placeholder='Any'></label><label>Through year<input name='year_to' type='number' min='1800' max='2100' value='"+esc(d.year_to)+"' placeholder='Any'></label><label>Results<select name='limit'>"+[5,10,20,30].map(n=>option(n,n,Number(d.limit)===n)).join("")+"</select></label></div>"+(patent?"<div class='editor-fields'><label>Publication authority<input name='country' maxlength='2' value='"+esc(d.country)+"' placeholder='Any · US, IN, EP, WO'></label><label>CPC classification<input name='cpc' maxlength='20' value='"+esc(d.cpc)+"' placeholder='Optional · A01N'></label></div>":"")+"<div class='research-form-actions'><p class='muted'>"+(patent?"Google Patents · publication records and snippets":"Crossref + Europe PMC · DOI records and available abstracts")+"</p><button class='button primary' type='submit'>Search "+(patent?"patents":"literature")+"</button></div><p class='muted'>Your query is sent to these public search providers. Searches run in the background and are saved to this project.</p></form>";
}
function sourceCard(record,search,saved){
 const metadata=record.kind==="patent"?[record.publication_number,record.country,record.assignee,record.publication_date?"Published "+record.publication_date:"",record.priority_date?"Priority "+record.priority_date:""]:[record.year,record.journal,(record.authors||[]).slice(0,4).join(", "),record.doi];
 const focus=record.focus_assessment,label=focus&&focus.label!=="No focus specified"?"<p class='scenario-note'>"+esc(focus.label)+". This checks available text, not study quality or applicability.</p>":"";
 return "<article class='research-card'><div class='research-card-top'><span class='badge'>"+esc(record.kind==="patent"?"Patent publication":"Literature")+" · "+esc((record.providers||[record.provider]).join(" / "))+"</span>"+(saved?"<span class='badge'>"+esc(saved.status)+"</span>":"")+"</div><h3>"+link(record.url,record.title)+"</h3><p class='research-meta'>"+esc(metadata.filter(Boolean).join(" · "))+"</p>"+label+(record.abstract?"<details><summary>"+(record.kind==="patent"?"Search snippet":"Available abstract")+"</summary><p>"+esc(record.abstract)+"</p></details>":"<p class='muted'>No abstract supplied. Open the source to review it.</p>")+(record.kind==="patent"?"<p class='muted'>Legal status unverified · open the source to inspect claims and family members.</p>":"")+"<p class='muted'>Evidence stage: "+esc((saved?.evidence_stage||(saved?.status==="reviewed"?"review_scope_unspecified":"metadata_only")).replaceAll("_"," "))+". Review scope is recorded by the reviewer; no compatibility or claim support is implied.</p>"+(saved?.notes?"<p class='research-notes'>"+esc(saved.notes)+"</p>":"")+"<p class='muted'>Retrieved "+esc(record.retrieved_at)+"</p><div class='card-actions'><button class='button' data-research-save='"+esc(record.record_id)+"' data-search-id='"+esc(search)+"'>"+(saved?"Edit source notes":"Save source")+"</button></div></article>";
}
async function render(){
 const sid=u.app.session,data=await u.json("/api/studio/research?session_id="+encodeURIComponent(sid));
 if(sid!==u.app.session)return "";
 const searches=data.searches,sources=new Map(data.sources.map(s=>[s.record_id,s]));
 let selected=choices.get(sid);
 if(u.app.selected){const a=u.app.view.artifacts.find(v=>v.artifact_id===u.app.selected);if(a?.kind==="research_search"){const full=await u.artifact(a.artifact_id);selected=full.payload.search_id;}else if(a?.kind==="research_source")savedOnly.set(sid,true);}
 if(!searches.some(s=>s.search_id===selected))selected=searches.at(-1)?.search_id;
 choices.set(sid,selected);
 const current=searches.find(s=>s.search_id===selected),only=savedOnly.get(sid)===true;
 let out="<div class='research-heading'><span class='section-kicker'>LITERATURE & PATENT SEARCH</span><h3>Find evidence for your formulation.</h3><p>Search publications, inspect sources, and keep the evidence that informs your next decision.</p></div>"+form();
 const running=(u.app.view.requests||[]).some(r=>["queued","running"].includes(r.status)&&r.question.startsWith("Search "));
 if(running)out+="<p class='research-progress' role='status'>Search in progress. Results will appear here when retrieved; you can keep working.</p>";
 out+="<div class='research-results-heading'><h3>"+(only?"Saved sources ("+data.sources.length+")":"Search results")+"</h3><label class='version-toggle'><input id='researchSavedOnly' type='checkbox'"+(only?" checked":"")+"> Saved sources</label></div>";
 if(only){out+=data.sources.length?data.sources.slice().reverse().map(s=>sourceCard(s.source,s.search_id,s)).join(""):"<p class='muted'>Save a paper or patent from your search results to build this project’s source list.</p>";}
 else{
  if(searches.length)out+="<label>Search history<select id='researchHistory'>"+searches.slice().reverse().map(s=>option(s.search_id,s.parameters.kind+" · "+s.parameters.query+" · "+s.retrieved_at.slice(0,16),s.search_id===selected)).join("")+"</select></label>";
  if(!current)out+="<div class='lab-empty'><h3>Start with a formulation question.</h3><p>Search by active ingredient, carrier, mechanism, author, DOI or patent number. No recipe or agent connection is required.</p></div>";
  else{
   out+="<div class='research-summary'><p><b>"+current.results.length+" records saved</b> · "+esc(current.status)+" · "+esc(current.retrieved_at)+"</p><div class='card-actions'><button class='button subtle' data-research-download='"+esc(current.search_id)+"'>Download search JSON</button><button class='button subtle' data-research-csv='"+esc(current.search_id)+"'>Download citations CSV</button></div></div>";
   for(const p of current.providers)out+="<p class='muted'>"+(p.url?link(p.url,p.provider):esc(p.provider))+" · "+esc(p.status)+(p.total!==null&&p.total!==undefined?" · "+esc(p.total)+" provider matches":"")+(p.error?" · "+esc(p.error):"")+"</p>";
   if(current.status==="unavailable")out+="<p class='notice' role='alert'>Search providers could not be reached. This is a failed retrieval, not evidence that no publications exist. Retry the search.</p>";
   else if(!current.results.length)out+="<p class='muted'>No records returned for these filters. Try a broader query or publication year range.</p>";
   if(current.status==="partial")out+="<p class='scenario-note'>Some providers were unavailable. Results below cover the responding providers.</p>";
   if(current.focus_summary?.terms?.length)out+="<p class='scenario-note'><b>"+current.focus_summary.matching_records+" of "+current.results.length+" records mention "+esc(current.focus_summary.terms.join(" / "))+" in available titles or abstracts.</b> "+(current.focus_summary.matching_records?"Start with matching sources. Compare the target organism, tested active, application route and measured outcome before choosing a provisional formulation direction.":"The retrieved metadata does not confirm this focus. Refine the query using one disease or pest and the crop’s scientific name; these hits are insufficient for a crop-specific treatment choice.")+"</p>";
   out+=current.results.map(r=>sourceCard(r,current.search_id,sources.get(r.record_id))).join("");
  }
 }
 return out+"<p class='scenario-note'>Search records are discovery evidence. Full text, experimental methods and patent claims require review. Patent results do not establish novelty, patentability, freedom to operate or current legal status.</p>";
}
function remember(form){const d=draft();for(const [key,value] of new FormData(form))d[key]=value;if(d.kind==="literature"){d.country="";d.cpc="";}return d;}
async function submit(e){
 if(e.target.id!=="researchSearchForm")return;
 e.preventDefault();const sid=u.app.session,d={...remember(e.target)};
 d.focus_terms=String(d.focus_terms||"").split(";").map(v=>v.trim()).filter(Boolean);
 const button=e.target.querySelector("button[type=submit]");button.disabled=true;
 try{await u.post("/api/studio/research-search",{session_id:sid,parameters:d});if(sid===u.app.session){u.app.selected=null;savedOnly.set(sid,false);choices.delete(sid);await u.refresh(true);}}
 finally{button.disabled=false;}
}
async function click(e){
 const b=e.target.closest("button");if(!b)return;
 if(b.dataset.researchSave){
  const sid=u.app.session,data=await u.json("/api/studio/research?session_id="+encodeURIComponent(sid));
  if(sid!==u.app.session)return;
  const found=data.searches.find(s=>s.search_id===b.dataset.searchId)?.results.find(r=>r.record_id===b.dataset.researchSave);
  if(!found)throw new Error("Search result is no longer available.");
  const saved=data.sources.find(s=>s.record_id===found.record_id);
  sourceEdit={sid,search_id:b.dataset.searchId,record_id:found.record_id,version:saved?.updated_at||""};
  el("researchSourceTitle").textContent=found.title;el("researchSourceNotes").value=saved?.notes||"";el("researchSourceStatus").value=saved?.status||"saved";el("researchSourceStage").value=saved?.evidence_stage||"metadata_only";el("researchSourceError").hidden=true;el("researchSourceDialog").showModal();
 }
 const id=b.dataset.researchDownload||b.dataset.researchCsv;
 if(id){
  const sid=u.app.session,data=await u.json("/api/studio/research?session_id="+encodeURIComponent(sid));
  if(sid!==u.app.session)return;
  const run=data.searches.find(s=>s.search_id===id);if(!run)return;
  if(b.dataset.researchDownload)u.download(id+".json",run);
  else{const rows=run.results.map(r=>({kind:r.kind,title:r.title,doi:r.doi||"",publication_number:r.publication_number||"",year:r.year||"",url:r.url,provider:r.providers.join("; "),retrieved_at:r.retrieved_at}));const keys=Object.keys(rows[0]||{title:"",url:""}),q=v=>'"'+String(v??"").replace(/^([=+@-])/,"'$1").replaceAll('"','""')+'"';u.download(id+".csv",[keys.map(q).join(","),...rows.map(r=>keys.map(k=>q(r[k])).join(","))].join("\n"),"text/csv");}
 }
}
async function init(context){
 u=context;
 document.addEventListener("input",e=>{const form=e.target.closest("#researchSearchForm");if(form)remember(form);});
 document.addEventListener("change",safe(async e=>{
  if(e.target.id==="researchKind"){remember(e.target.form);u.app.selected=null;await u.viewPanel("research");}
  if(e.target.id==="researchHistory"){choices.set(u.app.session,e.target.value);u.app.selected=null;await u.viewPanel("research");}
  if(e.target.id==="researchSavedOnly"){savedOnly.set(u.app.session,e.target.checked);u.app.selected=null;await u.viewPanel("research");}
 }));
 document.addEventListener("submit",safe(submit));document.addEventListener("click",safe(click));
 el("researchSourceForm").onsubmit=safe(async e=>{
  e.preventDefault();if(sourceEdit.sid!==u.app.session)throw new Error("Reopen this source in its project before saving.");
  const b=el("researchSourceSubmit");b.disabled=true;
  try{
   await u.post("/api/studio/research-source",{session_id:sourceEdit.sid,search_id:sourceEdit.search_id,record_id:sourceEdit.record_id,notes:el("researchSourceNotes").value,status:el("researchSourceStatus").value,evidence_stage:el("researchSourceStage").value,expected_source_version:sourceEdit.version});
   el("researchSourceDialog").close();await u.refresh(true);
  }catch(error){el("researchSourceError").textContent=error.message;el("researchSourceError").hidden=false;}
  finally{b.disabled=false;}
 });
}
return {init,render};
})();

