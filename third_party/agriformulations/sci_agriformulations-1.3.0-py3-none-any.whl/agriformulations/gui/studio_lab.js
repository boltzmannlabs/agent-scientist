"use strict";
// Shared guidance for simulation, study and optimization inputs.
window.FormulationInputHelp=(()=>{
const descriptions={
 model:"Choose the release mechanism used to calculate the curve.",
 rate_per_day:"Controls how quickly intrinsic release progresses; use a fit or an explicit assumed rate.",
 plateau:"Sets the maximum releasable fraction; 0.9 means 90%.",
 lag_days:"Delays the start of release by this many days.",
 tau_days:"Sets the Weibull release time scale.",
 beta:"Controls the shape of the Weibull release curve.",
 horizon_days:"Sets how many days the model evaluates; keep this shared when comparing candidates.",
 reservoir_half_life_days:"Controls degradation before release; leave blank to exclude this loss.",
 available_half_life_days:"Controls loss of active after release; leave blank to exclude this loss.",
 parameter_source:"Records where the release coefficients came from; this does not validate them.",
 release_specs:'Checks the intrinsic no-loss release curve at declared days, e.g. [{"day":5,"min_fraction":0.1,"max_fraction":0.3}]. These are model specifications, not measured efficacy.',
 reference_rate_per_day:"Sets chemical loss at the reference temperature; use assay-derived or explicitly assumed values.",
 reference_temperature_c:"Defines the temperature at which the reference coefficient applies.",
 activation_energy_kj_mol:"Controls how chemical loss changes with temperature; this is an input, not an estimated property of the recipe.",
 temperatures_c:"Lists temperatures for the curves. Stability study criteria assess the FIRST listed temperature; use separate scenarios for other temperatures.",
 minimum_retained_fraction:"Sets the retention-crossing threshold; 0.9 means 90%. Add a study Minimum separately to make it an acceptance requirement.",
 temperature_profile:'Optional changing-temperature schedule, e.g. [{"days":10,"temperature_c":25}]. Leave [] for no schedule; study retention still uses the first constant temperature.',
 evaluation_day:"Sets the day at which the hypothetical active requirement is assessed.",
 target_available_g_ha:"Sets the hypothetical available-active target for mass-balance arithmetic; it is not an efficacy recommendation.",
 storage_retained_fraction:"Sets the fraction of initial active remaining after storage; 0.9 means 90%.",
 deposition_fraction:"Sets the assumed fraction of applied material reaching the modeled deposit.",
 spray_volume_l_ha:"Converts the calculated product quantity into a spray-tank concentration.",
 release_rate_per_day:"Sets the assumed first-order release speed for the dose scenario.",
 release_horizon_days:"Sets the release calculation window; it must include the evaluation day.",
 particle_sizes_um:"Lists particle DIAMETERS for the settling bins; enter comma-separated values.",
 particle_weights:"Gives one relative weight per particle-size bin; positive total weights are normalized to one.",
 density_difference_kg_m3:"Sets particle density minus liquid density; its sign determines settling or creaming.",
 viscosity_mpa_s:"Sets the continuous-phase viscosity used in settling; it is not automatically taken from the rheology model.",
 solids_volume_fraction:"Sets the particle volume fraction for hindered settling; this is not the active mass fraction.",
 hindered_exponent:"Controls how particle crowding reduces ideal settling speed.",
 yield_stress_pa:"Sets the assumed stress needed to start flow, or the force-balance arrest threshold in a settling screen.",
 container_height_cm:"Sets the settling distance used to calculate the separated fraction.",
 consistency_pa_sn:"Sets flow resistance together with the flow index; use a flow-curve fit or an explicit assumption.",
 flow_index:"Controls shear thinning (<1), Newtonian contribution (=1) or shear thickening (>1). Choose search bounds from supported property values.",
 shear_rates_s:"Lists rates for the displayed flow curve; viscosity at 100 1/s and pipe shear are evaluated separately.",
 pipe_radius_mm:"Sets the internal pipe RADIUS, not diameter, for the approximate pressure calculation.",
 pipe_length_m:"Sets pipe length for the approximate pumping-pressure drop.",
 flow_l_min:"Sets the requested volumetric flow through the pipe.",
 intrinsic_solubility_mg_l:"Sets intrinsic single-active solubility before ionization and cosolvent corrections.",
 dissolution_enthalpy_kj_mol:"Controls the modeled temperature dependence of solubility.",
 ph:"Sets the water pH used for the assumed ionization correction.",
 ionization:"Choose whether the single active is modeled as neutral, a weak acid or a weak base.",
 pka:"Sets the acid/base dissociation value for the ionization correction.",
 cosolvent_fraction:"Sets the assumed cosolvent fraction in the solubility screen.",
 cosolvency_log10:"Controls the empirical change in solubility with cosolvent fraction.",
 loading_mg_l:"Sets active concentration to compare with the assumed solubility.",
 precipitation_rate_per_day:"Controls the assumed rate at which supersaturation relaxes.",
 dilution_factors:"Lists total dilution factors; enter comma-separated numbers.",
 product_density_kg_l:"Converts product volume into product mass for dilution arithmetic.",
 solubility_mg_l:"Sets the declared aqueous active solubility ceiling; it does not establish product compatibility.",
 hardness_mg_l_caco3:"Sets water hardness expressed as calcium-carbonate equivalent.",
 calcium_fraction:"Sets the assumed calcium share of the hardness.",
 carbonate_mmol_l:"Sets carbonate concentration for the calcium-carbonate saturation screen.",
 caco3_ksp:"Sets the solubility-product constant used in the carbonate screen.",
 droplet_sizes_um:"Lists starting droplet diameters for the flight screen.",
 release_height_m:"Sets the height from which modeled droplets fall.",
 wind_m_s:"Sets horizontal wind speed for the idealized downwind displacement.",
 liquid_density_kg_m3:"Sets droplet liquid density in the drag calculation.",
 air_viscosity_pa_s:"Sets air viscosity used in the drag calculation.",
 air_density_kg_m3:"Sets air density used in the drag calculation.",
 evaporation_um2_s:"Sets the assumed diameter-squared evaporation coefficient.",
 nonvolatile_volume_fraction:"Sets the droplet volume fraction remaining after volatile liquid evaporates.",
 horizon_seconds:"Sets the duration of the droplet calculation.",
 droplet_diameter_um:"Sets initial droplet diameter for footprint and drying calculations.",
 contact_angle_deg:"Controls the ideal droplet footprint on a surface.",
 droplets_per_cm2:"Sets droplet number per area for idealized coverage.",
 relative_humidity:"Sets air humidity as a fraction; 0.5 means 50%.",
 drying_hours:"Sets drying time before the modeled rainfall starts.",
 maximum_bound_fraction:"Sets the maximum fraction that can enter the more rain-resistant deposit state.",
 binding_rate_per_hour:"Controls transfer into the more rain-resistant deposit state.",
 labile_washoff_per_mm:"Sets assumed wash-off per millimetre of rain for the labile deposit.",
 bound_washoff_per_mm:"Sets assumed wash-off per millimetre of rain for the bound deposit.",
 rainfall_mm_hour:"Sets rainfall intensity during the wash-off scenario.",
 horizon_hours:"Sets how long the rainfall scenario runs.",
 initial_size_um:"Sets particle size before the modeled milling step.",
 limiting_size_um:"Sets the assumed lower particle-size limit approached during milling.",
 milling_rate_per_kwh_kg:"Controls empirical size reduction per unit of milling energy.",
 power_w:"Sets power supplied to the modeled process.",
 batch_kg:"Sets batch mass for energy and heating calculations.",
 heating_fraction:"Sets the fraction of supplied power converted to product heating.",
 heat_capacity_j_kg_k:"Controls the temperature rise per unit of heat input.",
 heat_transfer_w_k:"Controls heat exchange with the surroundings.",
 initial_temperature_c:"Sets the starting product temperature.",
 ambient_temperature_c:"Sets the surroundings temperature for heat transfer.",
 initial_cv:"Sets the starting mixing coefficient of variation.",
 mixing_rate_per_min:"Controls the assumed decrease in mixing variability over time.",
 horizon_minutes:"Sets the processing duration.",
 dry_product_kg:"Sets dry product mass for the moisture-capacity calculation.",
 area_m2:"Sets packaging area exposed to moisture transfer.",
 wvtr_g_m2_day:"Sets the supplied or assumed packaging water-vapour transmission rate.",
 wvtr_reference_rh_difference:"Defines the humidity difference at which the WVTR applies.",
 external_rh:"Sets external relative humidity as a fraction.",
 moisture_capacity_g_kg_aw:"Converts moisture content into the modeled water activity.",
 initial_moisture_g:"Sets the starting moisture mass inside the package.",
 initial_solvent_g:"Sets the starting solvent mass available for loss.",
 solvent_loss_rate_per_day:"Controls assumed first-order solvent loss from the package.",
 reference_model:"Chooses the mathematical two-active response reference, not a measured synergy conclusion.",
 doses_a:"Lists doses of active A for the reference response surface.",
 doses_b:"Lists doses of active B in the same dose units.",
 dose_unit:"Records the common unit used for doses and EC50 values.",
 ec50_a:"Sets the assumed or fitted 50% response dose for active A.",
 ec50_b:"Sets the assumed or fitted 50% response dose for active B.",
 hill_a:"Controls the steepness of the active-A dose-response curve.",
 hill_b:"Controls the steepness of the active-B dose-response curve.",
 initial_active_g_ha:"Sets initial active mass per hectare for the environmental mass balance.",
 soil_depth_cm:"Sets the depth of the simplified soil compartment.",
 volumetric_water_fraction:"Sets the water-filled volume fraction of the soil compartment.",
 bulk_density_kg_l:"Sets soil mass per bulk volume for sorption arithmetic.",
 koc_l_kg:"Sets organic-carbon-normalized sorption strength.",
 organic_carbon_fraction:"Sets the soil organic-carbon mass fraction.",
 drainage_mm_day:"Sets water drainage used for the leaching screen.",
 runoff_mm_day:"Sets water runoff used in the environmental screen.",
 degradation_half_life_days:"Sets the assumed time for half of the active to degrade.",
 receiving_water_m3_ha:"Sets receiving-water volume for the modeled runoff concentration.",
 base_model:"Selects the physical model to analyze; its fields and output units determine the controls below.",
 base_inputs:"Sets baseline or fixed physical conditions; searched parameters override their baseline values.",
 parameters:"Declares uncertain parameters or sensitivity ranges; use evidence-based ranges or label them as assumptions.",
 correlation:"Sets assumed correlations between uncertain inputs; leave the default for independence.",
 metric:"Selects the calculated output to assess, in that output's units.",
 minimum:"Sets the lowest acceptable OUTPUT; use a product requirement or benchmark, not the parameter's software limit. Blank means no lower requirement.",
 maximum:"Sets the highest acceptable OUTPUT; use a product requirement or equipment limit. Blank means no upper requirement.",
 samples:"Sets the number of uncertainty scenarios evaluated.",
 seed:"Makes randomized sampling repeatable; use the same whole number to repeat a search.",
 geometry:"Selects the ideal particle shape used in diffusion.",
 diffusivity_m2_s:"Sets effective diffusivity; release alone cannot independently identify both diffusivity and particle length.",
 length_um:"Sets sphere/cylinder radius or slab half-thickness, not diameter or full thickness.",
 bath_ratio:"Sets bath volume divided by particle-domain volume for finite-bath release.",
 swelling_rate:"Controls the assumed increase in particle length over time.",
 swelling_exponent:"Controls the time dependence of the assumed swelling.",
 variables:"Selects physical parameters and justified lower/upper search bounds; these are not ingredient percentages.",
 objectives:"Defines which model outputs to minimize, maximize or move toward a target.",
 constraints:"Defines required output limits from your product brief or equipment needs; these are not automatically known for a recipe.",
 evaluations:"Sets the main physics-evaluation budget; shortlisted points are checked again.",
 points:"Sets numerical grid density: time points for kinetics, or sweep points per sensitivity range with the baseline included. It does not create observations.",
 product_concentrations_g_l:"Lists dry product mass per final water volume for individual-active mass balance."
};
const escape=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const note=text=>"<small class='field-help'>"+escape(text)+"</small>";
function range(f){
 if(f.min===undefined&&f.max===undefined)return "";
 return "Allowed "+(f.type==="array"?"per value":"input")+": minimum "+f.min+", maximum "+f.max+(f.unit?" "+f.unit:"")+". Software limits, not recommended product values.";
}
function field(f){return note(descriptions[f.key]||("Sets "+f.label.toLowerCase()+" for this model."))+((f.min!==undefined||f.max!==undefined)?note(range(f)):"")+(f.type==="array"?note("Enter comma-separated numbers."):"");}
const units={pressure_bar:"bar",viscosity_at_100_s_pa_s:"Pa·s",product_kg_ha:"kg/ha",maximum_downwind_m:"m",drying_time_s:"s",footprint_area_mm2:"mm²",final_size_um:"µm",final_temperature_c:"°C",energy_kwh_kg:"kWh/kg",final_moisture_g:"g",final_solvent_g:"g",final_length_um:"µm",maximum_active_mg_l:"mg/L",final_cv:"coefficient of variation",caco3_saturation_ratio:"dimensionless ratio"};
function metricText(metric,base){
 if(metric.startsWith("input:")){const f=base.fields.find(f=>f.key===metric.slice(6));return f?"Input property in "+(f.unit||"dimensionless units")+". "+range(f):"Use the selected input property's units.";}
 if(metric.includes("fraction")||metric==="release_at_horizon"||metric==="available_at_horizon"||metric==="retention_at_first_temperature"||metric==="final_water_activity")return "Output fraction: 0–1; 0.9 means 90%."+(metric==="retention_at_first_temperature"?" Evaluates the FIRST listed constant storage temperature.":"");
 return "Output unit: "+(units[metric]||base.metric_unit||"selected metric units")+".";
}
function criterion(key,metric,base){
 const text={metric:"Choose the calculated output to compare.",minimum:descriptions.minimum,maximum:descriptions.maximum,goal:"Specifications only checks bounds. Minimize/maximize compares outputs; approach target compares distance to the target.",target:"Enter your desired output only for an Approach target objective; it is not a minimum or maximum requirement.",scale:"Normalizes the objective; start with 1. Minimum 1e-12, maximum 1e12. It is not an acceptance limit or importance weight."};
 return note(text[key])+(new Set(["metric","minimum","maximum","target"]).has(key)?note(metricText(metric,base)):"");
}
function searchBound(f,side){return note((side==="low"?"Lowest":"Highest")+" physical-property value to explore. Choose from measurements, supplier data, relevant literature or an explicit assumed range.")+note(range(f))+note("Lower must be less than upper; logarithmic bounds must both be positive.");}
return {field,note,range,criterion,searchBound,metricText,descriptions};
})();
window.FormulationLab=(()=>{
let u,models=[],kinds={},formatTypes=[],editingRecipe=null,recipeSource=null,editorSession=null,currentDataset=null,selectedFit=null,importPreview=null;
const pending=new Map(),uncertain=[];let lastRecipeBasis="pct";
const el=id=>document.getElementById(id);
const option=(value,text,selected=false)=>"<option value='"+u.esc(value)+"'"+(selected?" selected":"")+">"+u.esc(text)+"</option>";
const button=(label,attribute,value="",primary=false)=>"<button type='button' class='button"+(primary?" primary":"")+"' "+attribute+"='"+u.esc(value)+"'>"+u.esc(label)+"</button>";
const model=key=>models.find(m=>m.key===key);
const recipes=()=>u.latestArtifacts("recipe");
const payload=async id=>(await u.artifact(id)).payload;
function problem(error,dialog){u.notify(error);if(dialog){let note=dialog.querySelector(".lab-form-error");if(!note){note=document.createElement("p");note.className="notice lab-form-error";note.setAttribute("role","alert");dialog.querySelector("form").prepend(note);}note.hidden=false;note.textContent=error.message||String(error);note.scrollIntoView({block:"nearest"});}}
const protect=fn=>async event=>{try{await fn(event);}catch(error){problem(error,event?.target?.closest("dialog"));}};
async function fileData(file){if(!file||file.size>4000000)throw new Error("Choose a CSV or XLSX file up to 4 MB.");const bytes=new Uint8Array(await file.arrayBuffer());let text="";for(let i=0;i<bytes.length;i+=16384)text+=String.fromCharCode(...bytes.subarray(i,i+16384));return {filename:file.name,content_base64:btoa(text)};}
function clearErrors(dialog){dialog.querySelectorAll(".lab-form-error").forEach(e=>e.hidden=true);}
function sameSession(){if(editorSession!==u.app.session)throw new Error("This editor belongs to another project. Reopen it in the selected project.");}
function groupPlots(series){const groups=new Map();for(const s of series||[]){const key=s.x_label+"|"+s.y_label;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(s);}return [...groups.values()].map(group=>"<div class='lab-plot'>"+u.plot(group,group[0].x_label,group[0].y_label)+"</div>").join("");}
function metrics(values,labels={}){return "<div class='lab-metrics'>"+Object.entries(values||{}).map(([key,value])=>"<div class='metric'><b>"+u.esc(u.fmt(value))+"</b><span>"+u.esc(labels[key]||key.replaceAll("_"," "))+"</span></div>").join("")+"</div>";}
function empty(title,text,action){return "<div class='lab-empty'><h3>"+u.esc(title)+"</h3><p>"+u.esc(text)+"</p>"+action+"</div>";}
function kindsOptions(){el("measurementKind").innerHTML=Object.entries(kinds).map(([key,k])=>option(key,k.title)).join("");}
async function init(context){
 u=context;
 const catalogue=await u.json("/api/studio/catalogue");models=catalogue.simulations;kinds=catalogue.dataset_types;kindsOptions();
 formatTypes=catalogue.formulation_types||[];
 if(formatTypes.length)el("recipeFormat").innerHTML=formatTypes.map(f=>option(f.code,f.code+(f.aliases?.length?" / "+f.aliases.join(" / "):"")+" · "+f.name)).join("");
 el("recipeFormat").onchange=recipeFormatGuide;
 el("formulationTypesGuide").innerHTML=u.table(formatTypes.map(f=>({Code:f.code,Type:f.group,"Physical form":f.physical_form,"Water preparation":f.requires_tank_mixing===null?"Product-specific":f.requires_tank_mixing?"Dilute / disperse":"Direct dry application","Potential advantage":f.market_advantage,Conditions:f.design_caution})));
 el("labAddRecipe").onclick=protect(()=>openRecipe());
 el("labAddData").onclick=protect(openDataUpload);
 el("labNewSimulation").onclick=protect(()=>openSimulation());
 el("labOptimize").onclick=protect(()=>openSimulation("inverse_design"));
 el("addIngredient").onclick=()=>addIngredient();
 el("recipeForm").onsubmit=protect(saveRecipe);
 el("recipeIngredientRows").addEventListener("input",recipeBalance);
 el("recipeIngredientRows").addEventListener("change",recipeBalance);
 ["recipeBatch","recipeMode","recipeCount"].forEach(id=>el(id).addEventListener("input",recipeBalance));
 el("recipeBasis").onchange=()=>{const next=el("recipeBasis").value;if(next!==lastRecipeBasis){const factor=next==="grams"?Number(el("recipeBatch").value)/100:100/Number(el("recipeBatch").value);if(Number.isFinite(factor)&&factor>0)el("recipeIngredientRows").querySelectorAll("[data-recipe-field=pct]").forEach(input=>{if(input.value!=="")input.value=Number(input.value)*factor;});lastRecipeBasis=next;}recipeBalance();};
 el("recipeFile").onchange=protect(async()=>{const file=await fileData(el("recipeFile").files[0]);const preview=await u.post("/api/studio/recipe-preview",{file});recipeSource=file;el("recipeIngredientRows").innerHTML="";preview.ingredients.forEach(addIngredient);el("recipeSource").textContent=preview.source.filename+" · "+preview.source.sha256.slice(0,12);recipeBalance();});
 el("recipeTemplate").onclick=()=>u.download("recipe-ingredients.csv","name,role,pct,purity_pct,min_pct,max_pct,cost_per_kg,supplier,lot\nActive grade,active,10,95,10,10,,,\nVehicle,solvent,90,100,85,95,,,\n","text/csv");
 el("simulationModel").innerHTML=models.map(m=>option(m.key,m.title)).join("");
 el("simulationModel").onchange=protect(()=>configureModel());
 el("simulationRecipe").onchange=protect(async()=>{await simulationActives();await simulationFits();});
 el("simulationActive").onchange=protect(async()=>{await simulationActives(true);await simulationFits();});
 el("simulationFit").onchange=protect(applyFit);
 el("simulationFields").addEventListener("input",()=>{if(model(el("simulationModel").value)?.key==="robustness")return;if(selectedFit){const edited=Object.entries(selectedFit.parameters).some(([k,v])=>{const field=el("simulationFields").querySelector("[data-sim-key='"+CSS.escape(k)+"']");if(!field)return false;try{return JSON.stringify(readField(field))!==JSON.stringify(v);}catch{return true;}});el("simulationSourceBadge").textContent=edited?"Edited fit parameters · assumed scenario":(selectedFit.source_kind||"Unknown")+" fit parameters with explicit scenario settings";el("simulationSourceBadge").classList.toggle("measured",!edited&&selectedFit.source_kind==="experimental");}});
 el("simulationForm").onsubmit=protect(async e=>{e.preventDefault();const requests=await requestsFromForm();await submitSimulations(requests);});
 el("addSimulationBatch").onclick=protect(async()=>{if(!el("simulationForm").reportValidity())return;const list=pending.get(u.app.session)||[];list.push(...await requestsFromForm());if(list.length>50)throw new Error("Use at most 50 scenarios in one batch.");pending.set(u.app.session,list);renderPending();});
 el("runSimulationBatch").onclick=protect(()=>submitSimulations(pending.get(u.app.session)||[]));
 el("clearSimulationBatch").onclick=()=>{pending.delete(u.app.session);renderPending();};
 el("addUncertainty").onclick=()=>{uncertain.push({parameter:"",distribution:"uniform",low:0,high:1});renderUncertainty();};
 el("measurementKind").onchange=measurementKind;
 el("uploadForm").onsubmit=async event=>{try{await importMeasurements(event);}catch(error){el("importError").textContent=error.message;el("importError").hidden=false;}};
 el("measurementFile").onchange=protect(()=>previewUpload());
 el("mappingFields").addEventListener("change",()=>{el("timeMappingConfirmed").checked=false;syncImportTime(true);});
 ["measurementTime","measurementXUnit"].forEach(id=>el(id).addEventListener("change",()=>{el("timeMappingConfirmed").checked=false;syncImportTime();}));
 el("measurementActive").addEventListener("change",uploadSecond);
 el("datasetReviewForm").onsubmit=protect(saveReview);
 el("downloadDatasetSource").onclick=()=>{const source=currentDataset.source;u.download(source.filename,Uint8Array.from(atob(source.content_base64),c=>c.charCodeAt(0)),"application/octet-stream");};
 el("downloadDatasetCsv").onclick=()=>u.download(currentDataset.dataset_id+".csv",csvRows(currentDataset.observations),"text/csv");
 el("fitReviewedDataset").onclick=protect(async()=>{await queueFit(currentDataset.dataset_id);el("datasetDialog").close();});
 document.addEventListener("click",protect(click));
}
function csvRows(rows){if(!rows?.length)return "";const keys=[...new Set(rows.flatMap(Object.keys))];const quote=value=>'"'+String(value??"").replace(/^([=+@-])/,"'$1").replaceAll('"','""')+'"';return [keys.map(quote).join(","),...rows.map(r=>keys.map(k=>quote(r[k])).join(","))].join("\n");}
function addIngredient(item={}){
 const tr=document.createElement("tr"),roles=["active","carrier","matrix","solvent","surfactant","dispersant","binder","filler","coating","stabilizer","other"];
 const cell=(key,value,type="text",attrs="")=>"<input data-recipe-field='"+key+"' type='"+type+"' value='"+u.esc(value??"")+"' "+attrs+">";
 tr.innerHTML="<td>"+cell("name",item.name,"text","required maxlength='200' placeholder='Ingredient and grade'")+"<small>Unverified grade · availability unconfirmed</small><span data-recipe-error class='notice' role='alert'></span></td><td><select data-recipe-field='role'>"+roles.map(r=>option(r,r,r===(item.role||"other"))).join("")+"</select></td><td>"+cell("pct",item.pct,"number","min='0' step='any'")+"</td><td>"+cell("purity_pct",item.purity_pct??100,"number","required min='.001' max='100' step='any'")+"</td><td class='recipe-range'>"+cell("min_pct",item.min_pct,"number","min='0' max='100' step='any' placeholder='= reference'")+"</td><td class='recipe-range'>"+cell("max_pct",item.max_pct,"number","min='0' max='100' step='any' placeholder='= reference'")+"</td><td>"+cell("cost_per_kg",item.cost_per_kg,"number","min='0' step='any' placeholder='Optional'")+"</td><td>"+cell("supplier",item.supplier,"text","placeholder='Supplier' maxlength='200'")+cell("lot",item.lot,"text","placeholder='Lot' maxlength='200'")+"</td><td><button type='button' class='icon-button' data-lab-remove-ingredient aria-label='Remove ingredient'>×</button></td>";
 el("recipeIngredientRows").append(tr);recipeBalance();
}
function recipeRows(){
 const factor=el("recipeBasis").value==="grams"?100/Number(el("recipeBatch").value):1;
 return [...el("recipeIngredientRows").rows].map(tr=>{const row={};for(const input of tr.querySelectorAll("[data-recipe-field]")){const key=input.dataset.recipeField;row[key]=input.type==="number"?(input.value===""?null:Number(input.value)):input.value.trim();}if(row.pct!==null)row.pct*=factor;const original=editingRecipe?.ingredients.find(i=>i.name===row.name);if(original?.grade_source)row.grade_source=original.grade_source;if(original?.price_estimate&&row.cost_per_kg===null)row.price_estimate=structuredClone(original.price_estimate);return row;});
}
function recipeFormatGuide(){const f=formatTypes.find(f=>f.code===el("recipeFormat").value);el("recipeFormatGuide").textContent=f?f.physical_form+" · "+f.application_preparation+". "+f.market_advantage+" "+f.design_caution:"";}
function validateRecipe(rows,batch,range){
 const errors=rows.map(()=>[]);let total=0,active=0,lower=0,upper=0;
 rows.forEach((r,i)=>{
  const error=message=>errors[i].push(message),finite=v=>typeof v==="number"&&Number.isFinite(v);
  if(!r.name)error("Enter an ingredient and supplied grade.");
  if(!finite(r.purity_pct)||r.purity_pct<=0||r.purity_pct>100)error("Purity / assay must be greater than zero and at most 100%.");
  if(r.pct===null){if(!range||r.role==="active")error(range?"Enter the technical-active target amount to define loading.":"Enter an amount.");}
  else if(!finite(r.pct)||r.pct<0||r.pct>100)error("Amount must represent 0–100% of the batch.");
  const lo=r.min_pct??r.pct,hi=r.max_pct??r.pct;
  if(range){
   if(!finite(lo)||!finite(hi)||lo<0||hi>100)error("Supply bounds between 0 and 100%, or a reference amount.");
   else if(lo>hi)error("Ingredient minimum exceeds maximum.");
   else if(r.pct!==null&&(r.pct<lo-1e-8||r.pct>hi+1e-8))error("Reference amount must be within its bounds.");
  }
  if(r.cost_per_kg!==null&&r.cost_per_kg!==undefined&&(!finite(r.cost_per_kg)||r.cost_per_kg<0))error("Price must be nonnegative or unknown.");
  if(!errors[i].length){total+=r.pct??0;if(r.role==="active")active+=r.pct*r.purity_pct/100;lower+=r.role==="active"?r.pct:lo;upper+=r.role==="active"?r.pct:hi;}
 });
 const rowValid=errors.every(e=>!e.length),valid=rowValid&&Number.isFinite(batch)&&batch>0&&rows.length>=2&&rows.some(r=>r.role==="active")&&active>0&&(range?lower<=100+1e-7&&upper>=100-1e-7:Math.abs(total-100)<1e-7);
 return {errors,valid,rowValid,total:rowValid?total:null,active:rowValid?active:null,lower:rowValid?lower:null,upper:rowValid?upper:null};
}
function recipeBalance(){
 const range=el("recipeMode").value==="ranges",gram=el("recipeBasis").value==="grams";
 document.querySelectorAll(".recipe-range").forEach(e=>e.hidden=!range);el("recipeCountLabel").hidden=!range;
 el("recipeAmountHeading").textContent=(range?"Reference / active target ":"Amount ")+(gram?"(g)":"(%)");el("recipeRangeHelp").hidden=!range;
 const rows=recipeRows(),check=validateRecipe(rows,Number(el("recipeBatch").value),range),{total,active,lower,upper}=check;
 let valid=check.valid;
 if(range&&(!Number.isInteger(Number(el("recipeCount").value))||Number(el("recipeCount").value)<1||Number(el("recipeCount").value)>12))valid=false;
 [...el("recipeIngredientRows").rows].forEach((tr,i)=>{const note=tr.querySelector("[data-recipe-error]");note.textContent=check.errors[i].join(" ");note.hidden=!check.errors[i].length;tr.querySelectorAll("[data-recipe-field]").forEach(input=>{if(input.dataset.recipeField==="pct")input.required=!range||rows[i].role==="active";});});
 el("recipeBalance").textContent=check.rowValid?(range?"Effective bounds: "+u.fmt(lower)+"–"+u.fmt(upper)+"%":"Total: "+u.fmt(total)+"%")+" · Pure active: "+u.fmt(active)+"%":"Fix ingredient inputs before calculating composition totals.";
 el("recipeBalance").classList.toggle("invalid",!valid);
 el("saveRecipe").disabled=!valid||rows.length<2;
}
async function openRecipe(existing){
 editorSession=u.app.session;editingRecipe=existing||null;recipeSource=null;
 clearErrors(el("recipeDialog"));el("recipeEditorTitle").textContent=existing?"Edit as a new recipe version":"Add your recipe";
 el("recipeName").value=existing?.name||"";el("recipeFormat").value=existing?.format||"SC";el("recipeBatch").value=existing?.batch_g||1000;
 el("recipeBasis").value="pct";lastRecipeBasis="pct";el("recipeMode").value="fixed";el("recipeCostLimit").value="";el("recipeCurrency").value=existing?.currency||"INR";
 el("recipeSource").textContent="";el("recipeFile").value="";
 el("recipeProcess").value=(existing?.process||[]).map(s=>s.instruction).join("\n");el("recipeCrop").value=u.app.view?.project.brief.crop||"";el("recipeTarget").value=u.app.view?.project.brief.target||"";
 el("recipeIngredientRows").innerHTML="";
 if(existing)existing.ingredients.forEach(addIngredient);else{addIngredient({role:"active"});addIngredient({role:"solvent"});}
 recipeFormatGuide();recipeBalance();el("recipeDialog").showModal();
}
async function saveRecipe(e){
 e.preventDefault();sameSession();recipeBalance();if(el("saveRecipe").disabled)throw new Error("Correct the ingredient fields, active target and mass-balance bounds before saving.");const button=el("saveRecipe");button.disabled=true;
 try{
  const recipe={name:el("recipeName").value.trim(),format:el("recipeFormat").value,batch_g:Number(el("recipeBatch").value),mode:el("recipeMode").value,count:Number(el("recipeCount").value),ingredients:recipeRows(),process:el("recipeProcess").value,crop:el("recipeCrop").value,target:el("recipeTarget").value,currency:el("recipeCurrency").value,cost_limit:el("recipeCostLimit").value||null};
  if(recipeSource)recipe.source=recipeSource;
  await u.post("/api/studio/recipe",{session_id:editorSession,recipe,expected_revision:u.app.view.project.revision});
  el("recipeDialog").close();await u.refresh(true);await u.viewPanel("recipe");
 }finally{recipeBalance();}
}
function fieldMarkup(f,value=f.default){
 const common=" data-sim-key='"+u.esc(f.key)+"' data-sim-type='"+f.type+"'";
 let input;
 if(f.type==="select")input="<select"+common+">"+f.options.map(v=>option(v,v,v===value)).join("")+"</select>";
 else if(f.type==="json")input="<textarea"+common+">"+u.esc(JSON.stringify(value,null,2))+"</textarea>";
 else input="<input"+common+" type='"+(f.type==="number"?"number":"text")+"' value='"+u.esc(f.type==="array"?value.join(", "):value??"")+"'"+(f.type==="number"?" min='"+f.min+"' max='"+f.max+"' step='any'":"")+(f.optional?"":" required")+">";
 return "<label class='"+(f.type==="json"?"json-field full-width":"")+"'>"+u.esc(f.label)+(f.unit?" <small>"+u.esc(f.unit)+"</small>":"")+input+window.FormulationInputHelp.field(f)+"</label>";
}
function readField(input){
 if(input.dataset.simType==="number"){if(input.value===""&&model(el("simulationModel").value).fields.find(f=>f.key===input.dataset.simKey)?.optional)return null;const value=Number(input.value);if(!Number.isFinite(value)||input.value==="")throw new Error("Enter a finite value for "+input.dataset.simKey);return value;}
 if(input.dataset.simType==="array"){const values=input.value.split(/[,\s]+/).filter(Boolean).map(Number);if(!values.length||values.some(v=>!Number.isFinite(v)))throw new Error("Enter numeric values for "+input.dataset.simKey);return values;}
 if(input.dataset.simType==="json"){try{return JSON.parse(input.value);}catch{throw new Error("Check the structured JSON in "+input.dataset.simKey);}}
 return input.value.trim();
}
async function simulationActives(preserve=false){
 const r=await payload(el("simulationRecipe").value),selected=preserve?el("simulationActive").value:null;
 el("simulationActive").innerHTML=r.active_components.map(a=>option(a.name,a.name,a.name===selected)).join("");
 el("simulationSecond").innerHTML=r.active_components.filter(a=>a.name!==el("simulationActive").value).map(a=>option(a.name,a.name)).join("");
 if(el("simulationModel").value==="mixture_response"&&!el("simulationSecond").options.length)el("simulationSecond").innerHTML=option("","Recipe needs two distinct actives");
}
async function simulationFits(){
 const r=await payload(el("simulationRecipe").value),key=el("simulationModel").value,active=el("simulationActive").value;
 const fits=u.latestArtifacts("fit").filter(a=>a.recipe_id===r.recipe_id&&a.active_name===active&&a.metadata.simulation_key===key);
 el("simulationFit").innerHTML=option("","Editable assumed scenario")+fits.map(a=>option(a.artifact_id,a.title+" · "+a.metadata.fit_id.slice(0,10))).join("");
 const datasets=(await u.json("/api/studio/datasets?session_id="+encodeURIComponent(u.app.session))).datasets;
 el("simulationComparison").innerHTML=option("","Reference surface only")+datasets.filter(d=>d.kind==="mixture_response"&&d.recipe_id===r.recipe_id&&d.active_name===active).map(d=>option(d.dataset_id,d.filename)).join("");
}
async function configureModel(values){
 selectedFit=null;const m=model(el("simulationModel").value);
 el("simulationDescription").textContent=m.description;el("simulationEquation").textContent=m.equation;
 el("simulationLimits").innerHTML=m.limits.map(l=>"<li>"+u.esc(l)+"</li>").join("");
 el("simulationSourceBadge").textContent="Example inputs · editable unvalidated assumptions";el("simulationSourceBadge").classList.remove("measured");
 el("simulationFields").innerHTML=m.fields.filter(f=>m.key!=="robustness"||f.key!=="parameters").map(f=>fieldMarkup(f,values&&values[f.key]!==undefined?values[f.key]:f.default)).join("");
 el("simulationSecondLabel").hidden=m.key!=="mixture_response";el("simulationComparisonLabel").hidden=m.key!=="mixture_response";el("simulationAllActivesLabel").hidden=m.key==="mixture_response";
 el("robustnessEditor").hidden=m.key!=="robustness";
 if(m.key==="robustness"){
  const baseInput=el("simulationFields").querySelector("[data-sim-key=base_model]"),selection=document.createElement("select");
  selection.dataset.simKey="base_model";selection.dataset.simType="select";selection.innerHTML=models.filter(v=>!["robustness","inverse_design","sensitivity"].includes(v.key)).map(v=>option(v.key,v.title,v.key===(values?.base_model||"rainfastness"))).join("");baseInput.replaceWith(selection);
  selection.onchange=()=>{const base=model(selection.value);el("simulationFields").querySelector("[data-sim-key=metric]").value=base.metric;const target=el("simulationFields").querySelector("[data-sim-key=base_inputs]");target.value=JSON.stringify(Object.fromEntries(base.fields.map(f=>[f.key,f.default])),null,2);uncertain.length=0;const first=base.fields.find(f=>f.type==="number"&&f.default!==null&&f.default>0);if(first)uncertain.push({parameter:first.key,distribution:"uniform",low:first.default*.8,high:Math.min(first.max,first.default*1.2)});renderUncertainty();};
  uncertain.length=0;uncertain.push(...JSON.parse(JSON.stringify(values?.parameters||m.fields.find(f=>f.key==="parameters").default)));renderUncertainty();
  renderRobustnessBase(selection.value,values?.base_inputs||{});
  const oldChange=selection.onchange;selection.onchange=()=>{oldChange();renderRobustnessBase(selection.value,{});};
 }
 if(m.key==="inverse_design")configureDesign(values);
 if(m.key==="sensitivity")configureSensitivity(values);
 await simulationFits();
}
function configureDesign(values){
 const source=el("simulationFields").querySelector("[data-sim-key=base_model]"),selection=document.createElement("select");
 selection.dataset.simKey="base_model";selection.dataset.simType="select";
 selection.innerHTML=models.filter(v=>!["robustness","inverse_design","sensitivity","mixture_response"].includes(v.key)).map(v=>option(v.key,v.title,v.key===(values?.base_model||"rheology"))).join("");source.replaceWith(selection);
 const defaults=Object.fromEntries(model("inverse_design").fields.map(f=>[f.key,f.default]));
 renderDesign(values||defaults);
 selection.onchange=()=>{const base=model(selection.value),f=base.fields.find(f=>f.type==="number"&&f.default!==null&&f.default>0);if(!f)return;const low=Math.max(f.min,f.default*.5),high=Math.min(f.max,f.default*1.5);renderDesign({base_model:base.key,base_inputs:{},variables:[{parameter:f.key,low,high}],objectives:[{metric:base.metric,goal:"minimize",scale:1}],constraints:[]});};
}
function designMetricLabel(key,base){
 if(key.startsWith("input:")){const f=base.fields.find(f=>f.key===key.slice(6));return f?f.label+(f.unit?" ("+f.unit+")":""):key.slice(6).replaceAll("_"," ");}
 if(key==="maximum_precipitated_fraction"&&base.key==="dilution")return "Aqueous-only excess fraction (hypothetical)";
 const labels={pressure_bar:"Pumping pressure (bar)",viscosity_at_100_s_pa_s:"Viscosity at 100 s⁻¹ (Pa·s)",release_at_horizon:"Released fraction at horizon (0–1)",available_at_horizon:"Available fraction at horizon (0–1)",retention_at_first_temperature:"Chemical retention at first temperature (0–1)",product_kg_ha:"Product quantity (kg/ha)",available_fraction:"Available fraction (0–1)",separated_fraction:"Separated fraction (0–1)",maximum_precipitated_fraction:"Maximum precipitated fraction (0–1)",caco3_saturation_ratio:"Calcium carbonate saturation ratio",maximum_downwind_m:"Maximum downwind displacement (m)",initial_coverage_fraction:"Initial covered fraction (0–1)",drying_time_s:"Drying time (s)",footprint_area_mm2:"Droplet footprint (mm²)",retained_fraction:"Retained deposit fraction (0–1)",bound_fraction_before_rain:"Bound fraction before rain (0–1)",final_size_um:"Final particle size (µm)",final_temperature_c:"Final temperature (°C)",final_cv:"Final mixing coefficient of variation",energy_kwh_kg:"Specific energy (kWh/kg)",final_moisture_g:"Final moisture (g)",final_solvent_g:"Final solvent (g)",final_water_activity:"Final water activity",leached_fraction:"Leached fraction (0–1)",final_length_um:"Final radius or half-thickness (µm)"};
 return labels[key]||key.replaceAll("_"," ");
}
function sensitivityRange(field,inputs){
 const baseline=Number(inputs[field.key]??field.default??field.min);
 return {parameter:field.key,low:Math.max(field.min,baseline-Math.max(Math.abs(baseline)*.5,.1)),high:Math.min(field.max,baseline+Math.max(Math.abs(baseline)*.5,.1)),scale:"linear"};
}
function configureSensitivity(values){
 const source=el("simulationFields").querySelector("[data-sim-key=base_model]"),selection=document.createElement("select");
 selection.dataset.simKey="base_model";selection.dataset.simType="select";
 selection.innerHTML=models.filter(v=>!["robustness","inverse_design","sensitivity","mixture_response"].includes(v.key)).map(v=>option(v.key,v.title,v.key===(values?.base_model||"rheology"))).join("");source.replaceWith(selection);
 const metric=el("simulationFields").querySelector("[data-sim-key=metric]"),metricSelect=document.createElement("select");metricSelect.dataset.simKey="metric";metricSelect.dataset.simType="select";metric.replaceWith(metricSelect);
 const render=(value)=>{const base=model(selection.value);metricSelect.innerHTML=[...new Set([...(base.output_metrics||[base.metric]),value.metric].filter(Boolean))].map(k=>option(k,designMetricLabel(k,base),k===(value.metric||base.metric))).join("");renderSensitivity(value);};
 render(values||Object.fromEntries(model("sensitivity").fields.map(f=>[f.key,f.default])));
 selection.onchange=()=>{const base=model(selection.value),field=base.fields.find(f=>f.type==="number"&&f.default!==null&&f.default>0);render({base_inputs:{},parameters:[sensitivityRange(field,{})],metric:base.metric});};
}
function sensitivityValues(){
 const base=model(el("simulationFields").querySelector("[data-sim-key=base_model]").value),base_inputs={};
 for(const field of el("robustnessBaseFields").querySelectorAll("[data-base-key]")){const definition=base.fields.find(f=>f.key===field.dataset.baseKey);base_inputs[field.dataset.baseKey]=field.value===""&&definition.optional?null:readField(field);}
 const parameters=[...el("sensitivityControls").querySelectorAll("[data-sensitivity-row]")].map(row=>Object.fromEntries([...row.querySelectorAll("[data-sensitivity-field]")].map(field=>[field.dataset.sensitivityField,field.type==="number"?Number(field.value):field.value])));
 return {base_inputs,parameters};
}
function renderSensitivity(values){
 const base=model(el("simulationFields").querySelector("[data-sim-key=base_model]").value),fields=base.fields.filter(f=>f.type==="number");
 renderRobustnessBase(base.key,values.base_inputs||{});el("simulationFields").querySelector("[data-sim-key=parameters]").closest("label").hidden=true;
 let editor=el("sensitivityControls");if(!editor){editor=document.createElement("div");editor.id="sensitivityControls";editor.className="full-width design-controls";el("simulationFields").append(editor);}
 editor.innerHTML="<h3>Assumed parameter ranges</h3><p class='scenario-note'>Each sweep holds the other inputs at baseline. Include the baseline within each range. Ranks depend on these ranges and exclude interactions.</p>"+(values.parameters||[]).map((v,i)=>"<div class='design-row' data-sensitivity-row='"+i+"'><label>Parameter<select data-sensitivity-field='parameter'>"+fields.map(f=>option(f.key,f.label+(f.unit?" ("+f.unit+")":""),f.key===v.parameter)).join("")+"</select></label><label>Lower<input data-sensitivity-field='low' type='number' step='any' required value='"+u.esc(v.low)+"'></label><label>Upper<input data-sensitivity-field='high' type='number' step='any' required value='"+u.esc(v.high)+"'></label><label>Scale<select data-sensitivity-field='scale'>"+["linear","log"].map(s=>option(s,s,s===(v.scale||"linear"))).join("")+"</select></label>"+button("Remove","data-sensitivity-remove",String(i))+"</div>").join("")+button("+ Parameter range","data-sensitivity-add");
 editor.onclick=protect(e=>{const b=e.target.closest("button");if(!b)return;const current=sensitivityValues();if(b.hasAttribute("data-sensitivity-add")){if(current.parameters.length>=6){u.notify("Choose at most 6 parameters.");return;}const field=fields.find(f=>!current.parameters.some(v=>v.parameter===f.key)&&current.base_inputs[f.key]!==null);if(!field)return;current.parameters.push(sensitivityRange(field,current.base_inputs));}else if(b.dataset.sensitivityRemove!==undefined)current.parameters.splice(Number(b.dataset.sensitivityRemove),1);else return;renderSensitivity(current);});
 editor.onchange=protect(e=>{if(e.target.dataset.sensitivityField!=="parameter")return;const current=sensitivityValues(),index=Number(e.target.closest("[data-sensitivity-row]").dataset.sensitivityRow),field=fields.find(f=>f.key===e.target.value);current.parameters[index]=sensitivityRange(field,current.base_inputs);renderSensitivity(current);});
}
function renderDesign(values){
 const base=model(el("simulationFields").querySelector("[data-sim-key=base_model]").value);
 renderRobustnessBase(base.key,values.base_inputs||{});
 for(const key of ["variables","objectives","constraints"])el("simulationFields").querySelector("[data-sim-key="+key+"]").closest("label").hidden=true;
 let editor=el("designControls");if(!editor){editor=document.createElement("div");editor.id="designControls";editor.className="full-width design-controls";el("simulationFields").append(editor);}
 const help=window.FormulationInputHelp,fields=base.fields.filter(f=>f.type==="number");
 const input=(key,value,required=true,bounds=null)=>"<input data-design-field='"+key+"' type='number' step='any' value='"+u.esc(value??"")+"'"+(required?" required":"")+(bounds?" min='"+bounds.min+"' max='"+bounds.max+"'":"")+">";
 const remove=(kind,i)=>button("Remove","data-design-remove",kind+":"+i);
 const metricOptions=value=>[...new Set([...(base.output_metrics||[base.metric]),...(values.variables||[]).map(v=>"input:"+v.parameter),value].filter(Boolean))].map(k=>option(k,designMetricLabel(k,base),k===value)).join("");
 const metricHelp=metric=>help.note(help.metricText(metric,base));
 editor.innerHTML="<p class='scenario-note'>Search model parameters within declared bounds. Objectives and specifications use the model’s output units. This does not infer ingredient performance.</p><h3>Search bounds</h3><div class='design-rows'>"+(values.variables||[]).map((v,i)=>{
  const f=fields.find(f=>f.key===v.parameter)||fields[0];
  return "<div class='design-row' data-design-kind='variables'><label>Parameter<select data-design-field='parameter'>"+fields.map(f=>option(f.key,f.label+(f.unit?" ("+f.unit+")":""),f.key===v.parameter)).join("")+"</select>"+help.field(f)+"</label><label>Lower"+input("low",v.low,true,f)+help.searchBound(f,"low")+"</label><label>Upper"+input("high",v.high,true,f)+help.searchBound(f,"high")+"</label><label>Scale<select data-design-field='scale'>"+["linear","log"].map(s=>option(s,s,s===(v.scale||"linear"))).join("")+"</select>"+help.note("Linear spaces values evenly; log explores ratios. Log bounds must both be above zero.")+"</label>"+remove("variables",i)+"</div>";
 }).join("")+"</div>"+button("+ Search parameter","data-design-add","variables")+
 "<h3>Objectives</h3>"+(values.objectives||[]).map((o,i)=>"<div class='design-row' data-design-kind='objectives'><label>Metric<select data-design-field='metric'>"+metricOptions(o.metric)+"</select>"+help.note("Select the output to improve.")+metricHelp(o.metric)+"</label><label>Goal<select data-design-field='goal'>"+["minimize","maximize","target"].map(g=>option(g,g,g===o.goal)).join("")+"</select>"+help.note("Choose smaller, larger, or closest to a target. This preference does not set pass/fail limits.")+"</label><label>Target"+input("target",o.target,false)+help.note("Used only for a target goal. Enter the desired output from your design brief.")+metricHelp(o.metric)+"</label><label>Scale"+input("scale",o.scale??1,true,{min:1e-20,max:1e20})+help.note("Normalizes the output before scoring; start with 1. Allowed minimum 1e-20, maximum 1e20.")+"</label><label>Weight"+input("weight",o.weight??1,true,{min:1e-6,max:1e6})+help.note("Sets relative priority in search scoring; start with 1. Allowed minimum 1e-6, maximum 1e6. It does not set acceptance limits.")+"</label>"+remove("objectives",i)+"</div>").join("")+button("+ Objective","data-design-add","objectives")+
 "<h3>Required specifications</h3><p class='muted'>Use your product requirements or equipment limits. Leave either bound empty for a one-sided specification.</p>"+(values.constraints||[]).map((c,i)=>"<div class='design-row' data-design-kind='constraints'><label>Metric<select data-design-field='metric'>"+metricOptions(c.metric)+"</select>"+help.note("Select the output that must meet a requirement.")+metricHelp(c.metric)+"</label><label>Minimum"+input("minimum",c.minimum,false)+help.criterion("minimum",c.metric,base)+"</label><label>Maximum"+input("maximum",c.maximum,false)+help.criterion("maximum",c.metric,base)+"</label>"+remove("constraints",i)+"</div>").join("")+button("+ Specification","data-design-add","constraints");
 editor.onclick=protect(e=>{const b=e.target.closest("button");if(!b)return;const current=designValues();if(b.dataset.designAdd){const kind=b.dataset.designAdd,limits={variables:6,objectives:3,constraints:8};if(current[kind].length>=limits[kind]){u.notify("Maximum "+limits[kind]+" "+kind);return;}current[kind].push(kind==="variables"?{parameter:fields[0].key,low:fields[0].min,high:fields[0].max}:kind==="objectives"?{metric:base.metric,goal:"minimize",scale:1,weight:1}:{metric:base.metric,minimum:0});}else if(b.dataset.designRemove){const [kind,index]=b.dataset.designRemove.split(":");current[kind].splice(Number(index),1);}else return;renderDesign(current);});
 editor.onchange=protect(e=>{if(["parameter","metric"].includes(e.target.dataset.designField))renderDesign(designValues());});
}
function designValues(){
 const values={base_inputs:{},variables:[],objectives:[],constraints:[]},base=model(el("simulationFields").querySelector("[data-sim-key=base_model]").value);
 for(const field of el("robustnessBaseFields").querySelectorAll("[data-base-key]")){const definition=base.fields.find(f=>f.key===field.dataset.baseKey);values.base_inputs[field.dataset.baseKey]=field.value===""&&definition.optional?null:readField(field);}
 for(const row of el("designControls").querySelectorAll("[data-design-kind]")){const value={};for(const field of row.querySelectorAll("[data-design-field]")){if(field.value!=="")value[field.dataset.designField]=field.type==="number"?Number(field.value):field.value;}values[row.dataset.designKind].push(value);}
 return values;
}
function renderUncertainty(){
 const base=el("simulationFields").querySelector("[data-sim-key=base_model]")?.value||"rainfastness",fields=model(base).fields.filter(f=>f.type==="number"&&f.default!==null);
 el("uncertaintyRows").innerHTML=uncertain.map((r,i)=>"<div class='uncertainty-row' data-uncertainty-row='"+i+"'><label>Parameter<select data-uncertainty='parameter'>"+fields.map(f=>option(f.key,f.label,f.key===r.parameter)).join("")+"</select></label><label>Distribution<select data-uncertainty='distribution'>"+["uniform","normal"].map(d=>option(d,d,d===r.distribution)).join("")+"</select></label><label>Lower bound<input data-uncertainty='low' type='number' step='any' value='"+u.esc(r.low??0)+"' required></label><label>Upper bound<input data-uncertainty='high' type='number' step='any' value='"+u.esc(r.high??1)+"' required></label><button type='button' class='icon-button' data-lab-remove-uncertainty='"+i+"' aria-label='Remove distribution'>×</button><label>Normal mean<input data-uncertainty='mean' type='number' step='any' value='"+u.esc(r.mean??"")+"' placeholder='Normal only'></label><label>Normal standard deviation<input data-uncertainty='sd' type='number' step='any' min='0' value='"+u.esc(r.sd??"")+"' placeholder='Normal only'></label></div>").join("");
 el("uncertaintyRows").oninput=()=>{for(const row of el("uncertaintyRows").children){const i=Number(row.dataset.uncertaintyRow);for(const input of row.querySelectorAll("[data-uncertainty]"))uncertain[i][input.dataset.uncertainty]=input.type==="number"?(input.value===""?undefined:Number(input.value)):input.value;}};
 el("uncertaintyRows").onchange=el("uncertaintyRows").oninput;
}
function renderRobustnessBase(key,values){
 const base=model(key),source=el("simulationFields").querySelector("[data-sim-key=base_inputs]");
 source.closest("label").hidden=true;
 let container=el("robustnessBaseFields");
 if(!container){container=document.createElement("div");container.id="robustnessBaseFields";container.className="editor-fields full-width";el("simulationFields").append(container);}
 container.innerHTML="<h3 class='full-width'>Underlying model inputs</h3>"+base.fields.map(f=>fieldMarkup(f,values[f.key]??f.default).replaceAll("data-sim-key=","data-base-key=")).join("");
}
async function openSimulation(key="kinetics",request={}){
 if(!recipes().length){await openRecipe();return;}
 editorSession=u.app.session;clearErrors(el("simulationDialog"));
 el("simulationName").value=request.name||"";
 el("simulationRecipe").innerHTML=recipes().map(a=>option(a.artifact_id,a.title,a.recipe_id===request.recipe_id)).join("");
 el("simulationModel").value=model(key)?key:"kinetics";el("simulationAcrossRecipes").checked=false;el("simulationAllActives").checked=false;el("simulationExtrapolate").checked=!!request.allow_extrapolation;
 await simulationActives();if(request.active_name){el("simulationActive").value=request.active_name;await simulationActives(true);}if(request.active_b_name)el("simulationSecond").value=request.active_b_name;
 await configureModel(request.inputs);
 el("simulationAssumptions").value=(request.assumptions||["Unmeasured parameters are explicit research assumptions."]).join("\n");
 if(request.fit_id){const meta=u.latestArtifacts("fit").find(a=>a.metadata.fit_id===request.fit_id);if(meta){el("simulationFit").value=meta.artifact_id;await applyFit();if(request.inputs)setFieldValues(request.inputs);}}
 if(request.comparison_dataset_id)el("simulationComparison").value=request.comparison_dataset_id;
 renderPending();el("simulationDialog").showModal();
}
function setFieldValues(values){for(const input of el("simulationFields").querySelectorAll("[data-sim-key]")){const v=values[input.dataset.simKey];if(v===undefined)continue;input.value=input.dataset.simType==="json"?JSON.stringify(v,null,2):input.dataset.simType==="array"?v.join(", "):v??"";}}
async function applyFit(){
 selectedFit=el("simulationFit").value?await payload(el("simulationFit").value):null;
 if(!selectedFit){el("simulationSourceBadge").textContent="Editable assumed scenario";el("simulationSourceBadge").classList.remove("measured");return;}
 const f=selectedFit;setFieldValues(f.parameters);const domain=f.calibration_domain||{},key=el("simulationModel").value;
 if(key==="kinetics"&&domain.x_max>0)setFieldValues({horizon_days:domain.x_max});
 if(key==="rheology"&&domain.x_min>0)setFieldValues({shear_rates_s:[domain.x_min,(domain.x_min+domain.x_max)/2,domain.x_max]});
 if(key==="solubility")setFieldValues({temperatures_c:[domain.x_min,domain.x_max]});
 if(key==="rainfastness"&&domain.x_max>0){const intensity=Number(el("simulationFields").querySelector("[data-sim-key=rainfall_mm_hour]").value);if(intensity>0)setFieldValues({horizon_hours:domain.x_max/intensity});}
 if(key==="manufacturing"&&domain.x_max>0){const power=Number(el("simulationFields").querySelector("[data-sim-key=power_w]").value),mass=Number(el("simulationFields").querySelector("[data-sim-key=batch_kg]").value);if(power>0)setFieldValues({horizon_minutes:domain.x_max*mass*60000/power});}
 if(key==="stability"&&f.native?.temperatures_c)setFieldValues({temperatures_c:f.native.temperatures_c});
 el("simulationSourceBadge").textContent=(f.source_kind||"Unknown")+" fit · "+f.n_rows+" observations · "+f.n_independent_batches+" identified batches";
 el("simulationSourceBadge").classList.toggle("measured",f.source_kind==="experimental");
}
async function requestsFromForm(){
 sameSession();const key=el("simulationModel").value,inputs={};
 for(const field of el("simulationFields").querySelectorAll("[data-sim-key]"))inputs[field.dataset.simKey]=readField(field);
 if(key==="inverse_design")Object.assign(inputs,designValues());
 if(key==="sensitivity")Object.assign(inputs,sensitivityValues());
 if(key==="robustness"){inputs.parameters=JSON.parse(JSON.stringify(uncertain));const base=model(inputs.base_model),baseInputs={};for(const field of el("robustnessBaseFields").querySelectorAll("[data-base-key]")){const definition=base.fields.find(f=>f.key===field.dataset.baseKey);baseInputs[field.dataset.baseKey]=field.value===""&&definition.optional?null:readField(field);}inputs.base_inputs=baseInputs;}
 const selected=el("simulationAcrossRecipes").checked?recipes():[recipes().find(r=>r.artifact_id===el("simulationRecipe").value)];
 const requests=[];for(const meta of selected){const r=await payload(meta.artifact_id);const actives=el("simulationAllActives").checked&&key!=="mixture_response"?r.active_components.map(a=>a.name):[el("simulationActive").value];for(const active of actives){
  const req={model:key,inputs,recipe_id:r.recipe_id,active_name:active,allow_extrapolation:el("simulationExtrapolate").checked,assumptions:el("simulationAssumptions").value.split("\n").filter(Boolean)};
  if(el("simulationName").value.trim())req.name=el("simulationName").value.trim();
  if(key==="mixture_response"){req.active_b_name=el("simulationSecond").value;if(el("simulationComparison").value)req.comparison_dataset_id=el("simulationComparison").value;}
  if(selectedFit)req.fit_id=selectedFit.fit_id;requests.push(req);
 }}
 if(requests.length>50)throw new Error("Use at most 50 scenarios per batch.");return requests;
}
function renderPending(){const list=pending.get(u.app.session)||[];el("simulationBatchPreview").hidden=!list.length;el("runSimulationBatch").hidden=!list.length;el("clearSimulationBatch").hidden=!list.length;el("runSimulationBatch").textContent="Run batch ("+list.length+")";el("simulationBatchPreview").innerHTML="<b>"+list.length+" prepared scenarios</b><ol>"+list.slice(-8).map(r=>"<li>"+u.esc(model(r.model).title+" · "+r.active_name)+"</li>").join("")+"</ol>";}
async function submitSimulations(requests){
 sameSession();if(!requests.length)throw new Error("Add a simulation to the batch first.");
 const accepted=await u.post("/api/studio/simulate",{session_id:editorSession,requests});
 u.app.followSimulation={session:editorSession,request_id:accepted.request_id};
 pending.delete(editorSession);el("simulationDialog").close();await u.refresh(true);await u.viewPanel("simulation");
}
async function openDataUpload(){
 if(!recipes().length){await openRecipe();return;}
 editorSession=u.app.session;u.app.upload=null;importPreview=null;clearErrors(el("uploadDialog"));el("importError").hidden=true;el("measurementSourceKind").value="";el("timeMappingConfirmed").checked=false;el("timeMappingConfirmLabel").hidden=true;el("timeConversionPreview").innerHTML="";
 el("measurementFile").value="";el("uploadPreview").innerHTML="";el("mappingFields").innerHTML="";
 el("measurementRecipe").innerHTML=recipes().map(a=>option(a.artifact_id,a.title)).join("");
 await uploadActives();measurementKind();el("uploadDialog").showModal();
}
async function uploadActives(){
 const r=await payload(el("measurementRecipe").value);
 el("measurementActive").innerHTML=r.active_components.map(a=>option(a.name,a.name)).join("");await uploadSecond();
}
async function uploadSecond(){
 const r=await payload(el("measurementRecipe").value);
 el("measurementSecond").innerHTML=r.active_components.filter(a=>a.name!==el("measurementActive").value).map(a=>option(a.name,a.name)).join("");
}
function measurementKind(){
 const key=el("measurementKind").value,k=kinds[key],legacy=["release","stability","dose_response"].includes(key);
 el("measurementValue").value=k.value_unit||"";el("measurementXUnit").value=k.x_unit||"";
 el("measurementXLabel").hidden=legacy;el("measurementXUnit").required=!legacy;
 el("measurementSecondLabel").hidden=key!=="mixture_response";
 if(u.app.upload)previewUpload(true).catch(error=>problem(error,el("uploadDialog")));
}
async function previewUpload(reuse=false){
 if(!reuse)u.app.upload=await fileData(el("measurementFile").files[0]);
 if(!u.app.upload)return;
 const preview=await u.post("/api/rnd/preview-import",{...u.app.upload,kind:el("measurementKind").value}),key=el("measurementKind").value;
 el("uploadPreview").innerHTML="<p class='muted'>"+preview.source.n_rows+" source rows · SHA256 "+u.esc(preview.source.sha256.slice(0,16))+"</p>"+u.table(preview.preview,{keys:preview.columns});
 const needed=key==="release"?[["time","Time",/time|day|hour/i],["value","Measured release",/fraction|release|value/i]]:key==="stability"?[["time","Time",/time|day/i],["value","Chemical assay",/assay|retain|value/i],["temperature","Temperature",/temperature|temp/i]]:key==="dose_response"?[["dose","Dose",/^dose$/i],["value","Response (%)",/response|value/i]]:key==="mixture_response"?[["dose_a","Active A dose",/dose.?a|^a$/i],["dose_b","Active B dose",/dose.?b|^b$/i],["value","Observed response (%)",/response|value/i]]:[["x",kinds[key].x_label,/^x$|shear|temp|rain|energy|time|day/i],["value","Measured "+kinds[key].value_unit,/^y$|value|stress|solubility|retain|size|water|separat|fraction/i]];
 const mapping=[...needed,["batch","Independent batch",/batch/i],["replicate","Technical replicate",/replicate/i],["qc","QC flag",/qc|status/i],["recipe","Recipe label",/^recipe_id$|^formulation_id$/i],["condition","Assay condition",/^condition_id$|^condition$/i]];
 el("mappingFields").innerHTML=mapping.map(([name,label,re])=>"<label>"+u.esc(label)+"<select data-mapping='"+name+"'>"+option("","Not mapped")+preview.columns.map(c=>option(c,c,c===chooseImportColumn(name,preview))).join("")+"</select></label>").join("");
 importPreview=preview;syncImportTime(true);
 if(key==="release"){const col=el("mappingFields").querySelector("[data-mapping=value]").value;const values=preview.preview.map(r=>Number(r[col])).filter(Number.isFinite);if(values.length)el("measurementValue").value=Math.max(...values)<=1?"fraction":"percent";}
}
function chooseImportColumn(name,preview){
 const key=el("measurementKind").value,time=["release","stability"].includes(key)?"time":["suspension","packaging"].includes(key)?"x":null;
 if(name===time&&preview.time_conversion?.column)return preview.time_conversion.column;
 const patterns={time:/time|day|hour|minute/i,x:/^x$|shear|temp|rain|energy|time|day/i,value:key==="release"?/fraction|release|value/i:key==="stability"?/assay|retain|value/i:/^y$|value|stress|solubility|retain|size|water|separat|fraction|response/i,temperature:/temperature|temp/i,dose:/^dose$/i,dose_a:/dose.?a|^a$/i,dose_b:/dose.?b|^b$/i,batch:/batch/i,replicate:/replicate/i,qc:/qc|status/i,recipe:/^recipe_id$|^formulation_id$/i,condition:/^condition_id$|^condition$/i};
 return preview.columns.find(c=>patterns[name]?.test(c))||"";
}
function syncImportTime(infer=false){
 const info=importPreview?.time_conversion,key=el("measurementKind").value,legacy=["release","stability"].includes(key);el("measurementTime").closest("label").hidden=!legacy;
 if(!info){el("timeConversionPreview").innerHTML="";el("timeMappingConfirmLabel").hidden=true;return;}
 const input=el("mappingFields").querySelector("[data-mapping='"+info.axis+"']"),column=input?.value,candidate=info.time_columns.find(c=>c.column===column),unitField=el(legacy?"measurementTime":"measurementXUnit");
 if(infer)unitField.value=candidate?.unit||"days";
 const unit=unitField.value,factor={days:1,hours:1/24,minutes:1/1440}[unit],rows=(importPreview.preview||[]).slice(0,5).map(r=>({Source:r[column],"Normalized days":Number(r[column])*factor}));
 el("timeMappingConfirmLabel").hidden=!info.confirmation_required;
 el("timeConversionPreview").innerHTML="<p class='scenario-note'>Time mapping: "+u.esc(column||"unmapped")+" ("+u.esc(unit)+") → days. Multiply by "+u.esc(factor??"invalid unit")+". "+(info.confirmation_required?"Multiple time columns detected; confirm this selection.":"")+"</p>"+u.table(rows);
}
async function importMeasurements(e){
 e.preventDefault();sameSession();el("importError").hidden=true;if(!el("measurementSourceKind").value)throw new Error("Choose the observation source kind.");if(!u.app.upload)throw new Error("Choose a measurement file first.");
 const r=await payload(el("measurementRecipe").value),brief=u.app.view.project.brief,kind=el("measurementKind").value;
 const data={...u.app.upload,kind,source_kind:el("measurementSourceKind").value,time_mapping_confirmed:el("timeMappingConfirmed").checked,recipe_id:r.recipe_id,active_name:el("measurementActive").value,active_b_name:el("measurementSecond").value||undefined,instrument:el("measurementMethod").value,
  mapping:Object.fromEntries([...el("mappingFields").querySelectorAll("[data-mapping]")].map(f=>[f.dataset.mapping,f.value])),time_unit:el("measurementTime").value,value_unit:el("measurementValue").value.trim(),x_unit:el("measurementXUnit").value.trim(),
  dose_unit:el("measurementDose").value,recipe_value:el("measurementRecipeValue").value.trim()||undefined,condition_value:el("measurementConditionValue").value.trim()||undefined,
  context:{recipe_id:r.recipe_id,active_name:el("measurementActive").value,crop_or_system:brief.crop||"User laboratory system",target:brief.target||"Laboratory response",assay:el("measurementAssay").value||el("measurementMethod").value}};
 syncImportTime();if(!el("timeMappingConfirmLabel").hidden&&!el("timeMappingConfirmed").checked)throw new Error("Confirm the time column and unit shown in the conversion preview.");await u.post("/api/studio/import",{session_id:editorSession,data});el("uploadDialog").close();await u.refresh(true);await u.viewPanel("data");
}
async function queueFit(id){await u.post("/api/studio/fit",{session_id:u.app.session,dataset_id:id,options:{}});await u.refresh(true);await u.viewPanel("data");}
async function openDataset(id){
 editorSession=u.app.session;currentDataset=await u.json("/api/studio/dataset?session_id="+encodeURIComponent(editorSession)+"&dataset_id="+encodeURIComponent(id));
 const d=currentDataset;clearErrors(el("datasetDialog"));el("datasetTitle").textContent=d.source.filename;
 el("datasetSummary").innerHTML="<p class='muted'>"+u.esc((kinds[d.kind]?.title||d.kind)+" · "+d.active_name+" · "+d.instrument+" · source: "+(d.source_kind||"unknown"))+"</p><p class='muted'>"+d.observations.length+" included observations; "+(d.excluded||[]).length+" source/QC exclusions. Source SHA256: "+u.esc(d.source.sha256)+"</p>"+((d.warnings||[]).map(w=>"<p class='scenario-note'>"+u.esc(w)+"</p>").join(""));
 el("datasetSourceKind").value=d.source_kind||"unknown";el("datasetReviewStatus").value=d.review.status;el("datasetReviewNotes").value=d.review.notes||"";el("datasetExcluded").value=(d.review.excluded_source_rows||[]).join(", ");
 let series=[];if(d.kind==="release")series=[{name:"Observed release",x:d.observations.map(r=>r.time_days),y:d.observations.map(r=>r.fraction),x_label:"Time (days)",y_label:"Released fraction",scatter:true}];else if(d.kind==="dose_response")series=[{name:"Observed response",x:d.observations.map(r=>r.dose),y:d.observations.map(r=>r.response_pct),x_label:d.dose_unit,y_label:"Response (%)",scatter:true}];else if(d.kind!=="stability"&&d.kind!=="mixture_response")series=[{name:"Observed "+d.kind,x:d.observations.map(r=>r.x),y:d.observations.map(r=>r.value),x_label:(kinds[d.kind]?.x_label||"x")+" ("+d.x_unit+")",y_label:d.original_value_unit,scatter:true}];
 el("datasetChart").innerHTML=groupPlots(series);
 el("datasetRows").innerHTML=u.table(d.observations.slice(0,200))+(d.observations.length>200?"<p class='muted'>Previewing the first 200 observations. Download contains all rows.</p>":"")+(d.excluded?.length?"<h3>Source/QC exclusions</h3>"+u.table(d.excluded.slice(0,100)):"");
 el("datasetDialog").showModal();
}
async function saveReview(e){
 e.preventDefault();sameSession();const tokens=el("datasetExcluded").value.split(/[,\s]+/).filter(Boolean),rows=tokens.map(Number);
 if(rows.some(v=>!Number.isInteger(v)))throw new Error("Exclusions must be source-row integers.");
 await u.post("/api/studio/data-review",{session_id:editorSession,dataset_id:currentDataset.dataset_id,expected_revision:u.app.view.project.revision,review:{source_kind:el("datasetSourceKind").value,status:el("datasetReviewStatus").value,notes:el("datasetReviewNotes").value,excluded_source_rows:rows}});
 el("datasetDialog").close();await u.refresh(true);await u.viewPanel("data");
}
async function cataloguePanel(){
 return "<div class='lab-catalogue-heading'><span class='section-kicker'>"+models.length+" FORMULATION DESIGN MODELS</span><h3>Choose a question to explore.</h3><p>Choose a formulation question, compare recipe candidates under matching inputs, and inspect each model’s maturity and assumptions. Measured data can refine a scenario but is optional.</p></div><div class='lab-filters'><input id='labModelSearch' type='search' placeholder='Find a model…' aria-label='Find a simulation'><select id='labModelCategory' aria-label='Simulation category'>"+option("","All categories")+[...new Set(models.map(m=>m.category))].map(c=>option(c,c)).join("")+"</select></div><div class='lab-model-grid'>"+models.map(m=>"<button class='lab-model-card' data-lab-model='"+m.key+"' data-search='"+u.esc((m.title+" "+m.description).toLowerCase())+"' data-category='"+u.esc(m.category)+"'><span class='badge'>"+u.esc(m.category)+" · "+u.esc(m.maturity||"Local screening model")+"</span><h3>"+u.esc(m.title)+"</h3><p>"+u.esc(m.description)+"</p><small class='model-decision'>Helps decide: "+u.esc(m.decision_support||m.description)+"</small><span class='model-open'>Configure inputs ↗</span></button>").join("")+"</div>";
}
function heatmap(value){
 return "<div class='table-wrap'><table class='lab-heatmap'><thead><tr><th>"+u.esc(value.y_label)+" ↓ / "+u.esc(value.x_label)+" →</th>"+value.x.map(x=>"<th>"+u.esc(u.fmt(x))+"</th>").join("")+"</tr></thead><tbody>"+value.y.map((y,i)=>"<tr><th>"+u.esc(u.fmt(y))+"</th>"+value.values[i].map(v=>"<td style='background:rgba(70,130,85,"+(.05+.7*v/100)+")' title='Reference response'>"+u.esc(u.fmt(v))+"%</td>").join("")+"</tr>").join("")+"</tbody></table></div>";
}
function resultActions(a,entry){return "<div class='card-actions'>"+button("Edit & run a new scenario","data-lab-rerun",a.artifact_id)+button("Ask agents","data-pin",a.artifact_id)+button("Download inputs & result","data-download",a.artifact_id)+button("Download result CSV","data-lab-result-csv",a.artifact_id)+"</div>";}
async function matchedCandidates(meta,entry){const peers=u.app.view.artifacts.filter(v=>v.kind===meta.kind&&v.active_name===meta.active_name&&v.recipe_id!==meta.recipe_id);if(!peers.length)return "";const sig=p=>JSON.stringify({inputs:p.inputs,assumptions:p.assumptions,fit:p.request?.fit_id||"",extra:p.request?.allow_extrapolation===true,b:p.active_b_name||""});const target=sig(entry),rows=[{recipe:meta.title,...entry.result.metrics}];for(const peer of peers){try{const p=(await u.artifact(peer.artifact_id)).payload;if(sig(p)===target)rows.push({recipe:peer.title,...p.result.metrics})}catch(_){}}if(rows.length<2)return "";const keys=["recipe",...Object.keys(entry.result.metrics||{}).filter(k=>rows.every(row=>Number.isFinite(row[k])))];return "<section class='candidate-compare'><h3>Recipe comparison · matched scenario</h3><p>Same model inputs, active, assumptions and fit. Metrics stay separate; there is no universal winner.</p>"+u.table(rows,{keys})+"</section>"}
async function resultsPanel(){
 const all=u.app.view.artifacts.filter(a=>model(a.kind)&&(!el("recipeFilter").value||a.recipe_id===el("recipeFilter").value)&&(!el("activeFilter").value||a.active_name===el("activeFilter").value));
 if(!all.length)return empty("Your next simulation starts here.","Choose a model and enter parameters. The composer remains available while calculations run.",button("Browse simulations","data-panel","catalogue",true));
 const meta=all.find(a=>a.artifact_id===u.app.selected)||all.at(-1),a=await u.artifact(meta.artifact_id);u.app.selected=a.artifact_id;
 const entry=a.payload,r=entry.result,m=model(a.kind);
 const scenarioLabel=v=>(v.metadata.scenario_label||v.title)+" · "+new Date(v.created).toLocaleString()+" · "+v.recipe_id.slice(-8);
 let out="<label class='lab-result-picker'>Saved scenario<select id='labResultChoice'>"+all.slice().reverse().map(v=>option(v.artifact_id,scenarioLabel(v),v.artifact_id===a.artifact_id)).join("")+"</select></label><div class='lab-result-list'>"+[meta,...all.slice().reverse().filter(v=>v.artifact_id!==meta.artifact_id).slice(0,5)].map(v=>"<button class='"+(v.artifact_id===a.artifact_id?"selected":"")+"' data-artifact='"+u.esc(v.artifact_id)+"'><span>"+u.esc(v.metadata.scenario_label||v.title)+"<small>"+u.esc(new Date(v.created).toLocaleString()+" · "+v.recipe_id)+"</small></span><span>"+u.esc(v.metadata.evidence)+"</span></button>").join("")+"</div><article class='chart-card'><h3>"+u.esc(meta.metadata.scenario_label||a.title)+"</h3><span class='badge "+(/fitted parameters/i.test(r.evidence)?"assumed":/fitted measurements|measured data/i.test(r.evidence)?"measured":"assumed")+"'>"+u.esc(/fitted parameters/i.test(r.evidence)?"Fit-informed scenario":r.evidence||"Assumed scenario")+"</span>"+((r.interpretation||a.kind==="dilution")?"<p class='notice' role='note'>"+u.esc(r.interpretation||"Aqueous-only screen: assumes all active enters water. Oil partitioning and emulsion behavior are excluded; this is not predicted product precipitation or stability.")+"</p>":"")+metrics(r.metrics,a.kind==="dilution"?{...r.metric_labels,maximum_precipitated_fraction:"Aqueous-only excess fraction (hypothetical)"}:r.metric_labels);
 if(r.series)out+=groupPlots(r.series);
 else out+="<p class='muted'>Open this earlier result in its original tab or download the numerical output.</p>";
 out+="<div class='model-guidance'><strong>"+u.esc(r.model_maturity||m.maturity)+"</strong><span>Helps decide: "+u.esc(r.decision_support||m.decision_support)+"</span><span>Inputs that matter: "+u.esc(r.critical_inputs||m.critical_inputs||"Model-specific parameters")+"</span></div>";
 if(r.recipe_linkage)out+="<p class='scenario-note'><b>Recipe linkage:</b> "+u.esc(r.recipe_linkage.note)+"</p>";if(r.heatmap)out+=heatmap(r.heatmap);
 if(a.kind==="inverse_design"){
  out+="<section class='design-shortlist'><h3>"+u.esc(r.search_status)+"</h3><p>"+u.esc(r.uncertainty_basis)+"</p>";
  if(r.shortlist?.length){out+="<p>Non-dominated feasible candidates, ranked by your scaled objective priorities. Every value below was evaluated by the physical model.</p>"+u.table(r.shortlist.map((c,i)=>({candidate:i+1,...c.parameters,...Object.fromEntries(r.objectives.map(o=>[o.metric,c.metrics[o.metric]])),verification:c.verification})));out+=r.shortlist.map((c,i)=>"<button type='button' class='button' data-design-candidate='"+u.esc(a.artifact_id)+"' data-design-index='"+i+"'>Inspect candidate "+(i+1)+" in simulator ↗</button>").join("");}
  else out+="<p class='scenario-note'>No evaluated candidate met all specifications within this budget. Review the bounds, model domain and specifications. This result does not prove physical impossibility.</p>";
  out+="<h3>Next experiments</h3>"+(r.next_experiments||[]).map(next=>"<details class='input-details'><summary>"+u.esc(next.purpose)+"</summary><span class='badge assumed'>"+u.esc(next.evidence)+"</span><pre>"+u.esc(JSON.stringify(next,null,2))+"</pre></details>").join("")+"<details class='input-details'><summary>Base physics equation & assumptions</summary><p>"+u.esc(r.base_equation)+"</p><ul>"+(r.base_limitations||[]).map(l=>"<li>"+u.esc(l)+"</li>").join("")+"</ul></details></section>";
 }
 if(a.kind==="sensitivity"){
  out+="<section class='design-shortlist'><h3>Influence of the assumed ranges</h3><p>Complete sweeps are ranked by maximum absolute change from the baseline, in "+u.esc(designMetricLabel(r.metric,model(r.base_model)))+". Rejected sweeps remain unranked.</p>"+u.table(r.ranking.map(v=>({Rank:v.rank??"Unranked",Parameter:v.label,Unit:v.unit,Baseline:v.baseline,Lower:v.low,Upper:v.high,Scale:v.scale,"Maximum absolute change":v.max_absolute_change,"Sampled output span":v.sampled_output_span,"Rejected points":v.rejected_points})))+"<h3>Focused validation needs</h3>";
  out+=r.next_measurements.length?"<ul>"+r.next_measurements.map(v=>"<li>"+u.esc(v.purpose)+"</li>").join("")+"</ul><p class='muted'>Suggestions follow numerical sensitivity; no measurement has been performed.</p>":"<p>No nonzero effect was found in complete sweeps. Review the ranges and rejected points before choosing a validation measurement.</p>";
  out+="<ul>"+r.analysis_notes.map(v=>"<li>"+u.esc(v)+"</li>").join("")+"</ul><details class='input-details'><summary>Base physics equation & assumptions</summary><p>"+u.esc(r.base_equation)+"</p><ul>"+r.base_limitations.map(v=>"<li>"+u.esc(v)+"</li>").join("")+"</ul></details>"+button("Inspect baseline in simulator","data-sensitivity-baseline",a.artifact_id)+"</section>";
 }
 out+=resultActions(a,entry)+"<details class='input-details'><summary>Exact inputs, equation & provenance</summary><div class='lab-equation'>"+u.esc(r.equation||m.equation)+"</div><pre>"+u.esc(JSON.stringify({recipe_id:a.recipe_id,active_name:a.active_name,engine_version:entry.engine_version,engine_manifest:entry.engine_manifest,inputs:entry.inputs,input_provenance:entry.input_provenance||r.input_provenance,recipe_linkage:r.recipe_linkage,calibration:r.calibration,sources:r.sources,scenario_id:entry.scenario_id},null,2))+"</pre></details>";
 const compare=await matchedCandidates(meta,entry);if(compare)out+=compare;
 if(r.rows?.length)out+="<details class='input-details'><summary>Numerical output table ("+r.rows.length+" rows)</summary>"+u.table(r.rows.slice(0,200))+"</details>";
 if(r.comparison_rows?.length)out+="<h3>Observed minus reference · descriptive comparison</h3>"+u.table(r.comparison_rows.slice(0,200));
 out+="<div class='scenario-note'>"+u.esc([...(Array.isArray(r.limitations)?r.limitations:m.limits),...(entry.assumptions||[])].join(" "))+"</div></article>";return out;
}
async function dataPanel(){
 const datasets=(await u.json("/api/studio/datasets?session_id="+encodeURIComponent(u.app.session))).datasets,fits=u.latestArtifacts("fit");
 let out="<div class='lab-catalogue-heading'><span class='section-kicker'>OPTIONAL MODEL REFINEMENT</span><h3>Refine models with feedback</h3><p>Design and simulate without experimental data. When measurements become available, use them to calibrate a relevant model or check a prediction. Fits stay tied to the exact recipe, active and source observations.</p></div><div class='lab-inline-actions'>"+button("Import CSV/XLSX","data-lab-import","",true)+"<label>CSV template<select id='labTemplateType'>"+Object.entries(kinds).map(([key,k])=>option(key,k.title)).join("")+"</select></label>"+button("Download CSV template","data-lab-templates")+"</div>";
 if(!datasets.length)return out+empty("Keep designing; add feedback when available.","Measurements are optional. Continue with agents, simulations and optimization, or import an existing result to refine a specific model.",button("Explore simulation models","data-panel","catalogue"));
 for(const d of datasets)out+="<article class='lab-data-card'><span class='badge'>"+u.esc((d.source_kind||"unknown")+" · "+(d.review?.status||"unreviewed"))+"</span><h3>"+u.esc(d.filename)+"</h3><p>"+u.esc((kinds[d.kind]?.title||d.kind)+" · "+d.active_name)+"</p><p>"+d.n_rows+" observations · "+d.n_qc_excluded+" source exclusions · "+d.n_review_excluded+" review exclusions</p><p>Units: "+u.esc((d.x_unit||"time/dose")+ " → "+d.original_value_unit)+" · "+u.esc(d.instrument)+"</p><div class='card-actions'>"+button("Review observations","data-lab-dataset",d.dataset_id)+button("Fit dataset","data-lab-fit",d.dataset_id)+button("Discuss dataset","data-lab-discuss-data",d.dataset_id)+"</div></article>";
 out+="<section class='canvas-section'><h3>Saved descriptive fits</h3>"+(fits.length?fits.slice().reverse().map(f=>"<div class='lab-data-card'><h3>"+u.esc(f.title)+"</h3><div class='card-actions'>"+button("Inspect fit","data-lab-inspect-fit",f.artifact_id)+(f.metadata.simulation_key?button("Use in simulation","data-lab-use-fit",f.artifact_id):"")+button("Download fit","data-download",f.artifact_id)+"</div></div>").join(""):"<p class='muted'>Fit results appear here after calculations finish.</p>")+"</section>";
 const selected=fits.find(f=>f.artifact_id===u.app.selected);
 if(selected){const f=await payload(selected.artifact_id);out+="<article class='chart-card'><h3>"+u.esc((f.source_kind||"Unknown")+" descriptive fit · "+f.kind)+"</h3><p class='scenario-note'>"+u.esc(f.source_kind?f.evidence:"Legacy fit: observation origin was not recorded. Reclassify and refit before treating it as empirical evidence.")+"</p>"+metrics(f.parameters)+groupPlots(f.series)+"<p class='scenario-note'>"+u.esc((f.warnings||[]).join(" "))+"</p><details class='input-details'><summary>Fit diagnostics & source provenance</summary><pre>"+u.esc(JSON.stringify({...f,series:undefined},null,2))+"</pre></details></article>";}
 return out;
}
async function click(e){
 const b=e.target.closest("button");if(!b)return;
 if(b.hasAttribute("data-lab-remove-ingredient")){b.closest("tr").remove();recipeBalance();}
 if(b.dataset.labModel)await openSimulation(b.dataset.labModel);
 if(b.hasAttribute("data-lab-recipe"))await openRecipe();
 if(b.hasAttribute("data-lab-import"))await openDataUpload();
 if(b.dataset.labDataset)await openDataset(b.dataset.labDataset);
 if(b.dataset.labFit)await queueFit(b.dataset.labFit);
 if(b.dataset.labInspectFit){u.app.selected=b.dataset.labInspectFit;await u.viewPanel("data");}
 if(b.dataset.labUseFit){const f=await payload(b.dataset.labUseFit);await openSimulation(f.simulation_key,{recipe_id:f.recipe_id,active_name:f.active_name,active_b_name:f.active_b_name,fit_id:f.fit_id});}
 if(b.dataset.labRerun){const a=await u.artifact(b.dataset.labRerun);const entry=a.payload;await openSimulation(a.kind,entry.request||{recipe_id:a.recipe_id,active_name:a.active_name,inputs:Object.fromEntries(model(a.kind).fields.filter(f=>entry.inputs[f.key]!==undefined).map(f=>[f.key,entry.inputs[f.key]]))});}
 if(b.dataset.designCandidate){const a=await u.artifact(b.dataset.designCandidate),r=a.payload.result,c=r.shortlist[Number(b.dataset.designIndex)];if(c)await openSimulation(r.base_model,{recipe_id:a.recipe_id,active_name:a.active_name,inputs:c.inputs,assumptions:["Candidate from a bounded numerical design search; physical inputs require experimental confirmation."]});}
 if(b.dataset.sensitivityBaseline){const a=await u.artifact(b.dataset.sensitivityBaseline),r=a.payload.result;await openSimulation(r.base_model,{recipe_id:a.recipe_id,active_name:a.active_name,inputs:r.base_inputs,assumptions:["Baseline from a parameter sensitivity analysis; physical inputs are explicit scenario assumptions."]});}
 if(b.hasAttribute("data-lab-remove-uncertainty")){uncertain.splice(Number(b.dataset.labRemoveUncertainty),1);renderUncertainty();}
 if(b.dataset.labResultCsv){const a=await payload(b.dataset.labResultCsv),r=a.result;const rows=r.rows?.length?r.rows:(r.series||[]).flatMap(s=>s.x.map((x,i)=>({series:s.name,x,y:s.y[i],x_unit:s.x_label,y_unit:s.y_label})));u.download(a.kind+"-"+a.scenario_id+".csv",csvRows(rows),"text/csv");}
 if(b.dataset.labDiscussData){const d=await u.json("/api/studio/dataset?session_id="+encodeURIComponent(u.app.session)+"&dataset_id="+encodeURIComponent(b.dataset.labDiscussData));await u.send("Review the actual dataset "+d.dataset_id+" ("+d.source.filename+"), explain data quality and fitting options. Do not fabricate missing measurements.","discussion");}
 if(b.hasAttribute("data-lab-templates")){const key=el("labTemplateType")?.value||"release",headers={release:"time_days,release_fraction",stability:"time_days,assay_percent,temperature_c",dose_response:"dose,response_percent",rheology:"shear_rate_per_s,stress_pa",solubility:"temperature_c,solubility_mg_l",rainfastness:"rainfall_mm,retained_fraction",milling:"energy_kwh_kg,particle_size_um",suspension:"time_days,separated_fraction",packaging:"time_days,water_g",mixture_response:"dose_a,dose_b,response_percent",property:"x,value"};u.download(key+"-measurements-template.csv",headers[key]+",batch,replicate,qc,condition\n","text/csv");}
}
document.addEventListener("input",e=>{if(!u)return;if(e.target.id==="labModelSearch"||e.target.id==="labModelCategory")filterModels();});
document.addEventListener("change",e=>{if(!u)return;if(e.target.id==="labModelCategory")filterModels();if(e.target.id==="labResultChoice"){u.app.selected=e.target.value;u.viewPanel("simulation").catch(u.notify);}});
function filterModels(){const search=(el("labModelSearch")?.value||"").toLowerCase(),category=el("labModelCategory")?.value||"";document.querySelectorAll(".lab-model-card").forEach(card=>card.hidden=!card.dataset.search.includes(search)||!!category&&card.dataset.category!==category);}
return {init,validateRecipe,owns:panel=>["catalogue","simulation","data"].includes(panel),render:panel=>panel==="catalogue"?cataloguePanel():panel==="data"?dataPanel():resultsPanel(),openRecipe,openSimulation,openDataUpload,uploadActives,previewUpload,importMeasurements,fitArtifact:async a=>{const d=a.payload;let id=d.dataset_id;if(!id){const list=(await u.json("/api/studio/datasets?session_id="+encodeURIComponent(u.app.session))).datasets;id=list.find(v=>v.source_sha256===d.source?.sha256&&v.recipe_id===d.recipe_id&&v.active_name===d.active_name)?.dataset_id;}if(!id)throw new Error("Open this dataset in the Data workspace before fitting.");await queueFit(id);},get models(){return models;}};
})();
