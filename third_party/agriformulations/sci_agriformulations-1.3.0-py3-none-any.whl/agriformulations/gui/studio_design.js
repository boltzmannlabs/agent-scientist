"use strict";
window.FormulationDesign=(()=>{
let u,models=[],draft=null,editorSession=null,recipeRecords=[],selectedStudy=null;
const el=id=>document.getElementById(id),model=key=>models.find(m=>m.key===key);
const esc=v=>u.esc(v),opt=(v,t,s=false)=>"<option value='"+esc(v)+"'"+(s?" selected":"")+">"+esc(t)+"</option>";
const safe=fn=>async e=>{try{await fn(e);}catch(error){u.notify(error);const note=el("studyError");if(el("studyDialog").open){note.textContent=error.message;note.hidden=false;}}};
const permitted=()=>models.filter(m=>!["inverse_design","robustness","sensitivity","mixture_response"].includes(m.key));
const primaryGoal=m=>["release_at_horizon","retention_at_first_temperature","retained_fraction","initial_coverage_fraction"].includes(m.metric)?"maximize":"minimize";
const help=window.FormulationInputHelp;
function field(f,value,attribute){
 const a=" "+attribute+"='"+esc(f.key)+"'";
 let input;
 if(f.type==="select")input="<select"+a+">"+f.options.map(v=>opt(v,v,v===value)).join("")+"</select>";
 else if(f.type==="json")input="<textarea"+a+">"+esc(JSON.stringify(value,null,2))+"</textarea>";
 else input="<input"+a+" type='"+(f.type==="number"?"number":"text")+"' value='"+esc(f.type==="array"?value.join(", "):value??"")+"'"+(f.type==="number"?" step='any' min='"+f.min+"' max='"+f.max+"'":"")+(f.optional?"":" required")+">";
 return input+help.field(f);
}
function read(input,f){
 if(input.value===""&&f.optional)return null;
 if(f.type==="number"){const n=Number(input.value);if(input.value===""||!Number.isFinite(n))throw new Error("Enter a finite value for "+f.label);return n;}
 if(f.type==="array"){const values=input.value.split(/[,\s]+/).filter(Boolean).map(Number);if(!values.length||values.some(v=>!Number.isFinite(v)))throw new Error("Enter numeric values for "+f.label);return values;}
 if(f.type==="json"){try{return JSON.parse(input.value);}catch{throw new Error("Check the structured inputs for "+f.label);}}
 return input.value.trim();
}
async function init(context){
 u=context;models=(await u.json("/api/studio/catalogue")).simulations;
 el("labDesignStudy").onclick=safe(()=>open());el("studyForm").onsubmit=safe(submit);
 el("studyAddScenario").onclick=safe(()=>{draft=collect();if(draft.scenarios.length>=4)throw new Error("Choose at most four physical scenarios.");addScenario(el("studyModel").value);renderEditor();});
 el("studyCandidates").onchange=safe(()=>{draft=collect();renderEditor();});
 el("studyActive").onchange=safe(()=>{draft=collect();for(const c of draft.candidates)c.active_name=el("studyActive").value;renderEditor();});
 el("studyScenarios").onchange=safe(e=>{if(e.target.hasAttribute("data-study-properties")||e.target.dataset.criterion==="metric"){draft=collect();renderEditor();}});
 el("studyScenarios").onclick=safe(e=>{const b=e.target.closest("button");if(!b||b.dataset.studyRemove===undefined)return;draft=collect();draft.scenarios=draft.scenarios.filter(s=>s.id!==b.dataset.studyRemove);draft.criteria=draft.criteria.filter(c=>c.scenario!==b.dataset.studyRemove);renderEditor();});
 document.addEventListener("click",safe(click));
}
function addScenario(key){
 const m=model(key),id="scenario_"+(Math.max(0,...draft.scenarios.map(s=>Number(s.id.split("_").at(-1))||0))+1);
 draft.scenarios.push({id,model:key,inputs:Object.fromEntries(m.fields.map(f=>[f.key,structuredClone(f.default)])),candidate_parameters:m.candidate_parameters.slice(0,1)});
 draft.criteria.push({scenario:id,metric:m.metric,goal:primaryGoal(m),scale:1});
}
async function open(study=null){
 editorSession=u.app.session;recipeRecords=await Promise.all(u.latestArtifacts("recipe").map(async a=>({artifact:a,recipe:(await u.artifact(a.artifact_id)).payload})));
 if(editorSession!==u.app.session)return;
 if(!recipeRecords.length){await window.FormulationLab.openRecipe();return;}
 const brief=u.app.view.project.brief;
 draft=study?structuredClone(study.request):{name:"Formulation design comparison",goal:brief.objective||"Compare candidate recipes under shared conditions and identify the next design revision.",candidates:recipeRecords.slice(-Math.min(3,recipeRecords.length)).map(r=>({recipe_id:r.recipe.recipe_id,active_name:r.recipe.active_components[0]?.name,inputs:{}})),scenarios:[],criteria:[],assumptions:["Unmeasured material coefficients are explicit, editable physical assumptions."]};
 if(study){
  draft.parent_study_id=study.study_id;
  if(draft.candidates.some(c=>Object.keys(c.fit_ids||{}).length)){
   for(const scenario of draft.scenarios)scenario.inputs=structuredClone(study.candidates[0].cases[scenario.id].inputs);
   for(const candidate of draft.candidates){const saved=study.candidates.find(c=>c.recipe_id===candidate.recipe_id);candidate.inputs={};for(const scenario of draft.scenarios)candidate.inputs[scenario.id]=Object.fromEntries(scenario.candidate_parameters.map(p=>[p,saved.cases[scenario.id].inputs[p]]));delete candidate.fit_ids;}
   draft.assumptions.push("Revised measured-fit inputs are copied into explicit editable scenarios; this revision is not a new calibration.");
  }
 }
 if(!draft.scenarios.length){addScenario("rheology");addScenario("stability");}
 el("studyError").hidden=true;el("studyModel").innerHTML=permitted().map(m=>opt(m.key,m.title)).join("");renderEditor();el("studyDialog").showModal();
}
function renderEditor(){
 for(const c of draft.candidates){c.inputs=Object.fromEntries(Object.entries(c.inputs||{}).filter(([sid])=>draft.scenarios.some(s=>s.id===sid)));if(c.fit_ids)c.fit_ids=Object.fromEntries(Object.entries(c.fit_ids).filter(([sid])=>draft.scenarios.some(s=>s.id===sid)));}
 el("studyName").value=draft.name;el("studyGoal").value=draft.goal;el("studyAssumptions").value=draft.assumptions.join("\n");
 el("studyCandidates").innerHTML=recipeRecords.map(({recipe:r})=>"<label class='study-recipe-choice'><input type='checkbox' value='"+esc(r.recipe_id)+"'"+(draft.candidates.some(c=>c.recipe_id===r.recipe_id)?" checked":"")+"> "+esc(r.name)+" <small>"+esc(r.recipe_id.slice(-8))+"</small></label>").join("");
 const chosen=recipeRecords.filter(r=>draft.candidates.some(c=>c.recipe_id===r.recipe.recipe_id)),common=chosen.length?chosen[0].recipe.active_components.map(a=>a.name).filter(name=>chosen.every(r=>r.recipe.active_components.some(a=>a.name===name))):[];
 const active=draft.candidates[0]?.active_name;
 el("studyActive").innerHTML=common.length?common.map(name=>opt(name,name,name===active)).join(""):opt("","Choose recipes sharing an individual active");
 for(const c of draft.candidates)c.active_name=el("studyActive").value;
 el("studyScenarios").innerHTML=draft.scenarios.map(s=>{
  const m=model(s.model),properties=m.fields.filter(f=>s.candidate_parameters.includes(f.key));
  return "<article class='study-scenario' data-study-scenario='"+esc(s.id)+"'><div class='chart-heading'><h3>"+esc(m.title)+"</h3><button type='button' class='button subtle' data-study-remove='"+esc(s.id)+"'>Remove</button></div><p class='muted'>"+esc(m.maturity)+" · "+esc(m.description)+"</p><details><summary>Shared physical inputs and assumptions</summary><div class='editor-fields'>"+m.fields.map(f=>"<label>"+esc(f.label)+(f.unit?" <small>"+esc(f.unit)+"</small>":"")+field(f,s.inputs[f.key]??f.default,"data-study-input")+"</label>").join("")+"</div><ul>"+m.limits.map(l=>"<li>"+esc(l)+"</li>").join("")+"</ul></details><label>Material/property inputs allowed to differ between candidates<select data-study-properties multiple size='3'>"+m.fields.filter(f=>m.candidate_parameters.includes(f.key)).map(f=>opt(f.key,f.label,s.candidate_parameters.includes(f.key))).join("")+"</select>"+help.note("Choose properties with justified candidate-specific values. Keep test conditions shared; identical properties can give identical results.")+"</label><p class='muted'>Select the coefficients you can justify. Test conditions stay shared; ingredient names do not determine these coefficients.</p>"+(properties.length?"<div class='table-wrap'><table><thead><tr><th>Candidate</th>"+properties.map(f=>"<th>"+esc(f.label)+(f.unit?" ("+esc(f.unit)+")":"")+"</th>").join("")+"</tr></thead><tbody>"+draft.candidates.map(c=>"<tr data-study-candidate-input='"+esc(c.recipe_id)+"'><th>"+esc(recipeRecords.find(r=>r.recipe.recipe_id===c.recipe_id)?.recipe.name||c.recipe_id)+"</th>"+properties.map(f=>"<td>"+field(f,Object.hasOwn(c.inputs?.[s.id]||{},f.key)?c.inputs[s.id][f.key]:(s.inputs[f.key]??f.default),"data-study-property")+"</td>").join("")+"</tr>").join("")+"</tbody></table></div>":"")+"<h4>Specifications and objectives</h4>"+draft.criteria.filter(c=>c.scenario===s.id).map(c=>"<div class='study-criterion' data-study-criterion><label>Output<select data-criterion='metric'>"+m.output_metrics.map(k=>opt(k,k.replaceAll("_"," "),k===c.metric)).join("")+"</select>"+help.criterion("metric",c.metric,m)+"</label><label>Minimum<input data-criterion='minimum' type='number' step='any' value='"+esc(c.minimum??"")+"'>"+help.criterion("minimum",c.metric,m)+"</label><label>Maximum<input data-criterion='maximum' type='number' step='any' value='"+esc(c.maximum??"")+"'>"+help.criterion("maximum",c.metric,m)+"</label><label>Objective<select data-criterion='goal'>"+[["","Specifications only"],["minimize","Minimize"],["maximize","Maximize"],["target","Approach target"]].map(([v,l])=>opt(v,l,v===(c.goal||""))).join("")+"</select>"+help.criterion("goal",c.metric,m)+"</label><label>Target<input data-criterion='target' type='number' step='any' value='"+esc(c.target??"")+"'>"+help.criterion("target",c.metric,m)+"</label><label>Scale<input data-criterion='scale' type='number' min='1e-12' step='any' required max='1e12' value='"+esc(c.scale??1)+"'>"+help.criterion("scale",c.metric,m)+"</label><button type='button' class='button subtle' data-study-criterion-remove='"+draft.criteria.indexOf(c)+"'>Remove criterion</button></div>").join("")+"<button type='button' class='button' data-study-criterion-add='"+esc(s.id)+"'>+ Output criterion</button></article>";
 }).join("");
}
function collect(){
 const next=structuredClone(draft),selected=[...el("studyCandidates").querySelectorAll("input:checked")].map(i=>i.value);
 next.name=el("studyName").value.trim();next.goal=el("studyGoal").value.trim();next.assumptions=el("studyAssumptions").value.split("\n").map(v=>v.trim()).filter(Boolean);
 next.candidates=selected.map(id=>structuredClone(draft.candidates.find(c=>c.recipe_id===id)||{recipe_id:id,active_name:el("studyActive").value,inputs:{}}));next.criteria=[];
 for(const card of el("studyScenarios").querySelectorAll("[data-study-scenario]")){
  const s=next.scenarios.find(s=>s.id===card.dataset.studyScenario),m=model(s.model);s.inputs={};
  for(const input of card.querySelectorAll("[data-study-input]")){const f=m.fields.find(f=>f.key===input.dataset.studyInput);s.inputs[f.key]=read(input,f);}
  s.candidate_parameters=[...card.querySelector("[data-study-properties]").selectedOptions].map(o=>o.value);
  for(const candidate of next.candidates){const row=[...card.querySelectorAll("[data-study-candidate-input]")].find(r=>r.dataset.studyCandidateInput===candidate.recipe_id);candidate.inputs??={};candidate.inputs[s.id]={};if(row)for(const input of row.querySelectorAll("[data-study-property]"))if(s.candidate_parameters.includes(input.dataset.studyProperty)){const f=m.fields.find(f=>f.key===input.dataset.studyProperty);candidate.inputs[s.id][f.key]=read(input,f);}}
  for(const row of card.querySelectorAll("[data-study-criterion]")){const c={scenario:s.id};for(const input of row.querySelectorAll("[data-criterion]")){if(input.value!=="")c[input.dataset.criterion]=input.type==="number"?Number(input.value):input.value;}next.criteria.push(c);}
 }
 return next;
}
async function submit(e){
 e.preventDefault();if(editorSession!==u.app.session)throw new Error("Reopen the study in the selected project.");
 draft=collect();if(!draft.candidates.length||!el("studyActive").value)throw new Error("Choose candidate recipes sharing an individual active.");
 const button=el("studyRun");button.disabled=true;
 try{const accepted=await u.post("/api/studio/design-study",{session_id:editorSession,study:draft});u.app.followStudy={session:editorSession,request_id:accepted.request_id};el("studyDialog").close();if(editorSession===u.app.session){await u.refresh(true);await u.viewPanel("design");}}finally{button.disabled=false;}
}
async function render(){
 const artifacts=u.latestArtifacts("design_study");
 if(!artifacts.length)return "<div class='lab-empty'><h3>Turn model results into a design decision.</h3><p>Compare recipes under shared conditions, declare output specifications and inspect Pareto tradeoffs. Add justified property assumptions or measured fits when available.</p><button class='button primary' data-study-new>New design study</button></div>";
 const meta=artifacts.find(a=>a.artifact_id===u.app.selected)||artifacts.at(-1),a=await u.artifact(meta.artifact_id),s=a.payload;selectedStudy=s;u.app.selected=a.artifact_id;
 let out="<div class='lab-inline-actions'><button class='button primary' data-study-new>New study</button><button class='button' data-study-revise='"+esc(a.artifact_id)+"'>Revise study</button><button class='button' data-pin='"+esc(a.artifact_id)+"'>Ask agents</button><button class='button' data-download='"+esc(a.artifact_id)+"'>Download study JSON</button><button class='button' data-study-csv>Download comparison CSV</button></div><label>Saved study<select id='studyChoice'>"+artifacts.slice().reverse().map(v=>opt(v.artifact_id,v.title+(v.artifact_id===a.artifact_id?" · selected":""),v.artifact_id===a.artifact_id)).join("")+"</select></label><h3>"+esc(s.name)+"</h3><p>"+esc(s.goal)+"</p><span class='badge assumed'>"+esc(s.evidence)+"</span><div class='lab-metrics'><div class='metric'><b>"+s.summary.complete_candidates+" / "+s.summary.candidates+"</b><span>FULLY EVALUATED CANDIDATES</span></div><div class='metric'><b>"+(s.summary.has_acceptance_limits?s.summary.meeting_specifications:"Not assessed")+"</b><span>MEETING MODEL SPECIFICATIONS</span></div><div class='metric'><b>"+s.summary.pareto_candidates+"</b><span>PARETO CANDIDATES</span></div></div>";
 out+="<p class='scenario-note'>Pareto candidates expose tradeoffs between declared objectives. There is no universal recipe score. Passing model specifications requires confirmation of the underlying physical assumptions.</p>"+u.table(comparisonRows(s));
 out+="<p class='muted'>Specification margins use each metric’s own units: positive is within bounds, zero is on a bound, negative is outside. Metrics remain separate.</p>";
 for(const warning of s.warnings)out+="<p class='notice'>"+esc(warning)+"</p>";
 for(const [i,c] of s.candidates.entries()){
  out+="<article class='chart-card'><h3>"+esc(c.recipe_name)+" · "+esc(c.status)+"</h3>"+u.table(c.checks.map(v=>({Scenario:v.scenario,Output:v.metric_label||v.metric,Value:v.value,Minimum:v.minimum??null,Maximum:v.maximum??null,Objective:v.goal||"—",Target:v.target??null,Scale:v.scale,"Specification margin":v.specification_margin??null,"Distance to target":v.target_distance??null,Result:!v.available?v.reason:v.passed===null?"No acceptance bound":v.passed?"Within model specification":"Outside specification"})))+"<div class='card-actions'><button class='button' data-study-variant='"+esc(c.recipe_id)+"'>Create recipe variant</button></div>";
  for(const [sid,entry] of Object.entries(c.cases))out+="<details class='input-details'><summary>"+esc(model(entry.model).title)+" · "+esc(entry.evidence)+"</summary><p>"+esc(entry.reason||entry.recipe_linkage?.note||"")+"</p><div class='card-actions'><button class='button' data-study-inspect='"+i+":"+esc(sid)+"'>Inspect exact scenario</button><button class='button' data-study-refine='"+i+":"+esc(sid)+"'>Explore constrained revision</button></div><pre>"+esc(JSON.stringify(entry,null,2))+"</pre></details>";
  out+="</article>";
 }
 out+="<h3>Next design steps</h3>"+u.table(s.next_steps.map(v=>({Candidate:v.recipe_id||"Study",Scenario:v.scenario||"—",Output:v.metric||"—",Action:v.action,Margin:v.specification_margin??null,Reason:v.reason})))+"<details class='input-details'><summary>Study assumptions and limits</summary><ul>"+[...s.limitations,...s.request.assumptions].map(v=>"<li>"+esc(v)+"</li>").join("")+"</ul><p>Engine: "+esc(s.engine_version)+" · "+esc(s.study_id)+"</p></details>";
 return out;
}
function comparisonRows(s){return s.candidates.map(c=>({Recipe:c.recipe_name,Active:c.active_name,"Active fraction":c.active_fraction,Status:c.status,Pareto:c.pareto?"Yes":"No",...Object.fromEntries(c.checks.map(v=>[v.scenario+":"+(v.metric_label||v.metric),v.value]))}));}
async function click(e){
 const b=e.target.closest("button");if(!b)return;
 if(b.hasAttribute("data-study-new"))await open();
 if(b.dataset.studyRevise)await open((await u.artifact(b.dataset.studyRevise)).payload);
 if(b.hasAttribute("data-study-csv")&&selectedStudy)u.download(selectedStudy.study_id+".csv",u.csv(comparisonRows(selectedStudy)),"text/csv");
 if(b.dataset.studyVariant){const a=u.latestArtifacts("recipe").find(a=>a.recipe_id===b.dataset.studyVariant);if(a)await window.FormulationLab.openRecipe((await u.artifact(a.artifact_id)).payload);}
 if(b.dataset.studyCriterionRemove!==undefined){const index=[...el("studyScenarios").querySelectorAll("[data-study-criterion]")].indexOf(b.closest("[data-study-criterion]"));draft=collect();draft.criteria.splice(index,1);renderEditor();}
 if(b.dataset.studyCriterionAdd){draft=collect();if(draft.criteria.length>=12)throw new Error("Choose at most twelve criteria.");const s=draft.scenarios.find(s=>s.id===b.dataset.studyCriterionAdd),m=model(s.model),metric=m.output_metrics.find(k=>!draft.criteria.some(c=>c.scenario===s.id&&c.metric===k));if(!metric)throw new Error("Every available output already has a criterion.");draft.criteria.push({scenario:s.id,metric,goal:primaryGoal(m),scale:1});renderEditor();}
 const action=b.dataset.studyInspect||b.dataset.studyRefine;
 if(action&&selectedStudy){
  const [i,sid]=action.split(":"),candidate=selectedStudy.candidates[Number(i)],entry=candidate.cases[sid];
  if(b.dataset.studyInspect)await window.FormulationLab.openSimulation(entry.model,{recipe_id:candidate.recipe_id,active_name:candidate.active_name,inputs:entry.inputs,assumptions:["Exact inputs copied from a design study; replay is an explicit scenario, not a new calibration."]});
  else{
   const m=model(entry.model),declared=selectedStudy.request.scenarios.find(s=>s.id===sid).candidate_parameters,fields=declared.length?declared:m.candidate_parameters,f=m.fields.find(f=>fields.includes(f.key)&&typeof entry.inputs[f.key]==="number"&&entry.inputs[f.key]>0);
   if(!f)throw new Error("Choose numerical material-property bounds in AI + physics design for this scenario.");
   const value=entry.inputs[f.key],criteria=selectedStudy.criteria.filter(c=>c.scenario===sid);
   const objectives=criteria.filter(c=>c.goal).map(c=>({metric:c.metric,goal:c.goal,scale:c.scale,...(c.goal==="target"?{target:c.target}:{})}));
   const constraints=criteria.filter(c=>c.minimum!==undefined||c.maximum!==undefined).map(c=>({metric:c.metric,...(c.minimum!==undefined?{minimum:c.minimum}:{}),...(c.maximum!==undefined?{maximum:c.maximum}:{})}));
   if(objectives.length>3||constraints.length>8)throw new Error("This scenario exceeds the optimizer’s limit of three objectives or eight specifications. Choose the intended scope explicitly in a revised study before opening the search.");
   await window.FormulationLab.openSimulation("inverse_design",{recipe_id:candidate.recipe_id,active_name:candidate.active_name,inputs:{base_model:entry.model,base_inputs:entry.inputs,variables:[{parameter:f.key,low:Math.max(f.min,value*.8),high:Math.min(f.max,value*1.2),scale:"linear"}],objectives:objectives.length?objectives:[{metric:criteria[0].metric,goal:"minimize",scale:1}],constraints,evaluations:24,seed:42},assumptions:["Initial ±20% property bounds and any default objective are editable assumptions.","All declared objectives and specifications for this scenario are transferred. This search covers one scenario only. Rerun the complete design study after a revision to check all model specifications."]});
  }
 }
}
document.addEventListener("change",e=>{if(u&&e.target.id==="studyChoice"){u.app.selected=e.target.value;u.viewPanel("design").catch(u.notify);}});
return {init,open,render,comparisonRows};
})();
