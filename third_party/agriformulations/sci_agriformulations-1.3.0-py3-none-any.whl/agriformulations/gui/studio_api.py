"""HTTP adapter for the local conversational formulation studio."""
import json
import time

def get(handler,path,query):
    studio=handler.server.sessions
    if path=="/api/studio/sessions":
        handler._json({"sessions":studio.list(),"has_active_runs":studio.runs.active})
    elif path=="/api/studio/research":
        handler._json(studio.research(query.get("session_id")))
    elif path=="/api/studio/catalogue":
        from ..rnd.simulation_catalog import catalogue
        from ..rnd.data_tools import KINDS
        from ..rnd.formulation_types import catalogue as formulation_types
        handler._json({"simulations":catalogue(),"dataset_types":KINDS,"formulation_types":formulation_types()})
    elif path=="/api/studio/datasets":
        handler._json({"datasets":studio.datasets(query.get("session_id"))})
    elif path=="/api/studio/dataset":
        from ..rnd.simulation_service import dataset
        session=studio._session(query.get("session_id"))
        state=studio.workspace.load(session["project_id"])["document"]
        handler._json(dataset(state,query.get("dataset_id")))
    elif path=="/api/studio/session":
        handler._json(studio.view(query.get("session_id")))
    elif path=="/api/studio/messages":
        handler._json({"messages":studio.messages(query.get("session_id"),query.get("before"))})
    elif path=="/api/studio/artifact":
        handler._json(studio.artifact(query.get("session_id"),query.get("artifact_id")))
    elif path=="/api/studio/run":
        sid=query.get("session_id")
        studio._session(sid)
        run=handler.server.agent_runs.get(query.get("run_id"),include_result=query.get("summary")!="true")
        if run.get("session_id")!=sid:
            raise ValueError("Run does not belong to this project")
        handler._json(run)
    elif path=="/api/studio/events":
        sid=query.get("session_id")
        studio._session(sid)
        after=int(handler.headers.get("Last-Event-ID") or query.get("after") or 0)
        handler.send_response(200)
        handler.send_header("Content-Type","text/event-stream")
        handler.send_header("Cache-Control","no-store")
        handler.send_header("Connection","close")
        handler.end_headers()
        deadline=time.monotonic()+25
        try:
            handler.wfile.write(b": connected\n\n")
            handler.wfile.flush()
            while time.monotonic()<deadline and not studio.closed:
                events=studio.events(sid,after)
                for event in events:
                    handler.wfile.write(("id: "+str(event["id"])+"\ndata: "+json.dumps(event)+"\n\n").encode())
                    after=event["id"]
                if events:
                    handler.wfile.flush()
                time.sleep(.2)
        except (BrokenPipeError,ConnectionResetError):
            pass
    else:
        return False
    return True

def post(handler,path,raw):
    studio=handler.server.sessions
    sid=raw.get("session_id")
    if path=="/api/studio/new":
        result=studio.create(raw.get("title") or "Untitled formulation")
    elif path=="/api/studio/research-search":
        result=studio.search_research(sid,raw.get("parameters"))
    elif path=="/api/studio/research-source":
        result=studio.save_research_source(sid,raw.get("search_id"),raw.get("record_id"),
            raw.get("notes",""),raw.get("status","saved"),raw.get("expected_revision"),raw.get("expected_source_version"),raw.get("evidence_stage"))
    elif path=="/api/studio/message":
        result=studio.enqueue(sid,raw.get("question"),raw.get("intent","auto"),raw.get("refs"),
            raw.get("request_id"),extra={"web_research":raw.get("web_research") is True})
    elif path=="/api/studio/stop":
        result=studio.stop(sid,raw.get("request_id"))
    elif path=="/api/studio/stop-all":
        result=studio.stop_all()
    elif path=="/api/studio/resume":
        result=studio.resume(sid,raw.get("run_id"))
    elif path=="/api/studio/rename":
        result=studio.rename(sid,raw.get("title"))
    elif path=="/api/studio/fork":
        result=studio.create(raw.get("title") or "Forked formulation",sid)
    elif path=="/api/studio/rerun":
        result=studio.rerun(sid,raw.get("artifact_id"),raw.get("overrides",{}))
    elif path=="/api/studio/recipe":
        result=studio.add_recipe(sid,raw.get("recipe",{}),raw.get("expected_revision"))
    elif path=="/api/studio/cost":
        result=studio.calculate_cost(sid,raw.get("cost",{}),raw.get("expected_revision"))
    elif path=="/api/studio/recipe-preview":
        from ..rnd.recipe_inputs import preview
        result=preview(raw.get("file",{}))
    elif path=="/api/studio/design-study":
        result=studio.design_study(sid,raw.get("study"))
    elif path=="/api/studio/simulate":
        result=studio.simulate(sid,raw.get("requests"))
    elif path=="/api/studio/fit":
        result=studio.fit_data(sid,raw.get("dataset_id"),raw.get("options"))
    elif path=="/api/studio/data-review":
        result=studio.review_data(sid,raw.get("dataset_id"),raw.get("review",{}),raw.get("expected_revision"))
    elif path=="/api/studio/import":
        result=studio.import_data(sid,raw.get("data",{}))
    elif path=="/api/studio/export":
        result=studio.export(sid)
    else:
        return False
    handler._json(result)
    return True

