"""Local R&D GUI server with validated scientific APIs and GPT agents.

Binds localhost by default; every endpoint validates its parameters
server-side and answers 400 with a message on bad input.  Browser assets and scientific engines are local. Configured GPT agents use
the server-side Codex connection by default, with an optional Responses API connection.
"""

from __future__ import annotations

import json
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from .compute import CAMPAIGN_PHASES, campaign_data, claim_scans, claim_state, degeneracy_data, simulate
from .page import PAGE
from .qa import answer as qa_answer
from ..rnd.api import bootstrap, dispatch
from ..rnd.workspace import Workspace, RevisionConflict
from ..rnd.codex_connection import AgentConnection
from ..rnd.runs import AgentRuns
from ..rnd.sessions import Sessions
from . import studio_api

ASSETS = Path(__file__).parent

CLAIM_KEYS = ("t1", "cap", "t2", "floor")


class GuiHandler(BaseHTTPRequestHandler):
    def _send(self, status: int, body: str, content_type: str) -> None:
        payload = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def _json(self, payload: dict, status: int = 200) -> None:
        self._send(status, json.dumps(payload, allow_nan=False), "application/json")

    def do_GET(self) -> None:  # noqa: N802 - stdlib naming
        route = urlsplit(self.path)
        query = {key: values[0] for key, values in parse_qs(route.query).items()}
        try:
            if route.path == "/" or route.path=="/workspace" or route.path.startswith("/workspace/"):
                self._send(200, (ASSETS / "studio.html").read_text(), "text/html; charset=utf-8")
            elif route.path=="/classic":
                self._send(200,(ASSETS/"workbench.html").read_text(),"text/html; charset=utf-8")
            elif route.path.startswith("/api/studio/") and studio_api.get(self,route.path,query):
                pass
            elif route.path == "/legacy":
                self._send(200, PAGE, "text/html; charset=utf-8")
            elif route.path in ("/assets/workbench.js", "/assets/workbench.css", "/assets/studio.js", "/assets/studio.css", "/assets/studio_lab.js", "/assets/studio_research.js", "/assets/studio_design.js", "/assets/studio_cost.js"):
                filename = route.path.rsplit("/", 1)[1]
                self._send(200, (ASSETS / filename).read_text(), "text/javascript; charset=utf-8" if filename.endswith(".js") else "text/css; charset=utf-8")
            elif route.path == "/api/rnd/bootstrap":
                self._json(bootstrap())
            elif route.path == "/api/rnd/projects":
                self._json(self.server.workspace.list())
            elif route.path == "/api/rnd/agent-runs":
                self._json({"runs":self.server.agent_runs.list(query.get("project_id"),include_discussions=query.get("include_discussions")=="true")})
            elif route.path == "/api/rnd/agent-run":
                self._json(self.server.agent_runs.get(query.get("run_id")))
            elif route.path == "/api/rnd/agent-status":
                self._json(self.server.agent_connection.status())
            elif route.path == "/api/simulate":
                kernel = query.get("kernel", "zero_order")
                params = {
                    "plateau": query.get("plateau", 1.0),
                    "rate": query.get("rate"),
                    "k0": query.get("k0"),
                    "lag": query.get("lag", 0.0),
                }
                payload = simulate(kernel, params, t_max=query.get("t_max", 60.0), points=query.get("points", 200))
                if any(key in query for key in CLAIM_KEYS):
                    missing = [key for key in CLAIM_KEYS if key not in query]
                    if missing:
                        raise ValueError(f"claim requires all of {CLAIM_KEYS}; missing {missing}")
                    payload["claim"] = claim_state(
                        kernel, params,
                        {key: query[key] for key in CLAIM_KEYS},
                    )
                self._json(payload)
            elif route.path == "/api/claim":
                self._json(claim_scans(query))
            elif route.path == "/api/campaign":
                self._json(campaign_data(query.get("phase", "v10")))
            elif route.path == "/api/degeneracy":
                self._json(degeneracy_data())
            elif route.path == "/api/ask":
                question = query.get("q", "").strip()[:300]
                if not question:
                    raise ValueError("q (the question) is required")
                self._json(qa_answer(question))
            else:
                self._json({"error": f"unknown route {route.path!r}"}, status=404)
        except ValueError as exc:
            self._json({"error": str(exc)}, status=400)
        except Exception as exc:  # never drop a connection without a response
            self._json({"error": f"internal error: {exc}"}, status=500)

    def do_POST(self) -> None:
        try:
            origin = self.headers.get("Origin")
            if origin and urlsplit(origin).netloc != self.headers.get("Host"):
                self._json({"error": "Cross-origin writes are not permitted"}, status=403)
                return
            if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                self._json({"error": "Use application/json"}, status=415)
                return
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 8_000_000:
                self._json({"error": "Request must be between 1 byte and 8 MB"}, status=413)
                return
            path = urlsplit(self.path).path
            if not path.startswith(("/api/rnd/","/api/studio/")):
                self._json({"error": "Unknown route"}, status=404)
                return
            raw = json.loads(self.rfile.read(size))
            if not isinstance(raw,dict):
                raise ValueError("Request must be an object")
            if path.startswith("/api/studio/"):
                if not studio_api.post(self,path,raw):
                    self._json({"error":"Unknown studio route"},status=404)
                return
            action=path.rsplit("/",1)[1]
            if action=="agent-stop":
                self._json(self.server.agent_runs.cancel(raw.get("run_id")))
                return
            if action=="agent-stop-all":
                self._json(self.server.sessions.stop_all())
                return
            if action=="agent-start":
                self._json(self.server.agent_runs.start(raw))
                return
            if action=="agent-configure" and self.server.agent_runs.active:
                raise ValueError("Wait for the current investigation before changing the agent connection")
            self._json(dispatch(path.rsplit("/", 1)[1], raw, self.server.workspace, self.server.agent_connection))
        except RevisionConflict as exc:
            self._json({"error": str(exc)}, status=409)
        except (ValueError, TypeError, KeyError) as exc:
            self._json({"error": str(exc)}, status=400)
        except Exception as exc:
            self._json({"error": f"Internal workbench error: {exc}"}, status=500)

    def log_message(self, *args) -> None:  # quiet by default
        pass


def make_server(host: str = "127.0.0.1", port: int = 9173, workspace_path=None, agent_connection=None) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer((host, port), GuiHandler)
    server.agent_connection = agent_connection or AgentConnection()
    server.workspace = Workspace(workspace_path or ASSETS.parents[2] / "data/workbench/workspace.sqlite3")
    server.agent_runs = AgentRuns(server.workspace,server.agent_connection)
    server.sessions = Sessions(server.workspace,server.agent_runs)
    original_close=server.server_close
    def close():
        server.sessions.close()
        original_close()
    server.server_close=close
    server.sessions.recover()
    server.sessions.kick()
    return server
