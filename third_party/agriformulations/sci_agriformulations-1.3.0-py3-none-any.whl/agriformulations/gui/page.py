"""The self-contained GUI page (v12): one HTML template, inline CSS + JS.

Offline by construction: no external URLs, no CDN, no fetches beyond the
local API.  Colors are the dataviz-validated palette (docs/v12_protocol.md)
declared as CSS custom properties per theme - selected dark steps, not a
flip.  Text wears ink tokens; status colors always ship with an icon and
label; every chart has a crosshair or per-mark tooltip and a table view.
"""

PAGE = """<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>agriformulations - formulation design GUI</title>
<style>
:root[data-theme="light"]{
  color-scheme:light;
  --page:#f8faf7; --surface:#ffffff; --ink:#18352b; --ink-2:#4a6b5c; --muted:#7d948a;
  --grid:#e3ebe6; --baseline:#c6d4cb; --border:rgba(24,53,43,.12);
  --series-1:#0c7f5d; --series-2:#eb6834; --series-3:#2a78d6;
  --ord-1:#86b6ef; --ord-2:#3987e5; --ord-3:#1c5cab; --ord-4:#617b89;
  --good:#0ca30c; --warn:#b97b00; --crit:#d03b3b; --note:#e7efdf;
}
:root[data-theme="dark"]{
  color-scheme:dark;
  --page:#0f1713; --surface:#14201b; --ink:#e8efe9; --ink-2:#b7c8bf; --muted:#8ba398;
  --grid:#27362f; --baseline:#3a4a42; --border:rgba(232,239,233,.12);
  --series-1:#2f9d7f; --series-2:#d95926; --series-3:#3987e5;
  --ord-1:#3987e5; --ord-2:#256abf; --ord-3:#184f95; --ord-4:#a4b9c4;
  --good:#0ca30c; --warn:#fab219; --crit:#d03b3b; --note:#1c2a24;
}
body{font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;background:var(--page);color:var(--ink);margin:0;padding:24px}
main{max-width:1180px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px} h2{font-size:16px;margin:26px 0 10px;border-bottom:1px solid var(--baseline);padding-bottom:4px}
.sub{color:var(--ink-2);font-size:13px;margin:0 0 6px}
.note{padding:12px 14px;background:var(--note);border-left:4px solid var(--series-1);margin:14px 0;font-size:13px;border-radius:0 6px 6px 0}
.panel{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:16px;margin:12px 0}
.controls{display:flex;flex-wrap:wrap;gap:10px;align-items:end;margin-bottom:12px}
.controls label{font-size:12px;color:var(--ink-2);display:flex;flex-direction:column;gap:3px}
input,select{font:inherit;padding:5px 8px;border:1px solid var(--baseline);border-radius:6px;background:var(--surface);color:var(--ink);min-width:84px}
input:focus,select:focus{outline:2px solid var(--series-1);outline-offset:1px}
button{font:inherit;padding:6px 14px;border:1px solid var(--series-1);background:var(--series-1);color:#fff;border-radius:6px;cursor:pointer}
button.ghost{background:transparent;color:var(--series-1)}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}
.chip{display:inline-flex;gap:6px;align-items:center;padding:4px 10px;border-radius:999px;font-size:12.5px;border:1px solid var(--baseline);background:var(--surface)}
.chip.good{border-color:var(--good);color:var(--ink)} .chip.warn{border-color:var(--warn);color:var(--ink)} .chip.crit{border-color:var(--crit);color:var(--ink)}
.dot{width:9px;height:9px;border-radius:50%;display:inline-block}
.chart{position:relative;min-height:220px}
.tip{position:fixed;pointer-events:none;background:var(--surface);border:1px solid var(--baseline);border-radius:6px;padding:6px 9px;font-size:12px;color:var(--ink);box-shadow:0 2px 8px rgba(0,0,0,.12);display:none;z-index:9;max-width:280px}
table.data{border-collapse:collapse;font-size:12.5px;width:100%;margin:8px 0}
table.data th,table.data td{padding:4px 8px;text-align:right;border-bottom:1px solid var(--grid);font-variant-numeric:tabular-nums}
table.data th:first-child,table.data td:first-child{text-align:left}
table.data th{color:var(--ink-2);font-weight:600;position:sticky;top:0;background:var(--surface)}
.scroll{max-height:340px;overflow:auto;border:1px solid var(--grid);border-radius:6px}
.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--ink-2);margin:4px 0 8px}
.legend .key{display:inline-flex;gap:6px;align-items:center}
.footer{color:var(--muted);font-size:12px;margin-top:22px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:900px){.grid2{grid-template-columns:1fr}}
svg text{font-family:system-ui,sans-serif}
.err{color:var(--crit);font-size:13px;display:none}
</style>
</head>
<body>
<main>
<h1>Formulation design GUI</h1>
<p class="sub">A view over the deterministic engines (v12). Requirements in, simulation graphs out; every number comes from a verified kernel or a frozen phase export.</p>
<div class="note"><strong>Scope.</strong> Mechanistic/kernel feasibility and prior-art coverage flags only. Nothing here is an efficacy, toxicity, field-performance, patentability or freedom-to-operate claim; the standing not-comparable register and amendments A1/A2 apply. Human review gates are unchanged.</div>

<div class="controls">
  <label>theme<button class="ghost" id="themeBtn" onclick="toggleTheme()">toggle dark</button></label>
</div>

<h2>1. Release simulator</h2>
<div class="panel">
  <div class="controls">
    <label>kernel<select id="kernel" onchange="onKernelChange()"><option value="zero_order">zero-order (membrane)</option><option value="fickian">Fickian sphere</option></select></label>
    <label id="rateWrap" style="display:none">rate D/L&sup2; (/day)<input id="rate" type="number" step="any" value="0.02"></label>
    <label id="k0Wrap">k0 (/day)<input id="k0" type="number" step="any" value="0.03"></label>
    <label>lag (days)<input id="lag" type="number" step="any" value="2"></label>
    <label>plateau<input id="plateau" type="number" step="any" min="0" max="1" value="0.9"></label>
    <label>horizon (days)<input id="t_max" type="number" step="any" value="60"></label>
    <label><input type="checkbox" id="claimOn" checked> claim pair</label>
    <label>t1 (d)<input id="t1" type="number" step="any" value="5"></label>
    <label>&le; cap<input id="cap" type="number" step="any" value="0.2"></label>
    <label>t2 (d)<input id="t2" type="number" step="any" value="35"></label>
    <label>&ge; floor<input id="floor" type="number" step="any" value="0.8"></label>
    <button onclick="runSim()">simulate</button>
  </div>
  <div class="chips" id="simChips"></div>
  <div class="chart" id="simChart"></div>
  <div id="simTable"></div>
  <p class="err" id="simErr"></p>
</div>

<h2>2. Claim feasibility (both kernel families)</h2>
<div class="panel">
  <div class="controls">
    <label>t1 (d)<input id="ct1" type="number" step="any" value="5"></label>
    <label>cap<input id="ccap" type="number" step="any" value="0.2"></label>
    <label>t2 (d)<input id="ct2" type="number" step="any" value="35"></label>
    <label>floor<input id="cfloor" type="number" step="any" value="0.8"></label>
    <button onclick="runClaim()">scan</button>
  </div>
  <div class="chips" id="claimChips"></div>
  <div class="chart" id="claimChart"></div>
  <div id="claimTable"></div>
  <p class="err" id="claimErr"></p>
</div>

<h2>3. Campaign explorer</h2>
<div class="panel">
  <div class="controls">
    <label>campaign<select id="phase" onchange="runCampaign()"><option value="v10">v10 benzovindiflupyr</option><option value="v8">v8 sulfoxaflor</option></select></label>
  </div>
  <div class="grid2">
    <div><p class="sub">Concepts: novelty vs priority, by prior-art flag</p><div class="chart" id="flagChart"></div><div id="flagTable"></div></div>
    <div><p class="sub">Transferred regions (per day, log scale), by stereo regime</p><div class="chart" id="regionChart"></div><div id="regionTable"></div></div>
  </div>
  <p class="sub" style="margin-top:10px">Shortlist (frozen export, pending human review)</p>
  <div class="scroll"><table class="data" id="shortTable"></table></div>
  <p class="err" id="campErr"></p>
</div>

<h2>4. Identifiability: what total-release data cannot tell you</h2>
<div class="panel">
  <div class="chips" id="degChips"></div>
  <div class="chart" id="degChart"></div>
  <div id="degTable"></div>
  <p class="err" id="degErr"></p>
</div>

<h2>5. Ask the modules</h2>
<div class="panel">
  <p class="sub">Free-text questions, routed deterministically to the engines - every answer names its route and engine; unrecognized questions get the capability list, never an invented answer.</p>
  <div class="controls">
    <label style="flex:1;min-width:280px">question<input id="askInput" type="text" style="min-width:260px" placeholder="e.g. is &lt;=20% at 5 days and &gt;=80% at 35 days feasible?" onkeydown="if(event.key==='Enter')ask()"></label>
    <button onclick="ask()">ask</button>
  </div>
  <div class="chips" id="askExamples"></div>
  <div id="askOut"></div>
  <p class="err" id="askErr"></p>
</div>

<p class="footer">Offline &middot; stdlib server &middot; deterministic engines &middot; reproduce: python3 -m scripts.run_v12_gui --selftest</p>
</main>
<div class="tip" id="tip"></div>
<script>
"use strict";
const TIP = document.getElementById("tip");
const css = name => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
function toggleTheme(){
  const root = document.documentElement;
  root.dataset.theme = root.dataset.theme === "light" ? "dark" : "light";
  rerenderAll();
}
function showTip(html, ev){ TIP.innerHTML = html; TIP.style.display = "block"; TIP.style.left = (ev.clientX + 14) + "px"; TIP.style.top = (ev.clientY - 10) + "px"; }
function hideTip(){ TIP.style.display = "none"; }
function fmt(v, d){ if (v === null || v === undefined || v === "") return ""; if (typeof v !== "number") return String(v); if (v !== 0 && (Math.abs(v) < 1e-3 || Math.abs(v) >= 1e4)) return v.toExponential(2); return v.toFixed(d === undefined ? 3 : d); }
function esc(s){ return String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
function chip(kind, icon, text){ return '<span class="chip ' + kind + '"><span class="dot" style="background:var(--' + (kind === "good" ? "good" : kind === "warn" ? "warn" : "crit") + ')"></span>' + icon + " " + esc(text) + "</span>"; }
function err(id, message){ const node = document.getElementById(id); node.style.display = message ? "block" : "none"; node.textContent = message || ""; }
async function api(path){ const response = await fetch(path); const body = await response.json(); if (!response.ok) throw new Error(body.error || ("HTTP " + response.status)); return body; }

/* ---------- chart primitives (inline SVG, crosshair + tooltips) ---------- */
function lineChart(container, cfg){
  const W = Math.max(container.clientWidth || 640, 320), H = cfg.height || 260;
  const pad = {l: 56, r: 18, t: 14, b: 40};
  const xs = cfg.xs, ys = [];
  cfg.series.forEach(s => s.values.forEach(v => ys.push(v)));
  (cfg.guides || []).forEach(g => ys.push(g.y));
  let xMin = Math.min(...xs), xMax = Math.max(...xs);
  const yMin = 0, yMax = Math.min(Math.max(...ys) * 1.08 + 0.01, 1.0);
  const X = v => cfg.logX ? pad.l + (Math.log10(v) - Math.log10(xMin)) / (Math.log10(xMax) - Math.log10(xMin)) * (W - pad.l - pad.r) : pad.l + (v - xMin) / (xMax - xMin) * (W - pad.l - pad.r);
  const Y = v => H - pad.b - (v - yMin) / (yMax - yMin) * (H - pad.t - pad.b);
  let out = '<svg width="' + W + '" height="' + H + '" role="img" aria-label="' + esc(cfg.title || "line chart") + '">';
  for (let i = 0; i <= 4; i++){ const y = yMin + (yMax - yMin) * i / 4;
    out += '<line x1="' + pad.l + '" y1="' + Y(y) + '" x2="' + (W - pad.r) + '" y2="' + Y(y) + '" stroke="var(--grid)" stroke-width="1"/>';
    out += '<text x="' + (pad.l - 8) + '" y="' + (Y(y) + 4) + '" text-anchor="end" font-size="11" fill="var(--muted)">' + fmt(y, 2) + "</text>"; }
  const xTicks = 6;
  for (let i = 0; i <= xTicks; i++){ let v = cfg.logX ? Math.pow(10, Math.log10(xMin) + (Math.log10(xMax) - Math.log10(xMin)) * i / xTicks) : xMin + (xMax - xMin) * i / xTicks;
    out += '<text x="' + X(v) + '" y="' + (H - pad.b + 16) + '" text-anchor="middle" font-size="11" fill="var(--muted)">' + fmt(v, 2) + "</text>"; }
  out += '<text x="' + ((W - pad.r + pad.l) / 2) + '" y="' + (H - 4) + '" text-anchor="middle" font-size="11" fill="var(--ink-2)">' + esc(cfg.xLabel || "") + "</text>";
  (cfg.guides || []).forEach(g => { out += '<line x1="' + pad.l + '" y1="' + Y(g.y) + '" x2="' + (W - pad.r) + '" y2="' + Y(g.y) + '" stroke="' + (g.color || "var(--baseline)") + '" stroke-width="1.5" stroke-dasharray="6 4"/>';
    out += '<text x="' + (W - pad.r - 4) + '" y="' + (Y(g.y) - 5) + '" text-anchor="end" font-size="11" fill="var(--ink-2)">' + esc(g.label || "") + "</text>"; });
  (cfg.vlines || []).forEach(v => { out += '<line x1="' + X(v.x) + '" y1="' + pad.t + '" x2="' + X(v.x) + '" y2="' + (H - pad.b) + '" stroke="var(--baseline)" stroke-width="1.5" stroke-dasharray="4 4"/>';
    out += '<text x="' + (X(v.x) + 4) + '" y="' + (pad.t + 12) + '" font-size="11" fill="var(--ink-2)">' + esc(v.label || "") + "</text>"; });
  cfg.series.forEach(s => { let d = "";
    s.values.forEach((v, i) => { d += (i ? "L" : "M") + X(xs[i]).toFixed(1) + " " + Y(v).toFixed(1); });
    out += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2"' + (s.dash ? ' stroke-dasharray="7 5"' : "") + "/>"; });
  (cfg.annotations || []).forEach(a => { out += '<circle cx="' + X(a.x) + '" cy="' + Y(a.y) + '" r="5" fill="var(--surface)" stroke="' + a.color + '" stroke-width="2"/><text x="' + (X(a.x) + 8) + '" y="' + (Y(a.y) - 8) + '" font-size="11.5" font-weight="600" fill="var(--ink)">' + esc(a.text) + "</text>"; });
  out += '<line x1="' + pad.l + '" y1="' + (H - pad.b) + '" x2="' + (W - pad.r) + '" y2="' + (H - pad.b) + '" stroke="var(--baseline)" stroke-width="1"/>';
  out += '<rect id="xhair' + container.id + '" x="' + pad.l + '" y="' + pad.t + '" width="' + (W - pad.l - pad.r) + '" height="' + (H - pad.t - pad.b) + '" fill="transparent"/>';
  out += '<line id="ch' + container.id + '" x1="0" y1="' + pad.t + '" x2="0" y2="' + (H - pad.b) + '" stroke="var(--muted)" stroke-width="1" opacity="0"/>';
  out += "</svg>";
  if (cfg.series.length > 1){ out += '<div class="legend">' + cfg.series.map(s => '<span class="key"><span class="dot" style="background:' + s.color + '"></span>' + esc(s.label) + "</span>").join("") + "</div>"; }
  container.innerHTML = out;
  const svgEl = container.querySelector("svg"), hair = container.querySelector("#ch" + container.id);
  svgEl.addEventListener("mousemove", ev => {
    const rect = svgEl.getBoundingClientRect();
    const px = ev.clientX - rect.left;
    if (px < pad.l || px > W - pad.r){ hair.setAttribute("opacity", 0); hideTip(); return; }
    let best = 0, bestD = 1e18;
    xs.forEach((x, i) => { const d = Math.abs(X(x) - px); if (d < bestD){ bestD = d; best = i; } });
    hair.setAttribute("x1", X(xs[best])); hair.setAttribute("x2", X(xs[best])); hair.setAttribute("opacity", 0.6);
    showTip("<b>t = " + fmt(xs[best], 2) + " (" + esc(cfg.xLabel || "x") + ")</b><br>" + cfg.series.map(s => esc(s.label) + ": " + fmt(s.values[best], 4)).join("<br>"), ev);
  });
  svgEl.addEventListener("mouseleave", () => { hair.setAttribute("opacity", 0); hideTip(); });
}
function scatterChart(container, cfg){
  const W = Math.max(container.clientWidth || 480, 300), H = cfg.height || 280;
  const pad = {l: 52, r: 14, t: 14, b: 40};
  const pts = cfg.groups.flatMap(g => g.points);
  const xMin = Math.min(...pts.map(p => p.x)), xMax = Math.max(...pts.map(p => p.x));
  const yMin = 0, yMax = Math.max(...pts.map(p => p.y)) * 1.1 + 0.02;
  const X = v => pad.l + (v - xMin) / (xMax - xMin || 1) * (W - pad.l - pad.r);
  const Y = v => H - pad.b - (v - yMin) / (yMax - yMin) * (H - pad.t - pad.b);
  let out = '<svg width="' + W + '" height="' + H + '" role="img" aria-label="concept scatter">';
  for (let i = 0; i <= 4; i++){ const y = yMin + (yMax - yMin) * i / 4;
    out += '<line x1="' + pad.l + '" y1="' + Y(y) + '" x2="' + (W - pad.r) + '" y2="' + Y(y) + '" stroke="var(--grid)"/>';
    out += '<text x="' + (pad.l - 8) + '" y="' + (Y(y) + 4) + '" text-anchor="end" font-size="11" fill="var(--muted)">' + fmt(y, 2) + "</text>"; }
  for (let i = 0; i <= 4; i++){ const x = xMin + (xMax - xMin) * i / 4;
    out += '<text x="' + X(x) + '" y="' + (H - pad.b + 16) + '" text-anchor="middle" font-size="11" fill="var(--muted)">' + fmt(x, 2) + "</text>"; }
  out += '<text x="' + ((W - pad.r + pad.l) / 2) + '" y="' + (H - 4) + '" text-anchor="middle" font-size="11" fill="var(--ink-2)">' + esc(cfg.xLabel) + "</text>";
  out += '<text x="14" y="' + (H / 2) + '" font-size="11" fill="var(--ink-2)" transform="rotate(-90 14 ' + (H / 2) + ')" text-anchor="middle">' + esc(cfg.yLabel) + "</text>";
  const mark = (g, p) => {
    const cx = X(p.x), cy = Y(p.y), r = 5;
    if (g.shape === "triangle") return '<path d="M' + cx + " " + (cy - r) + " L" + (cx + r) + " " + (cy + r) + " L" + (cx - r) + " " + (cy + r) + ' Z" fill="' + g.color + '" stroke="var(--surface)" stroke-width="1.5" data-tip="' + esc(p.tip) + '"/>';
    if (g.shape === "cross") return '<path d="M' + (cx - r) + " " + (cy - r) + " L" + (cx + r) + " " + (cy + r) + " M" + (cx + r) + " " + (cy - r) + " L" + (cx - r) + " " + (cy + r) + '" stroke="' + g.color + '" stroke-width="2.5" stroke-linecap="round" data-tip="' + esc(p.tip) + '"/>';
    return '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + g.color + '" stroke="var(--surface)" stroke-width="1.5" data-tip="' + esc(p.tip) + '"/>';
  };
  cfg.groups.forEach(g => g.points.forEach(p => { out += mark(g, p); }));
  out += "</svg>";
  out += '<div class="legend">' + cfg.groups.map(g => '<span class="key"><span class="dot" style="background:' + g.color + '"></span>' + g.icon + " " + esc(g.label) + "</span>").join("") + "</div>";
  container.innerHTML = out;
  container.querySelectorAll("[data-tip]").forEach(node => {
    node.addEventListener("mousemove", ev => showTip(node.dataset.tip, ev));
    node.addEventListener("mouseleave", hideTip);
  });
}
function intervalChart(container, cfg){
  const rows = cfg.rows.filter(r => r.low && r.high);
  const W = Math.max(container.clientWidth || 480, 300), rowH = 20, pad = {l: 8, r: 18, t: 6, b: 34};
  const H = rows.length * rowH + pad.t + pad.b + 18;
  const lo = Math.min(...rows.map(r => r.low)), hi = Math.max(...rows.map(r => r.high));
  const X = v => pad.l + 200 + (Math.log10(v) - Math.log10(lo)) / (Math.log10(hi) - Math.log10(lo)) * (W - pad.l - 200 - pad.r);
  let out = '<svg width="' + W + '" height="' + H + '">';
  rows.forEach((r, i) => { const y = pad.t + i * rowH + rowH / 2;
    out += '<text x="0" y="' + (y + 4) + '" font-size="10.5" fill="var(--ink-2)" clip-path="none">' + esc(r.label.length > 34 ? r.label.slice(0, 33) + "&#8230;" : r.label) + "</text>";
    out += '<line x1="' + X(r.low) + '" y1="' + y + '" x2="' + X(r.high) + '" y2="' + y + '" stroke="' + r.color + '" stroke-width="3" stroke-linecap="round" data-tip="' + esc(r.tip) + '"/>'; });
  for (let i = 0; i <= 5; i++){ const v = Math.pow(10, Math.log10(lo) + (Math.log10(hi) - Math.log10(lo)) * i / 5);
    out += '<text x="' + X(v) + '" y="' + (H - pad.b + 14) + '" text-anchor="middle" font-size="10.5" fill="var(--muted)">' + (v < 0.01 ? v.toExponential(0) : fmt(v, 3)) + "</text>"; }
  out += '<text x="' + ((W + 190) / 2) + '" y="' + (H - 2) + '" text-anchor="middle" font-size="11" fill="var(--ink-2)">' + esc(cfg.xLabel) + "</text></svg>";
  container.innerHTML = out;
  container.querySelectorAll("[data-tip]").forEach(node => {
    node.addEventListener("mousemove", ev => showTip(node.dataset.tip, ev));
    node.addEventListener("mouseleave", hideTip);
  });
}
function barChart(container, cfg){
  const rows = cfg.rows;
  const W = Math.max(container.clientWidth || 640, 320), rowH = 26, pad = {t: 6, r: 60, b: 30};
  const labelCol = 230;
  const H = rows.length * rowH + pad.t + pad.b + 8;
  const hi = Math.max(...rows.map(r => r.value)) * 1.05 || 1;
  const X = v => labelCol + (v / hi) * (W - labelCol - pad.r);
  let out = '<svg width="' + W + '" height="' + H + '">';
  for (let i = 0; i <= 4; i++){ const v = hi * i / 4;
    out += '<line x1="' + X(v) + '" y1="' + pad.t + '" x2="' + X(v) + '" y2="' + (H - pad.b) + '" stroke="var(--grid)"/>';
    out += '<text x="' + X(v) + '" y="' + (H - pad.b + 14) + '" text-anchor="middle" font-size="10.5" fill="var(--muted)">' + fmt(v, 2) + "</text>"; }
  rows.forEach((r, i) => { const y = pad.t + i * rowH;
    out += '<text x="' + (labelCol - 10) + '" y="' + (y + rowH / 2 + 4) + '" text-anchor="end" font-size="10.5" fill="var(--ink-2)">' + esc(r.label.length > 36 ? r.label.slice(0, 35) + "&#8230;" : r.label) + "</text>";
    out += '<rect x="' + labelCol + '" y="' + (y + 5) + '" width="' + Math.max(X(r.value) - labelCol, 2) + '" height="' + (rowH - 10) + '" rx="4" fill="' + (r.color || "var(--series-1)") + '" data-tip="' + esc(r.tip || r.label + ": " + fmt(r.value)) + '"/>';
    out += '<text x="' + (X(r.value) + 6) + '" y="' + (y + rowH / 2 + 4) + '" font-size="11" fill="var(--ink)">' + fmt(r.value) + "</text>"; });
  out += '<text x="' + ((W + labelCol) / 2) + '" y="' + (H - 2) + '" text-anchor="middle" font-size="11" fill="var(--ink-2)">' + esc(cfg.xLabel) + "</text></svg>";
  container.innerHTML = out;
  container.querySelectorAll("[data-tip]").forEach(node => {
    node.addEventListener("mousemove", ev => showTip(node.dataset.tip, ev));
    node.addEventListener("mouseleave", hideTip);
  });
}
function dataTable(container, columns, rows, note){
  if (!rows.length){ container.innerHTML = '<p class="sub"><em>no rows</em></p>'; return; }
  let out = (note ? '<p class="sub">' + esc(note) + "</p>" : "") + '<div class="scroll"><table class="data"><thead><tr>';
  columns.forEach(c => out += "<th>" + esc(c) + "</th>");
  out += "</tr></thead><tbody>";
  rows.forEach(r => { out += "<tr>"; columns.forEach(c => out += "<td>" + (typeof r[c] === "number" ? fmt(r[c]) : esc(r[c] === null || r[c] === undefined ? "" : r[c])) + "</td>"); out += "</tr>"; });
  container.innerHTML = out + "</tbody></table></div>";
}

/* ---------- panels ---------- */
function onKernelChange(){
  const kernel = document.getElementById("kernel").value;
  document.getElementById("rateWrap").style.display = kernel === "fickian" ? "" : "none";
  document.getElementById("k0Wrap").style.display = kernel === "zero_order" ? "" : "none";
  document.getElementById("lag").disabled = kernel !== "zero_order";
}
async function runSim(){
  err("simErr", "");
  const kernel = document.getElementById("kernel").value;
  const q = new URLSearchParams({kernel, plateau: val("plateau"), t_max: val("t_max"), points: 240});
  if (kernel === "fickian") q.set("rate", val("rate")); else { q.set("k0", val("k0")); q.set("lag", val("lag")); }
  const useClaim = document.getElementById("claimOn").checked;
  if (useClaim){ ["t1", "cap", "t2", "floor"].forEach(k => q.set(k, val(k))); }
  let data;
  try { data = await api("/api/simulate?" + q); } catch (e){ err("simErr", e.message); return; }
  const chips = document.getElementById("simChips");
  let html = chip("good", "&#9679;", data.kernel + " kernel, " + Object.entries(data.params).map(([k, v]) => k + "=" + fmt(v, 4)).join(", "));
  const cfg = {
    xs: data.times, xLabel: "time (days)", yLabel: "released fraction",
    series: [{label: data.kernel + " release", color: "var(--series-1)", values: data.values}],
    height: 280,
  };
  if (useClaim && data.claim){
    const c = data.claim;
    cfg.vlines = [{x: c.t1, label: "t1=" + c.t1}, {x: c.t2, label: "t2=" + c.t2}];
    cfg.guides = [{y: c.cap, label: "cap " + c.cap, color: "var(--crit)"}, {y: c.floor, label: "floor " + c.floor, color: "var(--good)"}];
    html += c.pass ? chip("good", "&#10003;", "claim pair PASS (" + fmt(c.v_t1, 3) + " at t1, " + fmt(c.v_t2, 3) + " at t2)") : chip("crit", "&#10007;", "claim pair FAIL (" + (c.pass_t1 ? "t2 short: " + fmt(c.v_t2, 3) + " < " + c.floor : "t1 burst: " + fmt(c.v_t1, 3) + " > " + c.cap) + ")");
  }
  chips.innerHTML = html;
  lineChart(document.getElementById("simChart"), cfg);
  dataTable(document.getElementById("simTable"), ["t (d)", "released"], data.times.map((t, i) => ({"t (d)": +t.toFixed(3), "released": data.values[i]})), "table view (" + data.times.length + " rows shown truncated)");
}
async function runClaim(){
  err("claimErr", "");
  const q = new URLSearchParams({t1: val("ct1"), cap: val("ccap"), t2: val("ct2"), floor: val("cfloor")});
  let data;
  try { data = await api("/api/claim?" + q); } catch (e){ err("claimErr", e.message); return; }
  const f = data.fickian, z = data.zero_order;
  document.getElementById("claimChips").innerHTML =
    (f.verdict === "feasible" ? chip("good", "&#10003;", "Fickian family: feasible (" + f.n_feasible + " candidates)") : chip("crit", "&#10007;", "Fickian: " + f.verdict + " - scanned ceiling " + fmt(f.ceiling_t2, 3) + " at t2 (ratio bound &radic;(t2/t1)=" + fmt(f.ratio_bound_sqrt, 2) + ")")) +
    (z.verdict === "feasible" ? chip("good", "&#10003;", (z.corner.nonempty ? "zero-order membrane: feasible - k0 in [" + fmt(z.corner.k0_interval_per_day[0], 4) + ", " + fmt(z.corner.k0_interval_per_day[1], 4) + "] /d at lag 0, plateau 1" : "zero-order membrane: feasible with lag; see example specs")) : chip("crit", "&#10007;", "zero-order: infeasible"));
  lineChart(document.getElementById("claimChart"), {
    xs: f.series.rate, logX: true, xLabel: "Fickian rate D/L&sup2; (/day, log)", yLabel: "best achievable fraction at t2",
    series: [{label: "achievable t2 (best plateau)", color: "var(--series-1)", values: f.series.achieved_t2}],
    guides: [{y: data.claim.floor, label: "claim floor", color: "var(--good)"}],
    annotations: f.verdict === "infeasible_for_the_family" ? [{x: f.best_rate_per_day, y: f.ceiling_t2, color: "var(--crit)", text: "ceiling " + fmt(f.ceiling_t2, 3)}] : [],
    height: 260,
  });
  dataTable(document.getElementById("claimTable"),
    ["k0_per_day", "lag_days", "plateau", "release_t1", "release_t2"],
    z.examples, "zero-order example specs (corner family; from " + z.n_feasible + " feasible grid points)");
}
async function runCampaign(){
  err("campErr", "");
  const phase = document.getElementById("phase").value;
  let data;
  try { data = await api("/api/campaign?phase=" + phase); } catch (e){ err("campErr", e.message); return; }
  const byFlag = {clear: {label: "clear", color: "var(--good)", shape: "circle", icon: "&#9679;", points: []},
                  adjacent: {label: "adjacent", color: "var(--warn)", shape: "triangle", icon: "&#9650;", points: []},
                  blocked: {label: "blocked", color: "var(--crit)", shape: "cross", icon: "&#10007;", points: []}};
  data.concepts.forEach(r => { const g = byFlag[r.flag]; if (g) g.points.push({x: +r.novelty, y: +r.priority, tip: "<b>" + esc(r.concept_id) + "</b><br>flag: " + r.flag + "<br>S_nearest: " + fmt(r.S_nearest) + "<br>india: " + fmt(r.india) + "<br>compatibility: " + fmt(r.compatibility)}); });
  scatterChart(document.getElementById("flagChart"), {groups: Object.values(byFlag).filter(g => g.points.length), xLabel: "novelty (1 - S_nearest)", yLabel: "priority", height: 300});
  dataTable(document.getElementById("flagTable"), ["concept_id", "flag", "novelty", "priority"], data.concepts.map(r => ({concept_id: r.concept_id, flag: r.flag, novelty: r.novelty, priority: r.priority})), "table view");
  const ordColor = {match: "var(--ord-1)", related: "var(--ord-2)", cross_class: "var(--ord-3)"};
  const rows = data.concepts.filter(r => r.region_low_per_day && r.region_high_per_day).map(r => ({
    label: r.concept_id, low: +r.region_low_per_day, high: +r.region_high_per_day,
    color: ordColor[r.stereo_regime] || "var(--muted)",
    tip: "<b>" + esc(r.concept_id) + "</b><br>analogue: " + esc(r.analogue || "") + "<br>stereo regime: " + esc(r.stereo_regime || "n/a (v8 export)") + "<br>w=" + fmt(r.w) + "<br>region [" + r.region_low_per_day.toExponential(2) + ", " + r.region_high_per_day.toExponential(2) + "] /d",
  })).sort((a, b) => a.label.localeCompare(b.label)).slice(0, 24);
  intervalChart(document.getElementById("regionChart"), {rows, xLabel: "transferred rate region (/day, log)"});
  dataTable(document.getElementById("regionTable"), ["concept_id", "analogue", "stereo_regime", "region_low_per_day", "region_high_per_day"], data.concepts.filter(r => r.region_low_per_day).map(r => ({concept_id: r.concept_id, analogue: r.analogue, stereo_regime: r.stereo_regime, region_low_per_day: r.region_low_per_day, region_high_per_day: r.region_high_per_day})), "table view");
  const cols = ["concept_id", "direction", "format", "enrichment", "flag", "S_nearest", "india", "compatibility", "feasibility", "priority"].filter(c => c in data.shortlist[0] || data.shortlist.some(r => c in r));
  dataTable({innerHTML: ""}, [], []);
  const st = document.getElementById("shortTable");
  let head = "<thead><tr>" + cols.map(c => "<th>" + esc(c) + "</th>").join("") + "</tr></thead><tbody>";
  data.shortlist.forEach(r => { head += "<tr>" + cols.map(c => "<td>" + (typeof r[c] === "number" ? fmt(r[c]) : esc(r[c] ?? "")) + "</td>").join("") + "</tr>"; });
  st.innerHTML = head + "</tbody>";
}
async function runDegeneracy(){
  err("degErr", "");
  let data;
  try { data = await api("/api/degeneracy"); } catch (e){ err("degErr", e.message); return; }
  document.getElementById("degChips").innerHTML =
    chip(data.verdict === "jointly_unidentifiable" ? "warn" : "good", "&#9650;", "total curve: " + data.verdict + " (" + data.n_passing_triples_campaign_tolerance + " triples @0.05, " + data.n_passing_triples_strict + " @0.02)") +
    chip("good", "&#10003;", "resolved curves identify both rates (v9 gate 12/12)") +
    chip("warn", "&#9650;", "effective rate only: " + fmt(data.effective_rate_per_hour, 4) + " /h");
  lineChart(document.getElementById("degChart"), {
    xs: data.observed.times, xLabel: "time (hours)", yLabel: "released fraction (total)",
    series: [{label: "observed total", color: "var(--series-1)", values: data.observed.values}].concat(
      data.alternatives.map((a, i) => ({label: "degenerate alternative " + (i + 1), color: "var(--ord-" + (i + 2) + ")", values: a.values, dash: true}))),
    height: 280,
  });
  dataTable(document.getElementById("degTable"), ["verdict", "n_triples_0.05", "n_triples_0.02", "effective_rate_per_hour"],
    [{verdict: data.verdict, "n_triples_0.05": data.n_passing_triples_campaign_tolerance, "n_triples_0.02": data.n_passing_triples_strict, "effective_rate_per_hour": data.effective_rate_per_hour}], "table view");
}
function val(id){ return document.getElementById(id).value; }
const ASK_ICONS = {good: "&#10003;", warn: "&#9650;", crit: "&#10007;"};
async function ask(question){
  err("askErr", "");
  const q = (question || document.getElementById("askInput").value).trim();
  if (!q) return;
  document.getElementById("askInput").value = q;
  let payload;
  try { payload = await api("/api/ask?q=" + encodeURIComponent(q)); } catch (e){ err("askErr", e.message); return; }
  const out = document.getElementById("askOut");
  const block = document.createElement("div");
  block.className = "ask-answer";
  block.style.borderTop = "1px solid var(--grid)";
  block.style.padding = "10px 0";
  let html = '<p class="sub"><b>Q:</b> ' + esc(q) + '</p><p style="margin:4px 0">' + esc(payload.answer) + "</p>";
  if (payload.chips && payload.chips.length){
    html += '<div class="chips">' + payload.chips.map(c => chip(c.kind, ASK_ICONS[c.kind] || "&#9679;", c.text)).join("") + "</div>";
  }
  block.innerHTML = html;
  out.insertBefore(block, out.firstChild);
  if (payload.chart){
    const chartDiv = document.createElement("div"); chartDiv.className = "chart"; block.appendChild(chartDiv);
    if (payload.chart.type === "line") lineChart(chartDiv, payload.chart.cfg);
    else if (payload.chart.type === "interval") intervalChart(chartDiv, payload.chart.cfg);
    else if (payload.chart.type === "bar") barChart(chartDiv, payload.chart.cfg);
  }
  if (payload.table && payload.table.rows && payload.table.rows.length){
    const tableDiv = document.createElement("div"); block.appendChild(tableDiv);
    dataTable(tableDiv, payload.table.columns, payload.table.rows, "table view");
  }
  if (payload.engine){
    const note = document.createElement("p"); note.className = "sub"; note.style.color = "var(--muted)";
    note.textContent = "computed by: " + payload.engine + " (route: " + payload.route + ")";
    block.appendChild(note);
  }
  if (payload.examples && payload.examples.length){
    document.getElementById("askExamples").innerHTML = payload.examples.map(ex =>
      '<button class="ghost" style="font-size:12px;padding:3px 10px;margin:2px" onclick="ask(' + JSON.stringify(ex).replace(/"/g, "&quot;") + ')">' + esc(ex.length > 62 ? ex.slice(0, 61) + "&#8230;" : ex) + "</button>").join("");
  }
  while (out.children.length > 6) out.removeChild(out.lastChild);
}
async function loadAskExamples(){
  try { await ask("help"); } catch (e){ /* non-fatal */ }
  document.getElementById("askOut").innerHTML = "";
}
function rerenderAll(){ runSim(); runClaim(); runCampaign(); runDegeneracy(); }
window.addEventListener("resize", () => rerenderAll());
onKernelChange(); rerenderAll(); loadAskExamples();
</script>
</body>
</html>
"""
