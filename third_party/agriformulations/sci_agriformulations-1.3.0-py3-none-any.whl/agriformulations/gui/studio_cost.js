"use strict";
window.FormulationCost=(()=>{
let u,recipe=null,session=null,previous=null;
const fields={yield_pct:"Saleable yield (%)",processing_per_input_kg:"Processing / input kg",packaging_per_saleable_kg:"Packaging / saleable kg",fixed_batch_cost:"Fixed cost / batch",overhead_pct:"Manufacturing overhead (%)",freight_per_batch:"Freight / batch",tax_pct:"Tax scenario (%)",pack_size_kg:"Pack size (kg, optional)"};
const el=id=>document.getElementById(id);
const money=v=>v===null||v===undefined?"Unavailable":u.fmt(v);
async function latest(){const all=await Promise.all(u.latestArtifacts("cost").map(a=>u.artifact(a.artifact_id)));return new Map(all.map(a=>[a.recipe_id,a.payload]));}
function summary(r,cost){
 const c=cost?.result||r.cost_estimate,esc=u.esc;
 let html="<p class='subtle-note'>"+esc(r.design_family?"Design family: "+r.design_family:"Composition variant within declared ingredient bounds")+"</p>";
 if(c){if(c.ingredients.some(i=>i.price_estimate))html+="<p class='scenario-note'>Indicative prices include estimates or grade/pack-size proxies. Branded-product assumptions may be unverified; inspect the price basis and confidence below.</p>";const range=c.ranges.final_cost_per_saleable_kg;html+="<div class='lab-source-note'><b>"+esc(c.currency)+" "+money(c.final_cost_per_saleable_kg)+" / saleable kg</b> · Materials: "+money(c.material_cost_per_input_kg)+" / input kg"+(range?" · Price scenario: "+money(range.low)+"–"+money(range.high):"")+"<br>Batch: "+money(c.final_batch_cost)+(c.cost_per_pack!==null?" · Pack: "+money(c.cost_per_pack):"")+"</div>";
  if(c.missing_ingredients.length||c.missing_assumptions.length)html+="<p class='scenario-note'>Missing prices: "+esc(c.missing_ingredients.join(", ")||"none")+". Missing production assumptions: "+esc(c.missing_assumptions.join(", ")||"none")+". Known materials subtotal: "+money(c.known_material_subtotal_per_input_kg)+" "+esc(c.currency)+" / input kg.</p>";
  html+="<details class='input-details'><summary>Cost breakdown, price sources & assumptions</summary>"+u.table(c.ingredients.map(i=>({Ingredient:i.name,"Input kg":i.input_mass_kg,"Unit price / kg":i.price_per_kg?.base??null,"Batch contribution":i.material_cost_batch?.base??null,Basis:i.price_origin,Confidence:i.price_estimate?.confidence||"user input","Price assumption":i.price_estimate?.basis||"declared unit price","Grade / scale":i.price_estimate?.grade_note||""})))+"<p class='scenario-note'>"+esc(c.range_basis)+" "+esc(c.evidence)+"</p><pre>"+esc(JSON.stringify({assumptions:c.assumptions,prices:c.ingredients.map(i=>({name:i.name,estimate:i.price_estimate})),notes:cost?.inputs.notes||[],basis:c.basis,exclusions:c.exclusions},null,2))+"</pre></details>";
 }else html+="<p class='scenario-note'>INR cost estimate pending. Add ingredient prices or ask the agent for indicative India prices.</p>";
 return html+"<div class='card-actions'><button class='button' data-cost-open='"+esc(r.recipe_id)+"'>Calculate / edit cost</button><button class='button' data-cost-agent='"+esc(r.recipe_id)+"'>Estimate India prices with agent</button><button class='button' data-diverse-recipes='"+esc(r.recipe_id)+"'>Suggest diverse alternatives</button></div>";
}
async function open(r,entry){
 recipe=r;session=u.app.session;previous=entry||null;
 el("costTitle").textContent="Estimated cost · "+r.name;el("costError").hidden=true;
 el("costCurrency").value=entry?.result.currency||(r.currency?.length===3?r.currency:"INR");
 const assumptions=entry?.result.assumptions||r.cost_estimate?.assumptions||{};
 el("costAssumptions").innerHTML=Object.entries(fields).map(([k,v])=>"<label>"+u.esc(v)+"<input data-cost-assumption='"+k+"' type='number' min='"+(k==="yield_pct"?".001":"0")+"' "+(k==="yield_pct"?"max='100' ":"")+"step='any' value='"+u.esc(assumptions[k]??"")+"' placeholder='Unknown'></label>").join("");
 el("costRows").innerHTML=r.ingredients.map((i,index)=>{const saved=entry?.inputs.recipe.ingredients.find(j=>j.name===i.name)||i,estimate=saved.price_estimate,price=saved.cost_per_kg;
  const input=(key,value)=>"<input data-cost-price='"+key+"' type='number' min='0' step='any' value='"+u.esc(value??"")+"' placeholder='Unknown'>";
  return "<tr data-cost-row='"+index+"'><td>"+u.esc(i.name)+"<br><small>"+u.esc(u.fmt(i.pct))+"% w/w supplied grade</small></td><td>"+input("low",price??estimate?.low)+"</td><td>"+input("base",price??estimate?.base)+"</td><td>"+input("high",price??estimate?.high)+"</td><td><input data-cost-source value='"+u.esc(estimate?.source||"")+"' placeholder='Source URL or user estimate'><input data-cost-grade value='"+u.esc(estimate?.grade_note||"")+"' placeholder='Grade / pack-size caveat'></td></tr>";}).join("");
 el("costNotes").value=(entry?.inputs.notes||[]).join("\n");el("costDialog").showModal();
}
async function save(event){
 event.preventDefault();if(session!==u.app.session)throw new Error("This cost editor belongs to another project. Reopen it in the selected project.");
 const currency=el("costCurrency").value.trim().toUpperCase(),assumptions={currency},prices={};
 for(const input of el("costAssumptions").querySelectorAll("[data-cost-assumption]"))assumptions[input.dataset.costAssumption]=input.value===""?null:Number(input.value);
 for(const row of el("costRows").querySelectorAll("[data-cost-row]")){
  const item=recipe.ingredients[Number(row.dataset.costRow)],values={};for(const input of row.querySelectorAll("[data-cost-price]"))values[input.dataset.costPrice]=input.value===""?null:Number(input.value);
  if(values.base===null){if(values.low!==null||values.high!==null)throw new Error("Enter a base price for "+item.name);prices[item.name]={cost_per_kg:null};continue;}
  const original=previous?.inputs.recipe.ingredients.find(i=>i.name===item.name)||item;
  const source=row.querySelector("[data-cost-source]").value.trim(),grade=row.querySelector("[data-cost-grade]").value.trim();
  const unchanged=original.price_estimate&&["low","base","high"].every(k=>(values[k]??values.base)===(original.price_estimate[k]??original.price_estimate.base))&&source===(original.price_estimate.source||"")&&grade===(original.price_estimate.grade_note||"")&&currency===original.price_estimate.currency;
  prices[item.name]={price_estimate:unchanged?structuredClone(original.price_estimate):{low:values.low??values.base,base:values.base,high:values.high??values.base,currency,source,grade_note:grade,basis:"User-edited indicative price scenario",confidence:"unverified",as_of:new Date().toISOString().slice(0,10)}};
 }
 await u.post("/api/studio/cost",{session_id:session,expected_revision:u.app.view.project.revision,cost:{recipe_id:recipe.recipe_id,prices,assumptions,notes:el("costNotes").value.split("\n").map(s=>s.trim()).filter(Boolean)}});
 el("costDialog").close();await u.refresh(true);await u.viewPanel("recipe");
}
async function click(event){
 const button=event.target.closest("button");if(!button)return;const rid=button.dataset.costOpen||button.dataset.costAgent||button.dataset.diverseRecipes;if(!rid)return;
 const a=u.latestArtifacts("recipe").find(a=>a.recipe_id===rid);if(!a)throw new Error("Recipe not found in the selected project.");const r=(await u.artifact(a.artifact_id)).payload;
 if(button.dataset.costOpen)return open(r,(await latest()).get(rid));
 if(button.dataset.diverseRecipes){await u.post("/api/studio/message",{session_id:u.app.session,question:"Suggest more diverse alternatives to recipe "+rid+" ("+r.name+"). Use create_recipe_portfolio to generate two or three scientifically motivated families with different excipient identities, three composition variants per family. Preserve the same individual active identities, pure-active loadings, batch size and formulation format. Explain the design hypothesis and unmeasured compatibility of each family; preserve existing recipes. Use INR when adding cost assumptions.",intent:"execute",refs:[a.artifact_id],web_research:true});await u.refresh(true);return;}
 await u.post("/api/studio/message",{session_id:u.app.session,question:"Estimate indicative INR prices in India and calculate final cost for recipe "+rid+" ("+r.name+"). Research technical-grade ingredient supplier listings and distinguish grade/pack-size proxies. Use editable low/base/high ranges with source URLs. Declare reasonable processing, packaging and yield assumptions explicitly, and use a pre-tax scenario (tax_pct=0, not a tax-rate claim). Save a cost scenario with calculate_formulation_cost; preserve recipe composition.",intent:"execute",refs:[a.artifact_id],web_research:true});
 await u.refresh(true);
}
async function init(context){u=context;el("costForm").onsubmit=u.safe(async e=>{try{await save(e);}catch(error){el("costError").textContent=error.message;el("costError").hidden=false;throw error;}});document.addEventListener("click",u.safe(click));}
return {init,latest,summary,open};
})();
