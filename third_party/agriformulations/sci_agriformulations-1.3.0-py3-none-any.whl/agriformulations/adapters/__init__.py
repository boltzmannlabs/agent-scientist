"""Internal-data adapters (v3): contract plus instrument implementations."""

from .base import AdapterContract, sha256_file
from .instruments import DissolutionExportAdapter, ELNGenericAdapter, PlateReaderAdapter

ADAPTERS = {
    "plate_reader": PlateReaderAdapter,
    "dissolution_export": DissolutionExportAdapter,
    "eln_generic": ELNGenericAdapter,
}


def run_adapter(config: dict, output_root, repo_root=None):
    """Instantiate and run the adapter named in ``config['adapter']``."""
    adapter_name = config.get("adapter")
    if adapter_name not in ADAPTERS:
        raise ValueError(f"unknown adapter {adapter_name!r}; known: {sorted(ADAPTERS)}")
    return ADAPTERS[adapter_name](config, output_root, repo_root).run()


__all__ = [
    "AdapterContract",
    "sha256_file",
    "PlateReaderAdapter",
    "DissolutionExportAdapter",
    "ELNGenericAdapter",
    "ADAPTERS",
    "run_adapter",
]
