"""Internal-data adapter contract (v3).

An adapter turns one instrument/ELN export into a study directory with the
same contract as literature studies: ``study.json`` (with source hashes and
``data_source: internal``), ``observations.csv``, ``claims.csv``.  Every
output row is stamped ``recorded_by: adapter:<name>``.  Agent-screened
ingests additionally require an APPROVED ``data_candidate`` proposal before
the adapter will run — the agent proposes, the human disposes.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from ..agents.runtime import require_approved


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


class AdapterContract:
    """Shared behaviour for internal adapters; subclasses fill ``ingest``."""

    name: str = "adapter:base"

    def __init__(self, config: dict, output_root: Path, repo_root: Path | None = None):
        self.config = config
        self.output_root = Path(output_root)
        self.repo_root = Path(repo_root) if repo_root else Path.cwd()

    def run(self) -> Path:
        config = self.config
        ingest_channel = config.get("ingest_channel", "direct_human")
        if ingest_channel == "agent_screened_human_approved":
            require_approved(config["phase"], config["proposal_id"], root=self.repo_root)
        frame = self.ingest()
        study_dir = self.write_study(frame)
        return study_dir

    def ingest(self) -> pd.DataFrame:
        raise NotImplementedError

    def write_study(self, frame: pd.DataFrame) -> Path:
        config = self.config
        study_dir = self.output_root / config["study_key"]
        study_dir.mkdir(parents=True, exist_ok=True)
        frame = frame.copy()
        frame["recorded_by"] = self.name
        frame.to_csv(study_dir / "observations.csv", index=False)
        pd.DataFrame(config.get("claims", [])).to_csv(study_dir / "claims.csv", index=False)
        source_files = {
            Path(source).name: {
                "path": str(source),
                "sha256": sha256_file(self.repo_root / source if not Path(source).is_absolute() else source),
            }
            for source in config.get("sources", [])
        }
        study = {
            "schema_version": "1.0",
            "study_id": config["study_id"],
            "title": config.get("title", config["study_id"]),
            "authors": config.get("authors", "internal"),
            "year": config.get("year"),
            "domain": config.get("domain", "internal"),
            "data_source": "internal",
            "ingest_channel": config.get("ingest_channel", "direct_human"),
            "counts": {"release_means": int(len(frame))},
            "target_contract": config.get("target_contract", {}),
            "source_files": source_files,
            "protocols": config.get("protocols", []),
            "ontology": config.get("ontology", {}),
            "extraction": f"{self.name} from configured sources; no digitization",
            "limitations": config.get(
                "limitations",
                ["Internal data: excluded from public benchmark tracks by construction."],
            ),
        }
        with open(study_dir / "study.json", "w") as handle:
            json.dump(study, handle, indent=1, sort_keys=True)
        return study_dir
