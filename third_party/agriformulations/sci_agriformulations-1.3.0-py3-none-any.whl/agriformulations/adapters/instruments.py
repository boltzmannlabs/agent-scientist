"""Concrete internal adapters: plate reader, dissolution export, generic ELN (v3).

All three are config-driven (one ``ingest.json`` per batch) so new batches
need configuration, not code.  Each maps its native export onto the common
observation frame; nothing is imputed, missing wells stay missing, and the
raw export is hash-recorded in the emitted study.json.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .base import AdapterContract

COMMON_COLUMNS = [
    "study_id",
    "formulation_id",
    "condition_id",
    "curve_id",
    "time",
    "time_unit",
    "value",
    "unit",
    "condition_name",
    "replicate_id",
    "included_primary",
    "qc_status",
]


class PlateReaderAdapter(AdapterContract):
    """Plate-map CSV export: wells -> formulation/replicate, columns -> times.

    Config: ``well_map`` (well -> formulation_id), ``time_map`` (column name
    -> hours), ``replicate_map`` (well -> replicate id), unit, target.
    """

    name = "adapter:plate_reader"

    def ingest(self) -> pd.DataFrame:
        config = self.config
        raw = pd.read_csv(self._resolve(config["source"]))
        well_map = config["well_map"]
        time_map = config["time_map"]
        replicate_map = config.get("replicate_map", {})
        rows = []
        for _, row in raw.iterrows():
            well = str(row[config["well_column"]])
            if well not in well_map:
                continue  # wells outside the map are not silently recoded
            formulation = well_map[well]
            for column, hours in time_map.items():
                value = row.get(column)
                rows.append(
                    {
                        "study_id": config["study_id"],
                        "formulation_id": formulation,
                        "condition_id": config.get("condition_id", "plate"),
                        "curve_id": f"{config['study_id']}__{formulation}__{config.get('condition_id', 'plate')}",
                        "time": float(hours),
                        "time_unit": "h",
                        "value": float(value) if pd.notna(value) else None,
                        "unit": config["unit"],
                        "condition_name": config.get("condition_name", "plate reader release"),
                        "replicate_id": replicate_map.get(well, well),
                        "included_primary": bool(pd.notna(value)),
                        "qc_status": "accepted" if pd.notna(value) else "missing_well",
                    }
                )
        return pd.DataFrame(rows)[COMMON_COLUMNS]

    def _resolve(self, source: str) -> Path:
        path = Path(source)
        return path if path.is_absolute() else self.repo_root / path


class DissolutionExportAdapter(AdapterContract):
    """Instrument dissolution CSV/Excel: one row per (vessel, time).

    Config: ``vessel_map`` (vessel id -> formulation_id), column names for
    time/value/vessel, native time unit converted explicitly.
    """

    name = "adapter:dissolution_export"

    def ingest(self) -> pd.DataFrame:
        from ..units import convert_time

        config = self.config
        source = self._resolve(config["source"])
        raw = pd.read_excel(source) if source.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(source)
        vessel_map = config["vessel_map"]
        rows = []
        for _, row in raw.iterrows():
            vessel = str(row[config["vessel_column"]])
            if vessel not in vessel_map:
                continue
            formulation = vessel_map[vessel]
            native_time = float(row[config["time_column"]])
            hours = convert_time(native_time, config.get("native_time_unit", "h"), "h")
            value = row[config["value_column"]]
            rows.append(
                {
                    "study_id": config["study_id"],
                    "formulation_id": formulation,
                    "condition_id": config.get("condition_id", "dissolution"),
                    "curve_id": f"{config['study_id']}__{formulation}__{config.get('condition_id', 'dissolution')}",
                    "time": hours,
                    "time_unit": "h",
                    "value": float(value) if pd.notna(value) else None,
                    "unit": config["unit"],
                    "condition_name": config.get("condition_name", "dissolution apparatus"),
                    "replicate_id": vessel,
                    "included_primary": bool(pd.notna(value)),
                    "qc_status": "accepted" if pd.notna(value) else "missing_reading",
                }
            )
        return pd.DataFrame(rows)[COMMON_COLUMNS]

    def _resolve(self, source: str) -> Path:
        path = Path(source)
        return path if path.is_absolute() else self.repo_root / path


class ELNGenericAdapter(AdapterContract):
    """Column-mapped ELN/LIMS export via a JSON column map.

    Config: ``column_map`` mapping ELN column names onto the common frame;
    required mappings: formulation, condition, time, value, replicate.
    """

    name = "adapter:eln_generic"

    REQUIRED = ("formulation", "condition", "time", "value")

    def ingest(self) -> pd.DataFrame:
        config = self.config
        mapping = config["column_map"]
        missing = [key for key in self.REQUIRED if key not in mapping]
        if missing:
            raise ValueError(f"ELN column map lacks required mappings: {missing}")
        raw = pd.read_csv(self._resolve(config["source"]))
        rows = []
        for _, row in raw.iterrows():
            formulation = str(row[mapping["formulation"]])
            condition = str(row[mapping["condition"]])
            value = row[mapping["value"]]
            replicate = str(row[mapping["replicate"]]) if "replicate" in mapping else ""
            rows.append(
                {
                    "study_id": config["study_id"],
                    "formulation_id": formulation,
                    "condition_id": condition,
                    "curve_id": f"{config['study_id']}__{formulation}__{condition}",
                    "time": float(row[mapping["time"]]),
                    "time_unit": config.get("time_unit", "h"),
                    "value": float(value) if pd.notna(value) else None,
                    "unit": config["unit"],
                    "condition_name": config.get("condition_name", "ELN record"),
                    "replicate_id": replicate,
                    "included_primary": bool(pd.notna(value)),
                    "qc_status": str(row[mapping["qc"]]) if "qc" in mapping and pd.notna(row.get(mapping["qc"])) else "accepted",
                }
            )
        return pd.DataFrame(rows)[COMMON_COLUMNS]

    def _resolve(self, source: str) -> Path:
        path = Path(source)
        return path if path.is_absolute() else self.repo_root / path
