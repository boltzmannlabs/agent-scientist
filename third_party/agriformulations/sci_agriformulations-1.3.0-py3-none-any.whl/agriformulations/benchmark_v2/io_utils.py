"""Study loading, hashing and the pre-run source validation gate.

Every v2 study directory carries ``study.json``, ``observations.csv`` and
``claims.csv`` (plus optional replicate/photolysis frames).  Raw source files
are hashed inside ``study.json`` by the extraction adapters; ``run`` refuses
to fit anything until those hashes and the frozen execution-manifest hashes
match what is on disk.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()
DATA_V2 = REPO_ROOT / "data" / "v2"

STUDY_DIRECTORIES = {
    "crop": DATA_V2 / "crop",
    "herbicide": DATA_V2 / "herbicide",
    "fertilizer": DATA_V2 / "fertilizer",
}


def sha256_file(path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_study(study_key: str, directory: Path | None = None) -> dict:
    """Load one study's frames; returns a dict of DataFrames and metadata."""
    base = Path(directory) if directory else STUDY_DIRECTORIES[study_key]
    with open(base / "study.json") as handle:
        meta = json.load(handle)
    frames = {
        "observations": pd.read_csv(base / "observations.csv"),
        "claims": pd.read_csv(base / "claims.csv"),
    }
    for optional in (
        "release_replicates.csv",
        "photolysis.csv",
        "photolysis_replicates.csv",
        "recipe_endpoints.csv",
    ):
        path = base / optional
        if path.exists():
            frames[optional[:-4]] = pd.read_csv(path)
    # Normalize the curve key: studies without an explicit curve_id get one.
    obs = frames["observations"]
    if "curve_id" not in obs.columns:
        obs["curve_id"] = obs["formulation_id"].astype(str) + "|" + obs["condition_id"].astype(str)
    if "included_primary" not in obs.columns:
        obs["included_primary"] = True
    if "qc_status" not in obs.columns:
        obs["qc_status"] = "accepted"
    return {"study_key": study_key, "meta": meta, **frames}


def verify_study_sources(study: dict) -> list[dict]:
    """Verify raw source SHA-256 hashes recorded in study.json; raise on drift."""
    records = []
    meta = study["meta"]
    for name, entry in (meta.get("source_files") or {}).items():
        path = REPO_ROOT / entry["path"]
        if not path.exists():
            raise FileNotFoundError(f"{study['study_key']}: missing source {name}: {path}")
        actual = sha256_file(path)
        if actual != entry["sha256"]:
            raise ValueError(
                f"{study['study_key']}: source hash drift for {name}: "
                f"expected {entry['sha256']}, found {actual}"
            )
        records.append({"study": study["study_key"], "source": name, "sha256": actual})
    sha_map = meta.get("sha256") or {}
    for name, expected in sha_map.items():
        for candidate in (REPO_ROOT / "research").rglob(name):
            actual = sha256_file(candidate)
            if actual != expected:
                raise ValueError(
                    f"{study['study_key']}: source hash drift for {name}: "
                    f"expected {expected}, found {actual}"
                )
            records.append(
                {"study": study["study_key"], "source": name, "sha256": actual}
            )
            break
    return records
