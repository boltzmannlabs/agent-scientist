"""Forecast track: early-time to late-time curve prediction (docs/v2_protocol.md).

Per curve with at least eight unique observed times: an outer chronological
split reserves the last ~30% of times as an untouched test block.  Candidates
are selected ONLY on an inner chronological split of the outer training block
(inner MAE in native units, ties to fewer parameters then fixed order), the
selected candidate is refit on all outer training rows and scored on the test
block once.  The constant last-observed baseline and the fixed-hyperparameter
XGBoost comparator are scored on identical test rows.  Every fold, prediction,
failure and selection is exported.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .candidates import CandidateFailure, fit_candidate
from .evaluation import curve_first_metrics, paired_baseline_comparison, utility_verdict
from .gpu_models import XGBContext, build_feature_frame
from .splits import MIN_UNIQUE_TIMES, inner_split, outer_split, unique_times

BASELINE = "last_observed_baseline"


def modeling_rows(study: dict) -> pd.DataFrame:
    """Primary fitting rows: accepted QC, in-target curves only."""
    obs = study["observations"]
    frame = obs[obs["included_primary"].astype(bool) & (obs["qc_status"] == "accepted")].copy()
    if "in_target" in frame.columns:
        frame = frame[frame["in_target"].astype(bool)].copy()
    return frame


def _score_inner(
    fit_frame: pd.DataFrame,
    val_frame: pd.DataFrame,
    name: str,
    plateau_bound: float | None,
    val_times,
) -> tuple[float, dict]:
    fit = fit_candidate(fit_frame, name, plateau_bound)
    predicted = fit.predict(val_times)
    observed = np.array(
        [float(val_frame.loc[val_frame["time"] == t, "value"].mean()) for t in val_times],
        dtype=float,
    )
    return float(np.mean(np.abs(predicted - observed))), dict(fit.parameters)


def run_forecast_track(
    study: dict,
    *,
    plateau_bound: float | None = None,
    xgb: XGBContext | None = None,
    utility_threshold: float = 0.10,
) -> dict:
    """Execute the forecast track for one study; returns long frames."""
    study_id = study["meta"]["study_id"]
    study_key = study["study_key"]
    frame = modeling_rows(study)
    unit = frame["unit"].iloc[0] if "unit" in frame.columns else ""
    time_unit = frame["time_unit"].iloc[0] if "time_unit" in frame.columns else ""

    fold_rows, prediction_rows = [], []
    xgb_train_parts, xgb_test_parts = [], []
    for curve_id, curve in frame.groupby("curve_id", sort=True):
        times = unique_times(curve)
        common = {
            "study_id": study_id,
            "curve_id": curve_id,
            "condition_id": str(curve["condition_id"].iloc[0]),
            "formulation_id": str(curve["formulation_id"].iloc[0]),
            "n_unique_times": len(times),
            "n_replicate_rows": int(len(curve)),
        }
        if len(times) < MIN_UNIQUE_TIMES:
            fold_rows.append(
                {**common, "status": "ineligible_insufficient_unique_times", "selected_model": None}
            )
            continue
        train, test = outer_split(curve)
        inner_train, inner_val = inner_split(train)
        val_times = unique_times(inner_val)
        order = ["persistence", "linear_trend", "first_order_plateau", "weibull_plateau"]
        n_outer = len(unique_times(train))
        n_inner_fit = len(unique_times(inner_train))
        eligible = []
        if n_inner_fit >= 4:
            eligible.append("first_order_plateau")
        if n_outer >= 7 and n_inner_fit >= 5:
            eligible.append("weibull_plateau")
        names = ["persistence", "linear_trend", *eligible]

        inner_scores, failures = {}, []
        for name in names:
            try:
                score, params = _score_inner(inner_train, inner_val, name, plateau_bound, val_times)
                inner_scores[name] = {"inner_mae": score, "parameters": params}
            except CandidateFailure as exc:
                failures.append({"candidate": name, "reason": str(exc)})
        if not inner_scores:
            selected, status = "persistence", "fit_failure_fallback_baseline"
        else:
            ranked = sorted(
                inner_scores.items(),
                key=lambda kv: (kv[1]["inner_mae"], order.index(kv[0])),
            )
            selected, status = ranked[0][0], "selected"

        test_times = unique_times(test)
        observed_test = [
            float(test.loc[test["time"] == t, "value"].mean()) for t in test_times
        ]

        def emit(model_label, predicted, source, candidate=""):
            for t, obs_v, pred_v in zip(test_times, observed_test, predicted):
                prediction_rows.append(
                    {
                        "study_id": study_id,
                        "track": "forecast",
                        "model": model_label,
                        "candidate": candidate,
                        "curve_id": curve_id,
                        "condition_id": common["condition_id"],
                        "formulation_id": common["formulation_id"],
                        "time": t,
                        "time_unit": time_unit,
                        "observed": obs_v,
                        "predicted": float(pred_v),
                        "unit": unit,
                        "source": source,
                    }
                )

        try:
            final = fit_candidate(train, selected, plateau_bound)
            emit("selected_candidate", final.predict(test_times), "outer_test_once", candidate=selected)
        except CandidateFailure as exc:
            failures.append({"candidate": selected, "reason": f"final refit: {exc}"})
            selected, status = "persistence", "fit_failure_fallback_baseline"
            emit(
                "selected_candidate",
                fit_candidate(train, "persistence").predict(test_times),
                "baseline_fallback",
                candidate="persistence",
            )
        baseline = fit_candidate(train, "persistence")
        emit(BASELINE, baseline.predict(test_times), "baseline_identical_test_rows")

        fold_rows.append(
            {
                **common,
                "n_outer_train_times": n_outer,
                "n_inner_fit_times": n_inner_fit,
                "n_inner_val_times": len(val_times),
                "eligible_candidates": names,
                "selected_model": selected,
                "status": status,
                "inner_scores": str(inner_scores).replace("'", '"'),
                "failures": str(failures).replace("'", '"') if failures else "",
                "train_cutoff_time": max(unique_times(train)),
                "test_start_time": min(test_times),
            }
        )
        xgb_train_parts.append(train)
        xgb_test_parts.append(test)

    # Pooled within-study XGBoost comparator on the identical outer splits.
    if xgb is not None and xgb_train_parts:
        train_rows = pd.concat(xgb_train_parts, ignore_index=True)
        test_rows = pd.concat(xgb_test_parts, ignore_index=True)
        X_train = build_feature_frame(train_rows, study_key)
        X_test = build_feature_frame(test_rows, study_key, train_columns=list(X_train.columns))
        xgb.fit(X_train, train_rows["value"].astype(float).to_numpy())
        preds = xgb.predict(X_test)
        for (_, row), pred in zip(test_rows.iterrows(), preds):
            prediction_rows.append(
                {
                    "study_id": study_id,
                    "track": "forecast",
                    "model": "xgboost_fixed",
                    "candidate": "",
                    "curve_id": row["curve_id"],
                    "condition_id": str(row["condition_id"]),
                    "formulation_id": str(row["formulation_id"]),
                    "time": float(row["time"]),
                    "time_unit": time_unit,
                    "observed": float(row["value"]),
                    "predicted": float(pred),
                    "unit": unit,
                    "source": "pooled_within_study_same_outer_split",
                }
            )

    predictions = pd.DataFrame(prediction_rows)
    folds = pd.DataFrame(fold_rows)
    per_curve, summary = (None, None)
    if not predictions.empty:
        per_curve, summary = curve_first_metrics(predictions)
    selection_frequency = (
        folds.loc[folds["status"].isin(["selected", "fit_failure_fallback_baseline"])]
        .groupby(["study_id", "selected_model"], dropna=False)
        .size()
        .rename("n_curves")
        .reset_index()
    ) if not folds.empty else pd.DataFrame(columns=["study_id", "selected_model", "n_curves"])
    utility = {}
    if summary is not None and not summary.empty:
        base = summary.loc[summary["model"] == BASELINE]
        for model in summary["model"].unique():
            if model == BASELINE:
                continue
            row_m = summary.loc[summary["model"] == model].iloc[0]
            row_b = base.iloc[0]
            utility[model] = utility_verdict(row_m["mae"], row_b["mae"], utility_threshold)
    return {
        "folds": folds,
        "predictions": predictions,
        "per_curve": per_curve,
        "summary": summary,
        "selection_frequency": selection_frequency,
        "utility": utility,
    }
