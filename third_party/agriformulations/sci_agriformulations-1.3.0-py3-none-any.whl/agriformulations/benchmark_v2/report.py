"""House-style HTML report renderer for the v2 three-paper benchmark.

Follows the project's report conventions: one self-contained HTML file, a
single inline ``<style>`` block with the established palette, an honest
``.note`` verdict under the title, numbered sections, pandas ``to_html``
tables framed by interpretation paragraphs, relative PNG/CSV artifact links
joined by middle dots, and a closing reproduction section.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

STYLE = (
    "body{font:16px/1.6 system-ui;margin:35px auto;max-width:1160px;padding:0 24px;"
    "color:#18352b;background:#f8faf7}"
    "h1,h2{line-height:1.25}h2{margin-top:2em;border-bottom:1px solid #dbe4da;padding-bottom:4px}"
    "table{border-collapse:collapse;font-size:14px;background:#fff;margin:12px 0;max-width:100%}"
    "th,td{padding:5px 10px;text-align:right;border-bottom:1px solid #dbe4da}"
    "th:first-child,td:first-child{text-align:left}"
    "img{width:100%}code{background:#e7efdf;padding:1px 5px;border-radius:3px;font-size:14px}"
    "a{color:#126a52}.note{padding:15px;background:#e7efdf;border-left:4px solid #679448;margin:18px 0}"
    ".small{font-size:13px;color:#4a6b5c}"
)


def _table(frame: pd.DataFrame | None, columns=None, float_format="{:.4g}") -> str:
    if frame is None or frame.empty:
        return "<p class='small'><em>no rows</em></p>"
    if columns:
        frame = frame[columns]
    return frame.to_html(index=False, border=0, float_format=lambda x: float_format.format(x), na_rep="")


def render_report(
    out_dir: Path,
    *,
    manifest: dict,
    studies: dict,
    audit: pd.DataFrame,
    forecast_folds: pd.DataFrame,
    forecast_summary: pd.DataFrame,
    forecast_selections: pd.DataFrame,
    forecast_utility: dict,
    transfer_folds: pd.DataFrame,
    transfer_summary: pd.DataFrame,
    transfer_utility: dict,
    recipe_pilot: pd.DataFrame | None,
    physics_calibration: pd.DataFrame,
    gpu_record: dict,
    device: dict,
) -> Path:
    counts_rows = []
    for key, study in studies.items():
        obs = study["observations"]
        target = obs
        if "in_target" in obs.columns:
            target = obs[obs["in_target"].astype(bool)]
        counts_rows.append(
            {
                "study": study["meta"]["study_id"],
                "domain": key,
                "recipes": target["formulation_id"].nunique(),
                "conditions": target["condition_id"].nunique(),
                "curves": target["curve_id"].nunique(),
                "times_per_curve": target.groupby("curve_id")["time"].nunique().max(),
                "replicate_rows": int(len(study.get("release_replicates", target))),
                "claims": int(len(study["claims"])),
            }
        )
    counts = pd.DataFrame(counts_rows)

    audit_counts = (
        audit.groupby(["study_id", "verdict"]).size().unstack(fill_value=0).reset_index()
        if not audit.empty
        else pd.DataFrame()
    )
    disagreements = audit[audit["verdict"] == "disagreement_under_stated_analysis"]

    selection_cols = ["study_id", "selected_model", "n_curves"]
    forecast_cols = ["study_id", "model", "mae", "rmse", "bias", "n_curves"]
    transfer_cols = ["study_id", "model", "mae", "rmse", "bias", "n_curves"]
    utility_rows = [
        {"track": track, "study": study, "model": model, **record}
        for track, utility in (("forecast", forecast_utility), ("transfer", transfer_utility))
        for study, models in utility.items()
        for model, record in models.items()
    ]
    utility_frame = pd.DataFrame(utility_rows)

    blocked = transfer_folds[transfer_folds["status"] == "blocked"] if not transfer_folds.empty else pd.DataFrame()
    infeasible = forecast_folds[forecast_folds["status"] == "ineligible_insufficient_unique_times"] if not forecast_folds.empty else pd.DataFrame()

    gpu_summary = {
        "device": device.get("resolved", device.get("requested", "cpu")),
        "gpu_name": device.get("gpu_name"),
        "torch": device.get("torch_version"),
        "xgboost": device.get("xgboost_version"),
    }

    html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>v2 three-paper benchmark</title>
<style>{STYLE}</style>
</head>
<body>
<h1>Three-paper benchmark, version 2</h1>
<p>Frozen protocol <code>docs/v2_protocol.md</code>, executed {manifest['created_utc']}
with seed {manifest['seed']} on {gpu_summary['device']}{'' if not gpu_summary['gpu_name'] else ' (' + str(gpu_summary['gpu_name']) + ')'}.
Studies: Xiang et al. 2026 (<a href="https://doi.org/10.1038/s41467-026-73922-3">10.1038/s41467-026-73922-3</a>),
Tang et al. 2023 (<a href="https://doi.org/10.1038/s41467-023-41878-3">10.1038/s41467-023-41878-3</a>),
Paul et al. 2024 (<a href="https://doi.org/10.1038/s41598-024-53820-8">10.1038/s41598-024-53820-8</a>).
This page reports equation-matched audit results, held-out forecasts and condition-transfer
experiments on publisher source data.</p>

<div class="note"><strong>Outcome.</strong> {audit.get('verdict', pd.Series()).eq('reproduced_at_reporting_precision').sum()} claims reproduce at reporting precision and
{audit.get('verdict', pd.Series()).eq('approximately_consistent').sum()} are approximately consistent under exploratory tolerances;
{len(disagreements)} disagree under our stated analysis (a statement about our analysis, not proof of a paper error).
Forecast and transfer utility against the last-observed baseline is reported per study below.
Three papers are a diversity benchmark, not an external validation dataset.</div>

<h2>1. Scope, counts and frozen manifest</h2>
<p>Counts are reported per independent unit (recipes, conditions, curves, times, replicates);
repeated measurements never increase the number of independent formulations.</p>
{_table(counts)}
<p class="small">Frozen execution manifest with input hashes, split rules, candidates, fixed
hyperparameters and thresholds: <a href="execution_manifest.json">execution_manifest.json</a>.
Source SHA-256 hashes were verified against each study.json before any fitting.</p>

<h2>2. Claims audit</h2>
<p>Every registered claim carries a computed verdict. Tabulated exact claims agree within half
their final printed decimal; approximate claims use the declared exploratory tolerances
(5 percentage points for prose, max(claim tolerance, 5% of magnitude) for forecast scopes).</p>
{_table(audit_counts)}
<p>Registered disagreements and their basis:</p>
{_table(disagreements, columns=["study_id", "claim_id", "comparison_scope", "reported_value", "our_value", "verdict_basis"])}
<p class="small">Full audit: <a href="v2_claims_audit.csv">v2_claims_audit.csv</a></p>

<h2>3. Forecast track</h2>
<p>Curves with at least eight unique times were split chronologically: earliest 70% of times for
training, last 30% untouched for scoring. Candidates were selected only on an inner chronological
split (inner MAE in native units, ties to fewer parameters), refit on the full outer training
block and scored once. The constant last-observed baseline and the fixed-hyperparameter GPU
XGBoost comparator were scored on identical test rows. Weibull was ineligible on the 8-time
grids (needs at least seven outer-training times).</p>
<p>Candidate selection frequency:</p>
{_table(forecast_selections, columns=selection_cols)}
<p>Study-level metrics (curve-first aggregation, native units):</p>
{_table(forecast_summary, columns=forecast_cols)}
<p>Forecast utility versus the last-observed baseline (protocol threshold: at least 10% lower
study-level MAE):</p>
{_table(utility_frame[utility_frame["track"] == "forecast"] if not utility_frame.empty else None)}
{'' if infeasible.empty else '<p>Curves excluded from the forecast track:</p>' + _table(infeasible, columns=['study_id', 'curve_id', 'n_unique_times', 'status'])}
<p><img src="v2_forecast_example.png" alt="Observed release curves with held-out forecasts for representative curves of each study"></p>
<p class="small">Full exports: <a href="v2_forecast_folds.csv">folds</a> ·
<a href="v2_forecast_predictions.csv">predictions</a> ·
<a href="v2_forecast_summary.csv">summary</a></p>

<h2>4. Transfer track</h2>
<p>Complete conditions were held out (all times and replicates of the group stayed outside
training); feature vocabularies, scaling and the matched-time baseline used training groups
only. Formulation-level folds are exploratory two-fold experiments; incompatible targets and
single-recipe studies block their folds with recorded reasons.</p>
{_table(transfer_summary, columns=transfer_cols)}
<p>Transfer utility versus the matched-time-mean baseline:</p>
{_table(utility_frame[utility_frame["track"] == "transfer"] if not utility_frame.empty else None)}
<p>Blocked experiments:</p>
{_table(blocked, columns=["study_id", "fold_id", "blocked_reason"])}
<p><img src="v2_transfer_predictions.png" alt="Predicted versus observed values for held-out condition and formulation folds"></p>
<p class="small">Full exports: <a href="v2_transfer_folds.csv">folds</a> ·
<a href="v2_transfer_predictions.csv">predictions</a> ·
<a href="v2_transfer_summary.csv">summary</a>
{'' if recipe_pilot is None or recipe_pilot.empty else ' · <a href="v2_recipe_endpoint_pilot.csv">crop recipe-endpoint pilot</a>'}</p>

<h2>5. GPU physics and numerical verification</h2>
<p>Spherical-diffusion calibration per curve (D/R&sup2; identified jointly; not a measured
molecular diffusivity) and a synthetic rate-sensitivity sweep computed on the batched analytic
kernel, with an independent torch finite-volume PDE leg:</p>
{_table(physics_calibration, columns=["study_id", "curve_id", "rate_h_inverse", "r2", "n_points", "scale_note"])}
<p><img src="v2_physics_sweep.png" alt="Released fraction at the last observed time across calibrated rate ranges for each study"></p>
<p>Numerical gates: mass balance {gpu_record.get('verification', {}).get('fv_subset_shells80', {}).get('mass_balance_error')!r}
(maximum over scenarios, gate 1e-6); finite-volume versus analytic at 80 shells
{gpu_record.get('verification', {}).get('fv_subset_vs_analytic_max_abs')!r};
mesh errors {gpu_record.get('verify', {}).get('mesh_errors_vs_analytic')!r};
CPU/CUDA float64 agreement {gpu_record.get('verify', {}).get('cpu_cuda_agreement')!r}.</p>
<p class="small">Device, dtype, work counts and wall times: <a href="v2_gpu_execution.json">v2_gpu_execution.json</a> ·
<a href="v2_physics_calibration.csv">calibration</a> · <a href="v2_physics_sweep.csv">sweep</a></p>

<h2>6. Interpretation and reproduction</h2>
<p>This benchmark runs one reproducible command: source hashes are verified, the execution
manifest is frozen before fitting, every claim receives a verdict, and every forecast and
transfer prediction is exported. Utility verdicts below the 10% threshold are reported as
failures, not tuned away. Held-out condition scores must not be compared with calibration
R&sup2;. Release fits cannot validate biological efficacy or deployment readiness; plant,
pathogen, earthworm and germination endpoints are registered as not comparable.</p>
<p>Reproduce with <code>python3 -m scripts.run_v2_benchmark</code>
(add <code>--device cuda</code> to force the GPU; it fails loudly when unavailable).
The v1 case study and direct paper benchmark remain available via
<code>python3 -m scripts.reproduce</code>.</p>
<p class="small">Software and original data have separate rights; author/publisher attribution
and source licences are retained in the manifests. No licence for commercial redistribution of
source workbooks is asserted.</p>
</body>
</html>
"""
    out = Path(out_dir) / "v2_benchmark.html"
    out.write_text(html)
    return out
