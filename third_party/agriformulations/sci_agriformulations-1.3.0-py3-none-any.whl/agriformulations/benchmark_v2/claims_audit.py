"""Claims audit: computed verdicts for every registered claim (docs/v2_protocol.md).

Verdict vocabulary (frozen): ``reproduced_at_reporting_precision``,
``approximately_consistent``, ``disagreement_under_stated_analysis``,
``source_inconsistency``, ``not_comparable``, ``insufficient_information``.
Tabulated exact claims agree within half their final printed decimal unit;
approximate claims use the exploratory tolerances declared per claim.  A
disagreement is a statement about OUR stated analysis, never a claim that the
paper is wrong.  Endpoint claims are audited in two scopes: against the
extracted source data (transcription) and against the held-out forecast
(independent prediction with an exploratory 5%-of-magnitude tolerance).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

VERDICTS = (
    "reproduced_at_reporting_precision",
    "approximately_consistent",
    "disagreement_under_stated_analysis",
    "source_inconsistency",
    "not_comparable",
    "insufficient_information",
)

NOT_COMPARABLE_TYPES = {"target_mismatch", "different_assay"}
INCONSISTENT_STATUSES = {"source_inconsistency"}

APPROXIMATE_MASS_REL = 0.05
APPROXIMATE_PCT_PP = 5.0


def normalize_claims(study: dict) -> pd.DataFrame:
    """Unify the crop ledger (metric/absolute_tolerance) with the richer
    herbicide/fertilizer ledger (claim_id/claim_type/status/tolerance)."""
    claims = study["claims"].copy()
    if "claim_id" not in claims.columns:
        claims["claim_id"] = claims.apply(
            lambda r: "__".join(
                str(x) for x in (r.get("study_id"), r.get("formulation_id"), r.get("condition_id"), r.get("metric"))
            ),
            axis=1,
        )
    if "tolerance" not in claims.columns:
        claims["tolerance"] = claims.get("absolute_tolerance")
    if "claim_type" not in claims.columns:
        claims["claim_type"] = claims["metric"].map(
            lambda m: "endpoint_claim" if m == "cumulative_release" else "fit_statistic"
        )
    if "status" not in claims.columns:
        claims["status"] = ""
    if "claim_text" not in claims.columns:
        claims["claim_text"] = ""
    if "comparison_scope" not in claims.columns:
        claims["comparison_scope"] = ""
    for column in ("analyte", "metric"):
        if column not in claims.columns:
            claims[column] = ""
    return claims


def refit_photolysis(photolysis: pd.DataFrame) -> pd.DataFrame:
    """Unweighted NLS of exp(-k t) on source-data means including t=0, per
    formulation, in remaining-fraction space; R2 in original response space."""
    rows = []
    for formulation, group in photolysis.groupby("formulation_id", sort=True):
        frame = group.copy()
        frame["fraction"] = frame["value"].astype(float) / 100.0
        t = frame["time"].astype(float).to_numpy()
        y = frame["fraction"].to_numpy()

        def residual(log_k):
            return np.exp(-np.exp(log_k) * t) - y

        result = least_squares(residual, [np.log(0.1)], bounds=([-12.0], [6.0]))
        k = float(np.exp(result.x[0]))
        predicted = np.exp(-k * t)
        ss_res = float(np.sum((y - predicted) ** 2))
        ss_tot = float(np.sum((y - y.mean()) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
        rows.append(
            {
                "formulation_id": formulation,
                "photolysis_k": k,
                "photolysis_r2": r2,
                "photolysis_half_life": float(np.log(2.0) / k),
                "rmse_percentage_points": float(np.sqrt(np.mean((predicted - y) ** 2)) * 100.0),
                "method": "unweighted NLS exp(-kt) on source means incl t=0",
            }
        )
    return pd.DataFrame(rows)


def anova_at_time(replicates: pd.DataFrame, formulation: str, analyte: str, time: float) -> dict | None:
    """One-way ANOVA across pH groups on replicates at one time point."""
    query = replicates[
        (replicates["formulation_id"] == formulation)
        & (replicates.get("analyte", "") == analyte if "analyte" in replicates.columns else True)
        & (replicates["time"].astype(float) == float(time))
    ]
    groups = [g["value"].astype(float).to_numpy() for _, g in query.groupby("condition_id")]
    groups = [g for g in groups if len(g) >= 2]
    if len(groups) < 2:
        return None
    all_values = np.concatenate(groups)
    grand = all_values.mean()
    ss_between = sum(len(g) * (g.mean() - grand) ** 2 for g in groups)
    ss_within = sum(((g - g.mean()) ** 2).sum() for g in groups)
    df_between = len(groups) - 1
    df_within = len(all_values) - len(groups)
    if ss_within <= 0 or df_within <= 0:
        return None
    f_stat = (ss_between / df_between) / (ss_within / df_within)
    return {"F": float(f_stat), "ss_between": float(ss_between), "ss_within": float(ss_within)}


def _observed_mean(obs: pd.DataFrame, claim: pd.Series, time: float) -> tuple[float | None, str]:
    query = obs
    for column in ("formulation_id", "condition_id"):
        if claim.get(column) not in (None, "") and column in query.columns:
            query = query[query[column].astype(str) == str(claim[column])]
    if claim.get("analyte") not in (None, "") and "analyte" in query.columns:
        query = query[query["analyte"].astype(str) == str(claim["analyte"])]
    rows = query[query["time"].astype(float) == float(time)]
    if rows.empty:
        return None, "no extracted observation at claim time"
    return float(rows["value"].astype(float).mean()), "extracted source-data mean"


def _forecast_value(forecast: pd.DataFrame | None, obs: pd.DataFrame, claim: pd.Series, time: float):
    if forecast is None or forecast.empty:
        return None, "forecast track unavailable"
    query = obs
    for column in ("formulation_id", "condition_id"):
        if claim.get(column) not in (None, "") and column in query.columns:
            query = query[query[column].astype(str) == str(claim[column])]
    if claim.get("analyte") not in (None, "") and "analyte" in query.columns:
        query = query[query["analyte"].astype(str) == str(claim["analyte"])]
    curves = query["curve_id"].unique()
    rows = forecast[
        forecast["curve_id"].isin(curves)
        & (forecast["time"].astype(float) == float(time))
        & (forecast["model"] == "selected_candidate")
    ]
    if rows.empty:
        return None, "claim time not inside the held-out forecast test block"
    return float(rows["predicted"].astype(float).mean()), "selected-candidate held-out forecast"


def _verdict(within: bool, exact: bool) -> str:
    if within:
        return "reproduced_at_reporting_precision" if exact else "approximately_consistent"
    return "disagreement_under_stated_analysis"


def audit_study(
    study: dict,
    forecast_predictions: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Compute a verdict row (or rows) for every registered claim of one study."""
    claims = normalize_claims(study)
    obs = study["observations"]
    photolysis_fits = (
        refit_photolysis(study["photolysis"]) if "photolysis" in study else None
    )
    replicates = study.get("release_replicates")

    rows = []
    for _, claim in claims.iterrows():
        claim_type = str(claim["claim_type"])
        status = str(claim["status"])
        base = {
            "study_id": claim["study_id"],
            "claim_id": claim["claim_id"],
            "claim_type": claim_type,
            "metric": claim.get("metric", ""),
            "formulation_id": claim.get("formulation_id", ""),
            "condition_id": claim.get("condition_id", ""),
            "analyte": claim.get("analyte", ""),
            "reported_value": claim.get("reported_value"),
            "unit": claim.get("unit", ""),
            "source_locator": claim.get("source_locator", ""),
            "claim_text": str(claim.get("claim_text", ""))[:220],
        }
        if status in INCONSISTENT_STATUSES:
            rows.append(
                {**base, "comparison_scope": "registered_conflict", "our_value": None,
                 "abs_error": None, "tolerance_used": None,
                 "verdict": "source_inconsistency",
                 "verdict_basis": "registered source conflict; preserved without adjudication"}
            )
            continue
        if claim_type in NOT_COMPARABLE_TYPES or status == "not_comparable":
            rows.append(
                {**base, "comparison_scope": "not_comparable", "our_value": None,
                 "abs_error": None, "tolerance_used": None,
                 "verdict": "not_comparable",
                 "verdict_basis": str(claim.get("comparison_scope", "different assay or target"))}
            )
            continue

        if claim_type == "fit_statistic" and str(claim["metric"]) == "kp_n":
            # Korsmeyer-Peppas pair-consistency audit (Perera 2026 pattern):
            # apply the paper's own equation M_t/M_inf = k t^n to the REPORTED
            # (n, k) and flag physically impossible combinations.  Parameters
            # are never treated as observations; the audit computes, it does
            # not refit.
            n_value = float(claim["reported_value"])
            k_value = float(claim.get("auxiliary_k") or float("nan"))
            if not (np.isfinite(k_value) and k_value > 0 and n_value > 0):
                rows.append({**base, "comparison_scope": "model_consistency", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information",
                             "verdict_basis": "reported pair incomplete or nonpositive"})
                continue
            fraction_at_1h = k_value  # M(1 h) = k * 1^n
            t50_hours = float((0.5 / k_value) ** (1.0 / n_value))
            issues = []
            if fraction_at_1h > 1.0:
                issues.append(f"implied fraction {fraction_at_1h:.3g} at 1 h exceeds unity")
            if t50_hours < 1.0:
                issues.append(f"implied t50 {t50_hours:.3g} h is near-instant, contradicting sustained release")
            # NOTE: an extrapolated t50 beyond the 15-day assay is NOT flagged:
            # Korsmeyer-Peppas is an early-window fit and extrapolating it past
            # the measured range is expected, not contradictory.
            rows.append(
                {**base, "comparison_scope": "kp_model_consistency", "our_value": round(fraction_at_1h, 6),
                 "abs_error": None, "tolerance_used": None,
                 "verdict": "approximately_consistent" if not issues else "disagreement_under_stated_analysis",
                 "verdict_basis": (f"paper equation M=k t^n on reported n={n_value}, k={k_value}: "
                                   f"t50={t50_hours:.3g} h; " + ("; ".join(issues) if issues else "physically admissible pair"))}
            )
            continue

        if claim_type == "fit_statistic" and str(claim["metric"]).startswith("first_order"):  # release-model R2
            query = obs[obs["formulation_id"].astype(str) == str(claim["formulation_id"])]
            if claim.get("condition_id"):
                query = query[query["condition_id"].astype(str) == str(claim["condition_id"])]
            if query.empty:
                rows.append({**base, "comparison_scope": "equation_matched_refit", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information", "verdict_basis": "no observations for the claimed curve"})
                continue
            from .candidates import fit_candidate

            frame = query.sort_values("time")
            try:
                fit = fit_candidate(frame, "first_order_plateau")
            except Exception as exc:
                rows.append({**base, "comparison_scope": "equation_matched_refit", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information", "verdict_basis": f"refit failed: {exc}"})
                continue
            predicted = fit.predict(frame["time"].astype(float).tolist())
            observed = frame["value"].astype(float).to_numpy()
            ss_res = float(np.sum((observed - predicted) ** 2))
            ss_tot = float(np.sum((observed - observed.mean()) ** 2))
            our = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
            reported = float(claim["reported_value"])
            tol = float(claim["tolerance"])
            rows.append(
                {**base, "comparison_scope": "equation_matched_refit", "our_value": our,
                 "abs_error": abs(our - reported), "tolerance_used": tol,
                 "verdict": _verdict(abs(our - reported) <= tol, exact=True),
                 "verdict_basis": "unweighted first-order plateau refit on curve means; author weighting/subset unresolved"}
            )
            continue

        if claim_type == "fit_statistic":  # crop photolysis k / R2 / half-life
            row_fit = photolysis_fits[
                photolysis_fits["formulation_id"] == claim["formulation_id"]
            ]
            if row_fit.empty:
                rows.append({**base, "comparison_scope": "equation_matched_refit", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information", "verdict_basis": "no refit available"})
                continue
            our = float(row_fit.iloc[0][str(claim["metric"])])
            reported = float(claim["reported_value"])
            tol = float(claim["tolerance"])
            rows.append(
                {**base, "comparison_scope": "equation_matched_refit", "our_value": our,
                 "abs_error": abs(our - reported), "tolerance_used": tol,
                 "verdict": _verdict(abs(our - reported) <= tol, exact=True),
                 "verdict_basis": "unweighted NLS exp(-kt) on 8 source means incl t=0; author weighting convention unspecified"}
            )
            continue

        if claim_type == "approximate_duration":
            query = obs[obs["formulation_id"] == claim["formulation_id"]] if claim["formulation_id"] else obs
            if claim["condition_id"]:
                query = query[query["condition_id"].astype(str) == str(claim["condition_id"])]
            accepted = query[query["qc_status"] == "accepted"] if "qc_status" in query.columns else query
            if accepted.empty:
                rows.append({**base, "comparison_scope": "duration", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information", "verdict_basis": "no accepted observations"})
                continue
            our = float(accepted["time"].astype(float).max())
            reported = float(claim["reported_value"])
            tol = float(claim["tolerance"])
            rows.append(
                {**base, "comparison_scope": "last_observed_time", "our_value": our,
                 "abs_error": abs(our - reported), "tolerance_used": tol,
                 "verdict": _verdict(abs(our - reported) <= tol, exact=False),
                 "verdict_basis": "last accepted measurement time; not depletion time or half-life"}
            )
            continue

        if claim_type == "anova_F":
            if replicates is None:
                rows.append({**base, "comparison_scope": "anova_recomputation", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information", "verdict_basis": "no replicate frame"})
                continue
            stats = anova_at_time(replicates, claim["formulation_id"], claim.get("analyte", ""), float(claim["time"]))
            if stats is None:
                rows.append({**base, "comparison_scope": "anova_recomputation", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information",
                             "verdict_basis": "insufficient replicate groups at claim time"})
                continue
            reported = float(claim["reported_value"])
            tol = float(claim["tolerance"])
            abs_err = abs(stats["F"] - reported)
            approx_band = max(tol, APPROXIMATE_MASS_REL * abs(reported))
            rows.append(
                {**base, "comparison_scope": "anova_recomputation", "our_value": stats["F"],
                 "abs_error": abs_err, "tolerance_used": tol,
                 "verdict": _verdict(abs_err <= tol, exact=True) if abs_err <= tol
                 else ("approximately_consistent" if abs_err <= approx_band else "disagreement_under_stated_analysis"),
                 "verdict_basis": f"one-way ANOVA on 3 pH groups x 3 replicates at t={claim['time']}; "
                                  f"ss_between={stats['ss_between']:.2f}, ss_within={stats['ss_within']:.2f}"}
            )
            continue

        if claim_type in ("prose_inequality", "rank_claim", "agarose_below_50"):
            metric = str(claim.get("metric", ""))
            time_claim = float(claim.get("time") or 168.0)
            if metric.startswith("rank_"):
                pair = str(claim.get("comparison_scope", "CTA>CMA"))
                high, low = (pair.split(">") + [""])[:2] if ">" in pair else ("CTA_DN", "CMA_DN")
                claim_high = claim.copy()
                claim_high["formulation_id"] = high
                claim_low = claim.copy()
                claim_low["formulation_id"] = low
                our_high, _ = _observed_mean(obs, claim_high, time_claim)
                our_low, _ = _observed_mean(obs, claim_low, time_claim)
                if our_high is None or our_low is None:
                    rows.append({**base, "comparison_scope": "rank_at_168h", "our_value": None,
                                 "abs_error": None, "tolerance_used": None,
                                 "verdict": "insufficient_information", "verdict_basis": "missing endpoint means"})
                    continue
                difference = our_high - our_low
                rows.append(
                    {**base, "comparison_scope": f"{high}_minus_{low}_at_168h", "our_value": difference,
                     "abs_error": None, "tolerance_used": None,
                     "verdict": "approximately_consistent" if difference > 0 else "disagreement_under_stated_analysis",
                     "verdict_basis": f"{high} {our_high:.2f} vs {low} {our_low:.2f} percentage points at 168 h; "
                                      "endpoint-at-168h definition of the ranking"}
                )
                continue
            our, basis = _observed_mean(obs, claim, time_claim)
            if our is None:
                rows.append({**base, "comparison_scope": "prose_check", "our_value": None,
                             "abs_error": None, "tolerance_used": None,
                             "verdict": "insufficient_information", "verdict_basis": basis})
                continue
            threshold = float(claim["reported_value"])
            tol = APPROXIMATE_PCT_PP
            if metric.endswith("_gte"):
                holds = our >= threshold
            elif metric.endswith("_lte"):
                holds = our <= threshold
            else:
                holds = abs(our - threshold) <= tol
            rows.append(
                {**base, "comparison_scope": "prose_inequality_at_168h", "our_value": our,
                 "abs_error": abs(our - threshold), "tolerance_used": tol,
                 "verdict": "approximately_consistent" if holds else "disagreement_under_stated_analysis",
                 "verdict_basis": f"{basis}; prose threshold {threshold} {claim.get('unit', '')} (5 pp exploratory band)"}
            )
            continue

        # Endpoint claims: transcription and forecast scopes.
        time_claim = claim.get("time")
        if time_claim in (None, "") or pd.isna(time_claim):
            rows.append({**base, "comparison_scope": "endpoint", "our_value": None,
                         "abs_error": None, "tolerance_used": None,
                         "verdict": "insufficient_information", "verdict_basis": "claim has no time anchor"})
            continue
        time_claim = float(time_claim)
        reported = float(claim["reported_value"])
        tol = float(claim["tolerance"]) if claim["tolerance"] not in (None, "") else 0.0
        exact = claim_type == "tabulated_endpoint"
        our, basis = _observed_mean(obs, claim, time_claim)
        if our is None:
            rows.append({**base, "comparison_scope": "transcription", "our_value": None,
                         "abs_error": None, "tolerance_used": None,
                         "verdict": "insufficient_information", "verdict_basis": basis})
        else:
            rows.append(
                {**base, "comparison_scope": "transcription", "our_value": our,
                 "abs_error": abs(our - reported), "tolerance_used": tol,
                 "verdict": _verdict(abs(our - reported) <= tol, exact=exact), "verdict_basis": basis}
            )
        forecast_tol = max(tol, APPROXIMATE_MASS_REL * abs(reported))
        our_f, basis_f = _forecast_value(forecast_predictions, obs, claim, time_claim)
        if our_f is None:
            rows.append({**base, "comparison_scope": "forecast_heldout", "our_value": None,
                         "abs_error": None, "tolerance_used": None,
                         "verdict": "insufficient_information", "verdict_basis": basis_f})
        else:
            rows.append(
                {**base, "comparison_scope": "forecast_heldout", "our_value": our_f,
                 "abs_error": abs(our_f - reported), "tolerance_used": forecast_tol,
                 "verdict": _verdict(abs(our_f - reported) <= forecast_tol, exact=False),
                 "verdict_basis": f"{basis_f}; exploratory tolerance max(claim tol, 5% of magnitude)"}
            )
    return pd.DataFrame(rows)
