"""Batched GPU radial finite-volume diffusion (docs/v2_protocol.md).

A conservative radial finite-volume discretization of the dimensionless
diffusion problem ``dc/dtau = A c`` in ``tau = D t / R^2`` with a perfect-sink
outer boundary and zero flux at the center, advanced by explicit Euler in
float64 on torch.  The operator is conservative by construction, so the
inventory-depletion and boundary-flux accounts of released mass must agree to
roundoff; the protocol mass-balance gate is 1e-6.  Mesh (20/40/80 shells) and
time-step (dt_safety halved) convergence, agreement with the analytic
eigenmode series, torch CPU/CUDA float64 agreement (abs 1e-8, rel 1e-6) and
the difference to the independent scipy solver are all recorded.

Batch elements are (rate, time) scenarios sharing one dimensionless schedule;
each element records the released fraction at the tau targets its own
schedule reaches.  Scenario grids are synthetic sensitivity calculations, not
new experimental data (the v1 honesty rule).
"""

from __future__ import annotations

import time

import numpy as np


def _resolve_device(device: str):
    import torch

    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("explicit device='cuda' requested but CUDA is unavailable")
    resolved = "cuda" if device in ("auto", "cuda") and torch.cuda.is_available() else "cpu"
    return torch, resolved


def build_fv_operator(shells: int):
    """Conservative radial FV operator and cell volumes on ``shells`` uniform
    shells, in dimensionless tau units with a sink boundary at r = 1."""
    import torch

    h = 1.0 / shells
    edges = np.arange(shells + 1, dtype=float) * h
    centers = (np.arange(shells, dtype=float) + 0.5) * h
    face_area = edges**2  # the r = 0 face has zero area -> zero center flux
    volumes = centers**2 * h

    lower = np.zeros(shells)
    upper = np.zeros(shells)
    diag = np.zeros(shells)
    for i in range(shells):
        conduct_in = face_area[i] / h
        if i < shells - 1:
            conduct_out = face_area[i + 1] / h
            upper[i] = conduct_out / volumes[i]
        else:
            conduct_out = face_area[shells] / (h / 2.0)  # half cell out to the sink
        diag[i] = -(conduct_in + conduct_out) / volumes[i]
        if i > 0:
            lower[i] = conduct_in / volumes[i]
    operator = np.diag(lower[1:], -1) + np.diag(diag) + np.diag(upper[:-1], 1)
    return (
        torch.tensor(operator, dtype=torch.float64),
        torch.tensor(volumes, dtype=torch.float64),
    )


def batched_fv_release(rates, times, *, shells: int = 40, device: str = "auto", dt_safety: float = 0.5):
    """Released fraction ``F(rate_i * time_j)`` for every scenario, batched.

    Returns ``(fractions, metadata)`` with ``fractions[i, j]`` the released
    fraction of a uniform unit sphere after physical time ``times[j]`` at rate
    ``rates[i]``.
    """
    torch, resolved = _resolve_device(device)
    started = time.perf_counter()
    rates = np.asarray(rates, dtype=float)
    times = np.asarray(times, dtype=float)
    tau_matrix = np.outer(rates, times)
    tau_targets, inverse = np.unique(tau_matrix.ravel(), return_inverse=True)
    index_of = inverse.reshape(tau_matrix.shape)
    max_tau = tau_matrix.max(axis=1)

    operator, volumes = build_fv_operator(shells)
    operator = operator.to(resolved)
    volumes = volumes.to(resolved)
    weights = volumes / volumes.sum()

    eigenvalues = np.linalg.eigvals(operator.cpu().numpy())
    eigen_scale = float(np.max(np.abs(eigenvalues.real)))
    dt = float(dt_safety / eigen_scale)
    h = 1.0 / shells
    # Sink-face leak in inventory-fraction units: conductance / total volume.
    boundary_conductance = 1.0 / ((h / 2.0) * float(volumes.sum().item()))

    batch = len(rates)
    max_tau_t = torch.tensor(max_tau, dtype=torch.float64, device=resolved)
    state = torch.ones((batch, shells), dtype=torch.float64, device=resolved)
    flux_released = torch.zeros(batch, dtype=torch.float64, device=resolved)
    recorded = torch.full((batch, len(tau_targets)), float("nan"), dtype=torch.float64, device=resolved)

    steps_done = 0
    next_target = 0
    tau_now = 0.0
    while next_target < len(tau_targets):
        while next_target < len(tau_targets) and tau_now + 1e-12 >= tau_targets[next_target]:
            reached = max_tau_t >= tau_targets[next_target] - 1e-12
            recorded[reached, next_target] = flux_released[reached]
            next_target += 1
        if next_target >= len(tau_targets):
            break
        advance = min(dt, float(tau_targets[next_target] - tau_now))
        sink = state[:, -1]
        state = state + advance * (state @ operator.T)
        flux_released = flux_released + advance * boundary_conductance * sink
        tau_now += advance
        steps_done += 1

    released_inventory = 1.0 - (state * weights).sum(dim=1)
    mass_balance_error = float(torch.max(torch.abs(released_inventory - flux_released)).item())

    gathered = recorded.cpu().numpy()
    fractions = np.take_along_axis(gathered, index_of, axis=1)
    elapsed = time.perf_counter() - started
    metadata = {
        "solver": "explicit euler conservative radial finite volume, float64",
        "device": resolved,
        "shells": shells,
        "batch_scenarios": int(batch),
        "n_tau_targets": int(len(tau_targets)),
        "dt": dt,
        "dt_safety": dt_safety,
        "steps": steps_done,
        "max_tau": float(tau_targets[-1]),
        "mass_balance_error": mass_balance_error,
        "wall_s": round(elapsed, 4),
        "dtype": "float64",
    }
    return fractions, metadata


def _analytic_fractions(tau_row: np.ndarray) -> np.ndarray:
    from agriformulations.release import release_fraction

    return np.array(
        [float(release_fraction(float(t), "spherical_diffusion", {"rate": 1.0})) for t in tau_row]
    )


def verify_fv(device: str = "auto") -> dict:
    """Numerical gates for the FV leg: mass balance, mesh and time-step
    convergence, analytic agreement, torch CPU/CUDA agreement, scipy diff."""
    from agriformulations.release import release_fraction, sphere_finite_volume

    tau = np.array([0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 3.0])
    rates = np.geomspace(1e-3, 1.0, 4)
    # Scenario mapping: element i evaluates F(rate_i * tau_j); the analytic
    # reference applies the same rate -> dimensionless-time mapping.
    analytic = np.array(
        [[float(release_fraction(float(r * t), "spherical_diffusion", {"rate": 1.0})) for t in tau]
         for r in rates]
    )

    record: dict = {"tau_grid": tau.tolist(), "gates": {}}
    mesh_errors = {}
    mesh_grids = {}
    for shells in (20, 40, 80):
        grid, meta = batched_fv_release(rates, tau, shells=shells, device=device)
        mesh_grids[shells] = (grid, meta)
        mesh_errors[shells] = float(np.max(np.abs(grid - analytic)))
    record["mesh_errors_vs_analytic"] = mesh_errors
    record["gates"]["mesh_convergence"] = bool(
        mesh_errors[20] > mesh_errors[40] > mesh_errors[80]
    )
    record["gates"]["mass_balance"] = bool(
        all(meta["mass_balance_error"] <= 1e-6 for _, meta in mesh_grids.values())
    )
    record["shells80_metadata"] = mesh_grids[80][1]

    # Time-step convergence: halve dt_safety, compare released fractions.
    coarse, _ = batched_fv_release(rates[:1], tau, shells=80, device=device, dt_safety=0.5)
    fine, _ = batched_fv_release(rates[:1], tau, shells=80, device=device, dt_safety=0.25)
    dt_change = float(np.max(np.abs(coarse[0] - fine[0])))
    record["time_step_convergence"] = {
        "max_fraction_change_dt_safety_0p5_to_0p25": dt_change,
        "below_mesh_error": bool(dt_change < mesh_errors[80]),
    }

    # Same discretization on CPU and CUDA: protocol float64 agreement gate.
    try:
        cpu_grid, _ = batched_fv_release(rates[:2], tau, shells=40, device="cpu")
        cuda_grid, _ = batched_fv_release(rates[:2], tau, shells=40, device="cuda")
        abs_dev = float(np.max(np.abs(cpu_grid - cuda_grid)))
        rel_dev = float(np.max(np.abs(cpu_grid - cuda_grid) / np.maximum(np.abs(cpu_grid), 1e-12)))
        record["cpu_cuda_agreement"] = {
            "max_abs": abs_dev,
            "max_rel": rel_dev,
            "within_tolerance": bool(abs_dev <= 1e-8 and rel_dev <= 1e-6),
        }
        record["gates"]["cpu_cuda_float64"] = record["cpu_cuda_agreement"]["within_tolerance"]
    except RuntimeError:
        record["cpu_cuda_agreement"] = {"note": "CUDA unavailable; single-device execution"}

    # Independent scipy BDF solver at the same shell count: reported difference
    # between two discretization details, not a float-equality gate.  Compared
    # on the rate = 1 scenario where tau maps directly.
    scipy_ref = np.asarray(sphere_finite_volume(tau.tolist(), rate=1.0, shells=80), dtype=float)
    rate1_grid = mesh_grids[80][0][int(np.argmin(np.abs(rates - 1.0)))]
    record["scipy_fv80_max_abs_diff"] = float(np.max(np.abs(rate1_grid - scipy_ref)))
    return record


def calibration_sweep(studies: dict, *, device: str = "auto", grid: int = 128) -> tuple[dict, dict]:
    """Per-study spherical-diffusion calibration and a synthetic rate-sensitivity
    sweep on the analytic batched kernel, with a torch-FV verification subset."""
    from agriformulations.accelerated import batch_sphere_predictions
    from agriformulations.release import fit_release, release_fraction

    from .forecast import modeling_rows

    calibration = []
    sweep_outputs = {}
    for study_key, study in studies.items():
        frame = modeling_rows(study)
        scale = 100.0 if study_key in ("crop", "fertilizer") else 1000.0
        study_rates = []
        for curve_id, curve in frame.groupby("curve_id", sort=True):
            try:
                fit = fit_release(
                    curve["time"].astype(float).to_numpy(),
                    curve["value"].astype(float).to_numpy() / scale,
                    "spherical_diffusion",
                )
            except Exception:
                continue
            study_rates.append(float(fit.parameters["rate"]))
            calibration.append(
                {
                    "study_id": study["meta"]["study_id"],
                    "curve_id": curve_id,
                    "rate_h_inverse": float(fit.parameters["rate"]),
                    "r2": fit.metrics.get("r2"),
                    "n_points": fit.n_points,
                    "scale_for_fraction": scale,
                    "scale_note": "percent scale"
                    if scale == 100.0
                    else "declared 1000 mg/g mass bound, not a measured loading",
                }
            )
        if not study_rates:
            continue
        rate_grid = np.geomspace(max(min(study_rates), 1e-7) * 0.5, max(study_rates) * 2.0, grid)
        end_time = float(frame["time"].astype(float).max())
        fractions, exec_meta = batch_sphere_predictions(rate_grid, np.array([end_time]), device=device)
        sweep_outputs[study_key] = {
            "study_id": study["meta"]["study_id"],
            "rate_grid_h_inverse": rate_grid,
            "end_time_native": end_time,
            "released_fraction_end": fractions[:, 0],
            "execution": exec_meta,
        }

    all_rates = np.array([row["rate_h_inverse"] for row in calibration]) if calibration else np.array([0.01])
    verify_rates = np.geomspace(max(float(all_rates.min()), 1e-7), float(all_rates.max()), 16)
    tau_check = np.array([0.1, 0.5, 1.0, 2.0])
    fv_grid, fv_meta = batched_fv_release(verify_rates, tau_check, shells=80, device=device)
    analytic_grid = np.array(
        [[float(release_fraction(float(r * t), "spherical_diffusion", {"rate": 1.0})) for t in tau_check]
         for r in verify_rates]
    )
    verification = {
        "fv_subset_shells80": fv_meta,
        "fv_subset_vs_analytic_max_abs": float(np.max(np.abs(fv_grid - analytic_grid))),
    }
    return {"calibration": calibration, "sweeps": sweep_outputs}, verification
