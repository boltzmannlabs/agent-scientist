"""Chronological split rules frozen by docs/v2_protocol.md.

Outer split: the earliest ``floor(0.7 * n)`` unique observed times of a curve
form the outer-training block and the remaining times the untouched outer-test
block; all replicates of a time stay together.  The inner split lives inside
outer training and is used only for candidate selection, with the inner
fitting block sized as ``max(floor(0.7 * n_train), cut_min)`` where ``cut_min``
is 5 when Weibull is comparable and 4 otherwise, so every eligible candidate
is scored on identical inner-validation times.  Rounding is part of the frozen
execution manifest: training fractions round down, keeping the test share at
or above the protocol's 30%.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import pandas as pd

OUTER_TRAIN_FRACTION = 0.7
INNER_TRAIN_FRACTION = 0.7
INNER_CUT_MIN = 4
INNER_CUT_MIN_WEIBULL = 5
WEIBULL_MIN_OUTER_TRAIN = 7
MIN_UNIQUE_TIMES = 8


def unique_times(frame: pd.DataFrame) -> list[float]:
    """Sorted distinct time values of an observation frame."""
    return sorted(float(t) for t in pd.unique(frame["time"]))


def _time_block(frame: pd.DataFrame, times) -> pd.DataFrame:
    keep = {float(t) for t in times}
    return frame[frame["time"].map(lambda t: float(t) in keep)].sort_values("time")


def outer_split(
    frame: pd.DataFrame, fraction: float = OUTER_TRAIN_FRACTION
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Split one curve into earliest-70% train and last-30% test blocks."""
    times = unique_times(frame)
    if len(times) < 2:
        raise ValueError("outer_split needs at least two unique times")
    cut = max(1, min(len(times) - 1, math.floor(fraction * len(times))))
    train = _time_block(frame, times[:cut])
    test = _time_block(frame, times[cut:])
    if not (train["time"].max() < test["time"].min()):
        raise AssertionError("outer split is not chronological")
    if len(train) + len(test) != len(frame):
        raise AssertionError("outer split lost rows")
    return train.reset_index(drop=True), test.reset_index(drop=True)


def inner_split(
    train: pd.DataFrame,
    fraction: float = INNER_TRAIN_FRACTION,
    cut_min: int = INNER_CUT_MIN,
    cut_min_weibull: int = INNER_CUT_MIN_WEIBULL,
    weibull_min_outer_train: int = WEIBULL_MIN_OUTER_TRAIN,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Split outer training into an earliest inner-training block and the
    remaining inner-validation times used for candidate selection only."""
    times = unique_times(train)
    if len(times) < 2:
        raise ValueError("inner_split needs at least two unique training times")
    weibull_comparable = len(times) >= weibull_min_outer_train
    need = cut_min_weibull if weibull_comparable else cut_min
    cut = max(1, min(len(times) - 1, max(math.floor(fraction * len(times)), need)))
    inner_train = _time_block(train, times[:cut])
    inner_val = _time_block(train, times[cut:])
    if not (inner_train["time"].max() < inner_val["time"].min()):
        raise AssertionError("inner split is not chronological")
    return inner_train.reset_index(drop=True), inner_val.reset_index(drop=True)
