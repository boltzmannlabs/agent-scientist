"""Transfer track: held-out conditions and formulations (docs/v2_protocol.md).

Complete conditions are held out first (all times and replicates of the group
stay outside training); formulation-level folds run only where at least two
recipes exist and are labelled exploratory.  Feature vocabularies, scaling and
the matched-time baseline are derived from training groups only.  Incompatible
targets and single-recipe studies block their folds with an explicit recorded
reason instead of being silently dropped.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .evaluation import curve_first_metrics, utility_verdict
from .forecast import BASELINE, modeling_rows
from .gpu_models import XGBContext, build_feature_frame


@dataclass(frozen=True)
class TransferFold:
    fold_id: str
    study_key: str
    group_column: str
    held_out: tuple[str, ...]
    exploratory: bool
    blocked_reason: str | None = None


def _crop_environment_groups(frame: pd.DataFrame) -> pd.Series:
    """Five environmental groups; the duplicated pH6/30C series share a group."""
    key = frame.apply(
        lambda r: (r.get("ph"), r.get("temperature_c")), axis=1
    )
    return key


def transfer_folds(study: dict) -> list[TransferFold]:
    study_key = study["study_key"]
    frame = modeling_rows(study)
    folds: list[TransferFold] = []
    if study_key == "herbicide":
        for condition in sorted(frame["condition_id"].unique()):
            folds.append(
                TransferFold(f"loco:{condition}", study_key, "condition_id", (str(condition),), False)
            )
        for formulation in sorted(frame["formulation_id"].unique()):
            folds.append(
                TransferFold(
                    f"lofo:{formulation}",
                    study_key,
                    "formulation_id",
                    (str(formulation),),
                    True,
                )
            )
    elif study_key == "crop":
        key = _crop_environment_groups(frame)
        for group in sorted(key.unique(), key=str):
            folds.append(
                TransferFold(f"env:{group}", study_key, "(ph,temperature_c)", (str(group),), False)
            )
        folds.append(
            TransferFold(
                "lofo:TEB_NPs", study_key, "formulation_id", ("TEB_NPs",), True,
                blocked_reason="single recipe; leave-one-formulation-out unavailable",
            )
        )
    elif study_key == "fertilizer":
        for condition in sorted(frame["condition_id"].unique()):
            folds.append(
                TransferFold(f"loco:{condition}", study_key, "condition_id", (str(condition),), False)
            )
        for formulation in sorted(frame["formulation_id"].unique()):
            folds.append(
                TransferFold(
                    f"lofo:{formulation}", study_key, "formulation_id", (str(formulation),), True
                )
            )
        for analyte in sorted(frame["analyte"].unique()):
            folds.append(
                TransferFold(
                    f"analyte:{analyte}",
                    study_key,
                    "analyte",
                    (str(analyte),),
                    False,
                    blocked_reason="incompatible target: different cargo denominators",
                )
            )
    return folds


def _matched_time_mean(train: pd.DataFrame, test: pd.DataFrame, formulation_known: bool) -> np.ndarray:
    """Baseline: mean of training rows at the same time, matched on formulation
    when the formulation remains in training, else the global time mean."""
    if formulation_known:
        means = train.groupby(["formulation_id", "time"])["value"].mean()
        global_means = train.groupby("time")["value"].mean()
        out = []
        for _, row in test.iterrows():
            key = (row["formulation_id"], row["time"])
            out.append(float(means[key]) if key in means.index else float(global_means[row["time"]]))
        return np.asarray(out, dtype=float)
    means = train.groupby("time")["value"].mean()
    return test["time"].map(lambda t: float(means[t])).to_numpy(dtype=float)


def run_transfer_track(
    study: dict,
    *,
    xgb_factory=None,
    utility_threshold: float = 0.10,
) -> dict:
    study_id = study["meta"]["study_id"]
    study_key = study["study_key"]
    frame = modeling_rows(study)
    time_unit = frame["time_unit"].iloc[0] if "time_unit" in frame.columns else ""
    unit = frame["unit"].iloc[0] if "unit" in frame.columns else ""

    prediction_rows, fold_rows = [], []
    for fold in transfer_folds(study):
        common = {
            "study_id": study_id,
            "fold_id": fold.fold_id,
            "group_column": fold.group_column,
            "held_out": ",".join(fold.held_out),
            "exploratory": fold.exploratory,
        }
        if fold.blocked_reason:
            fold_rows.append({**common, "status": "blocked", "blocked_reason": fold.blocked_reason})
            continue
        if fold.group_column == "condition_id":
            mask = frame["condition_id"].astype(str).isin(fold.held_out)
        elif fold.group_column == "formulation_id":
            mask = frame["formulation_id"].astype(str).isin(fold.held_out)
        elif fold.group_column == "analyte":
            mask = frame["analyte"].astype(str).isin(fold.held_out)
        else:  # crop environmental group
            key = _crop_environment_groups(frame)
            mask = key.astype(str).isin(fold.held_out)
        train, test = frame[~mask].copy(), frame[mask].copy()
        if train.empty or test.empty:
            fold_rows.append({**common, "status": "empty_fold", "blocked_reason": "empty train or test"})
            continue
        formulation_known = fold.group_column != "formulation_id"

        baseline_pred = _matched_time_mean(train, test, formulation_known)
        for (_, row), pred in zip(test.iterrows(), baseline_pred):
            prediction_rows.append(
                {
                    "study_id": study_id,
                    "track": "transfer",
                    "model": BASELINE,
                    "fold_id": fold.fold_id,
                    "curve_id": row["curve_id"],
                    "condition_id": str(row["condition_id"]),
                    "formulation_id": str(row["formulation_id"]),
                    "time": float(row["time"]),
                    "time_unit": time_unit,
                    "observed": float(row["value"]),
                    "predicted": float(pred),
                    "unit": unit,
                    "source": "matched_time_mean_training_groups_only",
                }
            )

        if xgb_factory is not None:
            feature_rows = frame.copy()
            if fold.group_column == "formulation_id" and "formulation_id" in feature_rows.columns:
                feature_rows = feature_rows.drop(columns=["formulation_id"])
            X_train = build_feature_frame(feature_rows[~mask], study_key)
            X_test = build_feature_frame(feature_rows[mask], study_key, train_columns=list(X_train.columns))
            local = xgb_factory()
            local.fit(X_train, train["value"].astype(float).to_numpy())
            preds = local.predict(X_test)
            for (_, row), pred in zip(test.iterrows(), preds):
                prediction_rows.append(
                    {
                        "study_id": study_id,
                        "track": "transfer",
                        "model": "xgboost_fixed",
                        "fold_id": fold.fold_id,
                        "curve_id": row["curve_id"],
                        "condition_id": str(row["condition_id"]),
                        "formulation_id": str(row["formulation_id"]),
                        "time": float(row["time"]),
                        "time_unit": time_unit,
                        "observed": float(row["value"]),
                        "predicted": float(pred),
                        "unit": unit,
                        "source": "grouped_covariate_transfer_training_groups_only",
                    }
                )
        fold_rows.append({**common, "status": "executed", "blocked_reason": ""})

    predictions = pd.DataFrame(prediction_rows)
    folds = pd.DataFrame(fold_rows)
    per_curve, summary = (None, None)
    if not predictions.empty:
        per_curve, summary = curve_first_metrics(predictions)
    utility = {}
    if summary is not None and not summary.empty:
        base = summary.loc[summary["model"] == BASELINE]
        for model in summary["model"].unique():
            if model == BASELINE:
                continue
            row_m = summary.loc[summary["model"] == model].iloc[0]
            row_b = base.iloc[0]
            utility[model] = utility_verdict(row_m["mae"], row_b["mae"], utility_threshold)
    return {
        "folds": folds,
        "predictions": predictions,
        "per_curve": per_curve,
        "summary": summary,
        "utility": utility,
    }


def recipe_endpoint_pilot(study: dict) -> pd.DataFrame:
    """Crop process-recipe pilot: leave-one-(flow, polymer)-group-out ridge on
    log10 process inputs versus the training mean, from the frozen v2 pilot."""
    from sklearn.linear_model import Ridge
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    if "recipe_endpoints" not in study:
        return pd.DataFrame()
    recipes = study["recipe_endpoints"]
    rows = []
    for endpoint in sorted(recipes["endpoint"].unique()):
        sub = recipes[recipes["endpoint"] == endpoint]
        keys = list(zip(sub["flow_ml_min"], sub["polymer_mg_ml"]))
        for group_key in sorted(set(keys)):
            in_group = sub.apply(lambda r: (r["flow_ml_min"], r["polymer_mg_ml"]) == group_key, axis=1)
            train, test = sub[~in_group], sub[in_group]
            if train.empty or test.empty:
                continue
            X_train = np.log10(train[["flow_ml_min", "polymer_mg_ml"]].astype(float))
            X_test = np.log10(test[["flow_ml_min", "polymer_mg_ml"]].astype(float))
            y_train = train["value"].astype(float).to_numpy()
            ridge = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
            ridge.fit(X_train, y_train)
            ridge_pred = ridge.predict(X_test)
            mean_pred = np.full(len(test), y_train.mean())
            fold = f"{group_key[0]}ml_min_{group_key[1]}mg_ml"
            for (_, row), pred_r, pred_m in zip(test.iterrows(), ridge_pred, mean_pred):
                for model, pred in (("ridge_log_process", pred_r), ("training_mean", pred_m)):
                    rows.append(
                        {
                            "endpoint": endpoint,
                            "unit": row.get("unit", ""),
                            "fold": fold,
                            "model": model,
                            "observed": float(row["value"]),
                            "predicted": float(pred),
                        }
                    )
    return pd.DataFrame(rows)
