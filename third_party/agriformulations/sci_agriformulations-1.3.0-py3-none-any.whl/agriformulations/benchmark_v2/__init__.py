"""Three-paper benchmark pipeline (docs/v2_protocol.md).

The package implements the frozen v2 protocol: chronological forecast splits
with inner model selection, condition/formulation transfer, the claims audit
verdict engine, fixed-hyperparameter GPU comparators and a batched GPU
finite-volume diffusion leg.  ``scripts.run_v2_benchmark`` orchestrates the
stages; this library holds the testable logic.
"""

from .splits import inner_split, outer_split, unique_times
from .candidates import CandidateFailure, CANDIDATES, fit_candidate
from .forecast import run_forecast_track
from .transfer import run_transfer_track, transfer_folds
from .claims_audit import audit_study, normalize_claims, refit_photolysis
from .io_utils import load_study, sha256_file, verify_study_sources
from .manifest import freeze_execution_manifest, verify_inputs

__all__ = [
    "inner_split",
    "outer_split",
    "unique_times",
    "CandidateFailure",
    "CANDIDATES",
    "fit_candidate",
    "run_forecast_track",
    "run_transfer_track",
    "transfer_folds",
    "audit_study",
    "normalize_claims",
    "refit_photolysis",
    "load_study",
    "sha256_file",
    "verify_study_sources",
    "freeze_execution_manifest",
    "verify_inputs",
]
