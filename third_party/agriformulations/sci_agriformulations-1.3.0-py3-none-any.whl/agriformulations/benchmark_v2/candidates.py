"""Prespecified release-forecast candidates (docs/v2_protocol.md).

The compact candidate list is frozen before running: persistence (constant
last observation), linear trend from the last three observations, a
two-parameter first-order plateau and a three-parameter Weibull plateau.
Eligibility depends only on training-set size: first-order needs at least
four fitting observations, Weibull at least five inner-training observations
and at least seven outer-training observations.  All candidates work in the
native units of the study; the plateau upper bound is a numerical or mass
bound declared per study, never an independently measured loading.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import least_squares

from .splits import unique_times


class CandidateFailure(Exception):
    """A candidate could not be fitted; the caller falls back to persistence."""


@dataclass(frozen=True)
class CandidateFit:
    name: str
    n_parameters: int
    parameters: dict[str, float]
    _predict: object  # callable: list[float] -> np.ndarray

    def predict(self, times) -> np.ndarray:
        return np.asarray(self._predict([float(t) for t in times]), dtype=float)


CANDIDATES = ("persistence", "linear_trend", "first_order_plateau", "weibull_plateau")
N_PARAMETERS = {"persistence": 1, "linear_trend": 2, "first_order_plateau": 2, "weibull_plateau": 3}


def _mean_by_time(frame) -> tuple[np.ndarray, np.ndarray]:
    times = unique_times(frame)
    values = [float(frame.loc[frame["time"] == t, "value"].mean()) for t in times]
    return np.asarray(times), np.asarray(values)


def _fit_persistence(frame) -> CandidateFit:
    times, values = _mean_by_time(frame)
    level = float(values[-1])

    def predict(ts):
        return np.full(len(ts), level)

    return CandidateFit("persistence", 1, {"level": level}, predict)


def _fit_linear_trend(frame) -> CandidateFit:
    times, values = _mean_by_time(frame)
    t0, y0 = times[-min(3, len(times)) :], values[-min(3, len(values)) :]
    if len(set(t0)) < 2:
        raise CandidateFailure("linear_trend needs two distinct times")
    slope, intercept = np.polyfit(t0, y0, 1)

    def predict(ts):
        return intercept + slope * np.asarray(ts)

    return CandidateFit(
        "linear_trend", 2, {"slope": float(slope), "intercept": float(intercept)}, predict
    )


def _bounded_fit(frame, model: str, plateau_bound: float) -> CandidateFit:
    times, values = _mean_by_time(frame)
    if len(times) < 2:
        raise CandidateFailure(f"{model} needs at least two observations")
    scale = float(np.median(times[times > 0])) if np.any(times > 0) else 1.0
    ts = times / scale
    span = max(float(values.max()), 1e-9)
    # Predeclared numerical bound: twice the largest observed value (or the
    # study mass bound when smaller).  A mass bound is not a measured loading.
    bound = float(min(plateau_bound, 2.0 * span)) if plateau_bound else 2.0 * span

    def unpack(p):
        plateau = p[0]
        if model == "first_order_plateau":
            return plateau, np.exp(p[1]) / scale
        return plateau, np.exp(p[1]) * scale, np.exp(p[2])

    def residual(p):
        if model == "first_order_plateau":
            plateau, k = unpack(p)
            return plateau * (1.0 - np.exp(-k * times)) - values
        plateau, tau, beta = unpack(p)
        return plateau * (1.0 - np.exp(-np.power(times / tau, beta))) - values

    y_last = float(values[-1])
    if model == "first_order_plateau":
        x0 = np.array([min(max(y_last, span * 0.5), bound), np.log(1.0 / max(scale, 1e-9))])
        lo = np.array([0.0, np.log(1e-6 / scale)])
        hi = np.array([bound, np.log(1e3 / scale)])
    else:
        x0 = np.array([min(max(y_last, span * 0.5), bound), np.log(scale), 0.0])
        lo = np.array([0.0, np.log(1e-3 * scale), np.log(0.05)])
        hi = np.array([bound, np.log(1e3 * scale), np.log(20.0)])
    x0 = np.clip(x0, lo + 1e-9, hi - 1e-9)
    try:
        result = least_squares(residual, x0, bounds=(lo, hi), max_nfev=2000)
    except Exception as exc:  # pragma: no cover - solver guard
        raise CandidateFailure(f"{model} solver error: {exc}") from exc

    def predict(ts_):
        arr = np.asarray(ts_, dtype=float)
        if model == "first_order_plateau":
            plateau, k = unpack(result.x)
            return plateau * (1.0 - np.exp(-k * arr))
        plateau, tau, beta = unpack(result.x)
        return plateau * (1.0 - np.exp(-np.power(arr / tau, beta)))

    if model == "first_order_plateau":
        plateau, k = unpack(result.x)
        params = {"plateau": float(plateau), "k_per_time": float(k)}
    else:
        plateau, tau, beta = unpack(result.x)
        params = {"plateau": float(plateau), "tau_time": float(tau), "beta": float(beta)}
    return CandidateFit(model, N_PARAMETERS[model], params, predict)


def fit_candidate(frame, name: str, plateau_bound: float | None = None) -> CandidateFit:
    """Fit one candidate on a observation frame with ``time``/``value`` columns."""
    if name == "persistence":
        return _fit_persistence(frame)
    if name == "linear_trend":
        return _fit_linear_trend(frame)
    if name in ("first_order_plateau", "weibull_plateau"):
        return _bounded_fit(frame, name, plateau_bound or 0.0)
    raise ValueError(f"unknown candidate {name!r}")


def eligible_candidates(n_outer_train_times: int, n_inner_train_times: int) -> list[str]:
    """Protocol eligibility from training-set sizes only."""
    names = ["persistence"]
    if n_outer_train_times >= 2:
        names.append("linear_trend")
    if n_inner_train_times >= 4:
        names.append("first_order_plateau")
    if n_outer_train_times >= 7 and n_inner_train_times >= 5:
        names.append("weibull_plateau")
    return names
