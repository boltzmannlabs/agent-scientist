"""Freezing and verification of the v2 execution manifest.

The manifest records input hashes, split rules, candidate list, fixed model
hyperparameters, thresholds, seeds and device BEFORE any fitting happens
(docs/v2_protocol.md).  ``verify_inputs`` re-checks every hash; ``amend``
records any post-freeze change with a reason instead of silently deviating.
"""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

from .io_utils import REPO_ROOT, sha256_file
from .candidates import CANDIDATES, N_PARAMETERS

INPUT_PATTERNS = (
    "data/v2/*/study.json",
    "data/v2/*/observations.csv",
    "data/v2/*/claims.csv",
    "data/v2/*/release_replicates.csv",
    "data/v2/*/photolysis.csv",
    "data/v2/*/photolysis_replicates.csv",
    "data/v2/*/recipe_endpoints.csv",
)
CODE_PATTERNS = ("src/agriformulations/benchmark_v2/*.py", "scripts/run_v2_benchmark.py")

SPLIT_RULES = {
    "eligibility_min_unique_times": 8,
    "outer_train_fraction": 0.7,
    "rounding": "floor",
    "inner_train_fraction": 0.7,
    "inner_cut_min": 4,
    "inner_cut_min_weibull": 5,
    "weibull_min_outer_train": 7,
    "replicates_kept_together": True,
    "mean_curve_target": ["crop", "fertilizer"],
    "selection_metric": "inner_mae_native_units",
    "tie_break": "fewer_parameters_then_fixed_order",
}

THRESHOLDS = {
    "forecast_utility_relative_mae_improvement": 0.10,
    "cpu_gpu_abs": 1e-8,
    "cpu_gpu_rel": 1e-6,
    "pde_mass_balance": 1e-6,
    "exact_numeric": "half final printed decimal",
    "approximate_pct_pp": 5.0,
    "approximate_mass": "max(half unit, 5pct magnitude)",
}

XGBOOST_ROLE = {
    "role": "exploratory_within_study_comparator",
    "hyperparameter_search": "none",
    "missing_values": "native_nan_no_imputation",
}


def _glob_inputs() -> dict:
    from glob import glob as _glob

    entries = {}
    for pattern in INPUT_PATTERNS:
        for rel in sorted(_glob(str(REPO_ROOT / pattern))):
            rel = Path(rel).relative_to(REPO_ROOT).as_posix()
            entries[rel] = {"sha256": sha256_file(REPO_ROOT / rel)}
    return entries


def freeze_execution_manifest(path, *, device: str, seed: int = 271828, extra: dict | None = None) -> dict:
    """Collect hashes and frozen rules and write the manifest before fitting."""
    from glob import glob as _glob

    inputs = _glob_inputs()
    code = {}
    for pattern in CODE_PATTERNS:
        for rel in sorted(_glob(str(REPO_ROOT / pattern))):
            rel = Path(rel).relative_to(REPO_ROOT).as_posix()
            code[rel] = sha256_file(REPO_ROOT / rel)
    manifest = {
        "manifest_version": "2.0",
        "created_utc": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "seed": seed,
        "protocol": {
            "document": "docs/v2_protocol.md",
            "sha256": sha256_file(REPO_ROOT / "docs" / "v2_protocol.md"),
        },
        "device": {"requested": device},
        "inputs": inputs,
        "code_sha256": code,
        "split_rules": SPLIT_RULES,
        "candidates": [
            {"name": name, "n_parameters": N_PARAMETERS[name]} for name in CANDIDATES
        ],
        "xgboost": XGBOOST_ROLE,
        "thresholds": THRESHOLDS,
        "amendments": [],
    }
    if extra:
        manifest.update(extra)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as handle:
        json.dump(manifest, handle, indent=1, sort_keys=True)
    return manifest


def verify_inputs(manifest: dict) -> None:
    """Hash gate: raise before any fitting when a frozen input has changed."""
    for rel, entry in manifest["inputs"].items():
        actual = sha256_file(REPO_ROOT / rel)
        if actual != entry["sha256"]:
            raise ValueError(f"input hash drift after freeze: {rel}")


def amend(manifest: dict, reason: str, changes: dict) -> dict:
    manifest["amendments"].append(
        {"reason": reason, "changes": changes}
    )
    return manifest
