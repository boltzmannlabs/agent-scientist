"""Curve-first error aggregation (docs/v2_protocol.md).

Errors are averaged within each curve first and then equally across curves
within a study, so repeated times or replicate rows never masquerade as
independent evidence.  Native units only; a secondary normalized metric would
have to declare a training-learned scale, which this pipeline does not use.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def _curve_errors(prediction_rows: pd.DataFrame) -> pd.DataFrame:
    frame = prediction_rows.copy()
    frame["_err"] = frame["predicted"].astype(float) - frame["observed"].astype(float)
    per_curve = (
        frame.assign(_abs=frame["_err"].abs(), _sq=frame["_err"] ** 2)
        .groupby(["study_id", "track", "model", "curve_id"], sort=True)
        .agg(
            mae=("_abs", "mean"),
            mean_sq=("_sq", "mean"),
            bias=("_err", "mean"),
            n_test_rows=("observed", "count"),
        )
        .reset_index()
    )
    per_curve["rmse"] = np.sqrt(per_curve["mean_sq"])
    return per_curve.drop(columns="mean_sq")


def curve_first_metrics(prediction_rows: pd.DataFrame) -> pd.DataFrame:
    """Per-curve MAE/RMSE/bias, then equal-weight study-level means per model."""
    per_curve = _curve_errors(prediction_rows).reset_index()
    study = (
        per_curve.groupby(["study_id", "track", "model"], sort=True)
        .agg(
            mae=("mae", "mean"),
            rmse=("rmse", "mean"),
            bias=("bias", "mean"),
            n_curves=("curve_id", "count"),
        )
        .reset_index()
    )
    return per_curve, study


def paired_baseline_comparison(prediction_rows: pd.DataFrame, baseline: str) -> pd.DataFrame:
    """Per-curve paired MAE differences of every model against one baseline,
    reported separately for each study."""
    per_curve = _curve_errors(prediction_rows).reset_index()
    wide = per_curve.pivot_table(
        index=["study_id", "track", "curve_id"], columns="model", values="mae"
    )
    if baseline not in wide.columns:
        raise ValueError(f"baseline model {baseline!r} missing from predictions")
    rows = []
    for (study_id, track), block in wide.groupby(level=["study_id", "track"]):
        for model in block.columns:
            if model == baseline:
                continue
            delta = block[model] - block[baseline]
            rows.append(
                {
                    "study_id": study_id,
                    "track": track,
                    "model": model,
                    "baseline": baseline,
                    "mean_paired_mae_difference": float(delta.mean()),
                    "curves_improved": int((delta < 0).sum()),
                    "curves_total": int(delta.notna().sum()),
                }
            )
    return pd.DataFrame(rows)


def utility_verdict(study_mae_model: float, study_mae_baseline: float, threshold: float = 0.10) -> dict:
    """Protocol forecast-utility rule: >=10% lower study-level MAE than baseline."""
    if study_mae_baseline <= 0:
        return {"relative_improvement": float("nan"), "meets_threshold": False, "threshold": threshold}
    improvement = float((study_mae_baseline - study_mae_model) / study_mae_baseline)
    return {
        "relative_improvement": improvement,
        "meets_threshold": bool(improvement >= threshold),
        "threshold": threshold,
    }
