"""Screening agent: ranked design shortlists as proposals (v6).

Runs the surrogate-plus-physics sweep over a declared candidate space and
submits a ``design_shortlist`` proposal with per-candidate provenance (which
model, which manifest, mismatch, solver-verification residual).  A human must
approve the proposal before the runner writes any recommendation section -
unapproved shortlists render as pending, never as advice.
"""

from __future__ import annotations

from .runtime import submit_proposal


def build_shortlist_proposal(
    verified_shortlist: list[dict],
    *,
    brief_id: str,
    manifest_sha256: str,
    v6_mode: str,
    phase: str = "v6",
    root=None,
):
    """Summarize the verified shortlist into a reviewable proposal."""
    payload = {
        "brief_id": brief_id,
        "v6_mode": v6_mode,
        "manifest_sha256": manifest_sha256,
        "candidates": [
            {
                "rate": entry["rate"],
                "plateau_fraction": entry["plateau_fraction"],
                "mismatch_native": entry["mismatch_native"],
                "solver_mismatch_native": entry.get("solver_mismatch_native"),
                "solver_verified": entry.get("solver_verified"),
                "provenance": {
                    "forward_model": "verified analytic eigenmode kernel + 80-shell FV cross-check",
                    "identifiability": "D/L^2 axis only; D and L never proposed separately",
                },
            }
            for entry in verified_shortlist
        ],
        "disclaimer": "Mechanistic feasibility only: release-curve matching under stated model assumptions. No efficacy, toxicity, field or synthesis-chemistry claim.",
    }
    return submit_proposal(
        phase,
        "design_shortlist",
        payload=payload,
        authored_by="agent:screening",
        root=root,
    )
