"""Runtime agent proposals with a human review gate (v3).

Runtime agents never mutate the catalog, the audit, or a report directly.
They submit proposals; a human reviews; deterministic code re-checks whatever
the proposal authorized before it takes effect.  Every proposal is a JSON
file under ``proposals/`` and every state change appends a hash-chained line
to ``agent_log.jsonl`` so the agent activity trail is tamper-evident.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()
PROPOSAL_TYPES = frozenset({"data_candidate", "verdict_draft", "design_shortlist", "campaign_shortlist"})
STATUSES = frozenset({"pending", "approved", "rejected"})


def _now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _chain_digest(log_path: Path, payload: str) -> str:
    previous = ""
    if log_path.exists():
        lines = log_path.read_text().strip().splitlines()
        if lines:
            previous = json.loads(lines[-1]).get("digest", "")
    return hashlib.sha256((previous + payload).encode()).hexdigest()


@dataclass(frozen=True)
class Proposal:
    proposal_id: str
    proposal_type: str
    payload: dict
    authored_by: str
    model: str | None
    created_utc: str
    status: str = "pending"
    reviewer: str | None = None
    reviewed_utc: str | None = None

    def __post_init__(self):
        if self.proposal_type not in PROPOSAL_TYPES:
            raise ValueError(f"proposal_type must be one of {sorted(PROPOSAL_TYPES)}")
        if not self.authored_by.startswith("agent:"):
            raise ValueError("authored_by must identify the agent as 'agent:<name>'")
        if self.status not in STATUSES:
            raise ValueError(f"status must be one of {sorted(STATUSES)}")
        if self.status != "pending" and not (self.reviewer and self.reviewed_utc):
            raise ValueError("reviewed proposals require a reviewer and timestamp")


def _proposal_path(root: Path, phase: str, proposal_id: str) -> Path:
    return root / "proposals" / phase / f"{proposal_id}.json"


def submit_proposal(
    phase: str,
    proposal_type: str,
    payload: dict,
    *,
    authored_by: str,
    model: str | None = None,
    root: Path | None = None,
) -> Proposal:
    """Write a pending proposal and append it to the hash-chained log."""
    root = root or REPO_ROOT
    proposal = Proposal(
        proposal_id=f"{proposal_type}_{uuid.uuid4().hex[:10]}",
        proposal_type=proposal_type,
        payload=payload,
        authored_by=authored_by,
        model=model,
        created_utc=_now(),
    )
    path = _proposal_path(root, phase, proposal.proposal_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(proposal), indent=1, sort_keys=True))
    _append_log(root, "submit", proposal)
    return proposal


def review(
    phase: str,
    proposal_id: str,
    decision: str,
    reviewer: str,
    root: Path | None = None,
) -> Proposal:
    """Record a human decision on a pending proposal."""
    if decision not in ("approved", "rejected"):
        raise ValueError("decision must be 'approved' or 'rejected'")
    if reviewer.startswith("agent:"):
        raise ValueError("an agent cannot review its own or any proposal; humans review")
    root = root or REPO_ROOT
    path = _proposal_path(root, phase, proposal_id)
    record = json.loads(path.read_text())
    if record["status"] != "pending":
        raise ValueError(f"proposal {proposal_id} is already {record['status']}")
    proposal = Proposal(
        proposal_id=record["proposal_id"],
        proposal_type=record["proposal_type"],
        payload=record["payload"],
        authored_by=record["authored_by"],
        model=record.get("model"),
        created_utc=record["created_utc"],
        status=decision,
        reviewer=reviewer,
        reviewed_utc=_now(),
    )
    path.write_text(json.dumps(asdict(proposal), indent=1, sort_keys=True))
    _append_log(root, decision, proposal)
    return proposal


def load_proposal(phase: str, proposal_id: str, root: Path | None = None) -> Proposal:
    root = root or REPO_ROOT
    record = json.loads(_proposal_path(root, phase, proposal_id).read_text())
    return Proposal(**record)


def require_approved(phase: str, proposal_id: str, root: Path | None = None) -> Proposal:
    """Gate used by adapters and the design runner: refuses to act on
    proposals that are pending, rejected, or missing."""
    root = root or REPO_ROOT
    path = _proposal_path(root, phase, proposal_id)
    if not path.exists():
        raise PermissionError(f"proposal {proposal_id} does not exist under proposals/{phase}/")
    proposal = load_proposal(phase, proposal_id, root)
    if proposal.status == "pending":
        raise PermissionError(f"proposal {proposal_id} awaits human review; refusing to proceed")
    if proposal.status == "rejected":
        raise PermissionError(f"proposal {proposal_id} was rejected by {proposal.reviewer}")
    return proposal


def _append_log(root: Path, event: str, proposal: Proposal) -> None:
    log_path = root / "proposals" / "agent_log.jsonl"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(
        {
            "event": event,
            "proposal_id": proposal.proposal_id,
            "proposal_type": proposal.proposal_type,
            "authored_by": proposal.authored_by,
            "model": proposal.model,
            "status": proposal.status,
            "reviewer": proposal.reviewer,
            "utc": _now(),
        },
        sort_keys=True,
    )
    entry = {"digest": _chain_digest(log_path, payload), "payload": payload}
    with open(log_path, "a") as handle:
        handle.write(json.dumps(entry, sort_keys=True) + "\n")


def verify_log_chain(root: Path | None = None) -> bool:
    """Recompute the hash chain; False means the log was tampered with."""
    root = root or REPO_ROOT
    log_path = root / "proposals" / "agent_log.jsonl"
    if not log_path.exists():
        return True
    previous = ""
    for line in log_path.read_text().strip().splitlines():
        entry = json.loads(line)
        expected = hashlib.sha256((previous + entry["payload"]).encode()).hexdigest()
        if entry["digest"] != expected:
            return False
        previous = entry["digest"]
    return True
