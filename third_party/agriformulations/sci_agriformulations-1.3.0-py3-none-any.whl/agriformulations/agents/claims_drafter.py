"""Claims-drafter agent: scales the audit without moving a verdict (v5).

The deterministic engine computes every verdict.  The drafter only (i)
classifies new claims onto audit handlers, (ii) drafts ``verdict_basis`` prose
from templates keyed by verdict and scope, and (iii) flags rows needing human
attention.  Drafts are exported with ``verdict_drafted_by`` /
``verdict_confirmed_by`` column pairs; confirmation stays pending until a
human reviews - the counts, not the prose, carry the science.
"""

from __future__ import annotations

import pandas as pd

from .runtime import submit_proposal

TEMPLATES = {
    "reproduced_at_reporting_precision": (
        "Recomputed from author source data or replicates; agreement within the tabulated "
        "tolerance (half the final printed decimal unit where applicable)."
    ),
    "approximately_consistent": (
        "Recomputed value falls within the declared exploratory tolerance; prose-level "
        "agreement, not an exact reproduction."
    ),
    "disagreement_under_stated_analysis": (
        "Our stated analysis disagrees with the reported value; this is a statement about "
        "the analysis, not proof of a source error. Needs human review of the basis."
    ),
    "source_inconsistency": (
        "Registered source conflict preserved without adjudication; see the claims ledger."
    ),
    "not_comparable": (
        "Different assay or target; the release-model contract does not apply."
    ),
    "insufficient_information": (
        "The information required for this comparison is not available in the registered "
        "evidence; flagged for human follow-up."
    ),
}
NEEDS_HUMAN = {"disagreement_under_stated_analysis", "insufficient_information"}


def draft_verdicts(audit: pd.DataFrame, phase: str = "v5", root=None) -> pd.DataFrame:
    """Attach drafted bases and provenance stamps to a computed audit frame."""
    drafted = audit.copy()
    drafted["verdict_drafted_by"] = "agent:claims_drafter"
    drafted["verdict_confirmed_by"] = ""  # pending until human review
    drafted["needs_human"] = drafted["verdict"].isin(NEEDS_HUMAN)
    drafted["drafted_basis"] = drafted["verdict"].map(lambda v: TEMPLATES.get(v, ""))
    return drafted


def submit_draft_summary(drafted: pd.DataFrame, phase: str = "v5", root=None) -> object:
    """One verdict_draft proposal summarizing the drafted audit for review."""
    counts = drafted["verdict"].value_counts().to_dict()
    return submit_proposal(
        phase,
        "verdict_draft",
        payload={
            "claims_total": int(len(drafted)),
            "verdict_counts": counts,
            "needs_human": int(drafted["needs_human"].sum()),
            "note": "Deterministic verdicts computed by benchmark_v2.claims_audit; prose drafted from templates; confirmation pending human review.",
        },
        authored_by="agent:claims_drafter",
        root=root,
    )
