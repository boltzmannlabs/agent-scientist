"""Agent layer: proposals, review gates and agent-assisted pipeline features."""

from .runtime import (
    Proposal,
    load_proposal,
    require_approved,
    review,
    submit_proposal,
    verify_log_chain,
)
from .literature_monitor import CRITERIA, run_monitor, screen_candidate

__all__ = [
    "Proposal",
    "load_proposal",
    "require_approved",
    "review",
    "submit_proposal",
    "verify_log_chain",
    "CRITERIA",
    "run_monitor",
    "screen_candidate",
]
