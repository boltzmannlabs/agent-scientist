"""Literature-monitor agent: screening proposals only, never ingestion (v3).

The monitor consumes a fetch queue of candidate papers (from the literature
screener dev-agent or a manual list), scores each against the frozen
selection criteria of ``docs/v3_protocol.md``, and emits ``data_candidate``
proposals.  It never writes under ``data/``.  An approved proposal merely
authorizes a human-driven extraction adapter, which cites the proposal id in
``study.json`` as ``ingest_channel: "agent_screened_human_approved"``.
"""

from __future__ import annotations

import json
from pathlib import Path

from .runtime import submit_proposal

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()

# Frozen screening criteria (docs/v3_protocol.md): all mandatory for acceptance.
CRITERIA = (
    "numerical_series_min6_times",
    "machine_readable_supplement",
    "composition_at_ratio_level",
    "assay_medium_temperature_ph_stated",
    "target_and_denominator_unambiguous",
    "licence_permits_internal_analysis",
    "no_digitization_required",
)


def screen_candidate(candidate: dict) -> dict:
    """Score one candidate against the frozen criteria.

    ``candidate`` carries the metadata a screener gathered: doi, title, year,
    access observations and a boolean per criterion.  The function only
    reformats and totals; it never invents a criterion value — missing
    entries count as unverified.
    """
    checks = {name: bool(candidate.get(name, False)) for name in CRITERIA}
    missing = [name for name, ok in checks.items() if not ok]
    return {
        "doi": candidate.get("doi", ""),
        "title": candidate.get("title", ""),
        "year": candidate.get("year"),
        "screening_score": round(sum(checks.values()) / len(CRITERIA), 3),
        "criteria": checks,
        "unverified": missing,
        "decision": "propose_for_extraction" if not missing else "hold_missing_evidence",
        "notes": candidate.get("notes", ""),
    }


def run_monitor(queue_path: Path, phase: str = "v3", root: Path | None = None) -> list[dict]:
    """Screen every queued candidate and submit data_candidate proposals for
    the ones passing all criteria; returns the screening records."""
    root = root or REPO_ROOT
    queue = json.loads(Path(queue_path).read_text())
    records = []
    for candidate in queue.get("candidates", []):
        record = screen_candidate(candidate)
        records.append(record)
        if record["decision"] == "propose_for_extraction":
            proposal = submit_proposal(
                phase,
                "data_candidate",
                payload=record,
                authored_by="agent:literature_monitor",
                model=queue.get("screened_by_model"),
                root=root,
            )
            record["proposal_id"] = proposal.proposal_id
    out = Path(queue_path).with_name(Path(queue_path).stem + "_screened.json")
    out.write_text(json.dumps(records, indent=1, sort_keys=True))
    return records
