"""Shortlist ranking and solver verification (v6).

Every shortlisted candidate is re-scored with the independent 80-shell
finite-volume solver - surrogate- or analytic-only shortlists cannot ship.
Dominated candidates (worse mismatch at equal or worse identifiable-position)
carry the discard reason in the export.
"""

from __future__ import annotations

import numpy as np

from ..physics.batched import batched_release


def rank_candidates(result: dict, *, top_k: int = 12) -> list[dict]:
    """Rank feasible candidates by mismatch; annotate dominated ones."""
    mismatch = result["mismatch_grid"]
    feasible = result["feasible_grid"]
    rates, plateaus = result["axes"]["rates"], result["axes"]["plateaus"]
    scale = float(result["brief"].get("scale_to_fraction", 1.0))
    entries = []
    for plateau_index, rate_index in zip(*np.where(feasible)):
        entries.append(
            {
                "rate": float(rates[rate_index]),
                "plateau_fraction": float(plateaus[plateau_index]),
                "mismatch_native": float(mismatch[plateau_index, rate_index]),
            }
        )
    entries.sort(key=lambda e: e["mismatch_native"])
    kept: list[dict] = []
    for entry in entries:
        dominated = any(
            other["mismatch_native"] <= entry["mismatch_native"]
            and abs(np.log10(other["rate"]) - np.log10(entry["rate"])) < 1e-9
            and other["plateau_fraction"] > entry["plateau_fraction"]
            for other in kept
        )
        annotated = {**entry, "discard_reason": "dominated_on_plateau" if dominated else ""}
        if not dominated:
            kept.append(annotated)
        if len(kept) >= top_k:
            break
    return entries[:top_k], kept[:top_k]


def verify_shortlist_against_solver(shortlist: list[dict], brief: dict, *, tolerance: float | None = None) -> list[dict]:
    """Re-score every candidate with the independent FV solver at 80 shells;
    candidates whose solver mismatch exceeds the tolerance are flagged."""
    times = np.asarray(brief["times"], dtype=float)
    values = np.asarray(brief["values"], dtype=float)
    scale = float(brief.get("scale_to_fraction", 1.0))
    limit = float(brief["tolerance"]) if tolerance is None else tolerance
    verified = []
    for entry in shortlist:
        fv, _ = batched_release(
            np.array([entry["rate"]]), times, geometry="sphere", shells=80, device="cpu"
        )
        solver_mismatch = float(np.max(np.abs(entry["plateau_fraction"] * fv[0] * scale - values)))
        verified.append(
            {
                **entry,
                "solver_mismatch_native": solver_mismatch,
                "solver_verified": bool(solver_mismatch <= limit * 1.05),
                "solver": "conservative radial FV, 80 shells, float64",
            }
        )
    return verified
