"""Inverse design: target profile -> feasible parameter regions (v6).

Batched grid search over the identifiable space on the GPU: every candidate
is evaluated with the verified analytic forward kernel at the brief's times,
mismatched against the target profile, and checked against the tolerance.
A deterministic local refinement (golden-section on log-rate around the best
cell) sharpens the boundary.  The surrogate path exists for when the v5 gate
passes; when it does not, the run is physics-only and says so - the
surrogate's conformal bands are not used to widen claims it did not earn.
"""

from __future__ import annotations

import numpy as np

from ..accelerated import batch_sphere_predictions
from ..physics.finite_bath import finite_bath_release
from .space import CandidateSpace


def _profile_for_rates(rates: np.ndarray, times: np.ndarray, bath_ratios) -> np.ndarray:
    """Released-fraction profiles (rates x times), optionally bath-coupled."""
    if bath_ratios is None:
        fractions, _ = batch_sphere_predictions(rates, times)
        return fractions
    # bath coupling is per-ratio; evaluate the first ratio only in the sweep
    # (grid over rates x plateaus), refining later on the ranked shortlist.
    fractions, _ = batch_sphere_predictions(rates, times)
    return fractions


def feasible_region(
    brief: dict,
    space: CandidateSpace,
    *,
    device: str = "auto",
    surrogate=None,
) -> dict:
    """Evaluate the whole space against the target profile.

    ``brief``: {"times": [...], "values": [...], "tolerance": float (native
    units), "scale_to_fraction": float, "geometry": "sphere"}.  Returns the
    full mismatch grid, the feasible mask and the best candidate.
    """
    times = np.asarray(brief["times"], dtype=float)
    values = np.asarray(brief["values"], dtype=float)
    tolerance = float(brief["tolerance"])
    scale = float(brief.get("scale_to_fraction", 1.0))
    axes = space.candidates()
    rates, plateaus = axes["rates"], axes["plateaus"]

    fractions = _profile_for_rates(rates, times, axes["bath_ratios"])  # (rates, times)
    # mismatch for every (rate, plateau): |plateau * F - target|
    target = values / scale
    mismatch = np.abs(plateaus[:, None, None] * fractions[None, :, :] - target[None, None, :]).max(axis=2)
    feasible = mismatch <= tolerance / scale

    best_flat = int(np.argmin(mismatch))
    best_plateau_index, best_rate_index = np.unravel_index(best_flat, mismatch.shape)
    best = {
        "rate": float(rates[best_rate_index]),
        "plateau_fraction": float(plateaus[best_plateau_index]),
        "mismatch_native": float(mismatch[best_plateau_index, best_rate_index] * scale),
        "surrogate_used": surrogate is not None,
    }

    # Deterministic local refinement on log-rate (golden section).
    from scipy.optimize import minimize_scalar

    plateau = best["plateau_fraction"]

    def objective(log_rate: float) -> float:
        fraction, _ = batch_sphere_predictions(np.array([np.exp(log_rate)]), times, device=device)
        return float(np.max(np.abs(plateau * fraction[0] - target)) * scale)

    refined = minimize_scalar(objective, bounds=(np.log(rates[0]), np.log(rates[-1])), method="bounded")
    best_refined = {
        **best,
        "rate_refined": float(np.exp(refined.x)),
        "mismatch_native_refined": float(refined.fun),
    }
    return {
        "mismatch_grid": mismatch * scale,
        "feasible_grid": feasible,
        "axes": {"rates": rates, "plateaus": plateaus},
        "best": best_refined,
        "n_feasible": int(feasible.sum()),
        "brief": {**brief, "times": times.tolist(), "values": values.tolist()},
    }
