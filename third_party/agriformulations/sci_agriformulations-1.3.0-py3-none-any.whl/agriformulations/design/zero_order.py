"""Membrane-controlled (zero-order) release kernel and the claim-pair demonstration (v11).

F(t) = plateau * clip(k0 (t - lag), 0, 1): constant-rate release at k0 per
day after an induction lag, clamped at the plateau fraction.  This is the
complement to the Fickian family - a reservoir behind a rate-controlling
membrane, not a homogeneous matrix - and the only kernel family under which
total-depletion claim pairs (small early release, large late release) are
designable: the Fickian family's late/early ratio is bounded (early-time
F ~ 6 sqrt(tau/pi) caps the ratio at sqrt(t2/t1) ~ 2.65 for 35d/5d), while
zero-order release with lag approaching t1 has an unbounded ratio.  The
claim-pair scans export both sides honestly; kernel feasibility is a
mechanistic assumption, never an efficacy or patentability statement.
"""

from __future__ import annotations

import numpy as np

from ..release import release_fraction

CLAIM_T1_DAYS = 5.0
CLAIM_T2_DAYS = 35.0
CLAIM_CAP_T1 = 0.20
CLAIM_FLOOR_T2 = 0.80
FICKIAN_TAU_GRID = 4000
ZERO_ORDER_K0_GRID = 60
ZERO_ORDER_LAG_GRID = 50
ZERO_ORDER_PLATEAU_GRID = 21
RECOVERY_TRIALS = 12
RECOVERY_K0_REL = 0.10
RECOVERY_PLATEAU_ABS = 0.05
RECOVERY_LAG_ABS = 1.0


def zero_order_fraction(times, k0: float, plateau: float, lag: float) -> np.ndarray:
    """Released fraction in [0, plateau]; zero before the lag, constant rate
    on the ramp, clamped at the plateau (reservoir depletion)."""
    if not 0 < plateau <= 1.0:
        raise ValueError("plateau must lie in (0, 1]")
    if k0 <= 0 or lag < 0:
        raise ValueError("k0 must be positive and lag nonnegative")
    times = np.asarray(times, dtype=float)
    return float(plateau) * np.clip(k0 * (times - lag), 0.0, 1.0)


def zero_order_fit(times, values) -> dict:
    """Closed-form three-parameter fit: plateau from the maximum, lag and k0
    from a straight line through the ramp segment (v = P k0 t - P k0 lag)."""
    times = np.asarray(times, dtype=float)
    values = np.clip(np.asarray(values, dtype=float), 0.0, 1.0)
    plateau = float(min(max(values.max(), 1e-6), 1.0))
    ramp = (values > 0.02 * plateau) & (values < 0.98 * plateau)
    if int(ramp.sum()) >= 3:
        slope, intercept = np.polyfit(times[ramp], values[ramp], 1)
        if slope > 0:
            k0 = float(slope / plateau)
            lag = float(max(-intercept / slope, 0.0))
        else:
            k0, lag = float(values.max() / max(times[-1], 1e-9)), 0.0
    else:
        k0, lag = float(values[-1] / plateau / max(times[-1], 1e-9)), 0.0
    predicted = zero_order_fraction(times, k0, plateau, lag)
    residual = float(np.max(np.abs(predicted - values)))
    return {"k0": k0, "plateau": plateau, "lag": lag, "max_abs_residual": residual}


def _sphere_fraction(tau: np.ndarray) -> np.ndarray:
    """F(tau) for the dimensionless sphere kernel (rate 1, tau = rate x t)."""
    return np.asarray(
        release_fraction(np.asarray(tau, dtype=float), "spherical_diffusion", {"rate": 1.0}), dtype=float
    )


def fickian_claim_scan(t1: float = CLAIM_T1_DAYS, t2: float = CLAIM_T2_DAYS,
                       cap_t1: float = CLAIM_CAP_T1, floor_t2: float = CLAIM_FLOOR_T2,
                       *, grid_points: int = FICKIAN_TAU_GRID) -> dict:
    """Achievable t2 fraction over the whole Fickian sphere family.

    For each tau1 the best plateau is min(1, cap/F(tau1)); the achievable
    t2 value is plateau x F((t2/t1) tau1).  The family cannot do better:
    both constraints are monotone in tau, so the optimum sits at the cap."""
    tau1 = np.geomspace(1e-8, 5.0, grid_points)
    f1 = _sphere_fraction(tau1)
    f2 = _sphere_fraction((t2 / t1) * tau1)
    plateau_best = np.minimum(1.0, cap_t1 / np.maximum(f1, 1e-12))
    achieved = plateau_best * f2
    best_index = int(np.argmax(achieved))
    feasible = achieved >= floor_t2
    return {
        "n_feasible": int(feasible.sum()),
        "ceiling_t2": float(achieved[best_index]),
        "best_rate_per_day": float(tau1[best_index] / t1),
        "best_plateau": float(plateau_best[best_index]),
        "ratio_bound_sqrt": float(np.sqrt(t2 / t1)),
        "scan": {"tau1": tau1, "f1": f1, "f2": f2, "plateau_best": plateau_best, "achieved": achieved},
    }


def zero_order_claim_scan(t1: float = CLAIM_T1_DAYS, t2: float = CLAIM_T2_DAYS,
                          cap_t1: float = CLAIM_CAP_T1, floor_t2: float = CLAIM_FLOOR_T2, *,
                          k0_points: int = ZERO_ORDER_K0_GRID, lag_points: int = ZERO_ORDER_LAG_GRID,
                          plateau_points: int = ZERO_ORDER_PLATEAU_GRID) -> dict:
    """Feasible (k0, lag, plateau) region for the claim pair under the
    membrane kernel, plus the analytic corner check at lag=0, plateau=1."""
    k0_grid = np.geomspace(1e-3, 1.0, k0_points)
    lag_grid = np.linspace(0.0, t1 * 0.98, lag_points)
    plateau_grid = np.linspace(max(floor_t2, 0.05), 1.0, plateau_points)
    feasible_count = 0
    k0_feasible: list[float] = []
    examples: list[dict] = []
    for lag in lag_grid:
        release_t1 = np.clip(k0_grid * (t1 - lag), 0.0, 1.0)
        release_t2 = np.clip(k0_grid * (t2 - lag), 0.0, 1.0)
        for plateau in plateau_grid:
            ok = (plateau * release_t1 <= cap_t1) & (plateau * release_t2 >= floor_t2)
            feasible_count += int(ok.sum())
            k0_feasible.extend(k0_grid[ok].tolist())
            if ok.any() and len(examples) < 3:
                for index in np.where(ok)[0][: 3 - len(examples)]:
                    examples.append(
                        {
                            "k0_per_day": float(k0_grid[index]),
                            "lag_days": float(lag),
                            "plateau": float(plateau),
                            "release_t1": float(plateau * release_t1[index]),
                            "release_t2": float(plateau * release_t2[index]),
                        }
                    )
    corner_low, corner_high = floor_t2 / t2, cap_t1 / t1
    corner_nonempty = corner_low <= corner_high
    corner_inside = False
    if corner_nonempty:
        for k0 in (corner_low, corner_high):
            v1 = zero_order_fraction([t1], k0, 1.0, 0.0)[0]
            v2 = zero_order_fraction([t2], k0, 1.0, 0.0)[0]
            corner_inside = corner_inside or (v1 <= cap_t1 + 1e-12 and v2 >= floor_t2 - 1e-12)
    return {
        "n_feasible": feasible_count,
        "k0_feasible_min": float(min(k0_feasible)) if k0_feasible else None,
        "k0_feasible_max": float(max(k0_feasible)) if k0_feasible else None,
        "examples": examples,
        "corner": {
            "lag": 0.0,
            "plateau": 1.0,
            "k0_interval_per_day": [corner_low, corner_high],
            "nonempty": bool(corner_nonempty),
            "satisfies_claim": bool(corner_inside),
        },
    }


def synthetic_recovery(*, trials: int = RECOVERY_TRIALS, seed: int = 2026) -> dict:
    """Closed-form fit recovers (k0, plateau, lag) from noisy zero-order
    curves in >= 90% of trials; declared synthetic, pinned seed.  The
    observation grid is dense early (lag resolution) and spans depletion
    (plateau resolution): a window that ends mid-ramp leaves the plateau
    under-observed - an identifiability requirement, not a fitting detail."""
    rng = np.random.default_rng(seed)
    times = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 10.0, 15.0, 20.0, 30.0, 45.0, 60.0])
    recovered = 0
    for trial in range(trials):
        k0 = float(np.geomspace(0.02, 0.08, trials)[trial])
        plateau, lag = 0.85 + 0.1 * (trial % 3) / 2, 1.5 + (trial % 4) / 2
        values = zero_order_fraction(times, k0, plateau, lag) + 0.005 * rng.normal(size=times.size)
        fit = zero_order_fit(times, np.clip(values, 0.0, 1.0))
        hit = (
            abs(fit["k0"] / k0 - 1.0) <= RECOVERY_K0_REL
            and abs(fit["plateau"] - plateau) <= RECOVERY_PLATEAU_ABS
            and abs(fit["lag"] - lag) <= RECOVERY_LAG_ABS
        )
        recovered += int(hit)
    share = recovered / trials
    return {
        "pass": share >= 0.9,
        "recovered": recovered,
        "trials": trials,
        "tolerances": {"k0_rel": RECOVERY_K0_REL, "plateau_abs": RECOVERY_PLATEAU_ABS, "lag_abs": RECOVERY_LAG_ABS},
        "label": "synthetic demonstration; closed-form three-parameter fit",
    }
