"""Candidate design space for inverse design (v6).

The space is built from identifiable combinations only (docs/v4_protocol.md
identifiability table): the effective rate D/L^2, the released plateau/
loading fraction, and optionally the bath ratio.  D and L are NEVER separate
axes - the forward model cannot tell them apart, and the v6 protocol forbids
proposing what the data cannot identify.  In surrogate mode the registry's
valid input domain further constrains candidates; in physics-only mode the
mechanistic solver is valid everywhere but its assumptions are recorded on
every candidate.
"""

from __future__ import annotations

import numpy as np

IDENTIFIABLE_AXES = ("log10_rate", "plateau_fraction", "log10_bath_ratio")


class CandidateSpace:
    """Grid over identifiable axes; geomspace for rate and bath ratio."""

    def __init__(
        self,
        *,
        rate_bounds: tuple[float, float],
        rate_points: int = 96,
        plateau_bounds: tuple[float, float] = (0.05, 1.0),
        plateau_points: int = 32,
        bath_ratio: float | None = None,
        bath_bounds: tuple[float, float] | None = None,
        bath_points: int = 16,
    ):
        if not 0 < rate_bounds[0] < rate_bounds[1]:
            raise ValueError("rate bounds must be increasing and positive")
        if not 0 < plateau_bounds[0] <= plateau_bounds[1] <= 1.0:
            raise ValueError("plateau bounds must lie in (0, 1]")
        self.rates = np.geomspace(rate_bounds[0], rate_bounds[1], rate_points)
        self.plateaus = np.linspace(plateau_bounds[0], plateau_bounds[1], plateau_points)
        if bath_ratio is not None:
            self.bath_ratios = np.array([float(bath_ratio)])
        elif bath_bounds is not None:
            self.bath_ratios = np.geomspace(bath_bounds[0], bath_bounds[1], bath_points)
        else:
            self.bath_ratios = None

    @property
    def size(self) -> int:
        bath = len(self.bath_ratios) if self.bath_ratios is not None else 1
        return len(self.rates) * len(self.plateaus) * bath

    def candidates(self) -> dict:
        """Flattened axes for batched evaluation."""
        return {"rates": self.rates, "plateaus": self.plateaus, "bath_ratios": self.bath_ratios}

    def describe(self) -> dict:
        return {
            "axes": IDENTIFIABLE_AXES,
            "rate_bounds": [float(self.rates[0]), float(self.rates[-1])],
            "rate_points": int(len(self.rates)),
            "plateau_bounds": [float(self.plateaus[0]), float(self.plateaus[-1])],
            "plateau_points": int(len(self.plateaus)),
            "bath_ratios": None if self.bath_ratios is None else [float(self.bath_ratios[0]), float(self.bath_ratios[-1])],
            "identifiability_rule": "D and L are never separate axes; the space uses D/L^2 only",
        }
