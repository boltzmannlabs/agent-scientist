"""Explicit evidence records: assumptions must never masquerade as measurements."""
from dataclasses import asdict, dataclass
from enum import Enum
import math
from typing import Any
from urllib.parse import urlparse


class EvidenceKind(str, Enum):
    PUBLISHED_MEASURED = "published_measured"
    PUBLISHED_FITTED = "published_fitted"
    INTERNAL_MEASURED = "internal_measured"
    DERIVED = "derived"
    SYNTHETIC = "synthetic"


@dataclass(frozen=True)
class Provenance:
    kind: EvidenceKind
    source_url: str | None = None
    locator: str | None = None
    method: str | None = None
    parent_ids: tuple[str, ...] = ()
    notes: str = ""

    def __post_init__(self):
        object.__setattr__(self, "kind", EvidenceKind(self.kind))
        object.__setattr__(self, "parent_ids", tuple(self.parent_ids))
        if self.kind in (EvidenceKind.PUBLISHED_MEASURED, EvidenceKind.PUBLISHED_FITTED):
            parsed = urlparse(self.source_url or "")
            if parsed.scheme not in ("http", "https") or not parsed.netloc:
                raise ValueError("Published evidence requires an HTTP(S) source URL")
            if not self.locator or not self.locator.strip():
                raise ValueError("Published evidence requires a table, figure, or text locator")
        else:
            if not self.method or not self.method.strip():
                raise ValueError("Derived and synthetic evidence require an explicit method")
            if self.kind == EvidenceKind.DERIVED and not self.parent_ids:
                raise ValueError("Derived evidence requires parent evidence IDs")
        if any(not isinstance(p, str) or not p.strip() for p in self.parent_ids):
            raise ValueError("Parent evidence IDs must be nonempty strings")


@dataclass(frozen=True)
class Measurement:
    id: str
    name: str
    value: float
    unit: str
    provenance: Provenance
    uncertainty: float | None = None

    def __post_init__(self):
        if not self.id.strip() or not self.name.strip() or not self.unit.strip():
            raise ValueError("Each measurement needs an ID, name, and explicit unit ('1' for dimensionless)")
        if not math.isfinite(self.value):
            raise ValueError("Measurement value must be finite")
        if not isinstance(self.provenance, Provenance):
            raise TypeError("Measurement provenance must be a Provenance record")
        if self.uncertainty is not None and (not math.isfinite(self.uncertainty) or self.uncertainty < 0):
            raise ValueError("Uncertainty must be finite and nonnegative, in the measurement unit")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Component:
    name: str
    role: str
    mass_fraction: Measurement | None = None

    def __post_init__(self):
        if not self.name.strip() or not self.role.strip():
            raise ValueError("Component name and role are required")
        if self.mass_fraction is not None:
            if self.mass_fraction.unit != "1" or not 0 <= self.mass_fraction.value <= 1:
                raise ValueError("Mass fraction must be dimensionless ('1') and lie in [0, 1]")


@dataclass(frozen=True)
class Formulation:
    id: str
    name: str
    application: str
    components: tuple[Component, ...]
    properties: tuple[Measurement, ...] = ()
    notes: str = ""

    def __post_init__(self):
        object.__setattr__(self, "components", tuple(self.components))
        object.__setattr__(self, "properties", tuple(self.properties))
        if not self.id.strip() or not self.name.strip() or not self.application.strip():
            raise ValueError("Formulation ID, name, and application are required")
        if not self.components:
            raise ValueError("Formulation must identify at least one component")
        if sum(c.mass_fraction.value for c in self.components if c.mass_fraction is not None) > 1 + 1e-9:
            raise ValueError("Known component mass fractions cannot sum to more than one")
        identifiers = [p.id for p in self.properties]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("Property evidence IDs must be unique within a formulation")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
