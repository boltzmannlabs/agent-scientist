"""Hybrid formulation catalog (v3): one registry, public and internal studies.

The catalog is the single inventory the later phases draw from.  It counts
independent units separately (studies, recipes, conditions, curves, times,
replicates), computes ontology coverage, and validates that every registered
study still matches its contract: files present, hashes declared, counts
consistent, units unambiguous.  Public and internal studies share the schema
but carry ``data_source`` and are never silently pooled.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .ontology import FormulationRecord, formulation_from_dict
from .protocol_registry import AssayProtocol, protocol_from_dict

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()

CORE_FIELDS = (
    "geometry",
    "characteristic_length",
    "mass_fraction",
    "particle_d50",
    "loading",
    "crosslink_density",
    "process",
    "protocol_block",
)


@dataclass
class Catalog:
    registry_path: Path
    studies: dict[str, dict] = field(default_factory=dict)
    formulations: list[FormulationRecord] = field(default_factory=list)
    protocols: dict[str, AssayProtocol] = field(default_factory=dict)

    @property
    def public_studies(self) -> dict[str, dict]:
        return {k: v for k, v in self.studies.items() if v["data_source"] == "literature"}

    @property
    def internal_studies(self) -> dict[str, dict]:
        return {k: v for k, v in self.studies.items() if v["data_source"] == "internal"}


def load_catalog(registry_path: Path | None = None) -> Catalog:
    path = Path(registry_path) if registry_path else REPO_ROOT / "data" / "catalog" / "registry.json"
    with open(path) as handle:
        registry = json.load(handle)
    catalog = Catalog(registry_path=path)
    for entry in registry["studies"]:
        base = REPO_ROOT / entry["path"]
        with open(base / "study.json") as handle:
            meta = json.load(handle)
        observations = pd.read_csv(base / "observations.csv")
        if "curve_id" not in observations.columns:
            observations["curve_id"] = (
                observations["formulation_id"].astype(str) + "|" + observations["condition_id"].astype(str)
            )
        catalog.studies[entry["key"]] = {
            "path": base,
            "registry_entry": entry,
            "meta": meta,
            "data_source": entry.get("data_source", meta.get("data_source", "literature")),
            "observations": observations,
        }
        # v2 studies stay frozen on disk; ontology/protocol enrichment for the
        # catalog lives beside the registry and is merged here.
        enrichment_path = path.parent / "enrichment" / f"{entry['key']}.json"
        if enrichment_path.exists():
            with open(enrichment_path) as handle:
                enrichment = json.load(handle)
            meta.setdefault("protocols", []).extend(enrichment.get("protocols", []))
            meta.setdefault("ontology", {}).setdefault("formulations", []).extend(
                enrichment.get("ontology", {}).get("formulations", [])
            )
        for record in meta.get("ontology", {}).get("formulations", []):
            catalog.formulations.append(formulation_from_dict(record))
        for record in meta.get("protocols", []):
            protocol = protocol_from_dict(record)
            catalog.protocols[protocol.protocol_id] = protocol
    return catalog


def _formulations_for(catalog: Catalog, study_key: str) -> list[FormulationRecord]:
    study_id = catalog.studies[study_key]["meta"].get("study_id", study_key)
    return [f for f in catalog.formulations if f.study_id == study_id]


def coverage_matrix(catalog: Catalog) -> pd.DataFrame:
    """Ontology-field completeness per study (fraction of formulations with
    the field recorded) plus an overall column."""
    rows = []
    for key in sorted(catalog.studies):
        forms = _formulations_for(catalog, key)
        has_protocol_block = bool(catalog.studies[key]["meta"].get("protocols"))
        n = max(len(forms), 1)
        def share(predicate):
            return round(sum(1 for f in forms if predicate(f)) / n, 3) if forms else 0.0

        rows.append(
            {
                "study": key,
                "n_formulations": len(forms),
                "geometry": share(lambda f: True),
                "characteristic_length": share(lambda f: f.characteristic_length is not None),
                "mass_fraction": share(
                    lambda f: any(i.mass_fraction is not None for i in f.ingredients)
                ),
                "particle_d50": share(lambda f: any(i.particle_d50 is not None for i in f.ingredients)),
                "loading": share(lambda f: any(i.loading is not None for i in f.ingredients)),
                "crosslink_density": share(
                    lambda f: any(i.crosslink_density is not None for i in f.ingredients)
                ),
                "process": share(lambda f: len(f.process) > 0),
                "protocol_block": 1.0 if has_protocol_block else 0.0,
            }
        )
    frame = pd.DataFrame(rows).set_index("study")
    if not frame.empty:
        frame.loc["overall"] = frame.mean(numeric_only=True).round(3)
    return frame.reset_index()


def catalog_stats(catalog: Catalog) -> pd.DataFrame:
    """Independent-unit counts per study; repeated measurements never inflate
    the recipe count."""
    rows = []
    for key in sorted(catalog.studies):
        entry = catalog.studies[key]
        obs = entry["observations"]
        rows.append(
            {
                "study": key,
                "study_id": entry["meta"].get("study_id", key),
                "data_source": entry["data_source"],
                "recipes": obs["formulation_id"].nunique(),
                "conditions": obs["condition_id"].nunique(),
                "curves": obs["curve_id"].nunique(),
                "max_times_per_curve": int(obs.groupby("curve_id")["time"].nunique().max()) if len(obs) else 0,
                "observation_rows": int(len(obs)),
                "claims": int(len(pd.read_csv(entry["path"] / "claims.csv"))),
            }
        )
    return pd.DataFrame(rows)


def validate_catalog(catalog: Catalog) -> tuple[list[str], list[str]]:
    """Hard problems (first tuple) vs declared-gap warnings (second)."""
    problems: list[str] = []
    warnings: list[str] = []
    if not catalog.studies:
        problems.append("catalog registry lists no studies")
        return problems, warnings
    for key, entry in sorted(catalog.studies.items()):
        meta, obs = entry["meta"], entry["observations"]
        for required in ("study.json", "observations.csv", "claims.csv"):
            if not (entry["path"] / required).exists():
                problems.append(f"{key}: missing {required}")
        hashes = {**(meta.get("source_files") or {}), **(meta.get("sha256") or {})}
        if not hashes:
            problems.append(f"{key}: study.json declares no source hashes")
        units = set(obs["unit"].dropna().astype(str)) if "unit" in obs.columns else set()
        if len(units) > 1:
            problems.append(f"{key}: mixed units {sorted(units)} in one observations file")
        if "time_unit" in obs.columns:
            mixed_time = set(obs["time_unit"].dropna().astype(str))
            if len(mixed_time) > 1:
                problems.append(f"{key}: mixed time units {sorted(mixed_time)}")
        counts = meta.get("counts") or {}
        if counts.get("release_means") is not None and counts["release_means"] != len(obs):
            problems.append(
                f"{key}: study.json declares {counts['release_means']} means but observations.csv has {len(obs)}"
            )
        for formulation in _formulations_for(catalog, key):
            warnings.extend(formulation.validate())
        if not meta.get("protocols"):
            warnings.append(f"{key}: no assay protocol block recorded")
    return problems, warnings
