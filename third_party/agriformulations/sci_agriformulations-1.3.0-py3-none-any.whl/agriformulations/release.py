"""Controlled-release surrogates and spherical diffusion under perfect-sink conditions.

All public time arrays use hours, all outputs are release fractions in [0, 1].
The analytic sphere assumes uniform initial loading, constant D, fixed radius,
no reaction or swelling, and zero surface concentration. It represents a
homogeneous matrix, not a general core-shell coating. Rate = D/R**2 in h**-1;
release alone cannot identify D and R independently. Higuchi/Peppas clipping
at exhaustion is numerical protection, not a physical late-time theory.
"""
from dataclasses import asdict, dataclass
from collections.abc import Mapping
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from scipy.sparse import diags
from .metrics import regression_metrics

MODEL_PARAMETERS = {
    "first_order": ("k",),
    "burst_first_order": ("k", "burst"),
    "weibull": ("tau", "beta"),
    "higuchi": ("k",),
    "korsmeyer_peppas": ("k", "n"),
    "spherical_diffusion": ("rate",),
}


def _times(time_hours):
    t = np.asarray(time_hours, dtype=float)
    if t.ndim > 1 or not np.all(np.isfinite(t)) or np.any(t < 0):
        raise ValueError("Time must be a finite, nonnegative scalar or 1D array, in hours")
    return t


def _positive(value, name):
    if not np.isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return float(value)


def release_fraction(time_hours, model: str, parameters: Mapping[str, float]):
    """Evaluate bounded release with explicit parameters.

    k units: first order h^-1, Higuchi h^-1/2, Peppas h^-n.
    Weibull tau is hours and beta dimensionless. Burst is instantaneous at t=0.
    Peppas n must be positive; mechanism interpretation requires geometry.
    """
    t = _times(time_hours)
    if model not in MODEL_PARAMETERS:
        raise ValueError(f"Unknown model: {model}; choose from {tuple(MODEL_PARAMETERS)}")
    if set(parameters) != set(MODEL_PARAMETERS[model]):
        raise ValueError(f"{model} requires exactly {MODEL_PARAMETERS[model]}")
    p = {name: _positive(value, name) for name, value in parameters.items()}
    if model == "weibull":
        if p["tau"] == 0 or p["beta"] == 0:
            raise ValueError("Weibull tau and beta must be strictly positive")
        with np.errstate(over="ignore"):
            result = -np.expm1(-(t / p["tau"]) ** p["beta"])
    elif model == "burst_first_order":
        if p["burst"] > 1:
            raise ValueError("Burst fraction must lie in [0, 1]")
        with np.errstate(over="ignore"):
            result = p["burst"] + (1 - p["burst"]) * (-np.expm1(-p["k"] * t))
    elif model == "first_order":
        with np.errstate(over="ignore"):
            result = -np.expm1(-p["k"] * t)
    elif model == "higuchi":
        with np.errstate(over="ignore"):
            result = p["k"] * np.sqrt(t)
    elif model == "korsmeyer_peppas":
        if p["n"] <= 0:
            raise ValueError("Peppas exponent n must be positive")
        with np.errstate(over="ignore"):
            result = p["k"] * t ** p["n"] if p["k"] else np.zeros_like(t)
    else:
        with np.errstate(over="ignore"):
            tau = t * p["rate"]
        flat = tau.reshape(-1)
        values = np.empty_like(flat)
        early = flat < 0.02
        # Short-time transformed solution prevents spurious initial release from
        # truncating the eigenfunction series. Corrections are exponentially small.
        values[early] = 6 * np.sqrt(flat[early] / np.pi) - 3 * flat[early]
        modes = np.arange(1, 101, dtype=float)
        if np.any(~early):
            exponent = -np.pi**2 * np.outer(flat[~early], modes**2)
            values[~early] = 1 - 6 / np.pi**2 * (np.exp(exponent) @ (1 / modes**2))
        result = values.reshape(t.shape)
    bounded = np.clip(result, 0, 1)
    return float(bounded) if t.ndim == 0 else bounded


def rate_from_diffusivity(diffusivity_m2_s: float, radius_m: float) -> float:
    """Convert independently specified D and radius into the rate in h^-1."""
    d = _positive(diffusivity_m2_s, "Diffusivity")
    r = _positive(radius_m, "Radius")
    if r == 0:
        raise ValueError("Radius must be strictly positive")
    rate = d / r**2 * 3600
    if not np.isfinite(rate):
        raise ValueError("D/R squared must be finite")
    return rate


def sphere_finite_volume(time_hours, rate: float, shells: int = 80):
    """Conservative radial finite-volume PDE simulation independent of the series.

    dc/dt=(D/R**2)/r**2 d/dr(r**2 dc/dr), with symmetry at r=0 and
    perfect sink at r=1. Initial concentration is one in every shell.
    Shell inventories are volume weighted.
    """
    t = _times(time_hours)
    rate = _positive(rate, "rate")
    if not isinstance(shells, int) or shells < 4:
        raise ValueError("Use at least four radial shells")
    if t.size == 0:
        return np.empty_like(t)
    if rate == 0 or np.max(t) == 0:
        return float(0) if t.ndim == 0 else np.zeros_like(t)
    faces = np.linspace(0, 1, shells + 1)
    volume = np.diff(faces**3) / 3
    conductance = faces[1:-1] ** 2 * shells
    diagonal = np.zeros(shells)
    diagonal[:-1] -= conductance / volume[:-1]
    diagonal[1:] -= conductance / volume[1:]
    diagonal[-1] -= 2 * shells / volume[-1]
    matrix = rate * diags((conductance / volume[1:], diagonal,
                           conductance / volume[:-1]), offsets=(-1, 0, 1), format="csc")
    unique, inverse = np.unique(t.reshape(-1), return_inverse=True)
    solution = solve_ivp(lambda _, c: matrix @ c, (0, float(unique[-1])),
                         np.ones(shells), t_eval=unique, jac=matrix,
                         method="BDF", rtol=1e-8, atol=1e-10)
    if not solution.success:
        raise RuntimeError(f"Spherical diffusion integration failed: {solution.message}")
    fraction = 1 - (volume @ solution.y) / volume.sum()
    result = np.clip(fraction[inverse].reshape(t.shape), 0, 1)
    return float(result) if t.ndim == 0 else result


@dataclass(frozen=True)
class FitResult:
    model: str
    parameters: dict[str, float]
    metrics: dict[str, float]
    n_points: int
    fit_max_fraction: float | None
    success: bool
    message: str
    evidence_kind: str = "derived"

    def predict(self, time_hours):
        return release_fraction(time_hours, self.model, self.parameters)

    def to_dict(self):
        return asdict(self)


def fit_release(time_hours, fraction, model: str,
                fit_max_fraction: float | None = None) -> FitResult:
    """Bounded nonlinear least squares on fractions, without linearization.

    Peppas defaults to F<=0.6. Metrics describe only fitted observations;
    compare models using a common holdout. Fit is not evidence of mechanism.
    """
    t, y = _times(time_hours), np.asarray(fraction, dtype=float)
    if t.ndim != 1 or y.shape != t.shape:
        raise ValueError("Time and release must be equal one-dimensional arrays")
    if not np.all(np.isfinite(y)) or np.any((y < 0) | (y > 1)):
        raise ValueError("Observed release fractions must be finite and lie in [0, 1]")
    if model not in MODEL_PARAMETERS:
        raise ValueError(f"Unknown model: {model}")
    if fit_max_fraction is None and model == "korsmeyer_peppas":
        fit_max_fraction = 0.6
    if fit_max_fraction is not None:
        if not 0 < fit_max_fraction <= 1:
            raise ValueError("fit_max_fraction must lie in (0, 1]")
        mask = y <= fit_max_fraction
        t, y = t[mask], y[mask]
    names = MODEL_PARAMETERS[model]
    if t.size <= len(names) or np.count_nonzero(t > 0) < len(names) + 1:
        raise ValueError("Insufficient nonzero-time observations for model fitting")
    if np.unique(t[t > 0]).size < len(names) + 1:
        raise ValueError("Fitting needs distinct positive observation times")
    if np.ptp(y) <= 1e-12:
        raise ValueError("Constant release observations cannot identify kinetic parameters")
    scale = float(np.max(t))
    u = t / scale
    if model == "weibull":
        initial, lower, upper = [0.5, 1.0], [1e-8, 0.05], [1e6, 10.0]
    elif model == "burst_first_order":
        initial, lower, upper = [0.5, 0.1], [1e-12, 0.0], [1e4, 1.0]
    elif model == "korsmeyer_peppas":
        initial, lower, upper = [0.5, 0.5], [1e-12, 0.05], [100.0, 3.0]
    elif model == "spherical_diffusion":
        initial, lower, upper = [0.05], [1e-12], [1e4]
    else:
        initial, lower, upper = [0.5], [1e-12], [1e4]

    def prediction(theta):
        return release_fraction(u, model, dict(zip(names, theta)))

    result = least_squares(lambda theta: prediction(theta) - y, initial,
                           bounds=(lower, upper), x_scale="jac", max_nfev=5000,
                           ftol=1e-12, xtol=1e-12, gtol=1e-12)
    parameters = dict(zip(names, map(float, result.x)))
    if model == "weibull":
        parameters["tau"] *= scale
    elif model == "korsmeyer_peppas":
        parameters["k"] /= scale ** parameters["n"]
    elif model == "higuchi":
        parameters["k"] /= np.sqrt(scale)
    else:
        parameters[names[0]] /= scale
    return FitResult(model, parameters,
                     regression_metrics(y, release_fraction(t, model, parameters), len(names)),
                     int(t.size), fit_max_fraction, bool(result.success), str(result.message))


def spherical_fv_release(time_h, rate: float, n_shells: int = 80):
    """Alias with explicit radial-shell naming for the finite-volume simulator."""
    return sphere_finite_volume(time_h, rate, shells=n_shells)
