"""Leave-one-study-out evaluation of the surrogates (v5).

Whole studies are held out. Point forecasts fit the outer-training studies;
curves are reconstructed through the Weibull family and scored in native units
against the matched-time-mean baseline (pooling only within a unit family).
Separate nested-fit predictions center the intervals, keeping their calibration
study out of fitting. Calibration counts independent studies, not curves. A
single calibration study cannot establish finite 90% study-level intervals:
their coverage remains unavailable. Failures are exported, never tuned away.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..benchmark_v2.evaluation import curve_first_metrics, utility_verdict
from .features import SUMMARY_TARGETS, design_matrix, reconstruct_curve
from .models import MondrianConformal, StructuredGP

BASELINE = "matched_time_mean_baseline"
UTILITY_THRESHOLD = 0.10


def _matched_time_baseline(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    """Mean over training curves of the same unit family at the same time."""
    lookup: dict[tuple[str, float], list[float]] = {}
    for _, row in train.iterrows():
        lookup.setdefault((row["unit_family"], float(row["_time"])), []).append(float(row["_value"]))
    out = []
    for _, row in test.iterrows():
        key = (row["unit_family"], float(row["_time"]))
        values = lookup.get(key)
        if values is None:
            near = [t for (fam, t) in lookup if fam == row["unit_family"]]
            key = (row["unit_family"], min(near, key=lambda t: abs(t - float(row["_time"]))) if near else None)
            values = lookup.get(key, [0.0])
        out.append(float(np.mean(values)))
    return np.asarray(out, dtype=float)


def run_leave_one_study_out(summaries: pd.DataFrame, observations_by_curve: dict) -> dict:
    """Execute LOSO folds; returns predictions, metrics, coverage and utility."""
    prediction_rows = []
    coverage_rows = []
    study_keys = sorted(summaries["study_key"].unique())
    if len(study_keys) < 3:
        raise ValueError("leave-one-study-out needs at least three studies")
    for held_out in study_keys:
        train_summaries = summaries[summaries["study_key"] != held_out].copy()
        test_summaries = summaries[summaries["study_key"] == held_out].copy()
        finite_targets = np.isfinite(train_summaries[list(SUMMARY_TARGETS)]).all(axis=1)
        train_summaries = train_summaries[finite_targets]
        if train_summaries.empty or test_summaries.empty:
            continue
        X_train = design_matrix(train_summaries)
        X_test = design_matrix(test_summaries, train_columns=list(X_train.columns))
        gp = StructuredGP(SUMMARY_TARGETS).fit(X_train, train_summaries)
        predicted = gp.predict(X_test)

        # Split conformal: a nested holdout study provides calibration
        # residuals the GP never saw; without this the intervals would be
        # in-sample and too narrow.
        other_studies = sorted(train_summaries["study_key"].unique())
        calibration_study = held_out if not other_studies else other_studies[0]
        calibration_mask = (train_summaries["study_key"] == calibration_study).to_numpy()
        calibration_summaries = train_summaries[calibration_mask]
        fit_summaries = train_summaries[~calibration_mask]
        conformals, target_scales = {}, {}
        interval_predictions = None
        if not fit_summaries.empty and not calibration_summaries.empty:
            X_fit = design_matrix(fit_summaries)
            X_cal = design_matrix(calibration_summaries, train_columns=list(X_fit.columns))
            calibration_gp = StructuredGP(SUMMARY_TARGETS).fit(X_fit, fit_summaries)
            calibration_predictions = calibration_gp.predict(X_cal)
            interval_predictions = calibration_gp.predict(X_test)
            for target in SUMMARY_TARGETS:
                # Scale is fixed from fitting data, known before the held-out
                # outcome. Each target owns its calibrator. Study maxima keep
                # correlated curves from masquerading as independent units.
                target_scales[target] = max(float(np.median(np.abs(fit_summaries[target]))), 1e-3)
                conformals[target] = MondrianConformal().calibrate(
                    pd.Series(
                        calibration_summaries[target].astype(float).to_numpy()
                        - calibration_predictions[target].to_numpy()
                    ),
                    calibration_summaries["data_source"],
                    pd.Series([target_scales[target]] * len(calibration_summaries)),
                    units=calibration_summaries["study_id"],
                )

        for index, row in test_summaries.iterrows():
            pred_row = predicted.loc[index]
            scale = float(row["scale_to_native"])
            obs_rows = observations_by_curve[row["curve_id"]]
            times = obs_rows["time"].astype(float).to_numpy()
            observed = obs_rows["value"].astype(float).to_numpy()
            reconstructed = reconstruct_curve(pred_row, times) * scale
            for t, obs_v, pred_v in zip(times, observed, reconstructed):
                prediction_rows.append(
                    {
                        "study_id": row["study_id"],
                        "track": "surrogate_loso",
                        "model": "gp_structured",
                        "curve_id": row["curve_id"],
                        "condition_id": row["condition_id"],
                        "formulation_id": row["formulation_id"],
                        "time": float(t),
                        "time_unit": row["time_unit"],
                        "observed": float(obs_v),
                        "predicted": float(pred_v) if np.isfinite(pred_v) else np.nan,
                        "unit": row["unit"],
                        "source": f"loso_holdout_{held_out}",
                    }
                )
            for target in SUMMARY_TARGETS:
                point = float(interval_predictions.loc[index, target]) if interval_predictions is not None else float(pred_row[target])
                observed_summary = float(row[target])
                if not (np.isfinite(point) and np.isfinite(observed_summary)):
                    continue
                conformal = conformals.get(target)
                width = conformal.interval_half_width(row["data_source"], target_scales[target]) if conformal else float("inf")
                available = bool(np.isfinite(width))
                coverage_rows.append(
                    {
                        "study_id": row["study_id"],
                        "curve_id": row["curve_id"],
                        "target": target,
                        "point": point,
                        "observed": observed_summary,
                        "half_width": width if available else None,
                        "covered": abs(observed_summary - point) <= width if available else None,
                        "status": "finite interval" if available else "insufficient independent calibration studies",
                        "independent_calibration_units": (conformal.unit_counts.get(str(row["data_source"]), 0) if conformal else 0),
                        "scale_source": "fitting-data median absolute target; no held-out outcome used",
                    }
                )

        # Baseline on identical test rows: matched-time mean over train curves.
        train_rows = []
        for _, row in train_summaries.iterrows():
            obs_rows = observations_by_curve[row["curve_id"]]
            for t, v in zip(obs_rows["time"].astype(float), obs_rows["value"].astype(float)):
                train_rows.append({"unit_family": row["unit_family"], "_time": float(t), "_value": float(v)})
        train_frame = pd.DataFrame(train_rows)
        for _, row in test_summaries.iterrows():
            obs_rows = observations_by_curve[row["curve_id"]]
            test_frame = pd.DataFrame(
                [{"unit_family": row["unit_family"], "_time": float(t), "_value": float(v)}
                 for t, v in zip(obs_rows["time"].astype(float), obs_rows["value"].astype(float))]
            )
            baseline_pred = _matched_time_baseline(train_frame, test_frame)
            for (_, trow), pred_v in zip(test_frame.iterrows(), baseline_pred):
                prediction_rows.append(
                    {
                        "study_id": row["study_id"],
                        "track": "surrogate_loso",
                        "model": BASELINE,
                        "curve_id": row["curve_id"],
                        "condition_id": row["condition_id"],
                        "formulation_id": row["formulation_id"],
                        "time": float(trow["_time"]),
                        "time_unit": row["time_unit"],
                        "observed": float(trow["_value"]),
                        "predicted": float(pred_v),
                        "unit": row["unit"],
                        "source": "matched_time_mean_train_studies",
                    }
                )

    predictions = pd.DataFrame(prediction_rows)
    per_curve, summary_frame = curve_first_metrics(predictions)
    coverage = pd.DataFrame(coverage_rows)
    finite_coverage = coverage["covered"].dropna() if not coverage.empty else pd.Series(dtype=float)
    coverage_rate = float(finite_coverage.mean()) if not finite_coverage.empty else None
    utility = {}
    if summary_frame is not None and not summary_frame.empty:
        base = summary_frame.loc[summary_frame["model"] == BASELINE]
        for model in summary_frame["model"].unique():
            if model == BASELINE:
                continue
            row_m = summary_frame.loc[summary_frame["model"] == model].iloc[0]
            row_b = base.iloc[0]
            utility[model] = utility_verdict(row_m["mae"], row_b["mae"], UTILITY_THRESHOLD)
    return {
        "predictions": predictions,
        "per_curve": per_curve,
        "summary": summary_frame,
        "coverage": coverage,
        "coverage_rate": coverage_rate,
        "coverage_status": "finite interval diagnostics available" if len(finite_coverage) else "insufficient independent calibration studies",
        "coverage_limitations": "Nominal coverage requires exchangeability of independent studies. One nested calibration study cannot establish a finite 90% study-level prediction interval.",
        "utility": utility,
        "n_folds": len(study_keys),
    }
