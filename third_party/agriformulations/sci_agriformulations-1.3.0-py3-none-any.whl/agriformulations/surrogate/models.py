"""Surrogate models: structured GP, Mondrian conformal, hierarchical effects (v5).

Anti-goals frozen in docs/v5_protocol.md: no deep nets on tens-to-hundreds of
observations without written justification; fixed hyperparameters (no test
search); no model selected on outer-test scores.  The GP operates on
standardized covariates with a Matern(1.5)+White kernel; conformal intervals
are Mondrian (per data_source group) with whole-group calibration folds; the
hierarchical layer adds study effects with shrinkage and reports public-only
and hybrid side by side.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, WhiteKernel
from sklearn.preprocessing import StandardScaler

FIXED_KERNEL_SPEC = {"kernel": "Matern(nu=1.5, length_scale=1.0, length_scale_bounds='fixed') + WhiteKernel(0.05, 'fixed')",
                     "normalize_y": True, "alpha": 1e-10, "n_restarts_optimizer": 0}
CONFORMAL_ALPHA = 0.10


class StructuredGP:
    """One Gaussian process per summary target; standardized features.

    sklearn's GP cannot consume NaN: missing covariates are imputed with
    TRAIN-median values and an explicit missing-indicator column is appended
    per imputed feature, so missingness stays visible to the kernel.  (The
    XGBoost comparator consumes NaN natively; both behaviours are declared in
    docs/v5_protocol.md.)
    """

    def __init__(self, targets, spec: dict | None = None):
        self.targets = list(targets)
        self.spec = dict(FIXED_KERNEL_SPEC, **(spec or {}))
        self.models: dict[str, GaussianProcessRegressor] = {}
        self.scaler = StandardScaler()
        self.medians: np.ndarray | None = None
        self.imputed_columns: list[str] = []
        self.fitted = False

    def _prepare(self, X: pd.DataFrame, fit: bool) -> np.ndarray:
        values = X.to_numpy(dtype=float)
        missing = np.isnan(values)
        if fit:
            self.medians = np.nanmedian(values, axis=0)
            if np.isnan(self.medians).any():
                self.medians = np.where(np.isnan(self.medians), 0.0, self.medians)
            self.imputed_columns = list(X.columns)
        values = np.where(missing, self.medians, values)
        if missing.shape[1]:
            return np.concatenate([values, missing.astype(float)], axis=1)
        return values

    def fit(self, X: pd.DataFrame, summaries: pd.DataFrame) -> "StructuredGP":
        Xs = self.scaler.fit_transform(self._prepare(X, fit=True))
        for target in self.targets:
            kernel = Matern(nu=1.5, length_scale=1.0, length_scale_bounds="fixed") + WhiteKernel(
                noise_level=0.05, noise_level_bounds="fixed"
            )
            model = GaussianProcessRegressor(
                kernel=kernel, alpha=self.spec["alpha"], normalize_y=self.spec["normalize_y"],
                n_restarts_optimizer=self.spec["n_restarts_optimizer"], random_state=271828,
            )
            y = summaries[target].astype(float).to_numpy()
            model.fit(Xs, y)
            self.models[target] = model
        self.fitted = True
        return self

    def predict(self, X: pd.DataFrame) -> pd.DataFrame:
        if not self.fitted:
            raise RuntimeError("StructuredGP.predict before fit")
        values = X.to_numpy(dtype=float)
        if self.imputed_columns and list(X.columns) != self.imputed_columns:
            X = X.reindex(columns=self.imputed_columns, fill_value=0.0)
            values = X.to_numpy(dtype=float)
        Xs = self.scaler.transform(self._prepare(X, fit=False))
        return pd.DataFrame({t: self.models[t].predict(Xs) for t in self.targets}, index=X.index)


class MondrianConformal:
    """Split-conformal intervals with per-group (data_source) quantiles.

    The finite-sample order statistic is computed over independent units.
    Passing study IDs as ``units`` aggregates correlated curves by their
    maximum score. Too few units gives an unbounded interval, never a spurious
    finite confidence band. Exchangeability still needs scientific justification.
    """

    def __init__(self, alpha: float = CONFORMAL_ALPHA):
        if not np.isfinite(alpha) or not 0 < alpha < 1:
            raise ValueError("alpha must be between zero and one")
        self.alpha = alpha
        self.quantiles: dict[str, float] = {}
        self.unit_counts: dict[str, int] = {}
        self.unbounded_groups: set[str] = set()

    def calibrate(self, residuals: pd.Series, groups: pd.Series, scales: pd.Series, units: pd.Series | None = None) -> "MondrianConformal":
        residuals = residuals.reset_index(drop=True)
        groups = groups.reset_index(drop=True)
        scales = scales.reset_index(drop=True)
        if len(residuals) != len(groups) or len(scales) != len(groups):
            raise ValueError("Calibration arrays must have the same length")
        if not np.isfinite(residuals).all() or not np.isfinite(scales).all() or (scales <= 0).any() or groups.isna().any():
            raise ValueError("Calibration needs finite residuals, positive scales and defined groups")
        units = pd.Series(np.arange(len(groups))) if units is None else units.reset_index(drop=True)
        if len(units) != len(groups) or units.isna().any():
            raise ValueError("Calibration units must match the residuals")
        self.quantiles.clear()
        self.unit_counts.clear()
        self.unbounded_groups.clear()
        normalized = residuals.abs() / scales
        for group in sorted(groups.unique()):
            mask = (groups == group).to_numpy()
            scores = pd.DataFrame({"score":normalized[mask], "unit":units[mask]})
            values = np.sort(scores.groupby("unit")["score"].max().to_numpy())
            if values.size == 0:
                continue
            rank = int(np.ceil((values.size + 1) * (1 - self.alpha)))
            self.unit_counts[str(group)] = len(values)
            self.quantiles[str(group)] = float(values[min(rank, len(values)) - 1])
            if rank > len(values):
                self.unbounded_groups.add(str(group))
        return self

    def interval_half_width(self, group: str, scale: float) -> float:
        if not np.isfinite(scale) or scale <= 0:
            raise ValueError("Prediction scale must be finite and positive")
        if str(group) not in self.quantiles or str(group) in self.unbounded_groups:
            return float("inf")
        return self.quantiles[str(group)] * float(scale)

    def covers(self, point: float, observed: float, group: str, scale: float) -> bool:
        return abs(observed - point) <= self.interval_half_width(group, scale) + 1e-12


class HierarchicalEffects:
    """Study effects with shrinkage toward the global mean (partial pooling).

    Effects are estimated on training studies only; a held-out study's effect
    is exactly zero at prediction time (unknown), which is the honest choice.
    """

    def __init__(self, shrinkage: float = 5.0):
        self.shrinkage = shrinkage
        self.effects: dict[str, float] = {}

    def fit(self, residuals: pd.Series, studies: pd.Series) -> "HierarchicalEffects":
        residuals = residuals.reset_index(drop=True)
        studies = studies.reset_index(drop=True)
        overall = float(residuals.mean()) if len(residuals) else 0.0
        for study in sorted(studies.unique()):
            mask = (studies == study).to_numpy()
            n = int(mask.sum())
            self.effects[str(study)] = float(n / (n + self.shrinkage) * (float(residuals.to_numpy()[mask].mean()) - overall))
        return self

    def correction(self, study: str) -> float:
        return self.effects.get(str(study), 0.0)
