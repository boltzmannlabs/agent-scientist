"""Model registry: what each surrogate is fit for, and what it may not do (v5).

The registry freezes, per model: identity hashes, the training slice, the
observed input domain (feature ranges actually seen), evaluation verdicts,
and explicit prohibitions.  The v6 design phase hard-refuses candidates
outside the registered domain.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def build_registry(
    *,
    models: dict[str, dict],
    summaries: pd.DataFrame,
    feature_columns: list[str],
    evaluation: dict,
    manifest_path: Path,
) -> dict:
    """Assemble the registry from fitted-model metadata and evaluation output."""
    manifest_hash = _sha256_text(Path(manifest_path).read_text())
    domains = {}
    for column in feature_columns:
        if column in summaries.columns:
            values = pd.to_numeric(summaries[column], errors="coerce")
        else:
            # one-hot columns: domain is the observed set encoded by train
            # vocabularies; presence ranges 0..1 by construction
            domains[column] = {"min": 0.0, "max": 1.0, "kind": "indicator"}
            continue
        domains[column] = {
            "min": float(values.min()) if values.notna().any() else None,
            "max": float(values.max()) if values.notna().any() else None,
            "kind": "numeric_with_missing",
        }
    entries = {}
    for model_id, meta in models.items():
        entries[model_id] = {
            "model": model_id,
            "code_sha256": meta.get("code_sha256"),
            "manifest_sha256": manifest_hash,
            "training_slice": meta.get("training_slice", "public_literature"),
            "targets": meta.get("targets"),
            "valid_input_domain": domains,
            "evaluation": {
                "track": "leave_one_study_out",
                "study_mae": evaluation.get("summary_rows", {}).get(model_id),
                "baseline_mae": evaluation.get("summary_rows", {}).get("matched_time_mean_baseline"),
                "utility": evaluation.get("utility", {}).get(model_id),
                "conformal_coverage": evaluation.get("coverage_rate"),
            },
            "prohibitions": [
                "do not extrapolate outside the registered input domain",
                "do not predict across unit families; reconstruct only through the Weibull summary family",
                "do not interpret study effects for studies unseen in training",
            ],
        }
    return {
        "registry_version": "1.0",
        "frozen_rule": "v6 design must refuse candidates outside valid_input_domain",
        "models": entries,
    }


def write_registry(registry: dict, path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as handle:
        json.dump(registry, handle, indent=1, sort_keys=True, default=float)
    return path


def within_domain(registry: dict, model_id: str, candidate: dict[str, float]) -> tuple[bool, list[str]]:
    """Domain check used by the v6 design phase; NaN covariates are allowed
    (the GP handles missingness natively), out-of-range values are not."""
    entry = registry["models"][model_id]
    violations = []
    for feature, bounds in entry["valid_input_domain"].items():
        if bounds.get("kind") != "numeric_with_missing":
            continue
        value = candidate.get(feature)
        if value is None or value != value:  # None or NaN allowed
            continue
        lo, hi = bounds.get("min"), bounds.get("max")
        if lo is not None and value < lo - 1e-12:
            violations.append(f"{feature}={value:.4g} below registered min {lo:.4g}")
        if hi is not None and value > hi + 1e-12:
            violations.append(f"{feature}={value:.4g} above registered max {hi:.4g}")
    return (not violations), violations
