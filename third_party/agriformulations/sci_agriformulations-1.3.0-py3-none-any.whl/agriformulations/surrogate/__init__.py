"""Uncertainty-aware surrogates with study-level validation (v5)."""

from .features import SUMMARY_TARGETS, curve_summaries, design_matrix, reconstruct_curve
from .models import CONFORMAL_ALPHA, FIXED_KERNEL_SPEC, HierarchicalEffects, MondrianConformal, StructuredGP
from .evaluate import run_leave_one_study_out
from .registry import build_registry, within_domain, write_registry

__all__ = [
    "SUMMARY_TARGETS",
    "curve_summaries",
    "design_matrix",
    "reconstruct_curve",
    "CONFORMAL_ALPHA",
    "FIXED_KERNEL_SPEC",
    "HierarchicalEffects",
    "MondrianConformal",
    "StructuredGP",
    "run_leave_one_study_out",
    "build_registry",
    "within_domain",
    "write_registry",
]
