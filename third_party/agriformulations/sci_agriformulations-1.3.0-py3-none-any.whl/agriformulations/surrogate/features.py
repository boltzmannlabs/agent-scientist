"""Surrogate features and curve-summary targets (v5).

Design decision frozen in docs/v5_protocol.md: the surrogates predict CURVE
SUMMARIES (Weibull time-scale and shape, endpoint fraction, time-to-50%) on
the fraction scale, not every time point - respecting the small-data reality
- and curves are reconstructed through the parametric family.  Covariates
come from the ontology, the protocol registry and physics features; native
NaN everywhere, no imputation, train-only vocabularies.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..release import fit_release
from ..units import family

SUMMARY_TARGETS = ("weibull_tau_time", "weibull_beta", "endpoint_fraction", "t50_time")
_FIXED_COLUMNS = (
    "log10_end_time",
    "ph",
    "temperature_c",
    "finite_bath_factor",
    "log10_calibrated_rate",
)


def curve_summaries(catalog, physics: pd.DataFrame) -> pd.DataFrame:
    """One row per catalog curve with Weibull summaries on the fraction scale."""
    rate_lookup = physics.set_index("curve_id")
    rows = []
    for key, entry in sorted(catalog.studies.items()):
        observations = entry["observations"]
        if "included_primary" in observations.columns:
            observations = observations[observations["included_primary"].astype(bool)]
        if "qc_status" in observations.columns:
            observations = observations[observations["qc_status"] == "accepted"]
        if "in_target" in observations.columns:
            observations = observations[observations["in_target"].astype(bool)]
        for curve_id, curve in observations.groupby("curve_id", sort=True):
            unit = str(curve["unit"].iloc[0]) if "unit" in curve.columns else "%"
            unit_family = family(unit)
            scale = {"percent": 100.0, "mass_per_mass": 1000.0}.get(unit_family, 1.0)
            times = curve["time"].astype(float).to_numpy()
            values = curve["value"].astype(float).to_numpy() / scale
            endpoint = float(values[-1])
            crossing = np.where(values >= 0.5 * endpoint if endpoint > 0 else values >= 0)[0]
            t50 = float(times[crossing[0]]) if crossing.size else float("nan")
            tau = beta = float("nan")
            try:
                fit = fit_release(times, np.clip(values, 0.0, 1.0), "weibull")
                tau = float(fit.parameters["tau"])
                beta = float(fit.parameters["beta"])
            except Exception:
                pass
            phys = rate_lookup.loc[curve_id] if curve_id in rate_lookup.index else None
            rows.append(
                {
                    "study_key": key,
                    "study_id": entry["meta"].get("study_id", key),
                    "data_source": entry["data_source"],
                    "curve_id": curve_id,
                    "formulation_id": str(curve["formulation_id"].iloc[0]),
                    "condition_id": str(curve["condition_id"].iloc[0]),
                    "unit": unit,
                    "unit_family": unit_family,
                    "scale_to_native": scale,
                    "n_points": int(len(curve)),
                    "end_time_native": float(times.max()),
                    "time_unit": str(curve["time_unit"].iloc[0]) if "time_unit" in curve.columns else "h",
                    "weibull_tau_time": tau,
                    "weibull_beta": beta,
                    "endpoint_fraction": endpoint,
                    "t50_time": t50,
                    "ph": float(curve["ph"].iloc[0]) if "ph" in curve.columns and pd.notna(curve["ph"].iloc[0]) else np.nan,
                    "temperature_c": float(curve["temperature_c"].iloc[0])
                    if "temperature_c" in curve.columns and pd.notna(curve["temperature_c"].iloc[0])
                    else np.nan,
                    "geometry_tag": phys["geometry_tag"] if phys is not None else None,
                    "assay_type": phys["assay_type"] if phys is not None else None,
                    "sink_condition": phys["sink_condition"] if phys is not None else None,
                    "finite_bath_factor": phys["finite_bath_factor"] if phys is not None else np.nan,
                    "calibrated_rate": phys["calibrated_rate_per_time"] if phys is not None else np.nan,
                }
            )
    return pd.DataFrame(rows)


def design_matrix(summaries: pd.DataFrame, train_columns: list[str] | None = None) -> pd.DataFrame:
    """Covariate matrix with train-only vocabularies; NaN stays NaN."""
    parts = [
        np.log10(summaries["end_time_native"].clip(lower=1e-12)).to_frame("log10_end_time"),
        summaries[["ph", "temperature_c", "finite_bath_factor"]].astype(float),
        np.log10(summaries["calibrated_rate"].clip(lower=1e-12)).to_frame("log10_calibrated_rate"),
    ]
    categorical = [c for c in ("geometry_tag", "assay_type", "sink_condition", "data_source") if c in summaries.columns]
    if categorical:
        dummies = pd.get_dummies(summaries[categorical], prefix=categorical, dtype=float)
        parts.append(dummies)
    frame = pd.concat(parts, axis=1)
    if train_columns is not None:
        frame = frame.reindex(columns=train_columns, fill_value=0.0)
    return frame


def reconstruct_curve(row: pd.Series, times: np.ndarray) -> np.ndarray:
    """Weibull fraction curve from predicted summaries (robust to bad values)."""
    tau = float(row.get("weibull_tau_time", np.nan))
    beta = float(row.get("weibull_beta", np.nan))
    endpoint = float(row.get("endpoint_fraction", np.nan))
    if not (np.isfinite(tau) and tau > 0 and np.isfinite(beta) and beta > 0 and np.isfinite(endpoint)):
        return np.full(len(times), np.nan)
    fraction = endpoint * (1.0 - np.exp(-np.power(np.maximum(times, 0.0) / tau, beta)))
    return np.clip(fraction, 0.0, 1.0)
