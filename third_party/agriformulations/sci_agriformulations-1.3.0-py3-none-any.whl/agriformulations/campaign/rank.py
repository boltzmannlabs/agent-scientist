"""Priority scoring and the per-direction shortlist (v8).

Priority = 0.40 novelty + 0.25 india + 0.20 feasibility + 0.15
compatibility.  Blocked concepts never rank.  Concepts with no release
kinetics claim (feasibility not applicable) are ranked on the remaining
weights renormalized - stated on the row, never silently imputed.
"""

from __future__ import annotations

import pandas as pd

WEIGHTS = {"novelty": 0.40, "india": 0.25, "feasibility": 0.20, "compatibility": 0.15}
PER_DIRECTION = 3


def priority(row) -> tuple[float | None, bool]:
    """(priority, renormalized) for one scored concept row."""
    if row["flag"] == "blocked":
        return None, False
    if pd.isna(row["feasibility"]):
        available = WEIGHTS["novelty"] + WEIGHTS["india"] + WEIGHTS["compatibility"]
        score = (
            WEIGHTS["novelty"] * row["novelty"]
            + WEIGHTS["india"] * row["india"]
            + WEIGHTS["compatibility"] * row["compatibility"]
        ) / available
        return float(score), True
    score = (
        WEIGHTS["novelty"] * row["novelty"]
        + WEIGHTS["india"] * row["india"]
        + WEIGHTS["feasibility"] * float(row["feasibility"])
        + WEIGHTS["compatibility"] * row["compatibility"]
    )
    return float(score), False


def build_shortlist(frame: pd.DataFrame, *, per_direction: int = PER_DIRECTION) -> pd.DataFrame:
    """Top-k per direction by priority (desc), concept_id as the tiebreak."""
    eligible = frame[frame["flag"] != "blocked"].copy()
    eligible = eligible.sort_values(["priority", "concept_id"], ascending=[False, True], kind="mergesort")
    shortlist = eligible.groupby("direction", sort=True).head(per_direction)
    return shortlist.sort_values(["priority", "concept_id"], ascending=[False, True], kind="mergesort").reset_index(drop=True)
