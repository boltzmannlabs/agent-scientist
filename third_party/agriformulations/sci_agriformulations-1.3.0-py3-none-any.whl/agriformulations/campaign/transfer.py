"""Analogue transfer of release-kinetics regions (v8).

No sulfoxaflor release-kinetics study exists, so carrier concepts borrow
parameter regions from the five curve-bearing catalog studies: geometry,
carrier class and active solubility decide the analogy weight w; the
region is the [q25, q75] band of calibrated D/L^2 per day (calibration
R^2 >= 0.7, at least 4 usable curves) widened geometrically by
f = 1 + 0.5 (1 - w).  Feasibility is then checked with the v6 machinery:
the analogue's own best-fit brief must be reproduced inside the
transferred region by the analytic kernel; shortlisted candidates are
re-verified with the independent 80-shell finite-volume solver.  Every
region carries the hypothesis-generating label the risk register
demands; weak analogies (w < 0.4) cap feasibility at 0.5.
"""

from __future__ import annotations

import numpy as np

from ..design import CandidateSpace, feasible_region
from ..physics.features import physics_features
from ..stereo.regimes import regime_widen, stereo_regime
from .concepts import Concept

WEIGHTS = {"geometry": 0.4, "carrier": 0.4, "solubility": 0.2}
WIDEN_BASE = 0.5
WEAK_ANALOGY_W = 0.4
MIN_CALIBRATION_R2 = 0.70
MIN_CURVES = 4
TIME_TO_DAYS = {"h": 1.0 / 24.0, "day": 1.0}
UNIT_SCALE = {"%": 100.0, "mg/g": 1000.0}
TOLERANCE_FRACTION = 0.05
GRID_RATE_POINTS = 36
GRID_PLATEAU_POINTS = 14


def _scale_for(unit: str) -> float:
    if unit in UNIT_SCALE:
        return UNIT_SCALE[unit]
    return 1.0


def analogue_frame(catalog, registries, *, min_r2: float = MIN_CALIBRATION_R2) -> dict:
    """Per analogue study: calibrated per-day rates and the best-fit brief.

    Rates are converted to per-day so regions from hour-based and
    day-based studies are comparable; the brief (times, values, scale)
    is the study's best calibrated curve, v6 _derive_brief logic.
    """
    physics = physics_features(catalog)
    analogues: dict[str, dict] = {}
    for entry in registries.analogue_map["analogues"]:
        key = entry["study_key"]
        study = catalog.studies[key]
        frame = physics[(physics["study_key"] == key) & (physics["calibrated_r2"] >= min_r2)]
        frame = frame.sort_values("calibrated_r2", ascending=False)
        rates_day, time_units = [], set()
        observations = study["observations"]
        time_unit_by_curve = observations.groupby("curve_id")["time_unit"].first().to_dict() if "time_unit" in observations.columns else {}
        for _, row in frame.iterrows():
            unit = time_unit_by_curve.get(row["curve_id"], "h")
            if unit not in TIME_TO_DAYS:
                continue
            time_units.add(unit)
            rates_day.append(float(row["calibrated_rate_per_time"]) / TIME_TO_DAYS[unit])
        record = {**entry, "n_curves": len(rates_day), "rates_day": np.array(sorted(rates_day))}
        if len(rates_day) >= MIN_CURVES and not frame.empty:
            best = frame.iloc[0]
            curve = observations[observations["curve_id"] == best["curve_id"]]
            scale = _scale_for(str(best["unit"]))
            to_days = TIME_TO_DAYS[time_unit_by_curve.get(best["curve_id"], "h")]
            record["brief"] = {
                "brief_id": f"analogue_{key}_{best['curve_id']}",
                "target_source": (
                    f"best calibrated curve of analogue {key} (R^2={best['calibrated_r2']:.3f}); "
                    "analogue-transferred feasibility target, not a sulfoxaflor design claim"
                ),
                "times": (curve["time"].astype(float) * to_days).tolist(),
                "values": curve["value"].astype(float).tolist(),
                "tolerance": TOLERANCE_FRACTION * scale,
                "scale_to_fraction": scale,
                "unit": str(best["unit"]),
            }
        else:
            record["brief"] = None
        analogues[key] = record
    return analogues


def analogy_weight(concept: Concept, analogue: dict, active_solubility_class: str) -> dict:
    """w = 0.4 geometry + 0.4 carrier + 0.2 solubility (indicator matches)."""
    geometry_match = float(concept.geometry == analogue["geometry_tag"])
    carrier_match = float(bool(concept.carrier_tags) and analogue["carrier_class"] in concept.carrier_tags)
    solubility_match = float(active_solubility_class == analogue["active_solubility_class"])
    w = (
        WEIGHTS["geometry"] * geometry_match
        + WEIGHTS["carrier"] * carrier_match
        + WEIGHTS["solubility"] * solubility_match
    )
    return {
        "w": round(w, 6),
        "geometry_match": geometry_match,
        "carrier_match": carrier_match,
        "solubility_match": solubility_match,
    }


def transfer_concept(concept: Concept, analogues: dict, *, active_solubility_class: str,
                     analogue_regimes: dict | None = None, concept_regime: str | None = None) -> dict:
    """Best-analogue region, feasibility, and the candidate carried to FV verification.

    Deterministic: analogues are tried in (-w, study_key) order and the
    first with enough usable curves wins; non-sphere analogue kernels
    export region-only (the v6 analytic machinery is the sphere kernel).
    v10: when ``analogue_regimes`` and ``concept_regime`` are given, the
    v9 stereo regime distance widens the region geometrically BEFORE the
    feasibility evaluation (stereo enters at design time, not as an
    overlay); without them the behavior is the frozen v8 formula."""
    base = {
        "concept_id": concept.concept_id,
        "role": concept.role,
        "analogue": None,
        "w": None,
        "geometry_match": None,
        "carrier_match": None,
        "solubility_match": None,
        "region_low_per_day": None,
        "region_high_per_day": None,
        "region_widen_factor": None,
        "stereo_regime": None,
        "stereo_widen_factor": None,
        "feasibility": None,
        "feasibility_reason": "",
        "brief_id": None,
        "n_feasible": None,
        "verify_candidate": None,
        "brief": None,
        "label": "hypothesis-generating analogue transfer",
    }
    if concept.role != "carrier":
        base["feasibility_reason"] = "not_applicable_no_release_kinetics_claim"
        return base

    ranked = sorted(
        analogues.values(),
        key=lambda a: (-analogy_weight(concept, a, active_solubility_class)["w"], a["study_key"]),
    )
    chosen = None
    for analogue in ranked:
        if analogue["n_curves"] >= MIN_CURVES and analogue.get("brief") is not None:
            chosen = analogue
            break
    if chosen is None:
        base.update({"feasibility": 0.0, "feasibility_reason": "no_analogue_with_usable_curves"})
        return base

    weight = analogy_weight(concept, chosen, active_solubility_class)
    widen = 1.0 + WIDEN_BASE * (1.0 - weight["w"])
    stereo_widen = 1.0
    if analogue_regimes is not None and concept_regime is not None:
        regime = stereo_regime(concept_regime, analogue_regimes.get(chosen["study_key"], "unspecified"))
        stereo_widen = regime_widen(regime)
        base["stereo_regime"] = regime
        base["stereo_widen_factor"] = stereo_widen
    widen *= stereo_widen
    low, high = np.percentile(chosen["rates_day"], [25, 75])
    low, high = float(low) / widen, float(high) * widen
    base.update(
        {
            "analogue": chosen["study_key"],
            **{k: weight[k] for k in ("w", "geometry_match", "carrier_match", "solubility_match")},
            "region_low_per_day": float(low),
            "region_high_per_day": float(high),
            "region_widen_factor": float(widen),
            "brief_id": chosen["brief"]["brief_id"],
        }
    )
    if chosen["kernel"] != "sphere":
        base.update({"feasibility": 0.5, "feasibility_reason": "region_only_analogue_kernel_not_sphere"})
        base["brief"] = chosen["brief"]
        return base

    space = CandidateSpace(
        rate_bounds=(max(low, 1e-12), high), rate_points=GRID_RATE_POINTS,
        plateau_bounds=(0.05, 1.0), plateau_points=GRID_PLATEAU_POINTS,
    )
    brief = chosen["brief"]
    result = feasible_region(brief, space, device="cpu")
    best = result["best"]
    base["n_feasible"] = int(result["n_feasible"])
    base["brief"] = brief
    base["verify_candidate"] = {
        "rate": best["rate_refined"],
        "plateau_fraction": best["plateau_fraction"],
        "mismatch_native": best["mismatch_native_refined"],
    }
    if result["n_feasible"] == 0:
        base.update({"feasibility": 0.0, "feasibility_reason": "infeasible_region_no_candidates"})
    elif weight["w"] < WEAK_ANALOGY_W:
        base.update({"feasibility": 0.5, "feasibility_reason": "weak_analogy_w_below_0.4"})
    else:
        base.update({"feasibility": 1.0, "feasibility_reason": "region_transferred_and_kernel_feasible"})
    return base
