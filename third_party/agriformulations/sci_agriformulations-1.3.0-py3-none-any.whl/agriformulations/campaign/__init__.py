"""Sulfoxaflor patentability campaign layer (v8).

Deterministic scoring of enumerated formulation concepts against pinned
prior-art, component, compatibility, analogue and India-use registries,
with analogue-transferred feasibility regions and a human review gate.
Every output carries the risk-register A1 framing: coverage flags and
evidence plans, never legal or efficacy conclusions.
"""

from .concepts import Concept, enumerate_concepts
from .dataplan import build_dataplan
from .india import india_relevance
from .prior_art import assess_prior_art, jaccard, knockout, similarity
from .proposal import build_campaign_shortlist_proposal
from .rank import build_shortlist, priority
from .registry import CampaignRegistries, load_registries
from .transfer import analogue_frame, analogy_weight, transfer_concept

__all__ = [
    "CampaignRegistries",
    "Concept",
    "analogue_frame",
    "analogy_weight",
    "assess_prior_art",
    "build_campaign_shortlist_proposal",
    "build_dataplan",
    "build_shortlist",
    "enumerate_concepts",
    "india_relevance",
    "jaccard",
    "knockout",
    "load_registries",
    "priority",
    "similarity",
    "transfer_concept",
]
