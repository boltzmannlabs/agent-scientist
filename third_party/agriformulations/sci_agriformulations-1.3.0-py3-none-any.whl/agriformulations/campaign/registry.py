"""Loading and validation of the pinned v8 evidence registries.

Every registry is a frozen JSON under data/v8/ with controlled tag
vocabularies.  Validation is hard: the loader refuses banned component
keys (cost/price/toxicity/efficacy/field performance/economics - the
not-comparable register, enforced mechanically), missing provenance, tag
drift, and an analogue map that points outside the catalog or sneaks in
the claims-only perera_2026 study.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from agriformulations._paths import resource_root
REPO_ROOT = resource_root()
DATA_V8 = REPO_ROOT / "data" / "v8"

BANNED_COMPONENT_KEYS = frozenset(
    {"cost", "price", "toxicity", "efficacy", "field_performance", "economics", "market"}
)
SOLUBILITY_VOCAB = frozenset({"low", "moderate", "high"})
CARRIER_CLASSES = frozenset(
    {
        "matrix_polymer",
        "matrix_granule",
        "hydrogel_bead",
        "clay_mineral_granule",
        "polymer_nanoparticle",
        "film_former",
        "oil_phase",
        "drift_reduction_agent",
    }
)
GEOMETRY_TAGS = frozenset({"sphere", "granule", "cylinder", "slab"})
PRIOR_ART_SCOPES = frozenset({"disclosed_product", "composition_claim_comprising", "specific_binary"})
COMPATIBILITY_VALUES = frozenset({0.0, 0.5, 1.0})
KNOWN_DIMENSIONS = frozenset({"ai", "format", "carrier", "use", "coform", "enrichment"})
ROLES = frozenset({"active", "partner_chem", "partner_bio", "carrier"})


@dataclass(frozen=True)
class CampaignRegistries:
    prior_art: dict
    components: dict
    format_compatibility: dict
    analogue_map: dict
    use_context: dict
    concept_axes: dict
    methods: dict

    def component(self, name: str) -> dict:
        for record in self.components["components"]:
            if record["name"] == name:
                return record
        raise KeyError(f"component {name!r} not registered in data/v8/components.json")

    @property
    def prior_art_entries(self) -> list[dict]:
        return self.prior_art["entries"]

    @property
    def vocabulary(self) -> dict:
        return self.prior_art["vocabularies"]

    def compatibility(self, fmt: str, solubility_class: str) -> float:
        try:
            return float(self.format_compatibility["compatibility"][fmt][solubility_class])
        except KeyError as exc:
            raise ValueError(f"no compatibility pinned for ({fmt}, {solubility_class})") from exc

    def geometries(self, fmt: str) -> list[str]:
        return list(self.format_compatibility["format_geometries"][fmt])

    def method(self, method_id: str) -> dict:
        for record in self.methods["methods"]:
            if record["method_id"] == method_id:
                return record
        raise KeyError(f"method {method_id!r} not registered in data/v8/methods/methods.json")


def validate_prior_art(payload: dict) -> None:
    vocab = payload.get("vocabularies")
    if not isinstance(vocab, dict) or not {"ai", "format", "carrier", "use", "coform"} <= set(vocab):
        raise ValueError("prior_art.json must declare ai/format/carrier/use/coform vocabularies")
    weights = payload.get("weights")
    if weights is not None:
        unknown = set(weights) - KNOWN_DIMENSIONS
        if unknown:
            raise ValueError(f"prior_art.json weights use unknown dimensions: {sorted(unknown)}")
        if "enrichment" in weights and "enrichment" not in vocab:
            raise ValueError("an enrichment weight requires an enrichment vocabulary")
        if not all(isinstance(v, (int, float)) and v > 0 for v in weights.values()):
            raise ValueError("prior_art.json weights must be positive numbers")
        if abs(sum(weights.values()) - 1.0) > 1e-9:
            raise ValueError(f"prior_art.json weights must sum to 1, got {sum(weights.values())}")
    entries = payload.get("entries", [])
    if len(entries) < 4:
        raise ValueError(f"prior_art.json needs >= 4 verified entries, found {len(entries)}")
    seen: set[str] = set()
    for entry in entries:
        entry_id = entry.get("entry_id")
        if not entry_id or entry_id in seen:
            raise ValueError(f"prior-art entry ids must be non-empty and unique: {entry_id!r}")
        seen.add(entry_id)
        for dim, tags in vocab.items():
            unknown = set(entry.get(dim, [])) - set(tags)
            if unknown:
                raise ValueError(f"{entry_id}: {dim} tags {sorted(unknown)} outside vocabulary")
        if not entry.get("ai"):
            raise ValueError(f"{entry_id}: prior art must declare at least one ai tag")
        if entry.get("scope") not in PRIOR_ART_SCOPES:
            raise ValueError(f"{entry_id}: scope must be one of {sorted(PRIOR_ART_SCOPES)}")
        evidence = entry.get("evidence", {})
        if not evidence.get("source_url") or not evidence.get("retrieved_utc"):
            raise ValueError(f"{entry_id}: evidence requires source_url and retrieved_utc (retrieval pinning)")


def _reject_banned_keys(record: dict, where: str) -> None:
    for key, value in record.items():
        if key in BANNED_COMPONENT_KEYS:
            raise ValueError(f"{where}: banned key {key!r} - not-comparable attributes may not enter the registry")
        if isinstance(value, dict):
            _reject_banned_keys(value, where)


def validate_components(payload: dict, primary_active: str = "sulfoxaflor") -> None:
    components = payload.get("components", [])
    if len(components) < 10:
        raise ValueError(f"components.json needs >= 10 components, found {len(components)}")
    names: set[str] = set()
    actives: set[str] = set()
    for record in components:
        _reject_banned_keys(record, f"component {record.get('name')!r}")
        name = record.get("name")
        if not name or name in names:
            raise ValueError(f"component names must be non-empty and unique: {name!r}")
        names.add(name)
        role = record.get("role")
        if role not in ROLES:
            raise ValueError(f"{name}: role {role!r} outside {sorted(ROLES)}")
        if not record.get("source_url") or not record.get("retrieved_utc"):
            raise ValueError(f"{name}: source_url and retrieved_utc are required provenance")
        if role == "carrier":
            if record.get("carrier_class") not in CARRIER_CLASSES:
                raise ValueError(f"{name}: carrier_class must be one of {sorted(CARRIER_CLASSES)}")
        else:
            if record.get("solubility_class") not in SOLUBILITY_VOCAB:
                raise ValueError(f"{name}: actives/partners need a solubility_class in {sorted(SOLUBILITY_VOCAB)}")
            actives.add(name)
    if primary_active not in actives:
        raise ValueError(f"components.json must register the campaign active {primary_active!r}")


def validate_format_compatibility(payload: dict) -> None:
    formats = set(payload["compatibility"])
    if formats != set(payload["format_geometries"]):
        raise ValueError("compatibility matrix and format_geometries must cover the same formats")
    for fmt, by_class in payload["compatibility"].items():
        if set(by_class) != SOLUBILITY_VOCAB:
            raise ValueError(f"{fmt}: compatibility must cover {sorted(SOLUBILITY_VOCAB)}")
        for solubility, value in by_class.items():
            if value not in COMPATIBILITY_VALUES:
                raise ValueError(f"({fmt}, {solubility}): compatibility must be 0.0/0.5/1.0")
    for fmt, geometries in payload["format_geometries"].items():
        if not geometries or set(geometries) - GEOMETRY_TAGS:
            raise ValueError(f"{fmt}: geometries must be non-empty tags from {sorted(GEOMETRY_TAGS)}")


def validate_analogue_map(payload: dict, catalog_study_keys: set[str]) -> None:
    analogues = payload.get("analogues", [])
    if len(analogues) < 3:
        raise ValueError(f"analogue_map.json needs >= 3 analogues, found {len(analogues)}")
    seen: set[str] = set()
    for entry in analogues:
        key = entry.get("study_key")
        if key in seen:
            raise ValueError(f"analogue {key!r} listed twice")
        seen.add(key)
        if key not in catalog_study_keys:
            raise ValueError(f"analogue {key!r} is not a registered catalog study")
        if entry.get("geometry_tag") not in GEOMETRY_TAGS or entry.get("kernel") not in {"sphere", "cylinder", "slab"}:
            raise ValueError(f"analogue {key!r}: geometry_tag/kernel invalid")
        if entry.get("carrier_class") not in CARRIER_CLASSES:
            raise ValueError(f"analogue {key!r}: carrier_class outside vocabulary")
        if entry.get("active_solubility_class") not in SOLUBILITY_VOCAB:
            raise ValueError(f"analogue {key!r}: active_solubility_class outside vocabulary")
    for excluded in payload.get("excluded", []):
        if excluded in seen:
            raise ValueError(f"analogue {excluded!r} is declared excluded yet listed")


def validate_use_context(payload: dict, format_vocab: set[str]) -> None:
    contexts = payload.get("contexts", [])
    if len(contexts) < 3:
        raise ValueError(f"india/use_context.json needs >= 3 entries, found {len(contexts)}")
    for context in contexts:
        if not context.get("context_id") or not context.get("pests", []) and not context.get("crops"):
            raise ValueError("use contexts need an id and at least one pest or crop tag")
        unknown = set(context.get("robust_formats", [])) - format_vocab
        if unknown:
            raise ValueError(f"{context.get('context_id')}: robust_formats {sorted(unknown)} outside format vocabulary")


def validate_concept_axes(payload: dict, enrichment_vocab: list[str] | None = None) -> None:
    if not isinstance(payload.get("cap"), int) or payload["cap"] < 1:
        raise ValueError("concept_axes.json must declare a positive enumeration cap")
    if not payload.get("positive_control"):
        raise ValueError("concept_axes.json must declare the positive-control concept id")
    directions = payload.get("directions", [])
    if not directions:
        raise ValueError("concept_axes.json declares no directions")
    for direction in directions:
        for field in ("direction", "role", "formats", "carriers", "partners", "use", "pests", "crops"):
            if field not in direction:
                raise ValueError(f"direction {direction.get('direction')!r} missing {field!r}")
        enrichments = direction.get("enrichments", [])
        if enrichment_vocab is not None:
            unknown = set(enrichments) - set(enrichment_vocab)
            if unknown:
                raise ValueError(
                    f"direction {direction.get('direction')!r}: enrichments {sorted(unknown)} "
                    "outside the prior-art enrichment vocabulary"
                )


def validate_methods(payload: dict) -> None:
    ids = [method.get("method_id") for method in payload.get("methods", [])]
    if len(ids) != len(set(ids)) or not ids:
        raise ValueError("methods.json needs unique method ids")
    for required in ("sun_1950_ctc", "colby_1967", "cipac_mt_47_3", "who_hard_water_342"):
        if required not in ids:
            raise ValueError(f"methods.json is missing the pinned method {required}")
    if not isinstance(payload.get("rationale_codes"), dict) or not payload["rationale_codes"]:
        raise ValueError("methods.json must carry the rationale_codes table")


def load_registries(root: Path | None = None, catalog_study_keys: set[str] | None = None,
                    data_subdir: str = "v8") -> CampaignRegistries:
    """Load and validate every campaign registry; raise on any violation.

    ``data_subdir`` selects the pinned evidence set (``v8`` for the
    sulfoxaflor campaign, ``v10`` for benzovindiflupyr); each carries the
    same registry shapes."""
    base = (Path(root) / "data" / data_subdir) if root else (REPO_ROOT / "data" / data_subdir)

    def read(name: str) -> dict:
        with open(base / name) as handle:
            return json.load(handle)

    prior_art = read("prior_art.json")
    components = read("components.json")
    format_compatibility = read("format_compatibility.json")
    analogue_map = read("analogue_map.json")
    use_context = read("india/use_context.json")
    concept_axes = read("concepts/concept_axes.json")
    methods = read("methods/methods.json")

    validate_prior_art(prior_art)
    validate_concept_axes(concept_axes, enrichment_vocab=prior_art["vocabularies"].get("enrichment"))
    validate_components(components, primary_active=concept_axes.get("primary_active", "sulfoxaflor"))
    validate_format_compatibility(format_compatibility)
    if catalog_study_keys is not None:
        validate_analogue_map(analogue_map, catalog_study_keys)
    elif "perera_2026" in {entry.get("study_key") for entry in analogue_map["analogues"]}:
        raise ValueError("analogue_map.json must not include the claims-only perera_2026 study")
    validate_use_context(use_context, set(prior_art["vocabularies"]["format"]))
    validate_methods(methods)
    return CampaignRegistries(
        prior_art=prior_art,
        components=components,
        format_compatibility=format_compatibility,
        analogue_map=analogue_map,
        use_context=use_context,
        concept_axes=concept_axes,
        methods=methods,
    )
