"""India relevance from metadata joins only (v8).

0.5 pest + 0.3 crop + 0.2 robust: max-Jaccard of the concept's tags
against the use-context entries, plus a robustness term for formats a
robustness context lists.  No efficacy, mortality or market data enters
by construction - these are joins of declared metadata.
"""

from __future__ import annotations

from .concepts import Concept
from .prior_art import jaccard

WEIGHTS = {"pest": 0.5, "crop": 0.3, "robust": 0.2}


def india_relevance(concept: Concept, contexts: list[dict]) -> dict:
    pest = max((jaccard(concept.pests, frozenset(c.get("pests", []))) for c in contexts), default=0.0)
    crop = max((jaccard(concept.crops, frozenset(c.get("crops", []))) for c in contexts), default=0.0)
    robust = 1.0 if any(concept.format in c.get("robust_formats", []) for c in contexts) else 0.0
    total = WEIGHTS["pest"] * pest + WEIGHTS["crop"] * crop + WEIGHTS["robust"] * robust
    return {
        "concept_id": concept.concept_id,
        "pest_score": round(pest, 6),
        "crop_score": round(crop, 6),
        "robust_score": round(robust, 6),
        "india": round(total, 6),
    }
