"""Deterministic data-generation plans (v8).

Maps every shortlisted concept to the pinned methods its direction
needs: partner concepts -> Sun 1950 CTC + Colby 1967 mixture analysis;
carrier concepts -> a release assay on the catalog protocol contract;
robust formats -> CIPAC MT 47.3 suspension stability in WHO 342 ppm
standard hard water; plus a side-by-side comparator against the
commercial SC at the pinned India dose band.  Bioassays are named as
experiments the partner must run - the framework registers efficacy as
not comparable.  Patent/legal context appears only as rationale_code
strings from methods.json, never as conclusions.
"""

from __future__ import annotations

import pandas as pd

from .registry import CampaignRegistries

COMPARATOR_TEST = "comparator_vs_commercial_SC"
DIRECTION_TESTS = {
    "partner": (
        ("sun_1950_ctc", "CTC > 120 vs the single actives alone"),
        ("colby_1967", "observed exceeds expected at one or more ratio-grid points"),
    ),
    "carrier": (
        ("release_assay", "release curve inside the transferred region band; protocol-matched to the catalog contract"),
    ),
    "robust": (
        ("cipac_mt_47_3", "suspension-stability pass in WHO 342 ppm standard hard water"),
    ),
}
DIRECTION_RATIONALE = {
    "CR": ["IP_WINDOW_2027", "PRIOR_ART_GAP_CR", "NO_SUL_KINETICS_STUDY"],
    "FS": ["IP_WINDOW_2027", "PRIOR_ART_GAP_FS", "NO_SUL_KINETICS_STUDY"],
    "MIX": ["IP_WINDOW_2027", "BPH_RESISTANCE_LIAO2019"],
    "ROBUST": ["IP_WINDOW_2027", "PRIOR_ART_GAP_OD", "HARD_WATER_WHO342"],
}
ENRICHMENT_TESTS = (
    ("chiral_release_assay", "stereo-resolved release curves (chiral HPLC) - the v9 identifiability "
     "result requires resolved curves for any per-enantiomer claim"),
    ("enantioselective_bioassay", "enantiomer-separated bioassay at the partner lab vs the racemic "
     "reference; the framework registers efficacy as not comparable"),
)


def _rationale_map(registries: CampaignRegistries) -> dict:
    """Per-campaign direction rationale codes when the campaign's methods
    registry declares them; the module defaults (v8) otherwise."""
    declared = registries.methods.get("direction_rationale")
    return {**DIRECTION_RATIONALE, **declared} if declared else DIRECTION_RATIONALE
RELEASE_ASSAY_NOTE = (
    "immersion/dialysis release assay per the catalog protocol contract; target window is the "
    "analogue-transferred region, hypothesis-generating until measured"
)


def _dose_band(registries: CampaignRegistries) -> str:
    for context in registries.use_context["contexts"]:
        band = context.get("dose_band_g_ai_per_ha")
        if band:
            return f"{band[0]}-{band[1]} g a.i./ha (pinned, {context['context_id']})"
    return "dose band not pinned this campaign; set at trial design"


def build_dataplan(concepts: pd.DataFrame, shortlist_ids: list[str], registries: CampaignRegistries) -> pd.DataFrame:
    rows = []
    shortlisted = concepts[concepts["concept_id"].isin(shortlist_ids)]
    rationale = _rationale_map(registries)
    for _, row in shortlisted.iterrows():
        tests = DIRECTION_TESTS[row["role"]]
        if row["role"] == "carrier":
            tests = (("release_assay", RELEASE_ASSAY_NOTE),)
        for method_id, acceptance in tests:
            method = registries.method(method_id) if method_id in {m["method_id"] for m in registries.methods["methods"]} else None
            rows.append(
                {
                    "concept_id": row["concept_id"],
                    "direction": row["direction"],
                    "test_id": method_id,
                    "method_citation": method["citation"] if method else RELEASE_ASSAY_NOTE,
                    "acceptance": acceptance,
                    "rationale_codes": ";".join(rationale.get(row["direction"], [])),
                    "owner": "partner lab (bioassay/stability) or internal lab (release assay)",
                }
            )
        enrichment = row.get("enrichment")
        if isinstance(enrichment, str) and enrichment != "racemic":
            for method_id, acceptance in ENRICHMENT_TESTS:
                rows.append(
                    {
                        "concept_id": row["concept_id"],
                        "direction": row["direction"],
                        "test_id": method_id,
                        "method_citation": "v9 stereo layer requirement; partner lab",
                        "acceptance": acceptance,
                        "rationale_codes": ";".join(rationale.get(row["direction"], [])),
                        "owner": "partner lab (enantioselective work)",
                    }
                )
        rows.append(
            {
                "concept_id": row["concept_id"],
                "direction": row["direction"],
                "test_id": COMPARATOR_TEST,
                "method_citation": "side-by-side vs the commercial racemic reference in the same run",
                "acceptance": f"comparator executed at the pinned campaign dose context: {_dose_band(registries)}",
                "rationale_codes": ";".join(rationale.get(row["direction"], [])),
                "owner": "partner lab (bioassay); framework registers efficacy as not comparable",
            }
        )
    return pd.DataFrame(rows)
