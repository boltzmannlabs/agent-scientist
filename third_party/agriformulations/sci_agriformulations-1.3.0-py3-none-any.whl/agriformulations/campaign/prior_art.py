"""Prior-art similarity, knockout rule and novelty flags (v8).

S is a weighted Jaccard SIMILARITY to a pinned prior-art entry (higher =
closer to known art).  The nearest entry governs the flag: blocked when
the knockout rule fires (ai overlap AND (format OR coform overlap)),
adjacent when S >= 0.45, clear below.  Novelty for ranking is
1 - S_nearest.  Coverage disclaimer: this scores the pinned registry,
not the world.
"""

from __future__ import annotations

from .concepts import Concept
from .registry import KNOWN_DIMENSIONS

WEIGHTS = {"ai": 0.35, "format": 0.25, "carrier": 0.15, "use": 0.10, "coform": 0.15}
ADJACENT_THRESHOLD = 0.45


def jaccard(a: frozenset, b: frozenset) -> float:
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


def similarity(concept: Concept, entry: dict, weights: dict | None = None) -> float:
    """Weighted per-dimension Jaccard similarity to one prior-art entry.

    ``weights`` defaults to the frozen v8 five-dimension formula; a
    registry may declare its own dimension weights (validated to sum to
    1) - v10 adds the enrichment dimension for its chiral active."""
    weights = weights or WEIGHTS
    pairs = {
        "ai": (concept.ai_tags, frozenset(entry.get("ai", []))),
        "format": (concept.format_tags, frozenset(entry.get("format", []))),
        "carrier": (concept.carrier_tags, frozenset(entry.get("carrier", []))),
        "use": (concept.use_tags, frozenset(entry.get("use", []))),
        "coform": (concept.coform_tags, frozenset(entry.get("coform", []))),
        "enrichment": (concept.enrichment_tags, frozenset(entry.get("enrichment", []))),
    }
    return sum(weights[dim] * jaccard(*tags) for dim, tags in pairs.items() if dim in weights)


def knockout(concept: Concept, entry: dict) -> bool:
    """ai overlap AND (format OR coform overlap) fences a concept, with one
    guard: a MIXTURE concept is only fenced when the entry covers ALL of its
    active/coform tags (a disclosed product covers exactly what it discloses)
    or the entry is a comprising-type composition claim, whose claim language
    covers additions.  A marketed single-a.i. product does not fence a
    binary, and an azadirachtin-only nano product does not fence a
    sulfoxaflor+azadirachtin nano."""
    if not concept.ai_tags & frozenset(entry.get("ai", [])):
        return False
    axis = bool(concept.format_tags & frozenset(entry.get("format", []))) or bool(
        concept.coform_tags & frozenset(entry.get("coform", []))
    )
    if not axis:
        return False
    if entry.get("scope") == "composition_claim_comprising":
        return True
    covered = (
        frozenset(entry.get("ai", []))
        | frozenset(entry.get("coform", []))
        | frozenset(entry.get("enrichment", []))
    )
    return (concept.ai_tags | concept.coform_tags | concept.enrichment_tags) <= covered


def assess_prior_art(concept: Concept, entries: list[dict], weights: dict | None = None) -> dict:
    nearest_id, nearest_s = None, -1.0
    blocked_by, blocker_score = None, -1.0
    for entry in entries:
        score = similarity(concept, entry, weights)
        if score > nearest_s:
            nearest_id, nearest_s = entry["entry_id"], score
        if knockout(concept, entry) and score > blocker_score:
            blocked_by, blocker_score = entry["entry_id"], score
    nearest_s = round(nearest_s, 6) if nearest_id else 0.0
    # decide the flag on the ROUNDED score: 0.35+0.10 must land on the
    # 0.45 adjacent boundary, not float-noise below it
    blocked = blocked_by is not None
    if blocked:
        flag, novelty = "blocked", 0.0
    elif nearest_s >= ADJACENT_THRESHOLD:
        flag, novelty = "adjacent", 1.0 - nearest_s
    else:
        flag, novelty = "clear", 1.0 - nearest_s
    return {
        "concept_id": concept.concept_id,
        "S_nearest": nearest_s,
        "nearest_art": nearest_id,
        "flag": flag,
        "blocked_by": blocked_by,
        "novelty": round(novelty, 6),
        "coverage_disclaimer": "pinned registry only; not an exhaustive or legal search",
    }
