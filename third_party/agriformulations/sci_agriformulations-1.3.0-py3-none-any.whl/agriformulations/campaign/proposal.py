"""Campaign shortlist proposal (v8).

The ranked shortlist is submitted as a ``campaign_shortlist`` proposal;
the runner renders a recommendation section ONLY after a human approves
it through scripts.review.  The payload carries the prior-art coverage
disclaimer on every entry - an agent never asserts patentability, only
flagged coverage of the pinned registry.
"""

from __future__ import annotations

from ..agents import submit_proposal
from .rank import WEIGHTS as PRIORITY_WEIGHTS

DISCLAIMER = (
    "Prior-art coverage flags against the pinned registry only - not an exhaustive or legal search; "
    "analogue-transferred regions are hypothesis-generating; no efficacy, toxicity, field, cost, "
    "registrability or patentability claim."
)


def build_campaign_shortlist_proposal(
    shortlist_records: list[dict],
    *,
    manifest_sha256: str,
    n_concepts: int,
    phase: str = "v8",
    root=None,
):
    payload = {
        "manifest_sha256": manifest_sha256,
        "n_concepts_enumerated": n_concepts,
        "priority_weights": PRIORITY_WEIGHTS,
        "shortlist": [
            {
                "concept_id": entry["concept_id"],
                "direction": entry["direction"],
                "format": entry["format"],
                "carrier": entry.get("carrier"),
                "partner": entry.get("partner"),
                "prior_art_flag": entry["flag"],
                "S_nearest": entry["S_nearest"],
                "nearest_art": entry["nearest_art"],
                "india": entry["india"],
                "feasibility": entry.get("feasibility"),
                "compatibility": entry["compatibility"],
                "priority": entry["priority"],
                "solver_verified": entry.get("solver_verified"),
                "provenance": {
                    "scoring": "deterministic v8 formulas (docs/v8_protocol.md); constants frozen in the manifest",
                    "transfer": entry.get("transfer_note", "no kinetics claim"),
                },
            }
            for entry in shortlist_records
        ],
        "coverage_disclaimer": DISCLAIMER,
        "disclaimer": DISCLAIMER,
    }
    return submit_proposal(
        phase,
        "campaign_shortlist",
        payload=payload,
        authored_by="agent:campaign",
        root=root,
    )
