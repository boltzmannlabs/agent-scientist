"""Deterministic concept enumeration over the frozen axes (v8).

Direction x format x carrier x partner, capped at the declared cap.  The
declared positive control (the cyantraniliprole 1:1 binary) is part of
the enumeration and must exist; it proves the knockout machinery on a
concept known to be fenced.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace as dataclasses_replace

from .registry import CampaignRegistries


@dataclass(frozen=True)
class Concept:
    concept_id: str
    direction: str
    role: str
    format: str
    carrier: str | None
    partner: str | None
    geometry: str
    ai_tags: frozenset
    coform_tags: frozenset
    carrier_tags: frozenset
    use_tags: frozenset
    pests: frozenset
    crops: frozenset
    positive_control: bool = False
    ratio: str | None = None
    enrichment_tags: frozenset = frozenset()
    tags: dict = field(default_factory=dict, compare=False)

    @property
    def format_tags(self) -> frozenset:
        return frozenset({self.format})


def _concept_id(direction: str, fmt: str, carrier: str | None, partner: str | None,
                enrichment: str | None = None) -> str:
    base = f"{direction}__{fmt}__{carrier or 'none'}__{partner or 'none'}"
    return f"{base}__{enrichment}" if enrichment else base


def enumerate_concepts(registries: CampaignRegistries) -> list[Concept]:
    axes = registries.concept_axes
    vocab = registries.vocabulary
    active = axes["primary_active"]
    concepts: list[Concept] = []
    for direction in axes["directions"]:
        for fmt in direction["formats"]:
            if fmt not in vocab["format"]:
                raise ValueError(f"axis format {fmt!r} outside the pinned format vocabulary")
            use = tuple(direction.get("use_by_format", {}).get(fmt, direction["use"]))
            for carrier in direction["carriers"]:
                for partner in direction["partners"]:
                    for enrichment in direction.get("enrichments", [None]):
                        concept_id = _concept_id(direction["direction"], fmt, carrier, partner, enrichment)
                        carrier_tags = frozenset()
                        if carrier is not None:
                            carrier_tags = frozenset({registries.component(carrier)["carrier_class"]})
                        concepts.append(
                            Concept(
                                concept_id=concept_id,
                                direction=direction["direction"],
                                role=direction["role"],
                                format=fmt,
                                carrier=carrier,
                                partner=partner,
                                geometry=registries.geometries(fmt)[0],
                                ai_tags=frozenset({active} | ({partner} if partner else set())),
                                coform_tags=frozenset({partner} if partner else set()),
                                carrier_tags=carrier_tags,
                                use_tags=frozenset(use),
                                pests=frozenset(direction["pests"]),
                                crops=frozenset(direction["crops"]),
                                enrichment_tags=frozenset({enrichment} if enrichment else set()),
                                tags={"use": sorted(use)},
                            )
                        )
    if len(concepts) > axes["cap"]:
        raise ValueError(f"enumeration produced {len(concepts)} concepts, over the declared cap {axes['cap']}")
    control_id = axes["positive_control"]
    matches = [c for c in concepts if c.concept_id == control_id]
    if len(matches) != 1:
        raise ValueError(f"declared positive control {control_id!r} must enumerate exactly once")
    control = matches[0]
    replaced = [
        dataclasses_replace(control, positive_control=True, ratio="1:1")
        if c.concept_id == control_id
        else c
        for c in concepts
    ]
    return replaced


def enumeration_summary(concepts: list[Concept]) -> dict:
    by_direction: dict[str, int] = {}
    for concept in concepts:
        by_direction[concept.direction] = by_direction.get(concept.direction, 0) + 1
    return {
        "n_concepts": len(concepts),
        "by_direction": dict(sorted(by_direction.items())),
        "n_positive_controls": sum(c.positive_control for c in concepts),
    }
