"""Batched ideal-sphere predictions; CUDA when available, NumPy otherwise.

These are the same homogeneous-sphere assumptions as release.py, not a new
material mechanism. Float64 and 16 eigenmodes for tau >= .02; the omitted
tail is negligible at this switch. Short-time asymptotics handle tau < .02.
"""
import numpy as np

def batch_sphere_predictions(rates_h_inverse, time_hours, device="auto", batch_size=1024):
    """Return (scenario-by-time fractions, execution metadata).

    device is auto/cpu/cuda. An explicit CUDA request never silently falls back.
    Optional torch is imported lazily; without torch, auto/cpu use NumPy.
    """
    rates=np.asarray(rates_h_inverse,dtype=float)
    times=np.asarray(time_hours,dtype=float)
    if rates.ndim!=1 or times.ndim!=1 or rates.size==0 or times.size==0:
        raise ValueError("Rates and times must be nonempty 1D arrays")
    if not np.isfinite(rates).all() or not np.isfinite(times).all() or np.any(rates<0) or np.any(times<0):
        raise ValueError("Rates and times must be finite and nonnegative")
    if device not in ("auto","cpu","cuda"):raise ValueError("Choose auto, cpu, or cuda")
    if not isinstance(batch_size,int) or batch_size<1:raise ValueError("Positive integer batch size required")
    try:import torch
    except ImportError:
        torch=None
    cuda=bool(torch is not None and torch.cuda.is_available())
    if device=="cuda" and not cuda:raise RuntimeError("CUDA requested but unavailable")
    use_cuda=cuda and device!="cpu"
    out=np.empty((len(rates),len(times)),dtype=float)
    if use_cuda:
        td=torch.tensor(times,dtype=torch.float64,device="cuda")
        modes=torch.arange(1,17,dtype=torch.float64,device="cuda")
        with torch.inference_mode():
            for start in range(0,len(rates),batch_size):
                tau=torch.tensor(rates[start:start+batch_size],dtype=torch.float64,device="cuda")[:,None]*td[None,:]
                early=6*torch.sqrt(tau/np.pi)-3*tau
                series=1-6/np.pi**2*(torch.exp(-np.pi**2*tau[:,:,None]*modes**2)/(modes**2)).sum(dim=-1)
                result=torch.where(tau<.02,early,series).clamp(0,1)
                out[start:start+len(result)]=result.cpu().numpy()
        return out,dict(device="cuda",backend="torch",torch_version=torch.__version__,
            gpu_name=torch.cuda.get_device_name(0),dtype="float64",eigenmodes=16,batch_size=batch_size)
    modes=np.arange(1,17,dtype=float)
    for start in range(0,len(rates),batch_size):
        tau=rates[start:start+batch_size,None]*times[None,:]
        early=6*np.sqrt(tau/np.pi)-3*tau
        series=1-6/np.pi**2*(np.exp(-np.pi**2*tau[:,:,None]*modes**2)/(modes**2)).sum(axis=-1)
        out[start:start+len(tau)]=np.clip(np.where(tau<.02,early,series),0,1)
    return out,dict(device="cpu",backend="numpy",dtype="float64",eigenmodes=16,batch_size=batch_size)
